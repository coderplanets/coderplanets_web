// import React from 'react'
// import { shallow } from 'enzyme'

// import BuyMeChuanChuan from '../index'

describe('TODO <BuyMeChuanChuan />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
