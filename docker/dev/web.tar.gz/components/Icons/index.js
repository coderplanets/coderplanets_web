// import styled from 'styled-components'

// TODO: remove react-icon
import PinOutline from 'react-icons/lib/ti/pin-outline'
import Pin from 'react-icons/lib/md/fiber-pin'

export const PinIcon = Pin // styled(Pin)`font-size: 25px;`
export const PinIcon2 = PinOutline
