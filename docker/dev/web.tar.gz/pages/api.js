import React from 'react'

const Api = () => (
  <div>
    <h2>TODO</h2>
  </div>
)
export default Api

/* import { Voyager } from 'graphql-voyager' */
/* import Voyager from 'graphql-voyager' */
/* import { Provider } from 'mobx-react' */
/* import Playground from 'graphql-playground-react' */
/* import dynamic from 'next/dynamic' */

/* const VoyagerSSR = dynamic(import('graphql-voyager'), { */
/* ssr: false, */
/* }) */

/* export default () => <Voyager /> */

/*
   import dynamic from 'next/dynamic'

   import 'graphql-playground-react/playground.css'

   const PlaygroundWithNoSSR = dynamic(import('graphql-playground-react'), {
   ssr: false,
   })

   const Api = () => (
   <Provider store={{}}>
   <PlaygroundWithNoSSR endpoint="https://api.graph.cool/simple/v1/swapi" />
   </Provider>
   )
   export default Api
 */
