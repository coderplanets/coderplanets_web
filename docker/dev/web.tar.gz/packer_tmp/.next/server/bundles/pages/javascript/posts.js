module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		9: 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		// "0" is the signal for "already loaded"
/******/ 		if(installedChunks[chunkId] !== 0) {
/******/ 			var chunk = require("../../../" + ({"0":"chunks/containers_TypeWriter_31f1ffd146dca69bcb7a302edb951907","1":"chunks/components_StateTree_StateTree_a3db36e29b509b23128f4008fb315fb8"}[chunkId]||chunkId) + "-" + {"0":"5170ec5786c715f53ebf","1":"8fa6c7229e5774287856"}[chunkId] + ".js");
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids;
/******/ 			for(var moduleId in moreModules) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 		}
/******/ 		return require('next/dynamic').SameLoopPromise.resolve();
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// uncatched error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using System.import().catch()
/******/ 		});
/******/ 	};
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 183);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./utils/constants.js
var ERR = {
  CRAPHQL: 'CRAPHQL',
  PARSE_CHEATSHEET_MD: 'PARSE_CHEATSHEET_MD',
  NETWORK: 'NETWORK',
  NOT_FOUND: 'NOT_FOUND',
  TIMEOUT: 'TIMEOUT'
};
var EVENT = {
  LOGIN_PANEL: 'LOGIN_PANEL',
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  PREVIEW: 'PREVIEW',
  PREVIEW_CLOSE: 'PREVIEW_CLOSE',
  PREVIEW_CLOSED: 'PREVIEW_CLOSED',
  PREVIEW_POST: 'PREVIEW_POST',
  NAV_EDIT: 'NAV_EDIT',
  NAV_CREATE_POST: 'NAV_CREATE_POST',
  // refresh
  REFRESH_COMMUNITIES: 'REFRESH_COMMUNITIES',
  REFRESH_POSTS: 'REFRESH_POSTS',
  REFRESH_JOBS: 'REFRESH_JOBS',
  // community
  COMMUNITY_CHANGE: 'COMMUNITY_CHANGE',
  // Draft editor
  DRAFT_INSERT_SNIPPET: 'DRAFT_INSERT_SNIPPET'
};
var TYPE = {
  APP_HEADER_ID: 'APP_HEADER_ID',
  CHEATSHEET_ROOT_PAGE: 'CHEATSHEET_ROOT_PAGE',
  COMMUNITIES_ROOT_PAGE: 'COMMUNITIES_ROOT_PAGE',
  COMMUNITY_PAGE: 'COMMUNITY_PAGE',
  POST_PAGE: 'POST_PAGE',
  ACTIVITIES_ROOT_PAGE: 'ACTIVITIES_ROOT_PAGE',
  POST: 'POST',
  JOB: 'JOB',
  FAVORITE: 'FAVORITE',
  STAR: 'STAR',
  WATCH: 'WATCH',
  REACTION: 'reaction',
  UNDO_REACTION: 'undoReaction',
  // preview
  POST_PREVIEW_VIEW: 'POST_PREVIEW_VIEW',
  PREVIEW_ACCOUNT_VIEW: 'PREVIEW_ACCOUNT_VIEW',
  PREVIEW_ACCOUNT_EDIT: 'PREVIEW_ACCOUNT_EDIT',
  PREVIEW_ROOT_STORE: 'PREVIEW_ROOT_STORE',
  PREVIEW_CREATE_POST: 'PREVIEW_CREATE_POST',
  PREVIEW_COMMUNITY_EDITORS: 'PREVIEW_COMMUNITY_EDITORS',
  // PAGE STATE
  LOADING: 'LOADING',
  NOT_FOUND: 'NOT_FOUND',
  RESULT: 'RESULT',
  RESULT_EMPTY: 'RESULT_EMPTY',
  // filters
  ASC_INSERTED: 'ASC_INSERTED',
  DESC_INSERTED: 'DESC_INSERTED',
  MOST_LIKES: 'MOST_LIKES',
  MOST_DISLIKES: 'MOST_DISLIKES'
};
var ROUTE = {
  // NOTE: the lower-case is MUST
  COMMUNITIES: 'communities',
  CHEATSHEETS: 'cheatsheets',
  ACTIVITIES: 'activities',
  POSTS: 'posts',
  JOBS: 'jobs',
  VIDEOS: 'videos',
  USERS: 'users',
  REPOS: 'repos',
  POST: 'post',
  USER: 'user',
  JOB: 'JOB'
};
var THREAD = {
  __TYPES: ['post', 'job', 'video', 'repo', 'wiki', 'map', 'cheatsheets'],
  POST: 'post',
  JOB: 'job',
  VIDEO: 'video',
  REPO: 'repo',
  WIKI: 'wiki',
  MAP: 'map',
  CHEATSHEETS: 'cheatsheets'
};
var ACTION = {
  __TYPES: ['FAVORITE', 'STAR', 'WATCH'],
  FAVORITE: 'FAVORITE',
  STAR: 'STAR',
  WATCH: 'WATCH'
};
var FILTER = {
  __TYPES: ['ASC_INSERTED', 'DESC_INSERTED', 'MOST_LIKES', 'MOST_DISLIKES'],
  // when
  TODAY: 'TODAY',
  THIS_WEEK: 'THIS_WEEK',
  THIS_MONTH: 'THIS_MONTH',
  THIS_YEAR: 'THIS_YEAR',
  // sort
  MOST_VIEWS: 'MOST_VIEWS',
  MOST_STARS: 'MOST_STARS',
  MOST_FAVORITES: 'MOST_FAVORITES',
  MOST_COMMENTS: 'MOST_COMMENTS',
  ASC_INSERTED: 'ASC_INSERTED',
  DESC_INSERTED: 'DESC_INSERTED',
  MOST_LIKES: 'MOST_LIKES',
  MOST_DISLIKES: 'MOST_DISLIKES',
  // length
  MOST_WORDS: 'MOST_WORDS',
  LEAST_WORDS: 'LEAST_WORDS'
};
// EXTERNAL MODULE: external "debug"
var external__debug_ = __webpack_require__(99);
var external__debug__default = /*#__PURE__*/__webpack_require__.n(external__debug_);

// CONCATENATED MODULE: ./utils/dom_operator.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

// side effects, need refactor

/* eslint-disable no-undef */
var hasDocument = (typeof document === "undefined" ? "undefined" : _typeof(document)) === 'object' && document !== null;
var hasWindow = (typeof window === "undefined" ? "undefined" : _typeof(window)) === 'object' && window !== null && window.self === window;
var isBrowser = function isBrowser() {
  return hasDocument && hasWindow;
};

var getDocument = function getDocument() {
  return isBrowser() ? document : null;
};

var pageGoTop = function pageGoTop() {
  var safeDocument = getDocument();

  if (safeDocument) {
    safeDocument.body.scrollTop = 0; // For Safari

    safeDocument.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Oper
  }
}; // https://developer.mozilla.org/zh-CN/docs/Web/API/Element/scrollIntoView

var scrollIntoEle = function scrollIntoEle(eleID) {
  var safeDocument = getDocument();
  if (!safeDocument) return false;
  var e = safeDocument.getElementById(eleID);

  if (!!e && e.scrollIntoView) {
    e.scrollIntoView({
      behavior: 'smooth'
    });
  }
};
var holdPage = function holdPage() {
  var safeDocument = getDocument();

  if (safeDocument) {
    var el = safeDocument.getElementById('body');
    el.style.overflowY = 'hidden';
  }
};
var unholdPage = function unholdPage() {
  var safeDocument = getDocument();

  if (safeDocument) {
    var el = safeDocument.getElementById('body');
    el.style.overflowY = 'auto';
  }
};
var focusDoraemonBar = function focusDoraemonBar() {
  var safeDocument = getDocument();

  if (safeDocument) {
    setTimeout(function () {
      // side effect
      // has to use setTimeout
      // see: https://stackoverflow.com/questions/1096436/document-getelementbyidid-focus-is-not-working-for-firefox-or-chrome
      try {
        safeDocument.getElementById('doraemonInputbar').focus();
      } catch (e) {
        console.error(e);
      }
    }, 0);
  }
};
var hideDoraemonBarRecover = function hideDoraemonBarRecover() {
  var safeDocument = getDocument();

  if (safeDocument) {
    // side effect
    // onBlur will on focus the whole page, if not use this
    // openDoraemon will not work until you click the page
    document.getElementById('whereCallShowDoraemon').click();
  }
};
/* eslint-enable no-undef */
// CONCATENATED MODULE: ./utils/debug.js



if (isBrowser && "production" !== 'production' && "production" !== 'test') {
  // Heads Up!
  // https://github.com/visionmedia/debug/pull/331
  //
  // debug now clears storage on load, grab the debug settings before require('debug').
  // We try/catch here as Safari throws on localStorage access in private mode or with cookies disabled.
  var DEBUG;

  try {
    if (typeof window !== 'undefined') {
      /* eslint-disable no-undef */
      DEBUG = window.localStorage.debug;
      /* eslint-enable no-undef */
    }
  } catch (e) {
    /* eslint-disable no-console */
    console.error('Mastani could not enable debug.');
    console.error(e);
    /* eslint-enable no-console */
  } // enable what ever settings we got from storage


  external__debug__default.a.enable(DEBUG);
}
/**
 * Create a namespaced debug function.
 * @param {String} namespace Usually a component name.
 * @example
 * import { makeDebugger } from 'src/lib'
 * const debug = makeDebugger('namespace')
 *
 * debug('Some message')
 * @returns {Function}
 */


var debug_makeDebugger = function makeDebugger(namespace) {
  return external__debug__default()("".concat(namespace));
};
/**
 * Default debugger, simple log.
 * @example
 * import { debug } from 'src/lib'
 * debug('Some message')
 */

var debug = debug_makeDebugger('log');
// EXTERNAL MODULE: external "ramda/src/uniq"
var uniq_ = __webpack_require__(100);
var uniq__default = /*#__PURE__*/__webpack_require__.n(uniq_);

// EXTERNAL MODULE: external "ramda/src/slice"
var slice_ = __webpack_require__(29);
var slice__default = /*#__PURE__*/__webpack_require__.n(slice_);

// EXTERNAL MODULE: external "ramda/src/tap"
var tap_ = __webpack_require__(101);
var tap__default = /*#__PURE__*/__webpack_require__.n(tap_);

// EXTERNAL MODULE: external "ramda/src/trim"
var trim_ = __webpack_require__(51);
var trim__default = /*#__PURE__*/__webpack_require__.n(trim_);

// EXTERNAL MODULE: external "ramda/src/not"
var not_ = __webpack_require__(15);
var not__default = /*#__PURE__*/__webpack_require__.n(not_);

// EXTERNAL MODULE: external "ramda/src/compose"
var compose_ = __webpack_require__(12);
var compose__default = /*#__PURE__*/__webpack_require__.n(compose_);

// EXTERNAL MODULE: external "ramda/src/isEmpty"
var isEmpty_ = __webpack_require__(9);
var isEmpty__default = /*#__PURE__*/__webpack_require__.n(isEmpty_);

// EXTERNAL MODULE: external "ramda/src/isNil"
var isNil_ = __webpack_require__(22);
var isNil__default = /*#__PURE__*/__webpack_require__.n(isNil_);

// EXTERNAL MODULE: external "ramda/src/either"
var either_ = __webpack_require__(102);
var either__default = /*#__PURE__*/__webpack_require__.n(either_);

// EXTERNAL MODULE: external "ramda/src/keys"
var keys_ = __webpack_require__(21);
var keys__default = /*#__PURE__*/__webpack_require__.n(keys_);

// EXTERNAL MODULE: external "ramda/src/reduce"
var reduce_ = __webpack_require__(103);
var reduce__default = /*#__PURE__*/__webpack_require__.n(reduce_);

// EXTERNAL MODULE: external "ramda/src/curry"
var curry_ = __webpack_require__(23);
var curry__default = /*#__PURE__*/__webpack_require__.n(curry_);

// EXTERNAL MODULE: external "pubsub-js"
var external__pubsub_js_ = __webpack_require__(31);
var external__pubsub_js__default = /*#__PURE__*/__webpack_require__.n(external__pubsub_js_);

// CONCATENATED MODULE: ./utils/functions.js













function functions__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { functions__typeof = function _typeof(obj) { return typeof obj; }; } else { functions__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return functions__typeof(obj); }



/* eslint-disable */
// TODO: document ?

var Global = typeof window !== 'undefined' ? window : global;
var onClient = typeof window !== 'undefined' ? true : false;
var isObject = function isObject(value) {
  var type = functions__typeof(value);

  return value != null && (type == 'object' || type == 'function');
};
/* eslint-enable */
// see https://github.com/ramda/ramda/issues/1361

var mapKeys = curry__default()(function (fn, obj) {
  return reduce__default()(function (acc, key) {
    acc[fn(key)] = obj[key];
    return acc;
  }, {}, keys__default()(obj));
});
var nilOrEmpty = either__default()(isNil__default.a, isEmpty__default.a);
var notEmpty = compose__default()(not__default.a, isEmpty__default.a);
var isEmptyValue = compose__default()(isEmpty__default.a, trim__default.a);
/* eslint-disable */

var log = function log() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return function (data) {
    console.log.apply(null, args.concat([data]));
    return data;
  };
};
/* eslint-enable */
// reference: https://blog.carbonfive.com/2017/12/20/easy-pipeline-debugging-with-curried-console-log/


var functions_Rlog = function Rlog() {
  var arg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'Rlog: ';
  return tap__default()(log(arg));
};
var functions_cutFrom = function cutFrom(val) {
  var cutnumber = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 20;

  if (isEmptyValue(val)) {
    return '';
  } else if (val.length <= cutnumber) {
    return val;
  }

  return "".concat(slice__default()(0, cutnumber, val), " ...");
}; // https://stackoverflow.com/questions/9461621/how-to-format-a-number-as-2-5k-if-a-thousand-or-more-otherwise-900-in-javascrip

var prettyNum = function prettyNum(num) {
  var digits = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
  var si = [{
    value: 1,
    symbol: ''
  }, {
    value: 1e3,
    symbol: 'k'
  }, {
    value: 1e6,
    symbol: 'M'
  }, {
    value: 1e9,
    symbol: 'G'
  }, {
    value: 1e12,
    symbol: 'T'
  }, {
    value: 1e15,
    symbol: 'P'
  }, {
    value: 1e18,
    symbol: 'E'
  }];
  var rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
  var i;

  for (i = si.length - 1; i > 0; i -= 1) {
    if (num >= si[i].value) {
      break;
    }
  }
  /* eslint-disable */


  if (num < 1000) {
    return (num / si[i].value).toFixed(digits).replace(rx, '$1') + si[i].symbol;
  }

  return (num / si[i].value).toFixed(digits).replace(rx, '$1') + si[i].symbol + '+';
  /* eslint-enable  */
}; // from https://stackoverflow.com/questions/20396456/how-to-do-word-counts-for-a-mixture-of-english-and-chinese-in-javascript
// count both chinese-word and english-words

function countWords(str) {
  var matches = str.match(/[\u00ff-\uffff]|\S+/g);
  return matches ? matches.length : 0;
} // TODO remove

var getRandomInt = function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
};
var functions_dispatchEvent = function dispatchEvent(msg) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  // TODO: check the msg is valid
  // PubSub.publishSync(msg, data)
  external__pubsub_js__default.a.publish(msg, data);
};
var functions_closePreviewer = function closePreviewer() {
  var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  functions_dispatchEvent(EVENT.PREVIEW_CLOSE, {
    type: type
  });
};
/* eslint-disable */

function debounce(func, wait, immediate) {
  var timeout;
  return function () {
    var context = this;
    var args = arguments;

    var later = function later() {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };

    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}
/* eslint-enable */

function extractMentions(text) {
  var mentionsRegex = new RegExp('@([a-zA-Z0-9_.]+)', 'gim');
  var matches = text.match(mentionsRegex);

  if (matches && matches.length) {
    matches = matches.map(function (match) {
      return match.slice(1);
    });
    return uniq__default()(matches);
  }

  return [];
} // https://blogs.sap.com/2017/07/15/use-regular-expression-to-parse-the-image-reference-in-the-markdown-sourcre-code/

var extractAttachments = function extractAttachments(str) {
  var m;
  var regex = /!\[(.*?)\]\((.*?)\)/g;
  var urls = [];
  /* eslint-disable */

  while ((m = regex.exec(str)) !== null) {
    if (m.index === regex.lastIndex) {
      regex.lastIndex += 1;
    }

    urls.push(m[2]);
  }
  /* eslint-enable */


  return urls;
};
// EXTERNAL MODULE: external "ramda/src/pathEq"
var pathEq_ = __webpack_require__(104);
var pathEq__default = /*#__PURE__*/__webpack_require__.n(pathEq_);

// EXTERNAL MODULE: external "ramda/src/has"
var has_ = __webpack_require__(53);
var has__default = /*#__PURE__*/__webpack_require__.n(has_);

// EXTERNAL MODULE: external "ramda/src/and"
var and_ = __webpack_require__(54);
var and__default = /*#__PURE__*/__webpack_require__.n(and_);

// EXTERNAL MODULE: external "graphql-request"
var external__graphql_request_ = __webpack_require__(105);
var external__graphql_request__default = /*#__PURE__*/__webpack_require__.n(external__graphql_request_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// CONCATENATED MODULE: ./utils/graphql_helper.js







var asyncRes = curry__default()(function (key, obj) {
  return and__default()(obj[key], has__default()(key, obj));
});
var graphql_helper_asyncErr = function asyncErr(key) {
  return pathEq__default()(['error'], key);
}; // NOTE the client with jwt info is used for getInitialProps for SSR
// to load user related data

var graphql_helper_makeGQClient = function makeGQClient(token) {
  if (!nilOrEmpty(token)) {
    var client = new external__graphql_request_["GraphQLClient"](config["d" /* GRAPHQL_ENDPOINT */], {
      headers: {
        authorization: "Bearer ".concat(token)
      }
    });
    return client;
  }

  return {
    request: function request(schema, query) {
      return Object(external__graphql_request_["request"])(config["d" /* GRAPHQL_ENDPOINT */], schema, query);
    }
  };
}; // NOTE: this is a simple hack for send parallel requests in rxjs
// in rxjs, if you want to send parallel request you should use complex method
// like forkJoin .. which need to refactor whole sr71 part
// currently the simple later is fine

var later = function later(func) {
  var time = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 200;
  return setTimeout(func, time);
};
// EXTERNAL MODULE: external "ramda/src/merge"
var merge_ = __webpack_require__(13);
var merge__default = /*#__PURE__*/__webpack_require__.n(merge_);

// EXTERNAL MODULE: external "ramda/src/clone"
var clone_ = __webpack_require__(56);
var clone__default = /*#__PURE__*/__webpack_require__.n(clone_);

// EXTERNAL MODULE: external "ramda/src/toLower"
var toLower_ = __webpack_require__(16);
var toLower__default = /*#__PURE__*/__webpack_require__.n(toLower_);

// EXTERNAL MODULE: external "ramda/src/toUpper"
var toUpper_ = __webpack_require__(24);
var toUpper__default = /*#__PURE__*/__webpack_require__.n(toUpper_);

// EXTERNAL MODULE: external "ramda/src/endsWith"
var endsWith_ = __webpack_require__(57);
var endsWith__default = /*#__PURE__*/__webpack_require__.n(endsWith_);

// EXTERNAL MODULE: external "ramda/src/contains"
var contains_ = __webpack_require__(17);
var contains__default = /*#__PURE__*/__webpack_require__.n(contains_);

// EXTERNAL MODULE: external "ramda/src/prop"
var prop_ = __webpack_require__(58);
var prop__default = /*#__PURE__*/__webpack_require__.n(prop_);

// EXTERNAL MODULE: external "ramda/src/reject"
var reject_ = __webpack_require__(106);
var reject__default = /*#__PURE__*/__webpack_require__.n(reject_);

// EXTERNAL MODULE: external "ramda/src/split"
var split_ = __webpack_require__(33);
var split__default = /*#__PURE__*/__webpack_require__.n(split_);

// EXTERNAL MODULE: external "ramda/src/head"
var head_ = __webpack_require__(34);
var head__default = /*#__PURE__*/__webpack_require__.n(head_);

// CONCATENATED MODULE: ./utils/route_helper.js













 // example: /getme/xxx?aa=bb&cc=dd

var parseMainPath = compose__default()(head__default.a, split__default()('?'), head__default.a, reject__default()(isEmpty__default.a), split__default()('/'), prop__default()('asPath')); // example: /xxx/getme?aa=bb&cc=dd


var parsePathList = compose__default()(reject__default()(isEmpty__default.a), split__default()('/'), head__default.a, reject__default()(contains__default()('=')), reject__default()(isEmpty__default.a), split__default()('?'), prop__default()('asPath'));

var INDEX = '';
var route_helper_getMainPath = function getMainPath(routeObj) {
  if (isEmpty__default()(routeObj)) return INDEX;
  if (routeObj.asPath === '/') return INDEX;
  return parseMainPath(routeObj);
};
var route_helper_getSubPath = function getSubPath(routeObj) {
  if (isEmpty__default()(routeObj)) return INDEX;
  if (routeObj.asPath === '/') return INDEX;
  var asPathList = parsePathList(routeObj);
  return asPathList.length > 1 ? asPathList[1] : asPathList[0];
};
var route_helper_extractThreadFromPath = function extractThreadFromPath(props) {
  var uppper = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  var pathList = parsePathList(props);
  var subPath = pathList.length > 1 ? pathList[1] : pathList[0];
  var thread = endsWith__default()('s', subPath) ? slice__default()(0, -1, subPath) : subPath;
  return uppper ? toUpper__default()(thread) : toLower__default()(thread);
};
var defaultQuery = {
  page: 1,
  size: 20
};
var route_helper_mergeRouteQuery = function mergeRouteQuery() {
  var query = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  var routeQuery = clone__default()(query);

  var page = routeQuery.page,
      size = routeQuery.size;
  if (page) routeQuery.page = parseInt(page, 10);
  if (size) routeQuery.size = parseInt(size, 10); // { page: 2, size: 20 }

  return merge__default()(defaultQuery, routeQuery);
};
var route_helper_queryStringToJSON = function queryStringToJSON(path) {
  var splited = split__default()('?', path);

  if (splited.length <= 1) return route_helper_mergeRouteQuery();
  var result = {};
  var paris = splited[1].split('&');
  paris.forEach(function (pair) {
    pair = pair.split('=');
    result[pair[0]] = decodeURIComponent(pair[1] || '');
  });
  var json = JSON.parse(JSON.stringify(result));
  return route_helper_mergeRouteQuery(json);
};
/* eslint-disable */

var route_helper_getParameterByName = function getParameterByName(name) {
  /* if (!url) url = window.location.href;*/
  var url = Global.location.href;
  name = name.replace(/[\[\]]/g, '\\$&');
  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
};
/* eslint-enable */

var route_helper_serializeQuery = function serializeQuery(obj) {
  /* eslint-disable */
  var qstring = Object.keys(obj).reduce(function (a, k) {
    a.push(k + '=' + encodeURIComponent(obj[k]));
    return a;
  }, []).join('&');
  return isEmpty__default()(qstring) ? '' : "?".concat(qstring);
  /* eslint-enable */
};
var TR_MAP = {
  posts: 'post',
  jobs: 'job',
  videos: 'video',
  repos: 'repo',
  post: 'posts',
  job: 'jobs',
  video: 'videos',
  repo: 'repos'
  /* wiki: 'wiki', */

  /* map: 'map', */

};
var subPath2Thread = function subPath2Thread(path) {
  return TR_MAP[path] || path;
};
var thread2Subpath = function thread2Subpath(thread) {
  return TR_MAP[thread] || thread;
};
// EXTERNAL MODULE: external "ramda/src/map"
var map_ = __webpack_require__(18);
var map__default = /*#__PURE__*/__webpack_require__.n(map_);

// EXTERNAL MODULE: external "ramda/src/forEachObjIndexed"
var forEachObjIndexed_ = __webpack_require__(107);
var forEachObjIndexed__default = /*#__PURE__*/__webpack_require__.n(forEachObjIndexed_);

// EXTERNAL MODULE: external "ramda/src/path"
var path_ = __webpack_require__(35);
var path__default = /*#__PURE__*/__webpack_require__.n(path_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// CONCATENATED MODULE: ./utils/mobx_helper.js








function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var storePlug = curry__default()(function (wantedStore, props) {
  return _defineProperty({}, wantedStore, path__default()(['store', wantedStore], props));
});
/*
 * a helper to easly deal with sr71$ return data/error
 * example: sub$ = sr71$.data().subscribe($solve(dataResolver, errResovler))
 */

var matchResolver = function matchResolver(resolveArray, data) {
  for (var i = 0; i < resolveArray.length; i += 1) {
    if (resolveArray[i].match(data)) {
      return resolveArray[i].action(data);
    }
  }

  console.log('unMatched resovle data: ', data);
};

var $solver = curry__default()(function (dataResolver, errResolver, data) {
  return data.error ? matchResolver(errResolver, data) : matchResolver(dataResolver, data);
});
var mobx_helper_markStates = function markStates(sobj, self) {
  if (!isObject(sobj)) {
    throw new Error('markState get invalid object, exepect a object');
  }

  var selfKeys = keys__default()(self);

  forEachObjIndexed__default()(function (val, key) {
    if (contains__default()(key, selfKeys)) {
      self[key] = val;
    }
  }, sobj);
};
/*
   can't put this in store, because this method is async
   only boolean now
 */

var mobx_helper_meteorState = function meteorState(store, state, secs) {
  var _store$markState;

  var statusMsg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';

  if (!has__default()(state, store)) {
    /* eslint-disable */
    console.error("Error: meteorState not found ".concat(state));
    /* eslint-enable */

    return false;
  }

  store.markState((_store$markState = {}, _defineProperty(_store$markState, state, true), _defineProperty(_store$markState, "statusMsg", statusMsg), _store$markState));
  setTimeout(function () {
    var _store$markState2;

    store.markState((_store$markState2 = {}, _defineProperty(_store$markState2, state, false), _defineProperty(_store$markState2, "statusMsg", ''), _store$markState2));
  }, secs * 1000);
};
var mobx_helper_stripMobx = function stripMobx(obj) {
  if (!obj) return obj;
  return map__default()(function (v) {
    if (isObject(v) && has__default()('$mobx')) {
      return v.toJSON();
    }

    return v;
  }, obj);
};
/*
 *  make life easier by using the redux like connent syntax
 *  inject allows function see: https://github.com/mobxjs/mobx-react/blob/master/README.md
 *  inspired by https://gist.github.com/mostr/e8366c9fb64d23b96f5fc05ce23b572c
 */

/*
   mobx 中的 object 是封装过后的 observable 结构, 如果 obsered-object 被用于 containers 中的子组件,
   data 不会及时响应,需要处理成 toJSON 的 raw 结构
   需要在 store 的"端点"去除 mobx 的数据结构
   注意！ 该函数只应用户 store -> UI 的最后一个环节， store 内部之间的数据关联需要这种 obserable data
 */

var mobx_helper_observerHoc = function observerHoc(selector, Component) {
  var injectPlus = typeof selector === 'function' ? Object(external__mobx_react_["inject"])(selector) : external__mobx_react_["inject"].apply(void 0, _toConsumableArray(selector));
  return injectPlus(Object(external__mobx_react_["observer"])(Component));
};
// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./utils/animations.js

var shake =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from,to{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);}10%,30%,50%,70%,90%{-webkit-transform:translate3d(-10px,0,0);transform:translate3d(-10px,0,0);}20%,40%,60%,80%{-webkit-transform:translate3d(10px,0,0);transform:translate3d(10px,0,0);}"]);
var fadeInUp =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{opacity:0;transform:translate3d(0,90%,0);}to{opacity:1;transform:translate3d(0,0,0);}"]);
var pulse =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{transform:scale3d(1,1,1);}50%{transform:scale3d(1.05,1.05,1.05);}to{transform:scale3d(1,1,1);}"]);
var fadeInRight =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{opacity:0.3;transform:translate3d(50%,0,0);}to{opacity:1;transform:translate3d(0,0,0);}"]);
var fadeInDown =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{opacity:0;transform:translate3d(0,-2000px,0);}to{opacity:1;transform:translate3d(0,0,0);}"]);
var zoomIn =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{opacity:0;transform:scale3d(0.3,0.3,0.3);}50%{opacity:1;}"]);
var rotate360 =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{transform:rotate(0deg);}to{transform:rotate(360deg);}"]);
var Animate = {
  fadeInRight: fadeInRight,
  fadeInDown: fadeInDown,
  pulse: pulse,
  fadeInUp: fadeInUp,
  shake: shake,
  zoomIn: zoomIn,
  rotate360: rotate360
};
/* harmony default export */ var animations = (Animate);
// CONCATENATED MODULE: ./utils/common_styles.js
/*
   common styles use in styled-component
 */
var smokey = "\n  opacity: 0.6;\n\n  &:hover {\n    opacity: 1;\n    cursor: pointer;\n  }\n  transition: opacity 0.3s;\n";
var column = "\n  display: flex;\n  flex-direction: column;\n";
var columnCenter = "\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n";
// EXTERNAL MODULE: external "polished"
var external__polished_ = __webpack_require__(14);
var external__polished__default = /*#__PURE__*/__webpack_require__.n(external__polished_);

// CONCATENATED MODULE: ./utils/themes/Cyan.js
/*
 * a theme inspired by rethinkdb: https://rethinkdb.com/
 */

var primaryColor = '#5EABB3';
var bannerBg = '#DAE6E5';
var contentBg = '#E4EEED';
var contentBoxBg = '#f9fcfc';
var fontColor = primaryColor;
var sidebarBg = '#1C4752';
var markdownFont = '#9eb8bd';
var descText = '#a3bbbd';
var primaryMate = 'orange';
var Cyan = {
  logoText: descText,
  cover: primaryColor,
  coverIndex: '#F9FCFC',
  htmlBg: bannerBg,
  loading: {
    basic: bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, bannerBg)
  },
  error: {
    title: primaryColor,
    desc: Object(external__polished_["darken"])(0.1, primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, contentBoxBg)
  },
  font: fontColor,
  link: 'orange',
  main: '#7DC0C5',
  bodyBg: contentBg,
  selectionBg: 'tomato',
  avatarOpacity: 1,
  header: {
    fg: primaryColor,
    bg: bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, bannerBg),
    fixed: contentBoxBg,
    tabActive: '#61868c',
    // articleTitle
    tabOthers: Object(external__polished_["lighten"])(0.1, '#849ca0')
  },
  banner: {
    title: primaryColor,
    bg: bannerBg,
    desc: descText,
    spliter: bannerBg,
    numberDesc: '#a7bbbf',
    number: '#83a7ad',
    active: primaryMate,
    numberDivider: '#ccdcde',
    numberHoverBg: '#e4ecec'
  },
  thread: {
    bg: contentBoxBg,
    filterResultHint: descText,
    articleTitle: '#83a7ad',
    articleHover: '#f3f6f9',
    articleStrip: contentBoxBg,
    articleDigest: '#a2c0c5',
    articleTag: '#71979a',
    articleLink: descText,
    commentsUserBorder: contentBoxBg,
    extraInfo: '#84C3C8',
    articleSpliter: '#dee8ea'
  },
  content: {
    bg: contentBoxBg,
    cardBg: contentBoxBg,
    cardBorder: '#e6e6e6',
    cardBorderHover: primaryColor
  },
  footer: {
    text: '#b3ccc9',
    hover: '#5c868b',
    label: '#b7c6d0'
  },
  sidebar: {
    bg: sidebarBg,
    menuHover: Object(external__polished_["darken"])(0.1, sidebarBg),
    pinActive: primaryColor,
    menuLink: '#D9E6E5',
    borderColor: '#14363E'
  },
  preview: {
    title: '#83a2a5',
    desc: '#83a2a5',
    font: primaryColor,
    bg: contentBg,
    shadow: '-5px 0px 14px 0px rgba(189,189,189,0.37)',
    closerShadow: '-6px 4px 5px 2px rgba(156, 154, 154, 0.2)',
    markdownHelperBg: '#F9FCFC',
    accountBg: '#F9FCFC',
    articleBg: '#F9FCFC',
    helper: '#d9e5e6',
    helperHover: '#83a2a5',
    topLine: 'orange',
    icon: 'tomato',
    divider: '#ebf1f0'
  },
  article: {
    link: '#b5ccce',
    linkHover: 'orange',
    reactionTitle: '#7f979a',
    reactionHoverBg: '#F9FCFC'
  },
  comment: {
    icon: '#62868a',
    didIcon: 'orange',
    title: '#62868a',
    username: '#62868a',
    number: '#efbc60',
    floor: '#efbc60',
    reply: '#93b3b5',
    replyBg: '#e8f1f2',
    placeholder: '#C0D9DA',
    filter: '#62868a',
    filterActive: primaryColor,
    action: '#62868a',
    // mention text displayed in article
    mentionText: '#91a4b5',
    mentionTextBg: '#fcffdb',
    // mention popover background
    mentionBg: '#F9FCFC',
    mentionBorder: primaryColor,
    mentionActiveBg: Object(external__polished_["darken"])(0.1, '#F9FCFC'),
    mentionShadow: '0px 2px 10px 1px rgba(235, 235, 235, 1)'
  },
  editor: {
    title: '#7ea9ad',
    content: '#a6bebf',
    placeholder: '#B3CFD0',
    headerBg: '#F9FCFC',
    contentBg: '#F9FCFC',
    border: '#F9FCFC',
    borderActive: descText,
    borderNormal: '#e2eaea',
    footer: '#a6bebf',
    footerHover: Object(external__polished_["darken"])(0.05, '#a6bebf')
  },
  pagination: {
    activeNum: 'white',
    itemBg: '#cbe7ea',
    itemBorderColor: '#cbe7ea',
    disableText: '#BCD9DC',
    text: '#6d7f7b',
    inactiveNum: 'white'
  },
  heatmap: {
    activityLow: '#D6ECB2',
    activityHight: '#4F966E',
    borderHover: '#51abb2',
    empty: '#E4EEED',
    monthLabel: '#c6dbde',
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  bannerHeatmap: {
    activityLow: '#D6ECB2',
    activityHight: '#4F966E',
    borderHover: '#51abb2',
    empty: '#E4EEED',
    monthLabel: descText,
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  markdown: {
    title: primaryColor,
    fg: markdownFont,
    titleBottom: Object(external__polished_["lighten"])(0.3, primaryColor),
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, markdownFont),
    strongBg: '#34535C',
    link: 'orange',
    tableBg: Object(external__polished_["darken"])(0.01, contentBoxBg),
    tableBg2n: Object(external__polished_["darken"])(0.05, contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["darken"])(0.1, contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["darken"])(0.1, contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["darken"])(0.05, contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.3, primaryColor),
    searchInput: Object(external__polished_["lighten"])(0.3, primaryColor),
    searchIcon: Object(external__polished_["lighten"])(0.3, primaryColor),
    barBg: Object(external__polished_["darken"])(0.03, primaryColor),
    border: Object(external__polished_["darken"])(0.05, primaryColor),
    title: Object(external__polished_["lighten"])(0.3, bannerBg),
    desc: Object(external__polished_["lighten"])(0.2, primaryColor),
    activeBg: Object(external__polished_["darken"])(0.1, primaryColor)
  },
  button: {
    primary: primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, primaryColor),
    clicked: primaryColor
  },
  navigator: {
    activeBottom: primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, bannerBg),
    hoverBg: '#eee'
  },
  popover: {
    bg: '#f9fcfc',
    borderColor: '#51abb2',
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.8,
    text: '#71979a'
  },
  tagger: {
    text: '#d2a05f',
    bg: '#fff2b3',
    border: '#fff2b3',
    closeBtn: '#d2a05f'
  },
  tabs: {
    headerActive: primaryColor,
    header: Object(external__polished_["lighten"])(0.2, primaryColor),
    contentBg: '#FFFFFF',
    headerBg: '#F7F9F9',
    headerActiveTop: primaryColor,
    border: '#E8E8E8',
    bottomLine: '#d9e9ea'
  },
  modal: {
    bg: contentBoxBg,
    border: primaryColor,
    innerSelectBg: '#e4eeed45'
  },
  form: {
    inputBg: '#FFFFFF',
    text: '#88a4ad',
    label: '#88a4ad',
    border: '#B8C6C0'
  },
  a: {
    hover: primaryColor,
    active: Object(external__polished_["darken"])(0.1, primaryColor)
  }
};
/* harmony default export */ var themes_Cyan = (Cyan);
// CONCATENATED MODULE: ./utils/themes/Purple.js
/*
 * a theme inspired by Muzli && unbuntu
 */

var Purple_primaryColor = '#615c79';
var Purple_bannerBg = '#2f2c3c';
var Purple_contentBg = '#242029';
var Purple_contentBoxBg = '#27212d';
var Purple_fontColor = Purple_primaryColor;
var Purple_sidebarBg = '#222029';
var Purple_markdownFont = '#7F8189';
var Purple_descText = '#4a455a';
var Purple_primaryMate = '#a7674d';
var Purple = {
  logoText: Purple_primaryColor,
  cover: Purple_primaryColor,
  coverIndex: '#9e96c3',
  htmlBg: Purple_contentBoxBg,
  loading: {
    basic: Purple_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, Purple_bannerBg) // basic: '#113B4A',
    // animate: '#02495a',

  },
  error: {
    title: Purple_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, Purple_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, Purple_contentBoxBg)
  },
  font: Purple_fontColor,
  link: '#269A95',
  main: '#7DC0C5',
  bodyBg: Purple_contentBg,
  selectionBg: '#839496',
  avatarOpacity: 0.8,
  header: {
    fg: Purple_primaryColor,
    bg: Purple_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, Purple_bannerBg),
    fixed: Purple_bannerBg,
    tabActive: Purple_primaryColor,
    // articleTitle
    tabOthers: Object(external__polished_["darken"])(0.1, Purple_primaryColor)
  },
  banner: {
    title: Purple_primaryColor,
    bg: Purple_bannerBg,
    desc: Purple_descText,
    spliter: Object(external__polished_["darken"])(0.04, Purple_bannerBg),
    number: Purple_primaryColor,
    active: Purple_primaryMate,
    numberDesc: Purple_descText,
    numberDivider: Object(external__polished_["darken"])(0.08, Purple_descText),
    numberHoverBg: Object(external__polished_["lighten"])(0.03, Purple_bannerBg)
  },
  thread: {
    bg: Purple_contentBoxBg,
    filterResultHint: Purple_descText,
    articleTitle: '#737990',
    articleHover: Object(external__polished_["lighten"])(0.03, Purple_contentBoxBg),
    articleStrip: Purple_contentBoxBg,
    articleDigest: '#505667',
    articleTag: '#526482',
    articleLink: Purple_descText,
    commentsUserBorder: Purple_contentBoxBg,
    extraInfo: Purple_primaryMate,
    articleSpliter: '#3f3a50'
  },
  content: {
    bg: Purple_contentBoxBg,
    cardBg: Purple_bannerBg,
    cardBorder: Object(external__polished_["lighten"])(0.08, Purple_contentBoxBg),
    cardBorderHover: Object(external__polished_["lighten"])(0.1, Purple_contentBoxBg)
  },
  footer: {
    text: Purple_descText,
    hover: Object(external__polished_["lighten"])(0.1, Purple_descText),
    label: Purple_descText
  },
  sidebar: {
    bg: Purple_sidebarBg,
    menuHover: Object(external__polished_["lighten"])(0.1, Purple_sidebarBg),
    pinActive: '#849804',
    menuLink: '#93A1A1',
    borderColor: Object(external__polished_["lighten"])(0.05, Purple_sidebarBg)
  },
  preview: {
    title: Purple_primaryColor,
    desc: Object(external__polished_["lighten"])(0.05, Purple_descText),
    font: Purple_fontColor,
    bg: Purple_contentBoxBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: Object(external__polished_["lighten"])(0.04, Purple_contentBg),
    accountBg: Object(external__polished_["lighten"])(0.04, Purple_contentBg),
    articleBg: Object(external__polished_["lighten"])(0.04, Purple_contentBg),
    helper: Object(external__polished_["lighten"])(0.2, Purple_contentBg),
    helperHover: Object(external__polished_["lighten"])(0.3, Purple_contentBg),
    topLine: '#c387e8',
    icon: '#845145',
    divider: Object(external__polished_["darken"])(0.07, Purple_descText)
  },
  article: {
    link: Purple_primaryMate,
    linkHover: Object(external__polished_["lighten"])(0.05, Purple_primaryMate),
    reactionTitle: Purple_primaryColor,
    reactionHoverBg: Object(external__polished_["lighten"])(0.04, Purple_contentBg)
  },
  comment: {
    icon: Purple_primaryColor,
    didIcon: Purple_primaryMate,
    title: Purple_primaryColor,
    username: Purple_primaryColor,
    number: Purple_primaryMate,
    floor: Purple_primaryMate,
    reply: Purple_primaryColor,
    replyBg: '#3d3644',
    placeholder: Purple_descText,
    filter: Purple_descText,
    filterActive: Purple_primaryColor,
    action: Purple_primaryColor,
    // mention text displayed in article
    mentionText: '#70768B',
    mentionTextBg: '#423a4a',
    // mention popover background
    mentionBg: Purple_contentBoxBg,
    mentionBorder: Purple_primaryColor,
    mentionActiveBg: Object(external__polished_["lighten"])(0.1, Purple_contentBoxBg),
    mentionShadow: '0px 2px 10px 1px rgba(47, 46, 46, 0.8)'
  },
  editor: {
    title: Purple_primaryColor,
    content: '#6E717A',
    placeholder: Object(external__polished_["darken"])(0.03, Purple_descText),
    headerBg: Purple_bannerBg,
    contentBg: Purple_bannerBg,
    border: Purple_bannerBg,
    borderActive: Purple_primaryColor,
    borderNormal: Object(external__polished_["lighten"])(0.05, Purple_bannerBg),
    footer: Purple_descText,
    footerHover: Object(external__polished_["lighten"])(0.05, Purple_descText)
  },
  pagination: {
    activeNum: 'white',
    itemBg: Object(external__polished_["darken"])(0.1, Purple_descText),
    itemBorderColor: Object(external__polished_["darken"])(0.06, Purple_descText),
    disableText: Purple_descText,
    text: Purple_primaryColor,
    inactiveNum: Purple_primaryColor
  },
  heatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#342e3a',
    borderHover: Purple_primaryColor,
    monthLabel: Purple_descText,
    scale_1: Object(external__polished_["lighten"])(0.04, '#342e3a'),
    scale_2: Object(external__polished_["lighten"])(0.08, '#342e3a'),
    scale_3: Object(external__polished_["lighten"])(0.12, '#342e3a'),
    scale_4: Object(external__polished_["lighten"])(0.18, '#342e3a'),
    scale_5: Object(external__polished_["lighten"])(0.3, '#342e3a')
  },
  bannerHeatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#342e3a',
    borderHover: Purple_primaryColor,
    monthLabel: Purple_descText,
    scale_1: Object(external__polished_["lighten"])(0.04, '#342e3a'),
    scale_2: Object(external__polished_["lighten"])(0.08, '#342e3a'),
    scale_3: Object(external__polished_["lighten"])(0.12, '#342e3a'),
    scale_4: Object(external__polished_["lighten"])(0.18, '#342e3a'),
    scale_5: Object(external__polished_["lighten"])(0.3, '#342e3a')
  },
  markdown: {
    title: Object(external__polished_["darken"])(0.05, '#DBE0E1'),
    fg: Purple_markdownFont,
    titleBottom: '1px solid #154452',
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, Purple_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, Purple_markdownFont),
    strongBg: '#34535C',
    link: '#2382C4',
    tableBg: Object(external__polished_["lighten"])(0.01, Purple_contentBoxBg),
    tableBg2n: Object(external__polished_["lighten"])(0.05, Purple_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["lighten"])(0.07, Purple_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["lighten"])(0.1, Purple_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["lighten"])(0.03, Purple_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.2, Purple_contentBg),
    searchInput: Object(external__polished_["lighten"])(0.1, Purple_contentBg),
    searchIcon: Object(external__polished_["lighten"])(0.1, Purple_contentBg),
    barBg: Object(external__polished_["darken"])(0.01, Purple_contentBg),
    border: Object(external__polished_["lighten"])(0.05, Purple_contentBg),
    title: Object(external__polished_["lighten"])(0.4, Purple_contentBg),
    desc: Object(external__polished_["lighten"])(0.2, Purple_contentBg),
    activeBg: Object(external__polished_["lighten"])(0.05, Purple_contentBg)
  },
  button: {
    primary: Purple_primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, Purple_primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, Purple_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, Purple_primaryColor),
    clicked: Purple_primaryColor
  },
  navigator: {
    activeBottom: Purple_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, Purple_bannerBg),
    hoverBg: Object(external__polished_["lighten"])(0.05, Purple_bannerBg)
  },
  popover: {
    bg: Purple_bannerBg,
    borderColor: Purple_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.5,
    text: '#72788D'
  },
  tagger: {
    text: '#959cb9',
    bg: '#4A4559',
    border: '#4A4559',
    closeBtn: '#959cb9'
  },
  tabs: {
    headerActive: Purple_primaryColor,
    header: Object(external__polished_["darken"])(0.05, Purple_primaryColor),
    contentBg: Object(external__polished_["lighten"])(0.05, Purple_contentBoxBg),
    headerBg: Object(external__polished_["lighten"])(0.03, Purple_contentBoxBg),
    headerActiveTop: Purple_primaryColor,
    border: Purple_descText,
    bottomLine: Purple_descText
  },
  modal: {
    bg: Purple_bannerBg,
    border: Purple_primaryColor,
    innerSelectBg: '#333040'
  },
  form: {
    inputBg: Object(external__polished_["lighten"])(0.03, Purple_contentBoxBg),
    text: Purple_descText,
    label: Purple_primaryColor,
    border: Purple_descText
  },
  a: {
    hover: Purple_primaryColor,
    active: Object(external__polished_["darken"])(0.1, Purple_primaryColor)
  }
};
/* harmony default export */ var themes_Purple = (Purple);
// CONCATENATED MODULE: ./utils/themes/SolarizedDark.js
/*
 * a theme inspired by solarized: http://ethanschoonover.com/solarized
 */
// some selection color not supported

var SolarizedDark_primaryColor = '#2d7eb1';
var SolarizedDark_bannerBg = '#003B4A';
var SolarizedDark_contentBg = '#002A35';
var SolarizedDark_contentBoxBg = '#072d3a';
var SolarizedDark_fontColor = SolarizedDark_primaryColor;
var SolarizedDark_sidebarBg = '#001B21';
var SolarizedDark_markdownFont = '#687F82';
var SolarizedDark_descText = '#176179';
var SolarizedDark_primaryMate = '#2CB4AA';
var SolarizedDark = {
  logoText: SolarizedDark_primaryColor,
  cover: Object(external__polished_["lighten"])(0.08, SolarizedDark_bannerBg),
  coverIndex: SolarizedDark_primaryMate,
  htmlBg: SolarizedDark_contentBoxBg,
  loading: {
    basic: SolarizedDark_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, SolarizedDark_bannerBg) // basic: '#113B4A',
    // animate: '#02495a',

  },
  error: {
    title: SolarizedDark_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, SolarizedDark_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, SolarizedDark_contentBoxBg)
  },
  font: SolarizedDark_fontColor,
  link: '#269A95',
  main: '#7DC0C5',
  bodyBg: SolarizedDark_contentBg,
  selectionBg: '#839496',
  avatarOpacity: 0.8,
  header: {
    fg: SolarizedDark_primaryColor,
    bg: SolarizedDark_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, SolarizedDark_bannerBg),
    fixed: SolarizedDark_bannerBg,
    tabActive: SolarizedDark_primaryColor,
    // articleTitle
    tabOthers: Object(external__polished_["darken"])(0.1, SolarizedDark_primaryColor)
  },
  banner: {
    title: SolarizedDark_primaryColor,
    bg: SolarizedDark_bannerBg,
    desc: SolarizedDark_descText,
    spliter: Object(external__polished_["darken"])(0.04, SolarizedDark_bannerBg),
    number: SolarizedDark_primaryColor,
    active: SolarizedDark_primaryMate,
    numberDesc: SolarizedDark_descText,
    numberDivider: '#1b475d',
    numberHoverBg: '#0d475a'
  },
  thread: {
    bg: SolarizedDark_contentBoxBg,
    filterResultHint: SolarizedDark_descText,
    articleTitle: '#7B8F90',
    articleHover: '#113744',
    articleStrip: SolarizedDark_contentBoxBg,
    articleDigest: '#6B7F83',
    articleTag: SolarizedDark_primaryColor,
    articleLink: SolarizedDark_descText,
    commentsUserBorder: SolarizedDark_contentBoxBg,
    extraInfo: Object(external__polished_["darken"])(0.04, SolarizedDark_primaryMate),
    // '#987d40',
    articleSpliter: '#014454'
  },
  content: {
    bg: SolarizedDark_contentBoxBg,
    cardBg: SolarizedDark_bannerBg,
    cardBorder: '#194f6f',
    cardBorderHover: '#0F6186'
  },
  footer: {
    text: '#065365',
    hover: '#5c868b',
    label: '#065365'
  },
  sidebar: {
    bg: SolarizedDark_sidebarBg,
    menuHover: Object(external__polished_["lighten"])(0.1, SolarizedDark_sidebarBg),
    pinActive: '#849804',
    menuLink: '#93A1A1',
    borderColor: '#14363E'
  },
  preview: {
    title: SolarizedDark_primaryColor,
    desc: '#1b6d88',
    font: SolarizedDark_fontColor,
    bg: SolarizedDark_contentBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: Object(external__polished_["lighten"])(0.04, SolarizedDark_contentBg),
    accountBg: Object(external__polished_["lighten"])(0.04, SolarizedDark_contentBg),
    articleBg: Object(external__polished_["lighten"])(0.04, SolarizedDark_contentBg),
    helper: Object(external__polished_["lighten"])(0.1, SolarizedDark_contentBg),
    helperHover: Object(external__polished_["lighten"])(0.2, SolarizedDark_contentBg),
    topLine: '#41c7bd',
    icon: '#41c7bd',
    divider: '#005255'
  },
  article: {
    link: '#276788',
    linkHover: '#00A097',
    reactionTitle: '#62868a',
    reactionHoverBg: Object(external__polished_["lighten"])(0.04, SolarizedDark_contentBg)
  },
  comment: {
    icon: '#62868a',
    didIcon: 'orange',
    title: '#62868a',
    username: '#62868a',
    number: '#00A59B',
    floor: '#00A59B',
    reply: '#638688',
    replyBg: '#004c5f',
    placeholder: '#62868a',
    filter: '#62868a',
    filterActive: SolarizedDark_primaryColor,
    action: '#62868a',
    // mention text displayed in article
    mentionText: '#91a4b5',
    mentionTextBg: '#115267',
    // mention popover background
    mentionBg: SolarizedDark_contentBoxBg,
    mentionBorder: SolarizedDark_primaryColor,
    mentionActiveBg: Object(external__polished_["lighten"])(0.1, SolarizedDark_contentBoxBg),
    mentionShadow: '0px 2px 10px 1px rgba(47, 46, 46, 0.8)'
  },
  editor: {
    title: '#2a867f',
    content: '#467E93',
    placeholder: '#1E5162',
    headerBg: '#0e3444',
    contentBg: '#0e3444',
    border: '#0e3444',
    borderActive: '#10627b',
    borderNormal: '#2d505f',
    footer: SolarizedDark_descText,
    footerHover: Object(external__polished_["lighten"])(0.05, SolarizedDark_descText)
  },
  pagination: {
    activeNum: 'white',
    itemBg: '#103440',
    itemBorderColor: '#103440',
    disableText: '#1d5365',
    text: SolarizedDark_primaryColor,
    inactiveNum: SolarizedDark_primaryColor
  },
  heatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#024352',
    borderHover: SolarizedDark_descText,
    monthLabel: SolarizedDark_descText,
    scale_1: '#035b63',
    scale_2: '#007470',
    scale_3: '#048a84',
    scale_4: '#05a78e',
    scale_5: '#01c3a5'
  },
  bannerHeatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#024352',
    borderHover: SolarizedDark_descText,
    monthLabel: SolarizedDark_descText,
    scale_1: '#035b63',
    scale_2: '#007470',
    scale_3: '#048a84',
    scale_4: '#05a78e',
    scale_5: '#01c3a5'
  },
  markdown: {
    title: Object(external__polished_["darken"])(0.05, '#DBE0E1'),
    fg: SolarizedDark_markdownFont,
    titleBottom: '1px solid #154452',
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, SolarizedDark_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, SolarizedDark_markdownFont),
    strongBg: '#34535C',
    link: '#2382C4',
    tableBg: Object(external__polished_["lighten"])(0.01, SolarizedDark_contentBoxBg),
    tableBg2n: Object(external__polished_["lighten"])(0.05, SolarizedDark_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["lighten"])(0.07, SolarizedDark_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["lighten"])(0.1, SolarizedDark_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["lighten"])(0.03, SolarizedDark_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.2, SolarizedDark_contentBg),
    searchInput: Object(external__polished_["lighten"])(0.1, SolarizedDark_contentBg),
    searchIcon: Object(external__polished_["lighten"])(0.1, SolarizedDark_contentBg),
    barBg: Object(external__polished_["darken"])(0.01, SolarizedDark_contentBg),
    border: Object(external__polished_["lighten"])(0.05, SolarizedDark_contentBg),
    title: Object(external__polished_["lighten"])(0.4, SolarizedDark_contentBg),
    desc: Object(external__polished_["lighten"])(0.2, SolarizedDark_contentBg),
    activeBg: Object(external__polished_["lighten"])(0.05, SolarizedDark_contentBg)
  },
  button: {
    primary: SolarizedDark_primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, SolarizedDark_primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, SolarizedDark_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, SolarizedDark_primaryColor),
    clicked: SolarizedDark_primaryColor
  },
  navigator: {
    activeBottom: SolarizedDark_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, SolarizedDark_bannerBg),
    hoverBg: Object(external__polished_["lighten"])(0.05, SolarizedDark_bannerBg)
  },
  popover: {
    bg: SolarizedDark_bannerBg,
    borderColor: SolarizedDark_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.5,
    text: '#196677'
  },
  tagger: {
    text: '#a7bfbf',
    bg: '#004C61',
    border: '#004C61',
    closeBtn: '#a7bfbf'
  },
  tabs: {
    headerActive: SolarizedDark_primaryColor,
    header: Object(external__polished_["darken"])(0.1, SolarizedDark_primaryColor),
    contentBg: '#0F4553',
    headerBg: '#0d3a49',
    headerActiveTop: SolarizedDark_primaryColor,
    border: '#265663',
    bottomLine: SolarizedDark_descText
  },
  modal: {
    bg: SolarizedDark_bannerBg,
    border: SolarizedDark_primaryColor,
    innerSelectBg: '#03323e'
  },
  form: {
    inputBg: '#002D39',
    text: '#617F82',
    label: '#617F82',
    border: '#005256'
  },
  a: {
    hover: SolarizedDark_primaryColor,
    active: Object(external__polished_["darken"])(0.1, SolarizedDark_primaryColor)
  }
};
/* harmony default export */ var themes_SolarizedDark = (SolarizedDark);
// CONCATENATED MODULE: ./utils/themes/Github.js
/*
 * a theme inspired by Muzli && unbuntu
 */

var Github_primaryColor = '#615c79';
var Github_bannerBg = '#2f2c3c';
var Github_contentBg = '#242029';
var Github_contentBoxBg = '#27212d';
var Github_fontColor = Github_primaryColor;
var Github_sidebarBg = '#222029';
var Github_markdownFont = '#7F8189';
var Github_descText = '#4a455a';
var Github_primaryMate = '#a7674d';
var Github = {
  logoText: Github_primaryColor,
  cover: '#F6F8FA',
  coverIndex: '#9e96c3',
  htmlBg: Github_contentBoxBg,
  loading: {
    basic: Github_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, Github_bannerBg) // basic: '#113B4A',
    // animate: '#02495a',

  },
  error: {
    title: Github_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, Github_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, Github_contentBoxBg)
  },
  font: Github_fontColor,
  link: '#269A95',
  main: '#7DC0C5',
  bodyBg: Github_contentBg,
  selectionBg: '#839496',
  avatarOpacity: 0.8,
  header: {
    fg: Github_primaryColor,
    bg: Github_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, Github_bannerBg),
    fixed: Github_bannerBg,
    tabActive: Github_primaryColor,
    // articleTitle
    tabOthers: Object(external__polished_["darken"])(0.1, Github_primaryColor)
  },
  banner: {
    title: Github_primaryColor,
    bg: Github_bannerBg,
    desc: Github_descText,
    spliter: Object(external__polished_["darken"])(0.04, Github_bannerBg),
    number: Github_primaryColor,
    active: Github_primaryMate,
    numberDesc: Github_descText,
    numberDivider: Object(external__polished_["darken"])(0.08, Github_descText),
    numberHoverBg: Object(external__polished_["lighten"])(0.03, Github_bannerBg)
  },
  thread: {
    bg: Github_contentBoxBg,
    filterResultHint: Github_descText,
    articleTitle: '#737990',
    articleHover: Object(external__polished_["lighten"])(0.03, Github_contentBoxBg),
    articleStrip: Github_contentBoxBg,
    articleDigest: '#505667',
    articleTag: '#526482',
    articleLink: Github_descText,
    commentsUserBorder: Github_contentBoxBg,
    extraInfo: Github_primaryMate,
    articleSpliter: '#3c4648'
  },
  content: {
    bg: Github_contentBoxBg,
    cardBg: Github_bannerBg,
    cardBorder: Object(external__polished_["lighten"])(0.08, Github_contentBoxBg),
    cardBorderHover: Object(external__polished_["lighten"])(0.1, Github_contentBoxBg)
  },
  footer: {
    text: Github_descText,
    hover: Object(external__polished_["lighten"])(0.1, Github_descText),
    label: Github_descText
  },
  sidebar: {
    bg: Github_sidebarBg,
    menuHover: Object(external__polished_["lighten"])(0.1, Github_sidebarBg),
    pinActive: '#849804',
    menuLink: '#93A1A1',
    borderColor: Object(external__polished_["lighten"])(0.05, Github_sidebarBg)
  },
  preview: {
    title: Github_primaryColor,
    desc: Object(external__polished_["lighten"])(0.05, Github_descText),
    font: Github_fontColor,
    bg: Github_contentBoxBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: Object(external__polished_["lighten"])(0.04, Github_contentBg),
    accountBg: Object(external__polished_["lighten"])(0.04, Github_contentBg),
    articleBg: Object(external__polished_["lighten"])(0.04, Github_contentBg),
    helper: Object(external__polished_["lighten"])(0.2, Github_contentBg),
    helperHover: Object(external__polished_["lighten"])(0.3, Github_contentBg),
    topLine: '#c387e8',
    icon: '#845145',
    divider: Object(external__polished_["darken"])(0.07, Github_descText)
  },
  article: {
    link: Github_primaryMate,
    linkHover: Object(external__polished_["lighten"])(0.05, Github_primaryMate),
    reactionTitle: Github_primaryColor,
    reactionHoverBg: Object(external__polished_["lighten"])(0.04, Github_contentBg)
  },
  comment: {
    icon: Github_primaryColor,
    didIcon: Github_primaryMate,
    title: Github_primaryColor,
    username: Github_primaryColor,
    number: Github_primaryMate,
    floor: Github_primaryMate,
    reply: Github_primaryColor,
    replyBg: '#3d3644',
    placeholder: Github_descText,
    filter: Github_descText,
    filterActive: Github_primaryColor,
    action: Github_primaryColor,
    // mention text displayed in article
    mentionText: '#70768B',
    mentionTextBg: '#423a4a',
    // mention popover background
    mentionBg: Github_contentBoxBg,
    mentionBorder: Github_primaryColor,
    mentionActiveBg: Object(external__polished_["lighten"])(0.1, Github_contentBoxBg),
    mentionShadow: '0px 2px 10px 1px rgba(47, 46, 46, 0.8)'
  },
  editor: {
    title: Github_primaryColor,
    content: '#6E717A',
    placeholder: Object(external__polished_["darken"])(0.03, Github_descText),
    headerBg: Github_bannerBg,
    contentBg: Github_bannerBg,
    border: Github_bannerBg,
    borderActive: Github_primaryColor,
    borderNormal: Object(external__polished_["lighten"])(0.05, Github_bannerBg),
    footer: Github_descText,
    footerHover: Object(external__polished_["lighten"])(0.05, Github_descText)
  },
  pagination: {
    activeNum: 'white',
    itemBg: Object(external__polished_["darken"])(0.1, Github_descText),
    itemBorderColor: Object(external__polished_["darken"])(0.06, Github_descText),
    disableText: Github_descText,
    text: Github_primaryColor,
    inactiveNum: Github_primaryColor
  },
  heatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#342e3a',
    borderHover: Github_primaryColor,
    monthLabel: Github_descText,
    scale_1: Object(external__polished_["lighten"])(0.04, '#342e3a'),
    scale_2: Object(external__polished_["lighten"])(0.08, '#342e3a'),
    scale_3: Object(external__polished_["lighten"])(0.12, '#342e3a'),
    scale_4: Object(external__polished_["lighten"])(0.18, '#342e3a'),
    scale_5: Object(external__polished_["lighten"])(0.3, '#342e3a')
  },
  bannerHeatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#342e3a',
    borderHover: Github_primaryColor,
    monthLabel: Github_descText,
    scale_1: Object(external__polished_["lighten"])(0.04, '#342e3a'),
    scale_2: Object(external__polished_["lighten"])(0.08, '#342e3a'),
    scale_3: Object(external__polished_["lighten"])(0.12, '#342e3a'),
    scale_4: Object(external__polished_["lighten"])(0.18, '#342e3a'),
    scale_5: Object(external__polished_["lighten"])(0.3, '#342e3a')
  },
  markdown: {
    title: Object(external__polished_["darken"])(0.05, '#DBE0E1'),
    fg: Github_markdownFont,
    titleBottom: '1px solid #154452',
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, Github_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, Github_markdownFont),
    strongBg: '#34535C',
    link: '#2382C4',
    tableBg: Object(external__polished_["lighten"])(0.01, Github_contentBoxBg),
    tableBg2n: Object(external__polished_["lighten"])(0.05, Github_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["lighten"])(0.07, Github_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["lighten"])(0.1, Github_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["lighten"])(0.03, Github_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.2, Github_contentBg),
    searchInput: Object(external__polished_["lighten"])(0.1, Github_contentBg),
    searchIcon: Object(external__polished_["lighten"])(0.1, Github_contentBg),
    barBg: Object(external__polished_["darken"])(0.01, Github_contentBg),
    border: Object(external__polished_["lighten"])(0.05, Github_contentBg),
    title: Object(external__polished_["lighten"])(0.4, Github_contentBg),
    desc: Object(external__polished_["lighten"])(0.2, Github_contentBg),
    activeBg: Object(external__polished_["lighten"])(0.05, Github_contentBg)
  },
  button: {
    primary: Github_primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, Github_primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, Github_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, Github_primaryColor),
    clicked: Github_primaryColor
  },
  navigator: {
    activeBottom: Github_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, Github_bannerBg),
    hoverBg: Object(external__polished_["lighten"])(0.05, Github_bannerBg)
  },
  popover: {
    bg: Github_bannerBg,
    borderColor: Github_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.5,
    text: '#72788D'
  },
  tagger: {
    text: '#a7bfbf',
    bg: '#004C61',
    border: '#004C61',
    closeBtn: '#a7bfbf'
  },
  tabs: {
    headerActive: Github_primaryColor,
    header: Object(external__polished_["darken"])(0.05, Github_primaryColor),
    contentBg: Object(external__polished_["lighten"])(0.05, Github_contentBoxBg),
    headerBg: Object(external__polished_["lighten"])(0.03, Github_contentBoxBg),
    headerActiveTop: Github_primaryColor,
    border: Github_descText,
    bottomLine: Github_descText
  },
  modal: {
    bg: Github_bannerBg,
    border: Github_primaryColor,
    innerSelectBg: '#333040'
  },
  form: {
    inputBg: Object(external__polished_["lighten"])(0.03, Github_contentBoxBg),
    text: Github_descText,
    label: Github_primaryColor,
    border: Github_descText
  },
  a: {
    hover: Github_primaryColor,
    active: Object(external__polished_["darken"])(0.1, Github_primaryColor)
  }
};
/* harmony default export */ var themes_Github = (Github);
// CONCATENATED MODULE: ./utils/themes/Blue.js
/*
 * a theme inspired by Muzli && unbuntu
 */

var Blue_primaryColor = '#615c79';
var Blue_bannerBg = '#2f2c3c';
var Blue_contentBg = '#242029';
var Blue_contentBoxBg = '#27212d';
var Blue_fontColor = Blue_primaryColor;
var Blue_sidebarBg = '#222029';
var Blue_markdownFont = '#7F8189';
var Blue_descText = '#4a455a';
var Blue_primaryMate = '#a7674d';
var Blue = {
  logoText: Blue_primaryColor,
  cover: '#586ABD',
  coverIndex: '#9e96c3',
  htmlBg: Blue_contentBoxBg,
  loading: {
    basic: Blue_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, Blue_bannerBg) // basic: '#113B4A',
    // animate: '#02495a',

  },
  error: {
    title: Blue_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, Blue_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, Blue_contentBoxBg)
  },
  font: Blue_fontColor,
  link: '#269A95',
  main: '#7DC0C5',
  bodyBg: Blue_contentBg,
  selectionBg: '#839496',
  avatarOpacity: 0.8,
  header: {
    fg: Blue_primaryColor,
    bg: Blue_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, Blue_bannerBg),
    fixed: Blue_bannerBg,
    tabActive: Blue_primaryColor,
    // articleTitle
    tabOthers: Object(external__polished_["darken"])(0.1, Blue_primaryColor)
  },
  banner: {
    title: Blue_primaryColor,
    bg: Blue_bannerBg,
    desc: Blue_descText,
    spliter: Object(external__polished_["darken"])(0.04, Blue_bannerBg),
    number: Blue_primaryColor,
    active: Blue_primaryMate,
    numberDesc: Blue_descText,
    numberDivider: Object(external__polished_["darken"])(0.08, Blue_descText),
    numberHoverBg: Object(external__polished_["lighten"])(0.03, Blue_bannerBg)
  },
  thread: {
    bg: Blue_contentBoxBg,
    filterResultHint: Blue_descText,
    articleTitle: '#737990',
    articleHover: Object(external__polished_["lighten"])(0.03, Blue_contentBoxBg),
    articleStrip: Blue_contentBoxBg,
    articleDigest: '#505667',
    articleTag: '#526482',
    articleLink: Blue_descText,
    commentsUserBorder: Blue_contentBoxBg,
    extraInfo: Blue_primaryMate,
    articleSpliter: '#3c4648'
  },
  content: {
    bg: Blue_contentBoxBg,
    cardBg: Blue_bannerBg,
    cardBorder: Object(external__polished_["lighten"])(0.08, Blue_contentBoxBg),
    cardBorderHover: Object(external__polished_["lighten"])(0.1, Blue_contentBoxBg)
  },
  footer: {
    text: Blue_descText,
    hover: Object(external__polished_["lighten"])(0.1, Blue_descText),
    label: Blue_descText
  },
  sidebar: {
    bg: Blue_sidebarBg,
    menuHover: Object(external__polished_["lighten"])(0.1, Blue_sidebarBg),
    pinActive: '#849804',
    menuLink: '#93A1A1',
    borderColor: Object(external__polished_["lighten"])(0.05, Blue_sidebarBg)
  },
  preview: {
    title: Blue_primaryColor,
    desc: Object(external__polished_["lighten"])(0.05, Blue_descText),
    font: Blue_fontColor,
    bg: Blue_contentBoxBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: Object(external__polished_["lighten"])(0.04, Blue_contentBg),
    accountBg: Object(external__polished_["lighten"])(0.04, Blue_contentBg),
    articleBg: Object(external__polished_["lighten"])(0.04, Blue_contentBg),
    helper: Object(external__polished_["lighten"])(0.2, Blue_contentBg),
    helperHover: Object(external__polished_["lighten"])(0.3, Blue_contentBg),
    topLine: '#c387e8',
    icon: '#845145',
    divider: Object(external__polished_["darken"])(0.07, Blue_descText)
  },
  article: {
    link: Blue_primaryMate,
    linkHover: Object(external__polished_["lighten"])(0.05, Blue_primaryMate),
    reactionTitle: Blue_primaryColor,
    reactionHoverBg: Object(external__polished_["lighten"])(0.04, Blue_contentBg)
  },
  comment: {
    icon: Blue_primaryColor,
    didIcon: Blue_primaryMate,
    title: Blue_primaryColor,
    username: Blue_primaryColor,
    number: Blue_primaryMate,
    floor: Blue_primaryMate,
    reply: Blue_primaryColor,
    replyBg: '#3d3644',
    placeholder: Blue_descText,
    filter: Blue_descText,
    filterActive: Blue_primaryColor,
    action: Blue_primaryColor,
    // mention text displayed in article
    mentionText: '#70768B',
    mentionTextBg: '#423a4a',
    // mention popover background
    mentionBg: Blue_contentBoxBg,
    mentionBorder: Blue_primaryColor,
    mentionActiveBg: Object(external__polished_["lighten"])(0.1, Blue_contentBoxBg),
    mentionShadow: '0px 2px 10px 1px rgba(47, 46, 46, 0.8)'
  },
  editor: {
    title: Blue_primaryColor,
    content: '#6E717A',
    placeholder: Object(external__polished_["darken"])(0.03, Blue_descText),
    headerBg: Blue_bannerBg,
    contentBg: Blue_bannerBg,
    border: Blue_bannerBg,
    borderAcitve: Blue_primaryColor,
    borderNormal: Object(external__polished_["lighten"])(0.05, Blue_bannerBg),
    footer: Blue_descText,
    footerHover: Object(external__polished_["lighten"])(0.05, Blue_descText)
  },
  pagination: {
    activeNum: 'white',
    itemBg: Object(external__polished_["darken"])(0.1, Blue_descText),
    itemBorderColor: Object(external__polished_["darken"])(0.06, Blue_descText),
    disableText: Blue_descText,
    text: Blue_primaryColor,
    inactiveNum: Blue_primaryColor
  },
  heatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#342e3a',
    borderHover: Blue_primaryColor,
    monthLabel: Blue_descText,
    scale_1: Object(external__polished_["lighten"])(0.04, '#342e3a'),
    scale_2: Object(external__polished_["lighten"])(0.08, '#342e3a'),
    scale_3: Object(external__polished_["lighten"])(0.12, '#342e3a'),
    scale_4: Object(external__polished_["lighten"])(0.18, '#342e3a'),
    scale_5: Object(external__polished_["lighten"])(0.3, '#342e3a')
  },
  bannerHeatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#342e3a',
    borderHover: Blue_primaryColor,
    monthLabel: Blue_descText,
    scale_1: Object(external__polished_["lighten"])(0.04, '#342e3a'),
    scale_2: Object(external__polished_["lighten"])(0.08, '#342e3a'),
    scale_3: Object(external__polished_["lighten"])(0.12, '#342e3a'),
    scale_4: Object(external__polished_["lighten"])(0.18, '#342e3a'),
    scale_5: Object(external__polished_["lighten"])(0.3, '#342e3a')
  },
  markdown: {
    title: Object(external__polished_["darken"])(0.05, '#DBE0E1'),
    fg: Blue_markdownFont,
    titleBottom: '1px solid #154452',
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, Blue_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, Blue_markdownFont),
    strongBg: '#34535C',
    link: '#2382C4',
    tableBg: Object(external__polished_["lighten"])(0.01, Blue_contentBoxBg),
    tableBg2n: Object(external__polished_["lighten"])(0.05, Blue_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["lighten"])(0.07, Blue_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["lighten"])(0.1, Blue_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["lighten"])(0.03, Blue_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.2, Blue_contentBg),
    searchInput: Object(external__polished_["lighten"])(0.1, Blue_contentBg),
    searchIcon: Object(external__polished_["lighten"])(0.1, Blue_contentBg),
    barBg: Object(external__polished_["darken"])(0.01, Blue_contentBg),
    border: Object(external__polished_["lighten"])(0.05, Blue_contentBg),
    title: Object(external__polished_["lighten"])(0.4, Blue_contentBg),
    desc: Object(external__polished_["lighten"])(0.2, Blue_contentBg),
    activeBg: Object(external__polished_["lighten"])(0.05, Blue_contentBg)
  },
  button: {
    primary: Blue_primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, Blue_primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, Blue_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, Blue_primaryColor),
    clicked: Blue_primaryColor
  },
  navigator: {
    activeBottom: Blue_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, Blue_bannerBg),
    hoverBg: Object(external__polished_["lighten"])(0.05, Blue_bannerBg)
  },
  popover: {
    bg: Blue_bannerBg,
    borderColor: Blue_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.5,
    text: '#72788D'
  },
  tabs: {
    headerActive: Blue_primaryColor,
    header: Object(external__polished_["darken"])(0.05, Blue_primaryColor),
    contentBg: Object(external__polished_["lighten"])(0.05, Blue_contentBoxBg),
    headerBg: Object(external__polished_["lighten"])(0.03, Blue_contentBoxBg),
    headerActiveTop: Blue_primaryColor,
    border: Blue_descText,
    bottomLine: Blue_descText
  },
  modal: {
    bg: Blue_bannerBg,
    border: Blue_primaryColor,
    innerSelectBg: '#333040'
  },
  form: {
    inputBg: Object(external__polished_["lighten"])(0.03, Blue_contentBoxBg),
    text: Blue_descText,
    label: Blue_primaryColor,
    border: Blue_descText
  },
  a: {
    hover: Blue_primaryColor,
    active: Object(external__polished_["darken"])(0.1, Blue_primaryColor)
  }
};
/* harmony default export */ var themes_Blue = (Blue);
// CONCATENATED MODULE: ./utils/themes/Yellow.js
/*
 * a theme inspired by Muzli && unbuntu
 */

var Yellow_primaryColor = '#738990';
var Yellow_bannerBg = '#EFE8D6';
var Yellow_contentBg = '#FEF6E4';
var Yellow_contentBoxBg = '#FEF6E4';
var Yellow_fontColor = Yellow_primaryColor;
var Yellow_sidebarBg = '#323c40';
var Yellow_markdownFont = '#85979c';
var Yellow_descText = '#9eb7bd';
var Yellow_primaryMate = '#1e9089';
var Yellow = {
  logoText: Yellow_primaryColor,
  cover: Yellow_bannerBg,
  coverIndex: Yellow_primaryMate,
  htmlBg: Yellow_contentBoxBg,
  loading: {
    basic: Yellow_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, Yellow_bannerBg) // basic: '#113B4A',
    // animate: '#02495a',

  },
  error: {
    title: Yellow_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, Yellow_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, Yellow_contentBoxBg)
  },
  font: Yellow_fontColor,
  link: '#269A95',
  main: '#7DC0C5',
  bodyBg: Yellow_contentBg,
  selectionBg: '#839496',
  avatarOpacity: 0.8,
  header: {
    fg: Yellow_primaryColor,
    bg: Yellow_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, Yellow_bannerBg),
    fixed: Yellow_bannerBg,
    tabActive: Yellow_primaryColor,
    // articleTitle
    tabOthers: Object(external__polished_["lighten"])(0.1, Yellow_primaryColor)
  },
  banner: {
    title: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    bg: Yellow_bannerBg,
    desc: Yellow_descText,
    spliter: Object(external__polished_["darken"])(0.04, Yellow_bannerBg),
    number: Yellow_primaryColor,
    active: Yellow_primaryMate,
    numberDesc: Yellow_descText,
    numberDivider: '#dcdad6',
    numberHoverBg: Object(external__polished_["darken"])(0.03, Yellow_bannerBg)
  },
  thread: {
    bg: Yellow_contentBoxBg,
    filterResultHint: Yellow_descText,
    articleTitle: Yellow_primaryColor,
    articleHover: '#f7eedc',
    articleStrip: Yellow_contentBoxBg,
    articleDigest: Yellow_descText,
    articleTag: '#526482',
    articleLink: Yellow_descText,
    commentsUserBorder: Yellow_contentBoxBg,
    extraInfo: Yellow_primaryMate,
    articleSpliter: '#decfb0'
  },
  content: {
    bg: Yellow_contentBoxBg,
    cardBg: Yellow_bannerBg,
    cardBorder: Object(external__polished_["lighten"])(0.08, Yellow_contentBoxBg),
    cardBorderHover: Object(external__polished_["lighten"])(0.1, Yellow_contentBoxBg)
  },
  footer: {
    text: Object(external__polished_["lighten"])(0.1, Yellow_descText),
    hover: Yellow_descText,
    label: Yellow_descText
  },
  sidebar: {
    bg: Yellow_sidebarBg,
    menuHover: Object(external__polished_["lighten"])(0.1, Yellow_sidebarBg),
    pinActive: '#849804',
    menuLink: '#93A1A1',
    borderColor: Object(external__polished_["lighten"])(0.05, Yellow_sidebarBg)
  },
  preview: {
    title: Yellow_primaryColor,
    desc: Object(external__polished_["lighten"])(0.05, Yellow_descText),
    font: Yellow_fontColor,
    bg: Yellow_contentBoxBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: Object(external__polished_["lighten"])(0.04, Yellow_contentBg),
    accountBg: Yellow_contentBg,
    articleBg: '#fffaf0',
    helper: Object(external__polished_["lighten"])(0.3, Yellow_contentBg),
    helperHover: Yellow_primaryColor,
    topLine: '#4EAFA5',
    icon: '#4EAFA5',
    divider: '#eae7de'
  },
  article: {
    link: Yellow_primaryMate,
    linkHover: Object(external__polished_["lighten"])(0.05, Yellow_primaryMate),
    reactionTitle: Yellow_primaryColor,
    reactionHoverBg: Object(external__polished_["lighten"])(0.04, Yellow_contentBg)
  },
  comment: {
    icon: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    didIcon: Yellow_primaryMate,
    title: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    username: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    number: Yellow_primaryMate,
    floor: Yellow_primaryMate,
    reply: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    replyBg: '#fff4da',
    placeholder: Yellow_descText,
    filter: Yellow_descText,
    filterActive: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    action: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    // mention text displayed in article
    mentionText: '#70768B',
    mentionTextBg: '#423a4a',
    // mention popover background
    mentionBg: Yellow_contentBoxBg,
    mentionBorder: Object(external__polished_["lighten"])(0.06, Yellow_primaryColor),
    mentionActiveBg: Object(external__polished_["lighten"])(0.1, Yellow_contentBoxBg),
    mentionShadow: '0px 2px 10px 1px rgba(47, 46, 46, 0.8)'
  },
  editor: {
    title: Yellow_primaryColor,
    content: Yellow_descText,
    placeholder: '#c8d3cf',
    headerBg: '#fffaf0',
    contentBg: '#fffaf0',
    border: '#fffaf0',
    borderActive: Yellow_primaryColor,
    borderNormal: Object(external__polished_["darken"])(0.05, Yellow_bannerBg),
    footer: Yellow_descText
  },
  pagination: {
    activeNum: 'white',
    itemBg: Yellow_bannerBg,
    itemBorderColor: Object(external__polished_["darken"])(0.05, Yellow_bannerBg),
    disableText: Yellow_descText,
    text: Yellow_primaryColor,
    inactiveNum: Yellow_primaryColor
  },
  heatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#f1eddd',
    borderHover: Yellow_primaryColor,
    monthLabel: Yellow_descText,
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  bannerHeatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#f1eddd',
    borderHover: Yellow_primaryColor,
    monthLabel: Yellow_descText,
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  markdown: {
    title: Object(external__polished_["darken"])(0.05, '#DBE0E1'),
    fg: Yellow_markdownFont,
    titleBottom: '1px solid #154452',
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, Yellow_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, Yellow_markdownFont),
    strongBg: '#34535C',
    link: '#2382C4',
    tableBg: Object(external__polished_["lighten"])(0.01, Yellow_contentBoxBg),
    tableBg2n: Object(external__polished_["lighten"])(0.05, Yellow_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["lighten"])(0.07, Yellow_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["lighten"])(0.1, Yellow_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["lighten"])(0.03, Yellow_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.2, Yellow_contentBg),
    searchInput: Object(external__polished_["lighten"])(0.1, Yellow_contentBg),
    searchIcon: Object(external__polished_["lighten"])(0.1, Yellow_contentBg),
    barBg: Object(external__polished_["darken"])(0.01, Yellow_contentBg),
    border: Object(external__polished_["lighten"])(0.05, Yellow_contentBg),
    title: Object(external__polished_["lighten"])(0.4, Yellow_contentBg),
    desc: Object(external__polished_["lighten"])(0.2, Yellow_contentBg),
    activeBg: Object(external__polished_["lighten"])(0.05, Yellow_contentBg)
  },
  button: {
    primary: Yellow_primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, Yellow_primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, Yellow_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, Yellow_primaryColor),
    clicked: Yellow_primaryColor
  },
  navigator: {
    activeBottom: Yellow_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, Yellow_bannerBg),
    hoverBg: Object(external__polished_["lighten"])(0.05, Yellow_bannerBg)
  },
  popover: {
    bg: Yellow_bannerBg,
    borderColor: Yellow_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.7,
    text: '#72788D'
  },
  tagger: {
    text: '#FFF6E5',
    bg: '#afc1b3',
    border: '#afc1b3',
    closeBtn: '#FFF6E5'
  },
  tabs: {
    headerActive: Object(external__polished_["lighten"])(0.04, Yellow_primaryColor),
    header: Object(external__polished_["lighten"])(0.2, Yellow_primaryColor),
    contentBg: Object(external__polished_["darken"])(0.03, Yellow_contentBoxBg),
    headerBg: Object(external__polished_["darken"])(0.02, Yellow_contentBoxBg),
    headerActiveTop: Yellow_primaryColor,
    border: '#EAE0C9',
    bottomLine: '#e4e0d6'
  },
  modal: {
    bg: Yellow_bannerBg,
    border: Yellow_primaryColor,
    innerSelectBg: '#f7f0e0'
  },
  form: {
    inputBg: Object(external__polished_["lighten"])(0.03, Yellow_contentBoxBg),
    text: Yellow_descText,
    label: Yellow_primaryColor,
    border: Yellow_descText
  },
  a: {
    hover: Yellow_primaryColor,
    active: Object(external__polished_["darken"])(0.1, Yellow_primaryColor)
  }
};
/* harmony default export */ var themes_Yellow = (Yellow);
// CONCATENATED MODULE: ./utils/themes/Green.js
/*
 * a theme inspired by Green && unbuntu
 */

var Green_primaryColor = '#5da579';
var Green_bannerBg = '#bccebb'; // '#AEC4AD'

var Green_contentBg = '#D3DFD1';
var Green_contentBoxBg = '#e0e8db'; // '#DBE3D6'

var Green_fontColor = Green_primaryColor;
var Green_sidebarBg = '#3B4F43';
var Green_markdownFont = '#83a085';
var Green_descText = '#83a085';
var bannerTitle = '#708e7a';
var Green_primaryMate = '#b57a5b';
var Green = {
  logoText: bannerTitle,
  cover: '#B4C9B2',
  coverIndex: '#9e96c3',
  htmlBg: Green_contentBoxBg,
  loading: {
    basic: Green_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, Green_bannerBg) // basic: '#113B4A',
    // animate: '#02495a',

  },
  error: {
    title: Green_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, Green_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, Green_contentBoxBg)
  },
  font: Green_fontColor,
  link: '#269A95',
  main: '#7DC0C5',
  bodyBg: Green_contentBg,
  selectionBg: '#839496',
  avatarOpacity: 0.8,
  header: {
    fg: Green_primaryColor,
    bg: Green_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, Green_bannerBg),
    fixed: Green_contentBg,
    tabActive: bannerTitle,
    tabOthers: Green_descText
  },
  banner: {
    title: bannerTitle,
    bg: Green_bannerBg,
    desc: Green_descText,
    spliter: Green_bannerBg,
    number: bannerTitle,
    active: Green_primaryMate,
    numberDesc: Green_descText,
    numberDivider: '#aab9ab',
    numberHoverBg: Object(external__polished_["lighten"])(0.03, Green_bannerBg)
  },
  thread: {
    bg: Green_contentBoxBg,
    filterResultHint: Green_descText,
    articleTitle: '#62867A',
    articleHover: Object(external__polished_["lighten"])(0.03, Green_contentBoxBg),
    articleStrip: Green_contentBoxBg,
    articleDigest: Green_descText,
    articleTag: '#74a0ab',
    articleLink: Green_descText,
    commentsUserBorder: Green_contentBoxBg,
    extraInfo: Green_primaryMate,
    articleSpliter: '#BBCEBC'
  },
  content: {
    bg: Green_contentBoxBg,
    cardBg: Object(external__polished_["lighten"])(0.05, Green_contentBoxBg),
    cardBorder: Object(external__polished_["lighten"])(0.08, Green_contentBoxBg),
    cardBorderHover: Object(external__polished_["lighten"])(0.1, Green_contentBoxBg)
  },
  footer: {
    text: Object(external__polished_["lighten"])(0.1, Green_descText),
    hover: Green_descText,
    label: Green_descText
  },
  sidebar: {
    bg: Green_sidebarBg,
    menuHover: Object(external__polished_["lighten"])(0.1, Green_sidebarBg),
    pinActive: Green_contentBg,
    menuLink: '#A6BBAF',
    borderColor: Object(external__polished_["lighten"])(0.05, Green_sidebarBg)
  },
  preview: {
    title: bannerTitle,
    desc: Object(external__polished_["lighten"])(0.05, Green_descText),
    font: Green_descText,
    bg: Green_contentBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: Object(external__polished_["lighten"])(0.04, Green_contentBg),
    accountBg: Green_contentBoxBg,
    articleBg: Green_contentBoxBg,
    helper: '#b0bfa8',
    helperHover: Green_descText,
    topLine: Green_primaryColor,
    icon: '#845145',
    divider: '#ced8c6'
  },
  article: {
    link: Green_primaryMate,
    linkHover: Object(external__polished_["lighten"])(0.05, Green_primaryMate),
    reactionTitle: Green_descText,
    reactionHoverBg: Object(external__polished_["lighten"])(0.04, Green_contentBg)
  },
  comment: {
    icon: bannerTitle,
    didIcon: Green_primaryMate,
    title: bannerTitle,
    username: bannerTitle,
    number: Green_primaryMate,
    floor: Green_primaryMate,
    reply: bannerTitle,
    replyBg: '#e8efe5',
    placeholder: Object(external__polished_["lighten"])(0.05, Green_descText),
    filter: Green_descText,
    filterActive: bannerTitle,
    action: Green_descText,
    // mention text displayed in article
    mentionText: bannerTitle,
    mentionTextBg: '#f7f0dc',
    // mention popover background
    mentionBg: Green_contentBoxBg,
    mentionBorder: bannerTitle,
    mentionActiveBg: Object(external__polished_["lighten"])(0.01, Green_contentBoxBg),
    mentionShadow: '0px 2px 10px 1px rgba(47, 46, 46, 0.3)'
  },
  editor: {
    title: bannerTitle,
    content: Green_descText,
    placeholder: '#a6bba7',
    headerBg: Green_contentBoxBg,
    contentBg: Green_contentBoxBg,
    border: Green_contentBoxBg,
    borderActive: Green_primaryColor,
    borderNormal: Object(external__polished_["darken"])(0.05, Green_contentBoxBg),
    footer: Green_descText,
    footerHover: Object(external__polished_["darken"])(0.05, Green_descText)
  },
  pagination: {
    itemBg: Green_contentBg,
    itemBorderColor: '#C3D4C3',
    disableText: Green_descText,
    text: Green_primaryColor,
    inactiveNum: Green_primaryColor
  },
  heatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#d3dccc',
    borderHover: Green_primaryColor,
    monthLabel: Green_descText,
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  bannerHeatmap: {
    activityLow: '#007D7C',
    activityHight: '#26A9A0',
    empty: '#d3dccc',
    borderHover: Green_primaryColor,
    monthLabel: Green_descText,
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  markdown: {
    title: Object(external__polished_["darken"])(0.05, '#DBE0E1'),
    fg: Green_markdownFont,
    titleBottom: '1px solid #154452',
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, Green_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, Green_markdownFont),
    strongBg: '#34535C',
    link: '#2382C4',
    tableBg: Object(external__polished_["lighten"])(0.01, Green_contentBoxBg),
    tableBg2n: Object(external__polished_["lighten"])(0.05, Green_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["lighten"])(0.07, Green_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["lighten"])(0.1, Green_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["lighten"])(0.03, Green_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.2, Green_contentBg),
    searchInput: Object(external__polished_["lighten"])(0.1, Green_contentBg),
    searchIcon: Object(external__polished_["lighten"])(0.1, Green_contentBg),
    barBg: Object(external__polished_["darken"])(0.01, Green_contentBg),
    border: Object(external__polished_["lighten"])(0.05, Green_contentBg),
    title: Object(external__polished_["lighten"])(0.4, Green_contentBg),
    desc: Object(external__polished_["lighten"])(0.2, Green_contentBg),
    activeBg: Object(external__polished_["lighten"])(0.05, Green_contentBg)
  },
  button: {
    primary: Green_primaryColor,
    fg: Object(external__polished_["lighten"])(0.4, Green_primaryColor),
    hoverBg: Object(external__polished_["lighten"])(0.1, Green_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, Green_primaryColor),
    clicked: Green_primaryColor
  },
  navigator: {
    activeBottom: Green_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, Green_bannerBg),
    hoverBg: Object(external__polished_["lighten"])(0.05, Green_bannerBg)
  },
  popover: {
    bg: Green_contentBoxBg,
    borderColor: Green_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.7,
    text: '#74a0ab'
  },
  tagger: {
    text: '#8095ad',
    bg: '#BBCEBC',
    border: '#BBCEBC',
    closeBtn: '#8095ad'
  },
  tabs: {
    headerActive: '#628672',
    header: '#83A086',
    contentBg: Object(external__polished_["lighten"])(0.03, Green_contentBoxBg),
    headerBg: Object(external__polished_["lighten"])(0.02, Green_contentBoxBg),
    headerActiveTop: Green_primaryColor,
    border: Object(external__polished_["darken"])(0.05, Green_contentBoxBg),
    bottomLine: '#c6d4c6'
  },
  modal: {
    bg: Green_bannerBg,
    border: Green_primaryColor,
    innerSelectBg: '#333040'
  },
  form: {
    inputBg: Object(external__polished_["lighten"])(0.03, Green_contentBoxBg),
    text: Green_descText,
    label: bannerTitle,
    border: Green_descText
  },
  a: {
    hover: Green_primaryColor,
    active: Object(external__polished_["darken"])(0.1, Green_primaryColor)
  }
};
/* harmony default export */ var themes_Green = (Green);
// CONCATENATED MODULE: ./utils/themes/IronGreen.js
//

/*
 * a theme inspired by https://dribbble.com/shots/2478998-Forum-Concept
 */

var IronGreen_primaryColor = '#98dab4';
var IronGreen_bannerBg = '#477479';
var IronGreen_contentBg = '#528187';
var IronGreen_contentBoxBg = '#54848A';
var IronGreen_fontColor = IronGreen_primaryColor;
var IronGreen_sidebarBg = '#00B5B0';
var IronGreen_markdownFont = '#B4C7C6';
var IronGreen_descText = '#7EA7AC';
var IconGreen = {
  logoText: IronGreen_descText,
  cover: IronGreen_bannerBg,
  coverIndex: '#F9FCFC',
  htmlBg: IronGreen_bannerBg,
  loading: {
    basic: IronGreen_bannerBg,
    animate: Object(external__polished_["lighten"])(0.03, IronGreen_bannerBg)
  },
  error: {
    title: IronGreen_primaryColor,
    desc: Object(external__polished_["darken"])(0.1, IronGreen_primaryColor),
    bg: Object(external__polished_["lighten"])(0.02, IronGreen_contentBoxBg)
  },
  font: IronGreen_fontColor,
  link: 'orange',
  main: '#7DC0C5',
  bodyBg: IronGreen_contentBg,
  selectionBg: 'tomato',
  avatarOpacity: 0.8,
  header: {
    fg: IronGreen_primaryColor,
    bg: IronGreen_bannerBg,
    spliter: Object(external__polished_["darken"])(0.04, IronGreen_bannerBg),
    fixed: IronGreen_bannerBg,
    tabActive: Object(external__polished_["darken"])(0.05, IronGreen_primaryColor),
    tabOthers: Object(external__polished_["lighten"])(0.08, IronGreen_descText)
  },
  banner: {
    title: '#c3cdd0',
    bg: IronGreen_bannerBg,
    desc: IronGreen_descText,
    spliter: '#4f8486',
    numberDesc: Object(external__polished_["darken"])(0.08, IronGreen_descText),
    number: '#83a7ad',
    active: IronGreen_primaryColor,
    numberDivider: '#4f8486',
    numberHoverBg: '#4D8489'
  },
  thread: {
    bg: IronGreen_contentBoxBg,
    filterResultHint: IronGreen_descText,
    articleTitle: '#e4e4e4',
    articleHover: '#528187',
    articleStrip: IronGreen_contentBoxBg,
    articleDigest: '#B6C7C8',
    articleTag: '#B4C7C8',
    articleLink: IronGreen_descText,
    commentsUserBorder: IronGreen_contentBoxBg,
    extraInfo: '#95e4be',
    articleSpliter: '#79A7A9'
  },
  content: {
    bg: IronGreen_contentBoxBg,
    cardBg: IronGreen_contentBoxBg,
    cardBorder: '#e6e6e6',
    cardBorderHover: IronGreen_primaryColor
  },
  footer: {
    text: IronGreen_descText,
    hover: '#5c868b',
    label: IronGreen_descText
  },
  sidebar: {
    bg: IronGreen_sidebarBg,
    menuHover: Object(external__polished_["darken"])(0.05, IronGreen_sidebarBg),
    pinActive: '#54848B',
    menuLink: '#F0F9F8',
    borderColor: '#14363E'
  },
  preview: {
    title: '#C2CDD0',
    desc: IronGreen_descText,
    font: IronGreen_primaryColor,
    bg: IronGreen_bannerBg,
    shadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    closerShadow: '-5px 0px 14px 0px rgba(41, 18, 18, 0.19)',
    markdownHelperBg: '#F9FCFC',
    accountBg: IronGreen_contentBoxBg,
    articleBg: IronGreen_contentBoxBg,
    helper: IronGreen_descText,
    helperHover: Object(external__polished_["lighten"])(0.08, IronGreen_descText),
    topLine: IronGreen_sidebarBg,
    icon: IronGreen_primaryColor,
    divider: IronGreen_descText
  },
  article: {
    link: IronGreen_primaryColor,
    linkHover: Object(external__polished_["lighten"])(0.05, IronGreen_primaryColor),
    reactionTitle: IronGreen_descText,
    reactionHoverBg: IronGreen_contentBg
  },
  comment: {
    icon: '#62868a',
    didIcon: IronGreen_primaryColor,
    title: '#AAC1C1',
    username: '#DFDCD8',
    number: IronGreen_primaryColor,
    floor: IronGreen_primaryColor,
    reply: '#b5d4d6',
    replyBg: '#60959a',
    placeholder: IronGreen_descText,
    filter: IronGreen_descText,
    filterActive: IronGreen_primaryColor,
    action: IronGreen_descText,
    // mention text displayed in article
    mentionText: '#91a4b5',
    mentionTextBg: '#fcffdb',
    // mention popover background
    mentionBg: '#F9FCFC',
    mentionBorder: IronGreen_primaryColor,
    mentionActiveBg: Object(external__polished_["darken"])(0.1, '#F9FCFC'),
    mentionShadow: '0px 2px 10px 1px rgba(235, 235, 235, 1)'
  },
  editor: {
    title: '#DBE1E4',
    content: '#AEC7C8',
    placeholder: IronGreen_descText,
    headerBg: IronGreen_contentBoxBg,
    contentBg: IronGreen_contentBoxBg,
    border: IronGreen_contentBoxBg,
    borderAcitve: IronGreen_primaryColor,
    borderNormal: IronGreen_descText,
    footer: IronGreen_descText,
    footerHover: Object(external__polished_["darken"])(0.05, '#a6bebf')
  },
  pagination: {
    activeNum: '#417478',
    itemBg: IronGreen_bannerBg,
    itemBorderColor: IronGreen_bannerBg,
    disableText: '#6ea6a9',
    text: '#B4C7C8',
    inactiveNum: IronGreen_descText
  },
  heatmap: {
    activityLow: '#D6ECB2',
    activityHight: '#4F966E',
    borderHover: '#51abb2',
    empty: '#4f797d',
    monthLabel: '#c6dbde',
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  bannerHeatmap: {
    activityLow: '#D6ECB2',
    activityHight: '#4F966E',
    borderHover: '#51abb2',
    empty: '#4f797d',
    monthLabel: IronGreen_descText,
    scale_1: '#dbe290',
    scale_2: '#99c06f',
    scale_3: '#609d4c',
    scale_4: '#61793e',
    scale_5: '#37642c'
  },
  markdown: {
    title: IronGreen_primaryColor,
    fg: IronGreen_markdownFont,
    titleBottom: Object(external__polished_["lighten"])(0.3, IronGreen_primaryColor),
    hrColor: '#154452',
    blockquoteBorder: '0.25em solid #34535C',
    blockquoteFg: Object(external__polished_["darken"])(0.09, IronGreen_markdownFont),
    strongFg: Object(external__polished_["lighten"])(0.2, IronGreen_markdownFont),
    strongBg: '#34535C',
    link: 'orange',
    tableBg: Object(external__polished_["darken"])(0.01, IronGreen_contentBoxBg),
    tableBg2n: Object(external__polished_["darken"])(0.05, IronGreen_contentBoxBg),
    tableborder: "1px solid ".concat(Object(external__polished_["darken"])(0.1, IronGreen_contentBoxBg)),
    taskDone: '#528416',
    taskPeding: Object(external__polished_["darken"])(0.1, IronGreen_contentBoxBg)
  },
  code: {
    bg: Object(external__polished_["darken"])(0.05, IronGreen_contentBoxBg)
  },
  shell: {
    link: Object(external__polished_["lighten"])(0.3, IronGreen_primaryColor),
    searchInput: Object(external__polished_["lighten"])(0.3, IronGreen_primaryColor),
    searchIcon: Object(external__polished_["lighten"])(0.3, IronGreen_primaryColor),
    barBg: Object(external__polished_["darken"])(0.03, IronGreen_primaryColor),
    border: Object(external__polished_["darken"])(0.05, IronGreen_primaryColor),
    title: Object(external__polished_["lighten"])(0.3, IronGreen_bannerBg),
    desc: Object(external__polished_["lighten"])(0.2, IronGreen_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.1, IronGreen_primaryColor)
  },
  button: {
    primary: IronGreen_primaryColor,
    fg: '#426F7E',
    hoverBg: Object(external__polished_["lighten"])(0.1, IronGreen_primaryColor),
    activeBg: Object(external__polished_["darken"])(0.01, IronGreen_primaryColor),
    clicked: IronGreen_primaryColor
  },
  navigator: {
    activeBottom: IronGreen_primaryColor,
    borderRight: Object(external__polished_["darken"])(0.05, IronGreen_bannerBg),
    hoverBg: '#eee'
  },
  popover: {
    bg: IronGreen_contentBg,
    borderColor: IronGreen_primaryColor,
    boxShadoe: '0 1px 4px rgba(0, 0, 0, 0.15)'
  },
  tags: {
    dotOpacity: 0.8,
    text: Object(external__polished_["lighten"])(0.05, IronGreen_descText)
  },
  tabs: {
    headerActive: IronGreen_primaryColor,
    header: IronGreen_descText,
    contentBg: '#5b8b90',
    headerBg: '#5b8b90',
    headerActiveTop: IronGreen_primaryColor,
    border: '#5b8b90',
    bottomLine: IronGreen_descText
  },
  modal: {
    bg: '#4f858a',
    border: IronGreen_primaryColor,
    innerSelectBg: IronGreen_bannerBg
  },
  form: {
    inputBg: '#FFFFFF',
    text: '#88a4ad',
    label: '#88a4ad',
    border: '#B8C6C0'
  },
  a: {
    hover: IronGreen_primaryColor,
    active: Object(external__polished_["darken"])(0.1, IronGreen_primaryColor)
  }
};
/* harmony default export */ var IronGreen = (IconGreen);
// CONCATENATED MODULE: ./utils/themes/index.js





function themes__toConsumableArray(arr) { return themes__arrayWithoutHoles(arr) || themes__iterableToArray(arr) || themes__nonIterableSpread(); }

function themes__nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function themes__iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function themes__arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { themes__defineProperty(target, key, source[key]); }); } return target; }

function themes__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









var themeDict = {
  default: _objectSpread({}, themes_Cyan),

  /* cyan: { ...Cyan }, */
  solarized: _objectSpread({}, themes_SolarizedDark),
  purple: _objectSpread({}, themes_Purple),
  yellow: _objectSpread({}, themes_Yellow),
  github: _objectSpread({}, themes_Github),
  blue: _objectSpread({}, themes_Blue),
  green: _objectSpread({}, themes_Green),
  ironGreen: _objectSpread({}, IronGreen)
};
var themeKeys = keys__default()(themeDict);
var themeCoverMap = map__default()(path__default()(['cover']), themeDict);
var themeCoverIndexMap = map__default()(path__default()(['coverIndex']), themeDict); // shorthand for style-components

var themes_theme = function theme(themepath) {
  return path__default()(['theme'].concat(themes__toConsumableArray(split__default()('.', themepath)))) || 'wheat';
};
// CONCATENATED MODULE: ./utils/fake_user.js
/* avatar: 'http://coderplanets.oss-cn-beijing.aliyuncs.com/mock/avatar1-15.png', */
var users = [{
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/1.jpg',
  nickname: 'mydearxym'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/2.jpg',
  nickname: 'messi'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/3.jpg',
  nickname: 'iniesta'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/4.jpg',
  nickname: 'montu'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/5.jpg',
  nickname: 'fjiek'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/6.jpg',
  nickname: 'noone'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/7.jpg',
  nickname: 'noone'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/8.jpg',
  nickname: 'noone'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/9.jpg',
  nickname: 'noone'
}, {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/10.jpg',
  nickname: 'noone'
}];
/* harmony default export */ var fake_user = (users);
// EXTERNAL MODULE: external "store"
var external__store_ = __webpack_require__(59);
var external__store__default = /*#__PURE__*/__webpack_require__.n(external__store_);

// EXTERNAL MODULE: external "js-cookie"
var external__js_cookie_ = __webpack_require__(108);
var external__js_cookie__default = /*#__PURE__*/__webpack_require__.n(external__js_cookie_);

// CONCATENATED MODULE: ./utils/bstore.js




/* eslint-disable */
function _has_key(cookie, key) {
  return new RegExp('(?:^|;\\s*)' + escape(key).replace(/[\-\.\+\*]/g, '\\$&') + '\\s*\\=').test(cookie);
} // NOTE: this is used only in next's getInitialProps function
// because getInitialProps is runing on server, do not hove browser cookie


function _from_req(req, key) {
  var cookie = path__default()(['headers', 'cookie'], req);

  if (!cookie || !key || !_has_key(cookie, key)) {
    return null;
  }

  var regexpStr = '(?:^|.*;\\s*)' + escape(key).replace(/[\-\.\+\*]/g, '\\$&') + '\\s*\\=\\s*((?:[^;](?!;))*[^;]?).*';
  return unescape(cookie.replace(new RegExp(regexpStr), '$1'));
}
/* eslint-enable */
// js-cookie details: https://github.com/js-cookie/js-cookie
// store.js details: https://github.com/marcuswestin/store.js


var BStore = {
  get: function get(value, optional) {
    return external__store__default.a.get(value, optional);
  },
  set: function set(key, value) {
    return external__store__default.a.set(key, value);
  },
  remove: function remove(key) {
    return external__store__default.a.remove(key);
  },
  clearAll: function clearAll() {
    return external__store__default.a.clearAll();
  },
  cookie: {
    from_req: function from_req(req, key) {
      return _from_req(req, key);
    },
    set: function set(key, val) {
      var opt = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return external__js_cookie__default.a.set(key, val, opt);
    },
    get: function get(key) {
      return external__js_cookie__default.a.get(key);
    },
    remove: function remove(key) {
      return external__js_cookie__default.a.remove(key);
    }
  }
};
/* harmony default export */ var bstore = (BStore);
// CONCATENATED MODULE: ./utils/i18n/index.js
// this is tmp, use react-intl .. later
var I18nDict = {
  posts: '帖子',
  map: '地图',
  news: '动态',
  cheatsheet: 'cheatsheet',
  meetups: 'meetups',
  users: '用户',
  videos: '视频',
  repos: '开源项目',
  jobs: '招聘'
};
var Trans = function Trans(key) {
  return I18nDict[key] || key;
};
var holder = 1;
// CONCATENATED MODULE: ./utils/analytics.js
 // https://analytics.google.com/analytics/web/?hl=zh-CN&pli=1#/embed/report-home/a39874160w174341184p173551323
// https://developers.google.com/analytics/devguides/collection/gtagjs/pages

var analytics_pageview = function pageview(url) {
  Global.gtag('config', "UA-39874160-2", {
    page_location: url
  });
}; // https://developers.google.com/analytics/devguides/collection/gtagjs/events

/*
  report event like this:
  GA.event({
    action: 'submit_form',
    category: 'Contact',
    label: this.state.message
  })
*/


var analytics_event = function event(_ref) {
  var action = _ref.action,
      category = _ref.category,
      label = _ref.label,
      value = _ref.value;
  Global.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value
  });
};

var GA = {
  pageview: analytics_pageview,
  event: analytics_event
};
/* harmony default export */ var analytics = (GA);
// CONCATENATED MODULE: ./utils/index.js
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "e", function() { return EVENT; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "d", function() { return ERR; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "k", function() { return TYPE; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "j", function() { return THREAD; });
/* unused concated harmony import ACTION */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return ACTION; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "f", function() { return FILTER; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "i", function() { return ROUTE; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "G", function() { return debug_makeDebugger; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "u", function() { return functions_dispatchEvent; });
/* unused concated harmony import mapKeys */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return mapKeys; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "E", function() { return isObject; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "L", function() { return notEmpty; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "K", function() { return nilOrEmpty; });
/* unused concated harmony import getRandomInt */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return getRandomInt; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "D", function() { return isEmptyValue; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "h", function() { return Global; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "N", function() { return onClient; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "s", function() { return functions_cutFrom; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "O", function() { return prettyNum; });
/* unused concated harmony import Rlog */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return functions_Rlog; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "r", function() { return countWords; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "o", function() { return functions_closePreviewer; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "t", function() { return debounce; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "w", function() { return extractMentions; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "v", function() { return extractAttachments; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "H", function() { return graphql_helper_makeGQClient; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "m", function() { return graphql_helper_asyncErr; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "n", function() { return asyncRes; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "F", function() { return later; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "z", function() { return route_helper_getMainPath; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "A", function() { return route_helper_getSubPath; });
/* unused concated harmony import getParameterByName */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return route_helper_getParameterByName; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "P", function() { return route_helper_queryStringToJSON; });
/* unused concated harmony import mergeRouteQuery */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return route_helper_mergeRouteQuery; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "R", function() { return route_helper_serializeQuery; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "x", function() { return route_helper_extractThreadFromPath; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "V", function() { return subPath2Thread; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "_1", function() { return thread2Subpath; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "T", function() { return storePlug; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "I", function() { return mobx_helper_markStates; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "J", function() { return mobx_helper_meteorState; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "U", function() { return mobx_helper_stripMobx; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "a", function() { return $solver; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "M", function() { return mobx_helper_observerHoc; });
/* unused concated harmony import pageGoTop */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return pageGoTop; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "Q", function() { return scrollIntoEle; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "C", function() { return holdPage; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "_2", function() { return unholdPage; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "y", function() { return focusDoraemonBar; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "B", function() { return hideDoraemonBarRecover; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "b", function() { return animations; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "S", function() { return smokey; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "p", function() { return column; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "q", function() { return columnCenter; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "W", function() { return themes_theme; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "Z", function() { return themeDict; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "_0", function() { return themeKeys; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "Y", function() { return themeCoverMap; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "X", function() { return themeCoverIndexMap; });
/* unused concated harmony import fakeUsers */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return fake_user; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "c", function() { return bstore; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "l", function() { return Trans; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "g", function() { return analytics; });
/*
 * utils functiosn
 */









/*
 * theme related
 */







/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./components/GAWraper/index.js
var GAWraper = __webpack_require__(83);

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// CONCATENATED MODULE: ./components/A/index.js
/*
 *
 * A.js
 *
 * Renders an a tag, enforce use the
 */




var StyledA =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "A__StyledA",
  componentId: "s7fj27q-0"
})(["text-decoration:none;font-weight:bolder;color:", ";transition:color 0.3s;&:hover{text-decoration:underline;}"], Object(utils["W" /* theme */])('link'));

var A_A = function A(_ref) {
  var href = _ref.href,
      target = _ref.target,
      children = _ref.children;
  return external__react__default.a.createElement(StyledA, {
    href: href,
    rel: "noopener noreferrer",
    target: target
  }, children);
};

A_A.defaultProps = {
  target: '_blank'
};
/* harmony default export */ var components_A = (A_A);
// EXTERNAL MODULE: external "react-svg"
var external__react_svg_ = __webpack_require__(112);
var external__react_svg__default = /*#__PURE__*/__webpack_require__.n(external__react_svg_);

// CONCATENATED MODULE: ./components/Img/index.js
/*
 *
 * Img.js
 *
 * Renders an image, enforcing the usage of the alt="" tag
 */




var Img_NormalImg = function NormalImg(_ref) {
  var className = _ref.className,
      src = _ref.src,
      alt = _ref.alt;
  return external__react__default.a.createElement("img", {
    className: className,
    src: src,
    alt: alt
  });
};

var Img_Img = function Img(_ref2) {
  var className = _ref2.className,
      src = _ref2.src,
      alt = _ref2.alt;

  if (/\.(svg)$/i.test(src)) {
    return external__react__default.a.createElement(external__react_svg__default.a, {
      svgClassName: className,
      path: src
    });
  }

  return external__react__default.a.createElement(Img_NormalImg, {
    className: className,
    src: src,
    alt: alt
  });
};

Img_Img.defaultProps = {
  alt: 'coderplanets image',
  className: 'img-class'
};
/* harmony default export */ var components_Img = (Img_Img);
// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// CONCATENATED MODULE: ./components/EmptyThread/styles/index.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  margin-left: 3px;\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s14j7krr-0"
})(["display:flex;flex-direction:column;align-items:center;width:100%;height:100%;margin-top:10%;"]);
var Icon404 =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__Icon404",
  componentId: "s14j7krr-1"
})(["width:300px;height:300px;fill:#b9c8c8;"]);
var Icon =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Icon",
  componentId: "s14j7krr-2"
})([""]);
var Text =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Text",
  componentId: "s14j7krr-3"
})(["text-align:center;"]);
var Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Title",
  componentId: "s14j7krr-4"
})(["color:#b8c8c8;border-top:1px solid #e2e8e8;margin-top:20px;padding-top:20px;font-size:1.5rem;"]);
var DescWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__DescWrapper",
  componentId: "s14j7krr-5"
})(["color:#b8c8c8;margin-top:0.6rem;font-size:1rem;"]);
var styles_link =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "styles__link",
  componentId: "s14j7krr-6"
})(["text-decoration:none;font-weight:bolder;color:", ";transition:color 0.3s;&:hover{text-decoration:underline;color:tomato;}"], Object(utils["W" /* theme */])('header.fg'));
var IssueLink = styles_link.extend(_templateObject);
// CONCATENATED MODULE: ./components/EmptyThread/index.js
/*
 *
 * EmptyThread
 *
 */





/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('c:EmptyThread:index');
/* eslint-enable no-unused-vars */

var translator = {
  posts: '帖子',
  jobs: '工作'
};

var EmptyThread_DescContent = function DescContent(_ref) {
  var community = _ref.community,
      thread = _ref.thread;
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement("div", null, "\u5982\u679C\u4F60\u6709 ", community, " \u76F8\u5173\u7684", translator[thread], "\uFF0C\u6B22\u8FCE\u4E00\u8D77\u5206\u4EAB\u3001\u4EA4\u6D41"), external__react__default.a.createElement("div", null, "\u5982\u679C\u662F\u7F51\u7AD9\u7684\u95EE\u9898\uFF0C\u6073\u8BF7\u4F60", external__react__default.a.createElement(IssueLink, {
    href: config["f" /* ISSUE_ADDR */],
    rel: "noopener noreferrer",
    target: "_blank"
  }, "\u63D0\u4EA4issue"), "\uFF0C\u4EE5\u4FBF\u4E8E\u5F00\u53D1\u8005\u6392\u67E5\u4FEE\u590D\u3002"));
};

var EmptyThread_EmptyThread = function EmptyThread(_ref2) {
  var community = _ref2.community,
      thread = _ref2.thread;
  return external__react__default.a.createElement(Wrapper, null, external__react__default.a.createElement(Icon, null, external__react__default.a.createElement(Icon404, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/404/nofound1.svg")
  })), external__react__default.a.createElement(Text, null, external__react__default.a.createElement(Title, null, "\u76EE\u524D\u8FD8\u6CA1\u6709 ", community, " \u76F8\u5173\u7684", translator[thread]), external__react__default.a.createElement(DescWrapper, null, external__react__default.a.createElement(EmptyThread_DescContent, {
    community: community,
    thread: thread
  }))));
};

EmptyThread_EmptyThread.defaultProps = {}; // 如果你发现是网站的问题，恳请你在这里提交

/* harmony default export */ var components_EmptyThread = (EmptyThread_EmptyThread);
// EXTERNAL MODULE: external "ramda/src/isEmpty"
var isEmpty_ = __webpack_require__(9);
var isEmpty__default = /*#__PURE__*/__webpack_require__.n(isEmpty_);

// CONCATENATED MODULE: ./components/NotFound/styles/index.js
var styles__templateObject = /*#__PURE__*/ styles__taggedTemplateLiteral(["\n  margin-left: 3px;\n"]);

function styles__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s10sfyc4-0"
})(["display:flex;flex-direction:column;align-items:center;width:100%;height:100%;margin-top:10%;"]);
var styles_Icon404 =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__Icon404",
  componentId: "s10sfyc4-1"
})(["width:300px;height:300px;fill:#b9c8c8;"]);
var styles_Icon =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Icon",
  componentId: "s10sfyc4-2"
})([""]);
var styles_Text =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Text",
  componentId: "s10sfyc4-3"
})(["text-align:center;"]);
var styles_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Title",
  componentId: "s10sfyc4-4"
})(["color:#b8c8c8;border-top:1px solid #e2e8e8;margin-top:20px;padding-top:20px;font-size:1.5rem;"]);
var styles_DescWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__DescWrapper",
  componentId: "s10sfyc4-5"
})(["color:#b8c8c8;margin-top:0.6rem;font-size:1rem;"]);
var Desc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Desc",
  componentId: "s10sfyc4-6"
})(["color:#b8c8c8;"]);
var NotFound_styles_link =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "styles__link",
  componentId: "s10sfyc4-7"
})(["text-decoration:none;font-weight:bolder;color:", ";transition:color 0.3s;&:hover{text-decoration:underline;color:tomato;}"], Object(utils["W" /* theme */])('header.fg'));
var styles_IssueLink = NotFound_styles_link.extend(styles__templateObject);
// CONCATENATED MODULE: ./components/NotFound/index.js


/*
 *
 * NotFound
 *
 */





/* eslint-disable no-unused-vars */

var NotFound_debug = Object(utils["G" /* makeDebugger */])('c:NotFound:index');
/* eslint-enable no-unused-vars */

var NotFound_DefaultDesc = function DefaultDesc() {
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement("div", null, "\u5982\u679C\u6CA1\u6709\u4F60\u5173\u6CE8\u7684\u8BED\u8A00\u6216\u6846\u67B6\uFF0C\u4F60\u53EF\u4EE5", external__react__default.a.createElement(styles_IssueLink, {
    href: config["f" /* ISSUE_ADDR */],
    rel: "noopener noreferrer",
    target: "_blank"
  }, "\u63D0\u4EA4\u8BF7\u6C42"), "\uFF0C\u7BA1\u7406\u5458\u4F1A\u5728\u7B2C\u4E00\u65F6\u95F4\u6DFB\u52A0\u3002"), external__react__default.a.createElement("div", null, "\u5982\u679C\u4F60\u53D1\u73B0\u662F\u7F51\u7AD9\u7684\u95EE\u9898\uFF0C\u6073\u8BF7\u4F60", external__react__default.a.createElement(styles_IssueLink, {
    href: config["f" /* ISSUE_ADDR */],
    rel: "noopener noreferrer",
    target: "_blank"
  }, "\u63D0\u4EA4issue"), "\uFF0C\u4EE5\u4FBF\u4E8E\u5F00\u53D1\u8005\u5728\u7B2C\u4E00\u65F6\u95F4\u4FEE\u590D\u3002"));
};

var NotFound_NotFound = function NotFound(_ref) {
  var msg = _ref.msg,
      desc = _ref.desc;
  return external__react__default.a.createElement(styles_Wrapper, null, external__react__default.a.createElement(styles_Icon, null, external__react__default.a.createElement(styles_Icon404, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/404/nofound1.svg")
  })), external__react__default.a.createElement(styles_Text, null, external__react__default.a.createElement(styles_Title, null, msg), external__react__default.a.createElement(styles_DescWrapper, null, isEmpty__default()(desc) ? external__react__default.a.createElement(NotFound_DefaultDesc, null) : external__react__default.a.createElement(Desc, null, desc))));
};

NotFound_NotFound.defaultProps = {
  msg: '哦豁! 你所期待的内容没有找到 ...',
  desc: '' // 如果你发现是网站的问题，恳请你在这里提交

};
/* harmony default export */ var components_NotFound = (NotFound_NotFound);
// CONCATENATED MODULE: ./components/Modal/styles/index.js


 // display: ${props => (props.show ? 'block' : 'none')};

var Mask =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Mask",
  componentId: "s1buj0l6-0"
})(["position:fixed;overflow:auto;top:0;right:0;bottom:0;left:0;z-index:1000;display:", ";"], function (_ref) {
  var show = _ref.show;
  return show ? 'block' : 'none';
});
var Modal_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1buj0l6-1"
})(["position:relative;background:", ";margin:0 auto;top:15%;width:", ";min-height:320px;max-height:80vh;box-shadow:-5px 6px 37px -8px rgba(0,0,0,0.42);border:1px solid;border-top:3px solid;border-color:", ";animation:", " 0.5s linear;"], Object(utils["W" /* theme */])('modal.bg'), function (_ref2) {
  var width = _ref2.width;
  return width;
}, Object(utils["W" /* theme */])('modal.border'), utils["b" /* Animate */].zoomeIn);
var CloseBtn =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__CloseBtn",
  componentId: "s1buj0l6-2"
})(["fill:", ";position:absolute;width:30px;height:30px;right:15px;top:15px;display:", ";&:hover{animation:", " 2s cubic-bezier(0,0.56,0.24,0.72);font-weight:bold;cursor:pointer;}"], Object(utils["W" /* theme */])('font'), function (_ref3) {
  var show = _ref3.show;
  return show ? 'block' : 'none';
}, utils["b" /* Animate */].rotate360);
/* display: ${props => (props.show ? 'block' : 'none')}; */

/* opacity: ${props => (props.show ? 1 : 0)}; */

/* transition: opacity 1s ease-out; */
// animation: ${Animate.zoomeIn} 0.5s linear;
// CONCATENATED MODULE: ./components/Modal/index.js
/*
 *
 * Modal
 *
 */





/* eslint-disable no-unused-vars */

var Modal_debug = Object(utils["G" /* makeDebugger */])('c:Modal:index');
/* eslint-enable no-unused-vars */

var Modal_Modal = function Modal(_ref) {
  var children = _ref.children,
      show = _ref.show,
      width = _ref.width,
      showCloseBtn = _ref.showCloseBtn,
      onClose = _ref.onClose;
  return external__react__default.a.createElement(Mask, {
    show: show,
    onClick: onClose
  }, external__react__default.a.createElement(Modal_styles_Wrapper, {
    width: width
  }, external__react__default.a.createElement(CloseBtn, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/closeBtn.svg"),
    show: showCloseBtn,
    onClick: onClose
  }), external__react__default.a.createElement("div", {
    onClick: function onClick(e) {
      return e.stopPropagation();
    }
  }, children)));
};

Modal_Modal.defaultProps = {
  show: false,
  onClose: Modal_debug,
  width: '600px',
  showCloseBtn: false
};
/* harmony default export */ var components_Modal = (Modal_Modal);
// EXTERNAL MODULE: external "antd/lib/popover"
var popover_ = __webpack_require__(113);
var popover__default = /*#__PURE__*/__webpack_require__.n(popover_);

// CONCATENATED MODULE: ./components/Popover/styles/index.js


var ContentContainer =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ContentContainer",
  componentId: "s1yh3whg-0"
})(["margin:-20px;border-radius:2px;padding:5px;padding-right:8px;background:", ";border:1px solid;border-top:2px solid;border-color:", ";box-shadow:0 1px 4px rgba(0,0,0,0.15);position:relative;"], Object(utils["W" /* theme */])('popover.bg'), Object(utils["W" /* theme */])('popover.borderColor'));
var holder = 1;
// CONCATENATED MODULE: ./components/Popover/index.js


/*
 *
 * Popover
 *
 */




/* eslint-disable no-unused-vars */

var Popover_debug = Object(utils["G" /* makeDebugger */])('c:Popover:index');
/* eslint-enable no-unused-vars */

var Popover_renderContent = function renderContent(content) {
  return external__react__default.a.createElement(ContentContainer, null, content);
};

var Popover_PopoverComponent = function PopoverComponent(_ref) {
  var title = _ref.title,
      children = _ref.children,
      content = _ref.content,
      trigger = _ref.trigger,
      placement = _ref.placement;
  return external__react__default.a.createElement(popover__default.a, {
    content: Popover_renderContent(content),
    placement: placement,
    title: title,
    trigger: trigger
  }, children);
};

Popover_PopoverComponent.defaultProps = {
  title: '',
  trigger: 'hover',
  placement: 'bottom'
};
/* harmony default export */ var Popover = (Popover_PopoverComponent);
// CONCATENATED MODULE: ./components/BaseStyled/index.js


var Center =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "BaseStyled__Center",
  componentId: "s1gw84mw-0"
})(["position:absolute;top:50%;left:50%;transform:translateX(-50%) translateY(-50%);"]);
var HorizontalCenter =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "BaseStyled__HorizontalCenter",
  componentId: "s1gw84mw-1"
})(["text-align:center;"]);
var BaseStyled_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "BaseStyled__Title",
  componentId: "s1gw84mw-2"
})(["font-size:3vh;color:", ";transition:color 0.3s;"], Object(utils["W" /* theme */])('font'));
var Ul =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "BaseStyled__Ul",
  componentId: "s1gw84mw-3"
})(["list-style:none;padding:0;margin:0;color:", ";"], Object(utils["W" /* theme */])('font'));
var Li =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "BaseStyled__Li",
  componentId: "s1gw84mw-4"
})(["padding-left:16px;margin-bottom:8px;&:before{content:'\u2022';padding-right:8px;color:", ";}"], Object(utils["W" /* theme */])('font'));
var Mark =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "BaseStyled__Mark",
  componentId: "s1gw84mw-5"
})(["backgroun:lightgrey;"]);
var Margin =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "BaseStyled__Margin",
  componentId: "s1gw84mw-6"
})(["margin-top:", ";margin-bottom:", ";margin-left:", ";margin-right:", ";"], function (_ref) {
  var top = _ref.top;
  return top || 0;
}, function (_ref2) {
  var bottom = _ref2.bottom;
  return bottom || 0;
}, function (_ref3) {
  var left = _ref3.left;
  return left || 0;
}, function (_ref4) {
  var right = _ref4.right;
  return right || 0;
});
var Space =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "BaseStyled__Space",
  componentId: "s1gw84mw-7"
})(["margin-left:", ";margin-right:", ";"], function (_ref5) {
  var left = _ref5.left;
  return left || 0;
}, function (_ref6) {
  var right = _ref6.right;
  return right || 0;
});
var SpaceGrow =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "BaseStyled__SpaceGrow",
  componentId: "s1gw84mw-8"
})(["flex-grow:1;"]);
// EXTERNAL MODULE: external "remarkable"
var external__remarkable_ = __webpack_require__(48);
var external__remarkable__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_);

// EXTERNAL MODULE: external "remarkable-emoji"
var external__remarkable_emoji_ = __webpack_require__(49);
var external__remarkable_emoji__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_emoji_);

// EXTERNAL MODULE: external "remarkable-mentions"
var external__remarkable_mentions_ = __webpack_require__(50);
var external__remarkable_mentions__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_mentions_);

// EXTERNAL MODULE: external "mastani-codehighlight"
var external__mastani_codehighlight_ = __webpack_require__(41);
var external__mastani_codehighlight__default = /*#__PURE__*/__webpack_require__.n(external__mastani_codehighlight_);

// EXTERNAL MODULE: ./containers/ThemeWrapper/MarkDownStyle.js
var MarkDownStyle = __webpack_require__(97);

// CONCATENATED MODULE: ./components/MarkDownRender/styles/index.js
 // bbst

var PreviewerContainer =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewerContainer",
  componentId: "s13j9nd2-0"
})([""]);
var styles_holder = 1;
// CONCATENATED MODULE: ./components/MarkDownRender/index.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * MarkDownRender
 *
 */










var md = new external__remarkable__default.a();
md.use(external__remarkable_mentions__default()({
  url: config["g" /* MENTION_USER_ADDR */]
}));
md.use(external__remarkable_emoji__default.a);
/* eslint-disable no-unused-vars */

var MarkDownRender_debug = Object(utils["G" /* makeDebugger */])('c:MarkDownRender:index');
/* eslint-enable no-unused-vars */
// TODO: move it to components

var MarkDownRender_MarkDownRender =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MarkDownRender, _React$Component);

  function MarkDownRender() {
    _classCallCheck(this, MarkDownRender);

    return _possibleConstructorReturn(this, (MarkDownRender.__proto__ || Object.getPrototypeOf(MarkDownRender)).apply(this, arguments));
  }

  _createClass(MarkDownRender, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      external__mastani_codehighlight__default.a.highlightAll();
    }
  }, {
    key: "render",
    value: function render() {
      var body = this.props.body;
      return external__react__default.a.createElement(PreviewerContainer, null, external__react__default.a.createElement(MarkDownStyle["a" /* default */], null, external__react__default.a.createElement("div", {
        className: "markdown-body"
      }, external__react__default.a.createElement("div", {
        id: "typewriter-preview-container",
        dangerouslySetInnerHTML: {
          __html: md.render(body)
        }
      }))));
    }
  }]);

  return MarkDownRender;
}(external__react__default.a.Component); // TODO default props check


MarkDownRender_MarkDownRender.defaultProps = {
  body: ''
};
/* harmony default export */ var components_MarkDownRender = (MarkDownRender_MarkDownRender);
// EXTERNAL MODULE: external "antd/lib/button"
var button_ = __webpack_require__(114);
var button__default = /*#__PURE__*/__webpack_require__.n(button_);

// EXTERNAL MODULE: external "antd/lib/tag"
var tag_ = __webpack_require__(115);
var tag__default = /*#__PURE__*/__webpack_require__.n(tag_);

// EXTERNAL MODULE: external "antd/lib/row"
var row_ = __webpack_require__(62);
var row__default = /*#__PURE__*/__webpack_require__.n(row_);

// EXTERNAL MODULE: external "antd/lib/col"
var col_ = __webpack_require__(63);
var col__default = /*#__PURE__*/__webpack_require__.n(col_);

// CONCATENATED MODULE: ./components/ContentFilter/styles/index.js



var ContentFilter_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1bbh70k-0"
})(["flex-grow:1;"]);
var InnerBtnWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__InnerBtnWrapper",
  componentId: "s1bbh70k-1"
})(["display:flex;&:hover{cursor:pointer;}"]);
var FilterIcon =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__FilterIcon",
  componentId: "s1bbh70k-2"
})(["fill:", ";width:16px;height:16px;margin-top:2px;margin-left:3px;"], Object(utils["W" /* theme */])('font'));
var SelectPanelWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectPanelWrapper",
  componentId: "s1bbh70k-3"
})(["width:280px;margin-left:20px;"]);
var SelectTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectTitle",
  componentId: "s1bbh70k-4"
})(["border-bottom:1px solid;border-color:", ";font-weight:bold;width:80%;padding-bottom:5px;margin-bottom:10px;color:", ";"], Object(utils["W" /* theme */])('font'), Object(utils["W" /* theme */])('font'));
var SelectItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectItem",
  componentId: "s1bbh70k-5"
})(["margin-bottom:10px;color:", ";&:hover{cursor:pointer;color:", ";}"], function (_ref) {
  var active = _ref.active,
      item = _ref.item;
  return active === item ? Object(utils["W" /* theme */])('font') : Object(utils["W" /* theme */])('banner.desc');
}, Object(utils["W" /* theme */])('font'));
// CONCATENATED MODULE: ./components/ContentFilter/index.js





var _this = this;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 *
 * ContentFilter
 *
 */






/* eslint-disable no-unused-vars */

var ContentFilter_debug = Object(utils["G" /* makeDebugger */])('c:ContentFilter:index');
/* eslint-enable no-unused-vars */

var filterDict = {
  TODAY: '今天',
  THIS_WEEK: '本周',
  THIS_MONTH: '本月',
  THIS_YEAR: '今年',
  MOST_FAVORITES: '最多收藏',
  MOST_STARS: '最多点赞',
  MOST_VIEWS: '最多浏览',
  MOST_COMMENTS: '最多评论',
  MOST_WORDS: '字数最多',
  LEAST_WORDS: '字数最少'
};

var ContentFilter_SelectPanel = function SelectPanel(_ref) {
  var activeFilter = _ref.activeFilter,
      onSelect = _ref.onSelect;
  return external__react__default.a.createElement(SelectPanelWrapper, null, external__react__default.a.createElement(row__default.a, null, external__react__default.a.createElement(col__default.a, {
    span: 8
  }, external__react__default.a.createElement(SelectTitle, null, "\u65F6\u95F4"), external__react__default.a.createElement(SelectItem, {
    item: "TODAY",
    active: activeFilter.when,
    onClick: onSelect.bind(_this, {
      when: utils["f" /* FILTER */].TODAY
    })
  }, "\u4ECA\u5929"), external__react__default.a.createElement(SelectItem, {
    item: "THIS_WEEK",
    active: activeFilter.when,
    onClick: onSelect.bind(_this, {
      when: utils["f" /* FILTER */].THIS_WEEK
    })
  }, "\u672C\u5468"), external__react__default.a.createElement(SelectItem, {
    item: "THIS_MONTH",
    active: activeFilter.when,
    onClick: onSelect.bind(_this, {
      when: utils["f" /* FILTER */].THIS_MONTH
    })
  }, "\u672C\u6708"), external__react__default.a.createElement(SelectItem, {
    item: "THIS_YEAR",
    active: activeFilter.when,
    onClick: onSelect.bind(_this, {
      when: utils["f" /* FILTER */].THIS_YEAR
    })
  }, "\u4ECA\u5E74")), external__react__default.a.createElement(col__default.a, {
    span: 8
  }, external__react__default.a.createElement(SelectTitle, null, "\u6392\u5E8F"), external__react__default.a.createElement(SelectItem, {
    item: "MOST_VIEWS",
    active: activeFilter.sort,
    onClick: onSelect.bind(_this, {
      sort: utils["f" /* FILTER */].MOST_VIEWS
    })
  }, "\u6700\u591A\u6D4F\u89C8"), external__react__default.a.createElement(SelectItem, {
    item: "MOST_STARS",
    active: activeFilter.sort,
    onClick: onSelect.bind(_this, {
      sort: utils["f" /* FILTER */].MOST_STARS
    })
  }, "\u6700\u591A\u70B9\u8D5E"), external__react__default.a.createElement(SelectItem, {
    item: "MOST_FAVORITES",
    active: activeFilter.sort,
    onClick: onSelect.bind(_this, {
      sort: utils["f" /* FILTER */].MOST_FAVORITES
    })
  }, "\u6700\u591A\u6536\u85CF"), external__react__default.a.createElement(SelectItem, {
    item: "MOST_COMMENTS",
    active: activeFilter.sort,
    onClick: onSelect.bind(_this, {
      sort: utils["f" /* FILTER */].MOST_COMMENTS
    })
  }, "\u6700\u591A\u8BC4\u8BBA")), external__react__default.a.createElement(col__default.a, {
    span: 8
  }, external__react__default.a.createElement(SelectTitle, null, "\u957F\u5EA6"), external__react__default.a.createElement(SelectItem, {
    item: "MOST_WORDS",
    active: activeFilter.wordLength,
    onClick: onSelect.bind(_this, {
      wordLength: utils["f" /* FILTER */].MOST_WORDS
    })
  }, "\u5B57\u6570\u6700\u591A"), external__react__default.a.createElement(SelectItem, {
    item: "LEAST_WORDS",
    active: activeFilter.wordLength,
    onClick: onSelect.bind(_this, {
      wordLength: utils["f" /* FILTER */].LEAST_WORDS
    })
  }, "\u5B57\u6570\u6700\u5C11"))));
};

var ContentFilter_FilterTag = function FilterTag(_ref2) {
  var onSelect = _ref2.onSelect,
      active = _ref2.active,
      type = _ref2.type;
  return Object(utils["D" /* isEmptyValue */])(active) ? null : external__react__default.a.createElement(tag__default.a, {
    closable: true,
    onClose: onSelect.bind(_this, _defineProperty({}, type, ''))
  }, filterDict[active]);
};

var ContentFilter_ContentFilter = function ContentFilter(_ref3) {
  var activeFilter = _ref3.activeFilter,
      onSelect = _ref3.onSelect;
  return external__react__default.a.createElement(ContentFilter_styles_Wrapper, null, external__react__default.a.createElement(Popover, {
    placement: "bottomLeft",
    trigger: "hover",
    content: external__react__default.a.createElement(ContentFilter_SelectPanel, {
      onSelect: onSelect,
      activeFilter: activeFilter
    })
  }, external__react__default.a.createElement(button__default.a, {
    size: "small",
    type: "primary",
    ghost: true
  }, external__react__default.a.createElement(InnerBtnWrapper, null, "\u7EFC\u5408\u6392\u5E8F", external__react__default.a.createElement(FilterIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/filter2.svg")
  }))), "\xA0\xA0\xA0\xA0"), external__react__default.a.createElement(ContentFilter_FilterTag, {
    onSelect: onSelect,
    active: activeFilter.when,
    type: "when"
  }), external__react__default.a.createElement(ContentFilter_FilterTag, {
    onSelect: onSelect,
    active: activeFilter.sort,
    type: "sort"
  }), external__react__default.a.createElement(ContentFilter_FilterTag, {
    onSelect: onSelect,
    active: activeFilter.wordLength,
    type: "wordLength"
  }));
};

ContentFilter_ContentFilter.defaultProps = {
  activeFilter: {
    when: '',
    sort: '',
    wordLength: ''
  }
};
/* harmony default export */ var components_ContentFilter = (ContentFilter_ContentFilter);
// CONCATENATED MODULE: ./components/FileUploader/styles/index.js

var FileUploaderWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FileUploaderWrapper",
  componentId: "s1xgtug3-0"
})([""]);
var InputFile =
/*#__PURE__*/
external__styled_components__default.a.input.withConfig({
  displayName: "styles__InputFile",
  componentId: "s1xgtug3-1"
})(["width:0.1px;height:0.1px;opacity:0;overflow:hidden;position:absolute;z-index:-1;"]);
// CONCATENATED MODULE: ./components/FileUploader/index.js
function FileUploader__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { FileUploader__typeof = function _typeof(obj) { return typeof obj; }; } else { FileUploader__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return FileUploader__typeof(obj); }

function FileUploader__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function FileUploader__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function FileUploader__createClass(Constructor, protoProps, staticProps) { if (protoProps) FileUploader__defineProperties(Constructor.prototype, protoProps); if (staticProps) FileUploader__defineProperties(Constructor, staticProps); return Constructor; }

function FileUploader__possibleConstructorReturn(self, call) { if (call && (FileUploader__typeof(call) === "object" || typeof call === "function")) { return call; } return FileUploader__assertThisInitialized(self); }

function FileUploader__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function FileUploader__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

/*
 *
 * FileUploader
 *
 */





/* eslint-disable no-unused-vars */

var FileUploader_debug = Object(utils["G" /* makeDebugger */])('C:FileUploader');
/* eslint-enable no-unused-vars */

var getDir = function getDir() {
  /* yearYmonthM */
  var date = new Date();
  var day = date.getDate();

  if (day < 10) {
    day = "0".concat(day);
  }

  return "posts/".concat(date.getFullYear(), "_").concat(date.getMonth() + 1, "/").concat(day);
};

var getFileName = function getFileName(filename) {
  var community = 'javascript';
  var part = 'post';
  var partId = '113';
  var nickname = 'mydearxym';
  var userId = '112';
  return "".concat(community, "--").concat(part, "--").concat(partId, "--").concat(nickname, "-").concat(userId, "--").concat(filename);
};

var FileUploader_FileUploader =
/*#__PURE__*/
function (_React$Component) {
  FileUploader__inherits(FileUploader, _React$Component);

  function FileUploader(props) {
    var _this;

    FileUploader__classCallCheck(this, FileUploader);

    _this = FileUploader__possibleConstructorReturn(this, (FileUploader.__proto__ || Object.getPrototypeOf(FileUploader)).call(this, props));
    /* eslint-disable */

    /* OSS sdk is import in _document from ali cdn */

    Object.defineProperty(FileUploader__assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        ossClient: null
      }
    });
    FileUploader_debug('process.env', process.env);
    _this.state.ossClient = new OSS.Wrapper({
      region: "oss-cn-beijing",
      accessKeyId: "LTAI7tyltSTq7Rlt",
      accessKeySecret: "cakUhmNqMaTjXWTPCfETnkrLjhswpA",
      bucket: "coderplanets"
    });
    /* eslint-enable */

    return _this;
  }

  FileUploader__createClass(FileUploader, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      /* eslint-disable */
      delete this.state.ossClient;
      /* eslint-enable */
    }
    /* eslint-disable */

  }, {
    key: "handleCHange",
    value: function handleCHange(e) {
      var _this2 = this;

      // TODO: Dir nameing
      var files = e.target.files;
      /* console.log('handleCHange files: ', files) */

      var theFile = files[0];
      if (!theFile) return false;
      var FileSize = theFile.size / 1024 / 1024;

      if (FileSize > 2) {
        return alert('资源有限，请不要上传大于 2MB 的文件');
      }

      this.props.onUploadStart();
      var filename = theFile.name;
      this.state.ossClient.multipartUpload("".concat(getDir(), "/").concat(getFileName(filename)), theFile).then(function (result) {
        /* console.log('result: ', result) */
        var url = "".concat(config["a" /* ASSETS_ENDPOINT */], "/").concat(result.name);
        /* console.log('result.url: ', url) */

        _this2.props.onUploadDone(url);
      }).catch(function (err) {
        _this2.props.onUploadError(err);
      });
    }
    /* eslint-enable */

  }, {
    key: "render",
    value: function render() {
      var children = this.props.children;
      return external__react__default.a.createElement(FileUploaderWrapper, null, external__react__default.a.createElement(InputFile, {
        type: "file",
        name: "file",
        id: "file",
        accept: "image/*",
        onChange: this.handleCHange.bind(this)
      }), external__react__default.a.createElement("label", {
        htmlFor: "file"
      }, children));
    }
  }]);

  return FileUploader;
}(external__react__default.a.Component);

FileUploader_FileUploader.defaultProps = {
  onUploadStart: FileUploader_debug,
  onUploadError: FileUploader_debug,
  onUploadDone: FileUploader_debug
};
/* harmony default export */ var components_FileUploader = (FileUploader_FileUploader);
// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// CONCATENATED MODULE: ./components/UserList/styles/index.js



var TableWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TableWrapper",
  componentId: "yzvxrn-0"
})([""]); // background: ${theme('preview.articleBg')};

var UserWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UserWrapper",
  componentId: "yzvxrn-1"
})(["display:flex;margin-bottom:10px;padding-top:10px;padding-bottom:10px;border-bottom:1px solid;border-bottom-color:", ";"], Object(utils["W" /* theme */])('preview.divider'));
var UserAvatar =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__UserAvatar",
  componentId: "yzvxrn-2"
})(["width:50px;height:50px;border-radius:4px;display:block;"]);
var UserBrief =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UserBrief",
  componentId: "yzvxrn-3"
})(["margin-left:18px;flex-grow:1;"]);
var Nickname =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Nickname",
  componentId: "yzvxrn-4"
})(["color:", ";font-weight:bold;"], Object(utils["W" /* theme */])('banner.desc'));
var Bio =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Bio",
  componentId: "yzvxrn-5"
})(["width:500px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var Location =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Location",
  componentId: "yzvxrn-6"
})(["color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var Action =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Action",
  componentId: "yzvxrn-7"
})(["width:100px;"]);
// CONCATENATED MODULE: ./components/UserList/index.js
/*
 *
 * UserList
 *
 */






/* eslint-disable no-unused-vars */

var UserList_debug = Object(utils["G" /* makeDebugger */])('c:UserList:index');
/* eslint-enable no-unused-vars */

var UserList_UsersTable = function UsersTable(_ref) {
  var entries = _ref.entries;
  return external__react__default.a.createElement(TableWrapper, null, entries.map(function (user) {
    return external__react__default.a.createElement(UserWrapper, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement(UserAvatar, {
      src: user.avatar
    }), external__react__default.a.createElement(UserBrief, null, external__react__default.a.createElement(Nickname, null, user.nickname), external__react__default.a.createElement(Bio, null, user.bio), external__react__default.a.createElement(Location, null, external__react__default.a.createElement(external__antd_["Icon"], {
      type: "environment-o"
    }), user.location)), external__react__default.a.createElement(Action, null, external__react__default.a.createElement(external__antd_["Button"], {
      size: "small",
      type: "primary",
      ghost: true
    }, external__react__default.a.createElement(external__antd_["Icon"], {
      type: "user-add"
    }), "\u5173\u6CE8")));
  }));
};

var UserList_UserList = function UserList(_ref2) {
  var _ref2$data = _ref2.data,
      entries = _ref2$data.entries,
      pageNumber = _ref2$data.pageNumber,
      pageSize = _ref2$data.pageSize,
      totalCount = _ref2$data.totalCount,
      onPageChange = _ref2.onPageChange;
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(UserList_UsersTable, {
    entries: entries
  }), external__react__default.a.createElement(components_Pagi, {
    left: "-15px",
    pageNumber: pageNumber,
    pageSize: pageSize,
    totalCount: totalCount,
    onChange: onPageChange
  }));
};

UserList_UserList.defaultProps = {
  data: {
    entries: [],
    pageNumber: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0
  },
  onPageChange: UserList_debug
};
/* harmony default export */ var components_UserList = (UserList_UserList);
// EXTERNAL MODULE: external "next/dynamic"
var dynamic_ = __webpack_require__(38);
var dynamic__default = /*#__PURE__*/__webpack_require__.n(dynamic_);

// CONCATENATED MODULE: ./components/StateTree/styles/index.js


var StateViewerWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__StateViewerWrapper",
  componentId: "s1aubaxk-0"
})(["padding:25px;"]);
var StateTreeHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__StateTreeHeader",
  componentId: "s1aubaxk-1"
})(["border-bottom:1px dashed ", ";margin-left:5px;margin-bottom:5%;padding-bottom:10px;"], Object(utils["W" /* theme */])('font'));
// CONCATENATED MODULE: ./components/StateTree/index.js



var StateTreeWithNoSSR = dynamic__default()( false ? new (require('next/dynamic').SameLoopPromise)(function (resolve, reject) {
  eval('require.ensure = function (deps, callback) { callback(require) }');

  require.ensure([], function (require) {
    var m = require('./StateTree');

    m.__webpackChunkName = 'components_StateTree_StateTree_a3db36e29b509b23128f4008fb315fb8.js';
    resolve(m);
  }, 'chunks/components_StateTree_StateTree_a3db36e29b509b23128f4008fb315fb8.js');
}) : new (__webpack_require__(38).SameLoopPromise)(function (resolve, reject) {
  var weakId = /*require.resolve*/(161);

  try {
    var weakModule = __webpack_require__(weakId);

    return resolve(weakModule);
  } catch (err) {}

  __webpack_require__.e/* require.ensure */(1).then((function (require) {
    try {
      var m = __webpack_require__(161);

      m.__webpackChunkName = 'components_StateTree_StateTree_a3db36e29b509b23128f4008fb315fb8';
      resolve(m);
    } catch (error) {
      reject(error);
    }
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
}), {
  ssr: false
});

var StateTree_StateViewer = function StateViewer(_ref) {
  var json = _ref.json;
  return external__react__default.a.createElement(StateViewerWrapper, null, external__react__default.a.createElement(StateTreeHeader, null, "\u8FD9\u91CC\u663E\u793A\u7684\u662F Mobx \u7684 store, \xA0\xA0Apollo Client \u7684\u72B6\u6001\u8BF7\u4F7F\u7528 Apollo devtools \u67E5\u770B"), external__react__default.a.createElement(StateTreeWithNoSSR, {
    json: json
  }));
};

/* harmony default export */ var StateTree = (StateTree_StateViewer);
// EXTERNAL MODULE: external "react-trend"
var external__react_trend_ = __webpack_require__(116);
var external__react_trend__default = /*#__PURE__*/__webpack_require__.n(external__react_trend_);

// CONCATENATED MODULE: ./components/TrendLine/index.js
/*
 *
 * TrendLine
 *
 */





/* eslint-disable no-unused-vars */

var TrendLine_debug = Object(utils["G" /* makeDebugger */])('c:TrendLine:index');
/* eslint-enable no-unused-vars */

var TrendLine_TrendLine = function TrendLine(_ref) {
  var data = _ref.data,
      duration = _ref.duration,
      radius = _ref.radius,
      width = _ref.width,
      theme = _ref.theme;
  var activityLowColor = Object(utils["W" /* theme */])('heatmap.activityLow')({
    theme: theme
  });
  var activityHightColor = Object(utils["W" /* theme */])('heatmap.activityHight')({
    theme: theme
  });
  return external__react__default.a.createElement(external__react_trend__default.a, {
    smooth: true,
    autoDraw: true,
    autoDrawDuration: duration,
    autoDrawEasing: "ease-in",
    data: data,
    gradient: [activityLowColor, activityHightColor],
    radius: radius,
    strokeWidth: width,
    strokeLinecap: "round"
  });
};

TrendLine_TrendLine.defaultProps = {
  data: [],
  duration: 200,
  radius: 15,
  width: 3
};
/* harmony default export */ var components_TrendLine = (Object(external__styled_components_["withTheme"])(TrendLine_TrendLine));
// CONCATENATED MODULE: ./components/StatusBox/styles/index.js
 //


var StatusBox_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1kb3t5x-0"
})(["height:1em;"]);
var Msg =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "styles__Msg",
  componentId: "s1kb3t5x-1"
})(["margin-left:5px;"]);
var SuccessMsgBox =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SuccessMsgBox",
  componentId: "s1kb3t5x-2"
})(["color:yellowgreen;animation:", " 0.5s linear;display:", ";"], utils["b" /* Animate */].fadeInUp, function (_ref) {
  var success = _ref.success;
  return success ? 'block' : 'none';
});
var WarningMsgBox =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__WarningMsgBox",
  componentId: "s1kb3t5x-3"
})(["color:#e8c557;animation:", " 0.3s linear;display:", ";"], utils["b" /* Animate */].pulse, function (_ref2) {
  var warn = _ref2.warn;
  return warn ? 'block' : 'none';
});
var ErrorMsgBox =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ErrorMsgBox",
  componentId: "s1kb3t5x-4"
})(["color:tomato;animation:", " 0.3s linear;display:", ";"], utils["b" /* Animate */].shake, function (_ref3) {
  var error = _ref3.error;
  return error ? 'block' : 'none';
});
// CONCATENATED MODULE: ./components/StatusBox/index.js
/*
 *
 * StatusBox
 *
 */





/* eslint-disable no-unused-vars */

var StatusBox_debug = Object(utils["G" /* makeDebugger */])('c:StatusBox:index');
/* eslint-enable no-unused-vars */

function getDefaultMsg(success, error) {
  if (success) {
    return '已保存';
  }

  if (error) {
    return '出错了';
  }

  return '内容无改动，请编辑后再提交';
}

var StatusBox_StatusBox = function StatusBox(_ref) {
  var success = _ref.success,
      error = _ref.error,
      warn = _ref.warn,
      msg = _ref.msg;
  var hint = msg === '' ? getDefaultMsg(success, error) : msg;
  return external__react__default.a.createElement(StatusBox_styles_Wrapper, null, external__react__default.a.createElement(SuccessMsgBox, {
    success: success
  }, external__react__default.a.createElement(external__antd_["Icon"], {
    type: "check-circle"
  }), external__react__default.a.createElement(Msg, null, hint)), external__react__default.a.createElement(WarningMsgBox, {
    warn: warn
  }, external__react__default.a.createElement(external__antd_["Icon"], {
    type: "exclamation-circle"
  }), external__react__default.a.createElement(Msg, null, hint)), external__react__default.a.createElement(ErrorMsgBox, {
    error: error
  }, external__react__default.a.createElement(external__antd_["Icon"], {
    type: "close-circle"
  }), external__react__default.a.createElement(Msg, null, hint)));
};

StatusBox_StatusBox.defaultProps = {
  // info: true,
  warn: false,
  success: false,
  error: false,
  msg: ''
};
/* harmony default export */ var components_StatusBox = (StatusBox_StatusBox);
// EXTERNAL MODULE: external "ramda/src/reverse"
var reverse_ = __webpack_require__(117);
var reverse__default = /*#__PURE__*/__webpack_require__.n(reverse_);

// EXTERNAL MODULE: external "ramda/src/slice"
var slice_ = __webpack_require__(29);
var slice__default = /*#__PURE__*/__webpack_require__.n(slice_);

// EXTERNAL MODULE: external "ramda/src/filter"
var filter_ = __webpack_require__(30);
var filter__default = /*#__PURE__*/__webpack_require__.n(filter_);

// EXTERNAL MODULE: external "ramda/src/isNil"
var isNil_ = __webpack_require__(22);
var isNil__default = /*#__PURE__*/__webpack_require__.n(isNil_);

// EXTERNAL MODULE: external "ramda/src/not"
var not_ = __webpack_require__(15);
var not__default = /*#__PURE__*/__webpack_require__.n(not_);

// EXTERNAL MODULE: external "ramda/src/compose"
var compose_ = __webpack_require__(12);
var compose__default = /*#__PURE__*/__webpack_require__.n(compose_);

// EXTERNAL MODULE: ./config/general.js
var general = __webpack_require__(55);

// CONCATENATED MODULE: ./components/AvatarsRow/styles/index.js


var Avatars =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "styles__Avatars",
  componentId: "hj5npw-0"
})(["display:flex;list-style-type:none;margin:auto;height:", ";padding:0px 8px 0px 0px;flex-direction:row-reverse;"], function (_ref) {
  var height = _ref.height;
  return height;
}); // height: 49px;

var AvatarsItem =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "styles__AvatarsItem",
  componentId: "hj5npw-1"
})(["margin:0px 0px 0px 0px;padding:0px 0px 0px 0px;position:relative;width:25px;opacity:0.75;&:hover{opacity:1;animation:", " 0.3s linear;}"], utils["b" /* Animate */].pulse);
var AvatarsImg =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__AvatarsImg",
  componentId: "hj5npw-2"
})(["border:2px solid;border-color:", ";border-radius:100px 100px 100px 100px;color:#ffffff;display:block;font-family:sans-serif;font-size:12px;font-weight:100;height:30px;width:30px;text-align:center;"], Object(utils["W" /* theme */])('thread.commentsUserBorder'));
var AvatarsMore =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "styles__AvatarsMore",
  componentId: "hj5npw-3"
})(["background-color:#e6edf3;font-size:11px;border:2px solid #f9fcfc;border-radius:100px 100px 100px 100px;color:grey;display:block;font-family:sans-serif;font-weight:100;height:30px;width:30px;padding-top:7px;padding-left:2px;text-align:center;"]);
// CONCATENATED MODULE: ./components/AvatarsRow/index.js







var AvatarsRow__this = this;

/*
 *
 * AvatarsRow
 *
 */







/* eslint-disable no-unused-vars */

var AvatarsRow_debug = Object(utils["G" /* makeDebugger */])('c:AvatarsRow:index');
/* eslint-enable no-unused-vars */

var validUser = compose__default()(not__default.a, isNil__default.a);

var AvatarsRow_AvatarsRow = function AvatarsRow(_ref) {
  var users = _ref.users,
      total = _ref.total,
      height = _ref.height,
      limit = _ref.limit,
      onUserSelect = _ref.onUserSelect,
      onTotalSelect = _ref.onTotalSelect;

  if (users.length === 0) {
    return external__react__default.a.createElement("span", null);
  }

  users = filter__default()(validUser, users);
  return external__react__default.a.createElement(Avatars, {
    height: height
  }, total <= users.length ? external__react__default.a.createElement("span", null) : external__react__default.a.createElement(AvatarsItem, {
    onClick: onTotalSelect.bind(AvatarsRow__this, {
      users: users,
      total: total
    })
  }, external__react__default.a.createElement(AvatarsMore, null, Object(utils["O" /* prettyNum */])(total))), slice__default()(0, limit, reverse__default()(users)).map(function (user) {
    return external__react__default.a.createElement(AvatarsItem, {
      key: external__shortid__default.a.generate(),
      onClick: onUserSelect.bind(AvatarsRow__this, user)
    }, external__react__default.a.createElement(external__antd_["Tooltip"], {
      title: user.nickname
    }, external__react__default.a.createElement(AvatarsImg, {
      src: user.avatar
    })));
  }));
};

AvatarsRow_AvatarsRow.defaultProps = {
  height: '32px',
  users: [],
  limit: general["a" /* ATATARS_LIST_LENGTH */].POSTS,
  onUserSelect: AvatarsRow_debug,
  onTotalSelect: AvatarsRow_debug
};
/* harmony default export */ var components_AvatarsRow = (AvatarsRow_AvatarsRow);
// CONCATENATED MODULE: ./components/TagList/styles/index.js



var TagList_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "q5g05n-0"
})(["flex-direction:column;margin-left:10px;padding-left:10%;"]);
var TagItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagItem",
  componentId: "q5g05n-1"
})(["margin-bottom:18px;font-size:medium;display:flex;&:hover{cursor:pointer;font-weight:bold;}"]);
var AllTagIcon =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__AllTagIcon",
  componentId: "q5g05n-2"
})(["fill:#6b8688;margin-right:10px;margin-top:2px;width:14px;height:14px;"]);

var getDotBgColor = function getDotBgColor(active, title, color) {
  if (!active) return color;
  return active === title ? color : 'lightgrey';
};

var TagDot =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagDot",
  componentId: "q5g05n-3"
})(["width:14px;height:14px;margin-top:5px;margin-right:12px;border-radius:100%;background-color:", ";display:inline-block;opacity:", ";"], function (_ref) {
  var active = _ref.active,
      title = _ref.title,
      color = _ref.color;
  return getDotBgColor(active, title, color);
}, Object(utils["W" /* theme */])('tags.dotOpacity')); // ${props => (props.active === props.title ? 1 : 0.7)}

var TagTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagTitle",
  componentId: "q5g05n-4"
})(["color:", ";"], Object(utils["W" /* theme */])('tags.text'));
// CONCATENATED MODULE: ./components/TagList/index.js
var TagList__this = this;

/*
 *
 * TagList
 *
 */


 // import TagsLoading from '../../components/LoadingEffects/TagsLoading'




/* eslint-disable no-unused-vars */

var TagList_debug = Object(utils["G" /* makeDebugger */])('c:TagList:index');
/* eslint-enable no-unused-vars */

var prettyColor = {
  red: '#FC6360',
  orange: '#FFA653',
  yellow: '#F8CE5A',
  green: '#60CC5A',
  cyan: '#9fefe4',
  blue: '#2CB8F0',
  purple: '#D488DE',
  grey: 'lightgrey'
};

var TagList_TagList = function TagList(_ref) {
  var tags = _ref.tags,
      active = _ref.active,
      onSelect = _ref.onSelect;
  // const loading= true
  //   <TagsLoading num={7} />
  return external__react__default.a.createElement(TagList_styles_Wrapper, null, active.title ? external__react__default.a.createElement(TagItem, {
    onClick: onSelect.bind(TagList__this, {
      title: '',
      color: ''
    })
  }, external__react__default.a.createElement(AllTagIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/all_tags.svg")
  }), external__react__default.a.createElement(TagTitle, null, "\u5168\u90E8\u6807\u7B7E")) : null, tags.map(function (tag) {
    return external__react__default.a.createElement(TagItem, {
      key: external__shortid__default.a.generate(),
      onClick: onSelect.bind(TagList__this, {
        title: tag.title,
        color: tag.color,
        ext: 'helli'
      })
    }, external__react__default.a.createElement(TagDot, {
      color: prettyColor[tag.color],
      active: active.title,
      title: tag.title
    }), external__react__default.a.createElement(TagTitle, {
      active: active.title,
      title: tag.title,
      color: tag.color
    }, tag.title));
  }));
};

TagList_TagList.defaultProps = {
  active: {
    title: '',
    color: ''
  }
};
/* harmony default export */ var components_TagList = (TagList_TagList);
// EXTERNAL MODULE: external "antd/lib/pagination"
var pagination_ = __webpack_require__(118);
var pagination__default = /*#__PURE__*/__webpack_require__.n(pagination_);

// CONCATENATED MODULE: ./components/Pagi/styles/index.js

var PagiWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PagiWrapper",
  componentId: "cmupx7-0"
})(["text-align:center;margin-top:", ";margin-bottom:", ";margin-left:", ";"], function (_ref) {
  var top = _ref.top;
  return top;
}, function (_ref2) {
  var bottom = _ref2.bottom;
  return bottom;
}, function (_ref3) {
  var left = _ref3.left;
  return left;
});
var BottomMsg =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BottomMsg",
  componentId: "cmupx7-1"
})(["font-size:1.4em;color:#afaeae;&:before{content:'~~';margin-right:10px;}&:after{content:'~~';margin-left:10px;}"]);
// CONCATENATED MODULE: ./components/Pagi/index.js


/*
 *
 * Pagi
 *
 */




/* eslint-disable no-unused-vars */

var Pagi_debug = Object(utils["G" /* makeDebugger */])('c:Pagi:index');
/* eslint-enable no-unused-vars */

var hasExtraPage = function hasExtraPage(totalCount, pageSize) {
  return totalCount > pageSize;
};

var Pagi_PagiCustomRender = function PagiCustomRender(current, type, originalElement) {
  /* eslint-disable */
  if (type === 'prev') {
    return external__react__default.a.createElement("a", null, "\u4E0A\u4E00\u9875");
  } else if (type === 'next') {
    return external__react__default.a.createElement("a", null, "\u4E0B\u4E00\u9875");
  }
  /* eslint-enable */


  return originalElement;
};

var Pagi_BottomFooter = function BottomFooter(_ref) {
  var show = _ref.show,
      msg = _ref.msg;
  if (show) return external__react__default.a.createElement(BottomMsg, null, msg);
  return external__react__default.a.createElement("div", null);
};

var Pagi_Pagi = function Pagi(_ref2) {
  var pageNumber = _ref2.pageNumber,
      pageSize = _ref2.pageSize,
      totalCount = _ref2.totalCount,
      showBottomMsg = _ref2.showBottomMsg,
      emptyMsg = _ref2.emptyMsg,
      noMoreMsg = _ref2.noMoreMsg,
      left = _ref2.left,
      top = _ref2.top,
      bottom = _ref2.bottom,
      onChange = _ref2.onChange;

  if (totalCount === 0) {
    return external__react__default.a.createElement(PagiWrapper, {
      left: left,
      top: top,
      bottom: bottom
    }, external__react__default.a.createElement(Pagi_BottomFooter, {
      show: showBottomMsg,
      msg: emptyMsg
    }));
  }

  return external__react__default.a.createElement(PagiWrapper, {
    left: left,
    top: top,
    bottom: bottom
  }, hasExtraPage(totalCount, pageSize) ? external__react__default.a.createElement(pagination__default.a, {
    current: pageNumber,
    pageSize: pageSize,
    total: totalCount,
    itemRender: Pagi_PagiCustomRender,
    onChange: onChange
  }) : external__react__default.a.createElement(Pagi_BottomFooter, {
    show: showBottomMsg,
    msg: noMoreMsg
  }));
};

Pagi_Pagi.defaultProps = {
  emptyMsg: '还没有评论',
  noMoreMsg: '没有更多评论了',
  showBottomMsg: false,
  left: '0px',
  top: '30px',
  bottom: '30px'
};
/* harmony default export */ var components_Pagi = (Pagi_Pagi);
// CONCATENATED MODULE: ./components/Navigator/style/index.js



var Breadcrumbs =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "style__Breadcrumbs",
  componentId: "s8kbw07-0"
})(["max-width:520px;margin-left:3vw;height:100%;display:flex;align-items:center;"]);
var Logo =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "style__Logo",
  componentId: "s8kbw07-1"
})(["height:22px;margin-top:1px;width:22px;opacity:0.7;"]);
var LogoText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "style__LogoText",
  componentId: "s8kbw07-2"
})(["margin-left:6px;color:", ";"], Object(utils["W" /* theme */])('logoText'));
var BetaLogo =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "style__BetaLogo",
  componentId: "s8kbw07-3"
})(["fill:#ef8145;height:40px;width:40px;margin-top:5px;margin-left:3px;"]);
var UL =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "style__UL",
  componentId: "s8kbw07-4"
})(["&:before{content:' ';display:table;}&:after{content:' ';display:table;clear:both;}"]);
var LI =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "style__LI",
  componentId: "s8kbw07-5"
})(["float:left;padding:0 5px;min-width:15%;max-width:30%;border-bottom:1px solid;border-bottom-color:", ";border-right:1px solid;border-right-color:", ";&:hover{background:", ";}"], function (_ref) {
  var active = _ref.active;
  return active ? Object(utils["W" /* theme */])('navigator.activeBottom') : '';
}, Object(utils["W" /* theme */])('navigator.borderRight'), Object(utils["W" /* theme */])('navigator.hoverBg'));
var style_A =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "style__A",
  componentId: "s8kbw07-6"
})(["position:relative;display:block;padding:10px;padding-right:0 !important;font-size:1em;text-align:center;color:#aaa;cursor:pointer;"]);
// CONCATENATED MODULE: ./components/Navigator/index.js
/*
 *
 * Navigator
 *
 */
 // import PropTypes from 'prop-types'




/* eslint-disable no-unused-vars */

var Navigator_debug = Object(utils["G" /* makeDebugger */])('c:Navigator:index');
/* eslint-enable no-unused-vars */

var Navigator_Navigator = function Navigator() {
  return external__react__default.a.createElement(Breadcrumbs, null, external__react__default.a.createElement(Logo, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/keyboard_logo.svg")
  }), external__react__default.a.createElement(LogoText, null, "coderplanets"), external__react__default.a.createElement(BetaLogo, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/beta.svg")
  }));
};
/*
Navigator.propTypes = {
  // https://www.npmjs.com/package/prop-types
}

Navigator.defaultProps = {}
*/


/* harmony default export */ var components_Navigator = (Navigator_Navigator);
// CONCATENATED MODULE: ./components/ThemeSelector/style/index.js


var ThemeDot =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "style__ThemeDot",
  componentId: "s1uhsv1t-0"
})(["width:25px;height:25px;border-radius:100%;margin-right:10px;background:", ";border:", ";position:relative;cursor:pointer;color:", ";&:after{content:'T';position:absolute;color:", ";top:14%;left:35%;}"], function (_ref) {
  var name = _ref.name;
  return utils["Y" /* themeCoverMap */][name];
}, function (_ref2) {
  var name = _ref2.name;
  return name === 'github' ? '1px solid lightgrey' : '';
}, function (_ref3) {
  var active = _ref3.active,
      name = _ref3.name;
  return active ? Object(utils["W" /* theme */])('bodyBg') : utils["Y" /* themeCoverMap */][name];
}, function (_ref4) {
  var active = _ref4.active,
      name = _ref4.name;
  return active ? utils["X" /* themeCoverIndexMap */][name] : '';
});
var FlexWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "style__FlexWrapper",
  componentId: "s1uhsv1t-1"
})(["display:flex;justify-content:center;"]);
// CONCATENATED MODULE: ./components/ThemeSelector/index.js
var ThemeSelector__this = this;

/*
 *
 * ThemeSelector
 *
 */





/* eslint-disable no-unused-vars */

var ThemeSelector_debug = Object(utils["G" /* makeDebugger */])('c:ThemeSelector:index');
/* eslint-enable no-unused-vars */

var ThemeSelector_ThemeSelector = function ThemeSelector(_ref) {
  var curTheme = _ref.curTheme,
      changeTheme = _ref.changeTheme;
  return external__react__default.a.createElement(FlexWrapper, null, utils["_0" /* themeKeys */].map(function (name) {
    return external__react__default.a.createElement(ThemeDot, {
      key: external__shortid__default.a.generate(),
      active: curTheme === name,
      name: name,
      onClick: changeTheme.bind(ThemeSelector__this, name)
    });
  }));
};

ThemeSelector_ThemeSelector.defaultProps = {
  curTheme: ''
};
/* harmony default export */ var components_ThemeSelector = (ThemeSelector_ThemeSelector);
// EXTERNAL MODULE: ./components/Tabber/index.js
var Tabber = __webpack_require__(44);

// CONCATENATED MODULE: ./components/UserCell/styles/index.js

var UserCellWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UserCellWrapper",
  componentId: "dwivim-0"
})(["display:flex;align-items:center;justify-content:flex-start;margin-left:10px;"]);
var Avatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__Avatar",
  componentId: "dwivim-1"
})(["width:38px;height:38px;border-radius:100%;"]);
var UserInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UserInfo",
  componentId: "dwivim-2"
})(["display:flex;flex-direction:column;margin-left:10px;align-items:start;"]);
var NickName =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NickName",
  componentId: "dwivim-3"
})(["font-size:1rem;color:#a0bbbe;font-weight:bold;"]);
var styles_Bio =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Bio",
  componentId: "dwivim-4"
})(["color:#a0bbbe;margin-top:-3px;width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"]);
// CONCATENATED MODULE: ./components/UserCell/index.js
/*
 *
 * UserCell
 *
 */




/* eslint-disable no-unused-vars */

var UserCell_debug = Object(utils["G" /* makeDebugger */])('c:UserCell:index');
/* eslint-enable no-unused-vars */

var UserCell_UserCell = function UserCell(_ref) {
  var user = _ref.user;
  return external__react__default.a.createElement(UserCellWrapper, null, external__react__default.a.createElement(Avatar, {
    src: user.avatar
  }), external__react__default.a.createElement(UserInfo, null, external__react__default.a.createElement(NickName, null, user.nickname), external__react__default.a.createElement(styles_Bio, null, user.bio)));
};

UserCell_UserCell.defaultProps = {};
/* harmony default export */ var components_UserCell = (UserCell_UserCell);
// CONCATENATED MODULE: ./components/BuyMeChuanChuan/styles/index.js


 // background: #f9fcfc;

var BuyMeChuanChuan_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1badxb1-0"
})(["height:100%;min-height:400px;width:100%;display:flex;flex-direction:column;padding:15px 20px;"]);
var Header =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Header",
  componentId: "s1badxb1-1"
})(["height:35px;text-align:center;margin-left:20px;margin-bottom:20px;"]);
var BuyChuanChuan =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BuyChuanChuan",
  componentId: "s1badxb1-2"
})(["display:flex;"]);
var ChuanChuanDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ChuanChuanDesc",
  componentId: "s1badxb1-3"
})(["width:50%;justify-content:center;"]); // source: https://unsplash.com/photos/vzX2rgUbQXM

var FoodPic =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__FoodPic",
  componentId: "s1badxb1-4"
})(["width:80%;height:auto;display:block;margin:0 auto;border-radius:5px;"]);
var ChuanChuanSelect =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ChuanChuanSelect",
  componentId: "s1badxb1-5"
})(["width:50%;display:flex;flex-direction:column;"]);
var styles_SelectTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectTitle",
  componentId: "s1badxb1-6"
})(["display:flex;margin-left:5px;color:", ";font-size:1.3rem;"], Object(utils["W" /* theme */])('banner.desc'));
var MyName =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MyName",
  componentId: "s1badxb1-7"
})(["color:", ";margin-left:8px;margin-right:8px;display:flex;"], Object(utils["W" /* theme */])('link'));
var NameLinkIcon =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__NameLinkIcon",
  componentId: "s1badxb1-8"
})(["fill:", ";width:20px;height:20px;padding-top:3px;"], Object(utils["W" /* theme */])('link'));
var SelectDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectDesc",
  componentId: "s1badxb1-9"
})(["margin-top:5px;margin-left:5px;font-size:0.9rem;margin-bottom:12px;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var SelectBox =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectBox",
  componentId: "s1badxb1-10"
})(["margin-top:10px;border:1px solid;border-color:", ";border-radius:4px;background:", ";height:90px;display:flex;justify-content:left;align-items:center;background-image:linear-gradient(#51abb2 2px,transparent 2px),linear-gradient(90deg,#51abb200 2px,transparent 2px),linear-gradient(#5eabb333 1px,transparent 1px),linear-gradient(90deg,#5eabb336 1px,transparent 1px);background-size:100px 100px,100px 100px,20px 20px,20px 20px;background-position:-2px -2px,-2px -2px,-1px -1px,-1px -1px;"], Object(utils["W" /* theme */])('banner.desc'), Object(utils["W" /* theme */])('modal.innerSelectBg'));
var ChuanChuanIcon =
/*#__PURE__*/
external__styled_components__default()(components_Img).withConfig({
  displayName: "styles__ChuanChuanIcon",
  componentId: "s1badxb1-11"
})(["width:55px;height:55px;"]);
var Selectors =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Selectors",
  componentId: "s1badxb1-12"
})(["display:flex;"]);
var By =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__By",
  componentId: "s1badxb1-13"
})(["width:40px;height:40px;display:flex;justify-content:center;align-items:center;font-size:1.6rem;color:", ";margin-left:-10px;"], Object(utils["W" /* theme */])('font'));
var Circle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Circle",
  componentId: "s1badxb1-14"
})(["width:38px;height:38px;border:1px solid;border-color:", ";border-radius:100%;display:flex;justify-content:center;align-items:center;margin-right:10px;color:", ";background-color:", ";&:hover{cursor:pointer;animation:", " 0.3s linear;}transition:background-color 0.3s ease-out;"], Object(utils["W" /* theme */])('font'), function (_ref) {
  var active = _ref.active;
  return active ? 'white' : '#51abb2';
}, function (_ref2) {
  var active = _ref2.active;
  return active ? Object(utils["W" /* theme */])('font') : '';
}, utils["b" /* Animate */].pulse);
var SelectHolder =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SelectHolder",
  componentId: "s1badxb1-15"
})(["flex-grow:1;"]);
var PayButton =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PayButton",
  componentId: "s1badxb1-16"
})(["display:flex;justify-content:space-between;margin-right:5px;align-items:center;"]);
var PayDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PayDesc",
  componentId: "s1badxb1-17"
})(["font-size:0.8rem;display:flex;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var AliPay =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__AliPay",
  componentId: "s1badxb1-18"
})(["margin-left:5px;margin-right:5px;color:#42abe1;"]);
var Weixin =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Weixin",
  componentId: "s1badxb1-19"
})(["color:#3eb64b;margin-left:5px;"]);
var MoneyNum =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "styles__MoneyNum",
  componentId: "s1badxb1-20"
})(["color:#ffdad3;"]);
// CONCATENATED MODULE: ./components/BuyMeChuanChuan/index.js


var BuyMeChuanChuan__this = this;

function BuyMeChuanChuan__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { BuyMeChuanChuan__typeof = function _typeof(obj) { return typeof obj; }; } else { BuyMeChuanChuan__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return BuyMeChuanChuan__typeof(obj); }

function BuyMeChuanChuan__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function BuyMeChuanChuan__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function BuyMeChuanChuan__createClass(Constructor, protoProps, staticProps) { if (protoProps) BuyMeChuanChuan__defineProperties(Constructor.prototype, protoProps); if (staticProps) BuyMeChuanChuan__defineProperties(Constructor, staticProps); return Constructor; }

function BuyMeChuanChuan__possibleConstructorReturn(self, call) { if (call && (BuyMeChuanChuan__typeof(call) === "object" || typeof call === "function")) { return call; } return BuyMeChuanChuan__assertThisInitialized(self); }

function BuyMeChuanChuan__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function BuyMeChuanChuan__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

/*
 *
 * BuyMeChuanChuan
 *
 */




 // import { inject, observer } from 'mobx-react'
// import Link from 'next/link'
// import styled from 'styled-components'


/* eslint-disable no-unused-vars */

var BuyMeChuanChuan_debug = Object(utils["G" /* makeDebugger */])('c:Footer:index');
/* eslint-enable no-unused-vars */

var BuyMeChuanChuan_PayMoneyFooter = function PayMoneyFooter(_ref) {
  var num = _ref.num;
  return external__react__default.a.createElement(PayButton, null, external__react__default.a.createElement(PayDesc, null, "\u652F\u6301:", external__react__default.a.createElement(AliPay, null, external__react__default.a.createElement(external__antd_["Icon"], {
    type: "alipay-circle"
  }), "\u652F\u4ED8\u5B9D"), "|", external__react__default.a.createElement(Weixin, null, external__react__default.a.createElement(external__antd_["Icon"], {
    type: "wechat"
  }), " \u5FAE\u4FE1\u652F\u4ED8")), external__react__default.a.createElement(external__antd_["Button"], {
    type: "red"
  }, "\u8D44\u52A9 ", external__react__default.a.createElement(MoneyNum, null, "\uFFE5", num * 10.24, " \u5143")));
};

var BuyMeChuanChuan_ChuanSelector = function ChuanSelector(_ref2) {
  var active = _ref2.active,
      onSelect = _ref2.onSelect;
  return external__react__default.a.createElement(SelectBox, null, external__react__default.a.createElement(ChuanChuanIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/chuanchuan.svg")
  }), external__react__default.a.createElement(Selectors, null, external__react__default.a.createElement(By, null, "X"), external__react__default.a.createElement(Circle, {
    active: active === 1,
    onClick: onSelect.bind(BuyMeChuanChuan__this, 1)
  }, "1"), external__react__default.a.createElement(Circle, {
    active: active === 2,
    onClick: onSelect.bind(BuyMeChuanChuan__this, 2)
  }, "2"), external__react__default.a.createElement(Circle, {
    active: active === 3,
    onClick: onSelect.bind(BuyMeChuanChuan__this, 3)
  }, "3"), external__react__default.a.createElement(Circle, {
    active: active === 5,
    onClick: onSelect.bind(BuyMeChuanChuan__this, 5)
  }, "5"), external__react__default.a.createElement(Circle, {
    active: active === 10,
    onClick: onSelect.bind(BuyMeChuanChuan__this, 10)
  }, "10")));
};

var BuyMeChuanChuan_BuyMeChuanChuan =
/*#__PURE__*/
function (_React$Component) {
  BuyMeChuanChuan__inherits(BuyMeChuanChuan, _React$Component);

  function BuyMeChuanChuan() {
    var _ref3;

    var _temp, _this2;

    BuyMeChuanChuan__classCallCheck(this, BuyMeChuanChuan);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return BuyMeChuanChuan__possibleConstructorReturn(_this2, (_temp = _this2 = BuyMeChuanChuan__possibleConstructorReturn(this, (_ref3 = BuyMeChuanChuan.__proto__ || Object.getPrototypeOf(BuyMeChuanChuan)).call.apply(_ref3, [this].concat(args))), Object.defineProperty(BuyMeChuanChuan__assertThisInitialized(_this2), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        activeChuan: 1
      }
    }), _temp));
  }

  BuyMeChuanChuan__createClass(BuyMeChuanChuan, [{
    key: "componentDidMount",
    value: function componentDidMount() {}
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {}
  }, {
    key: "onChuanSelect",
    value: function onChuanSelect(activeChuan) {
      this.setState({
        activeChuan: activeChuan
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          show = _props.show,
          fromUser = _props.fromUser,
          onClose = _props.onClose;
      var activeChuan = this.state.activeChuan;
      return external__react__default.a.createElement(components_Modal, {
        width: "700px",
        show: show,
        showCloseBtn: true,
        onClose: onClose
      }, external__react__default.a.createElement(BuyMeChuanChuan_styles_Wrapper, null, external__react__default.a.createElement(Header, null, isEmpty__default()(fromUser) ? external__react__default.a.createElement("div", null) : external__react__default.a.createElement(components_UserCell, {
        user: fromUser
      })), external__react__default.a.createElement(BuyChuanChuan, null, external__react__default.a.createElement(ChuanChuanDesc, null, external__react__default.a.createElement(FoodPic, {
        src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/food.png")
      })), external__react__default.a.createElement(ChuanChuanSelect, null, external__react__default.a.createElement(styles_SelectTitle, null, "\u8BF7", ' ', external__react__default.a.createElement(MyName, null, "\u5F00\u53D1\u8005", external__react__default.a.createElement("a", {
        href: config["c" /* GITHUB_ME */],
        target: "_blank",
        rel: "noopener noreferrer"
      }, external__react__default.a.createElement(NameLinkIcon, {
        src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/link2.svg")
      }))), ' ', "\u64B8\u4E2A\u4E32"), external__react__default.a.createElement(SelectDesc, null, "\u4F60\u7684\u8D44\u52A9\u5C06\u4E3B\u8981\u7528\u4E8E coderplanets \u7F51\u7AD9\u7684\u8FD0\u7EF4\u8D39\u7528, \u4E0E\u6B64\u540C\u65F6\uFF0C\u4F60\u5C06\u89E3\u9501\u6240\u6709\u7CBE\u5FC3\u8BBE\u8BA1\u7684\u4E3B\u9898\u3002"), external__react__default.a.createElement(BuyMeChuanChuan_ChuanSelector, {
        active: activeChuan,
        onSelect: this.onChuanSelect.bind(this)
      }), external__react__default.a.createElement(SelectHolder, null), external__react__default.a.createElement(BuyMeChuanChuan_PayMoneyFooter, {
        num: activeChuan
      })))));
    }
  }]);

  return BuyMeChuanChuan;
}(external__react__default.a.Component);

/* harmony default export */ var components_BuyMeChuanChuan = (BuyMeChuanChuan_BuyMeChuanChuan);
BuyMeChuanChuan_BuyMeChuanChuan.defaultProps = {
  fromUser: {},
  show: false,
  onClose: BuyMeChuanChuan_debug
};
// EXTERNAL MODULE: ./components/LoadingEffects/index.js + 4 modules
var LoadingEffects = __webpack_require__(64);

// EXTERNAL MODULE: external "antd"
var external__antd_ = __webpack_require__(120);
var external__antd__default = /*#__PURE__*/__webpack_require__.n(external__antd_);

// CONCATENATED MODULE: ./components/index.js
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "j", function() { return GAWraper["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "a", function() { return components_A; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "l", function() { return components_Img; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "h", function() { return components_EmptyThread; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "q", function() { return components_NotFound; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "o", function() { return components_Modal; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "s", function() { return Popover; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "v", function() { return Space; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "w", function() { return SpaceGrow; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "n", function() { return components_MarkDownRender; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "g", function() { return components_ContentFilter; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "i", function() { return components_FileUploader; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "G", function() { return components_UserList; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "x", function() { return StateTree; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "E", function() { return components_TrendLine; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "y", function() { return components_StatusBox; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "c", function() { return components_AvatarsRow; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "B", function() { return components_TagList; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "r", function() { return components_Pagi; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "p", function() { return components_Navigator; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "C", function() { return components_ThemeSelector; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "z", function() { return Tabber["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "F", function() { return components_UserCell; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "e", function() { return components_BuyMeChuanChuan; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "f", function() { return LoadingEffects["b" /* CommentLoading */]; });
/* unused concated harmony import CheatSheetLoading */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return LoadingEffects["a" /* CheatSheetLoading */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "t", function() { return LoadingEffects["c" /* PostLoading */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "u", function() { return LoadingEffects["d" /* PostsLoading */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "d", function() { return external__antd_["Button"]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "b", function() { return external__antd_["Affix"]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "A", function() { return external__antd_["Tabs"]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "D", function() { return external__antd_["Tooltip"]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "k", function() { return external__antd_["Icon"]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "m", function() { return external__antd_["Input"]; });
 // Basic component







 // Utils component














 //

 // loading component

 // UI library (currently use antd)



/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./config/general.js
var general = __webpack_require__(55);

// CONCATENATED MODULE: ./config/endpoint.js
/* config for different envs */
var getGraphQLEndpoint = function getGraphQLEndpoint() {
  switch ("production") {
    case 'production':
      /* return 'http://api.coderplanets.com/graphiql' */
      return 'http://localhost:4001/graphiql';

    case 'dev':
      return 'http://devapi.coderplanets.com/graphiql';

    case 'local':
      return 'http://localhost:4001/graphiql';

    default:
      return 'http://localhost:4001/graphiql';
  }
};

var GRAPHQL_ENDPOINT = getGraphQLEndpoint();
var GITHUB_ADDR = 'https://github.com/mydearxym/mastani_web';
var GITHUB_ME = 'https://github.com/mydearxym';
var ISSUE_ADDR = 'https://github.com/mydearxym/mastani_web/issues/new';
var MENTION_USER_ADDR = 'https://coderplanets.com/users/';
// EXTERNAL MODULE: ./config/assets.js
var assets = __webpack_require__(32);

// CONCATENATED MODULE: ./config/index.js
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "h", function() { return general["c" /* PAGE_SIZE */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "j", function() { return general["e" /* WORD_LIMIT */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "i", function() { return general["d" /* TAG_COLORS */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "b", function() { return general["b" /* CMS_THREADS */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "d", function() { return GRAPHQL_ENDPOINT; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "f", function() { return ISSUE_ADDR; });
/* unused concated harmony import GITHUB_ADDR */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return GITHUB_ADDR; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "c", function() { return GITHUB_ME; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "g", function() { return MENTION_USER_ADDR; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "a", function() { return assets["a" /* ASSETS_ENDPOINT */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "e", function() { return assets["c" /* ICON_ASSETS */]; });
/* unused concated harmony import DEFAULT_ICON */
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, false, function() { return assets["b" /* DEFAULT_ICON */]; });




/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("mobx-state-tree");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("mobx-react");

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "ramda/src/forEach"
var forEach_ = __webpack_require__(43);
var forEach__default = /*#__PURE__*/__webpack_require__.n(forEach_);

// EXTERNAL MODULE: external "pubsub-js"
var external__pubsub_js_ = __webpack_require__(31);
var external__pubsub_js__default = /*#__PURE__*/__webpack_require__.n(external__pubsub_js_);

// EXTERNAL MODULE: external "rxjs/Subject"
var Subject_ = __webpack_require__(66);
var Subject__default = /*#__PURE__*/__webpack_require__.n(Subject_);

// EXTERNAL MODULE: external "rxjs/add/observable/of"
var of_ = __webpack_require__(123);
var of__default = /*#__PURE__*/__webpack_require__.n(of_);

// EXTERNAL MODULE: external "rxjs/add/observable/fromEventPattern"
var fromEventPattern_ = __webpack_require__(124);
var fromEventPattern__default = /*#__PURE__*/__webpack_require__.n(fromEventPattern_);

// EXTERNAL MODULE: external "rxjs/add/operator/debounceTime"
var debounceTime_ = __webpack_require__(67);
var debounceTime__default = /*#__PURE__*/__webpack_require__.n(debounceTime_);

// EXTERNAL MODULE: external "rxjs/add/operator/do"
var do_ = __webpack_require__(68);
var do__default = /*#__PURE__*/__webpack_require__.n(do_);

// EXTERNAL MODULE: external "rxjs/add/operator/switchMap"
var switchMap_ = __webpack_require__(69);
var switchMap__default = /*#__PURE__*/__webpack_require__.n(switchMap_);

// EXTERNAL MODULE: external "rxjs/add/operator/merge"
var merge_ = __webpack_require__(70);
var merge__default = /*#__PURE__*/__webpack_require__.n(merge_);

// EXTERNAL MODULE: external "rxjs/add/operator/timeoutWith"
var timeoutWith_ = __webpack_require__(125);
var timeoutWith__default = /*#__PURE__*/__webpack_require__.n(timeoutWith_);

// EXTERNAL MODULE: external "ramda/src/join"
var join_ = __webpack_require__(126);
var join__default = /*#__PURE__*/__webpack_require__.n(join_);

// EXTERNAL MODULE: external "rxjs/Observable"
var Observable_ = __webpack_require__(39);
var Observable__default = /*#__PURE__*/__webpack_require__.n(Observable_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "apollo-link"
var external__apollo_link_ = __webpack_require__(127);
var external__apollo_link__default = /*#__PURE__*/__webpack_require__.n(external__apollo_link_);

// EXTERNAL MODULE: external "apollo-link-retry"
var external__apollo_link_retry_ = __webpack_require__(128);
var external__apollo_link_retry__default = /*#__PURE__*/__webpack_require__.n(external__apollo_link_retry_);

// EXTERNAL MODULE: external "apollo-link-http"
var external__apollo_link_http_ = __webpack_require__(129);
var external__apollo_link_http__default = /*#__PURE__*/__webpack_require__.n(external__apollo_link_http_);

// EXTERNAL MODULE: external "apollo-link-error"
var external__apollo_link_error_ = __webpack_require__(130);
var external__apollo_link_error__default = /*#__PURE__*/__webpack_require__.n(external__apollo_link_error_);

// EXTERNAL MODULE: external "apollo-client"
var external__apollo_client_ = __webpack_require__(131);
var external__apollo_client__default = /*#__PURE__*/__webpack_require__.n(external__apollo_client_);

// EXTERNAL MODULE: external "apollo-cache-inmemory"
var external__apollo_cache_inmemory_ = __webpack_require__(132);
var external__apollo_cache_inmemory__default = /*#__PURE__*/__webpack_require__.n(external__apollo_cache_inmemory_);

// EXTERNAL MODULE: external "isomorphic-fetch"
var external__isomorphic_fetch_ = __webpack_require__(71);
var external__isomorphic_fetch__default = /*#__PURE__*/__webpack_require__.n(external__isomorphic_fetch_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// CONCATENATED MODULE: ./utils/network/setup.js







/* import { onError } from 'apollo-link-error' */



/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('Network');
/* eslint-enable no-unused-vars */

var graphLink = new external__apollo_link_http_["HttpLink"]({
  uri: config["d" /* GRAPHQL_ENDPOINT */],
  fetch: external__isomorphic_fetch__default.a
});
var TIMEOUT_THRESHOLD = 15000; // 5 sec

var GRAPHQL_TIMEOUT = 15000;
var MUTIATION_TIMEOUT = 15000;
var QUERY_TIMEOUT = 15000;
var retryLink = new external__apollo_link_retry_["RetryLink"]({
  delay: {
    initial: 300,
    max: Infinity,
    jitter: true
  },
  attempts: {
    max: 1
    /* retryIf: error => !!error, */

  }
});
/* const errorLink = onError(({ operation, graphQLErrors }) => { */

var errorLink = Object(external__apollo_link_error_["onError"])(function (_ref) {
  var graphQLErrors = _ref.graphQLErrors;

  if (graphQLErrors) {
    /* graphQLErrors.map(({ message, path, detail }) => */
    debug('[GraphQL error happend]');
    graphQLErrors.map(function (_ref2) {
      var message = _ref2.message;
      return debug("[error detail--> ]:  ".concat(message));
    });
  } // if (networkError) {
  // debug(`[Network error]: ${networkError}`)
  // }

});
var token = '';
var user = utils["c" /* BStore */].get('user');

if (user) {
  token = utils["c" /* BStore */].get('user').token || '';
}
/* const token = */

/* 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJtYXN0YW5pX3NlcnZlciIsImV4cCI6MTUyNTI2Nzc3NCwiaWF0IjoxNTI0MDU4MTc0LCJpc3MiOiJtYXN0YW5pX3NlcnZlciIsImp0aSI6IjdiNjdhYzJmLTIwMjYtNDMzNy04MjcyLTVmYjY0ZDMxMGVjNyIsIm5iZiI6MTUyNDA1ODE3Mywic3ViIjoiMTEyIiwidHlwIjoiYWNjZXNzIn0.mm0GuOhzs8UYikPZGnIKQpnGYJQiwzEtCx2xeRn1qcT3sOT6Yg3GvM303OxDoGHnrNf72HSjwVxiCO6mXkq8mg' */


var context = {
  headers: {
    special: 'Special header value',
    authorization: "Bearer ".concat(token)
  }
  /* const link = ApolloLink.from([errorLink, retryLink, graphLink]) */

};
var setup_link = external__apollo_link_["ApolloLink"].from([retryLink, errorLink, graphLink]);
/* const link = ApolloLink.from([retryLink, graphLink]) */
// disable cache in apollo-client
// sse https://www.apollographql.com/docs/react/essentials/queries.html#graphql-config-options-fetchPolicy
// see https://stackoverflow.com/questions/47879016/how-to-disable-cache-in-apollo-link-or-apollo-client

var defaultOptions = {
  watchQuery: {
    fetchPolicy: 'network-only',
    errorPolicy: 'ignore'
  },
  query: {
    fetchPolicy: 'network-only',
    errorPolicy: 'all'
  } // single-instance-pattern
  // see: https://k94n.com/es6-modules-single-instance-pattern

};
var client = new external__apollo_client_["ApolloClient"]({
  link: setup_link,

  /* cache: new InMemoryCache(), */
  cache: new external__apollo_cache_inmemory_["InMemoryCache"](),
  connectToDevTools: true,

  /* shouldBatch: false, */
  defaultOptions: defaultOptions
});
// CONCATENATED MODULE: ./utils/network/handler.js




/* eslint-disable no-unused-vars */

var handler_debug = Object(utils["G" /* makeDebugger */])('Network');
/* eslint-enable no-unused-vars */

var TimoutObservable = Observable_["Observable"].of({
  error: utils["d" /* ERR */].TIMEOUT,
  details: "server has no response in ".concat(TIMEOUT_THRESHOLD, " secs")
});

var handler_fomatDetail = function fomatDetail(errors) {
  var details = [];
  errors.map(function (_ref) {
    var message = _ref.message,
        path = _ref.path,
        key = _ref.key,
        code = _ref.code;
    return details.push({
      detail: key ? "".concat(key, ":").concat(message) : "".concat(message),
      path: path ? join__default()(' |> ', path) : '',
      code: code
    });
  });
  return details;
};

var handler_formatGraphErrors = function formatGraphErrors(error) {
  if (Array.isArray(error)) return {
    error: utils["d" /* ERR */].CRAPHQL,
    details: handler_fomatDetail(error)
  };
  var graphQLErrors = error.graphQLErrors;

  if (!Object(utils["K" /* nilOrEmpty */])(graphQLErrors)) {
    // graphQLErrors may not catch in graph query (wrang sytax etc ...)
    // checkout this issue https://github.com/apollographql/apollo-client/issues/2810
    return {
      error: utils["d" /* ERR */].CRAPHQL,
      details: handler_fomatDetail(graphQLErrors)
    };
  }

  return {
    error: utils["d" /* ERR */].NETWORK,
    details: 'checkout your server or network'
  };
};
var handler_getThenHandler = function getThenHandler(res) {
  switch (true) {
    case res.status >= 200 && res.status < 300:
      return Promise.resolve(res.text());

    case res.status === 404:
      return Promise.reject({
        error: utils["d" /* ERR */].NOT_FOUND,
        details: "".concat(res.url)
      });

    default:
      handler_debug('unhandle error: ', res);
      return Promise.reject({
        error: 10000,
        details: "".concat(res.statusText, ": unhandle")
      });
  }
};
var handler_getCatchHandler = function getCatchHandler(err) {
  /*
  if (!navigator.onLine) {
    return { error: 'NET_OFFLINE', details: 'NET_OFFLINE' }
  }
  */
  switch (true) {
    case err.error === utils["d" /* ERR */].NOT_FOUND:
      return {
        error: err.error,
        details: err.details
      };

    default:
      return {
        error: err.error,
        details: err.details
      };
  }
};
// EXTERNAL MODULE: external "rxjs/add/observable/fromPromise"
var fromPromise_ = __webpack_require__(72);
var fromPromise__default = /*#__PURE__*/__webpack_require__.n(fromPromise_);

// CONCATENATED MODULE: ./utils/network/index.js



/* import { makeDebugger } from '../../utils' */



/* eslint-disable no-unused-vars */

/* const debug = makeDebugger('Network') */

/* eslint-enable no-unused-vars */

var network_doQuery = function doQuery(query, variables) {
  return client.query({
    query: query,
    variables: variables,
    context: context
  }).then(function (res) {
    if (res.errors) return handler_formatGraphErrors(res.errors);
    return res.data;
  }).catch(handler_formatGraphErrors);
};

var network_doMutate = function doMutate(mutation, variables) {
  return client.mutate({
    mutation: mutation,
    variables: variables,
    context: context
  }).then(function (res) {
    return res.data;
  }).catch(handler_formatGraphErrors);
};

var network_GET = function GET(url) {
  return external__isomorphic_fetch__default()("".concat(url)).then(handler_getThenHandler).catch(handler_getCatchHandler);
};

var network_queryPromise = function queryPromise(_ref) {
  var query = _ref.query,
      variables = _ref.variables;
  return Observable_["Observable"].fromPromise(network_doQuery(query, variables));
};
var network_mutatePromise = function mutatePromise(_ref2) {
  var mutation = _ref2.mutation,
      variables = _ref2.variables;
  return Observable_["Observable"].fromPromise(network_doMutate(mutation, variables));
};
var network_restGetPromise = function restGetPromise(url) {
  return Observable_["Observable"].fromPromise(network_GET(url));
};
/*

const network = {
  query,
  mutate,
  GET,
}

export default network
*/
// CONCATENATED MODULE: ./utils/network/sr71.js


function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }














var sr71_SR71 =
/*#__PURE__*/
function () {
  function SR71() {
    var _this = this;

    var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
      resv_event: ''
    };

    _classCallCheck(this, SR71);

    this.getInput$ = new Subject_["Subject"]();
    this.queryInput$ = new Subject_["Subject"]();
    this.mutateInput$ = new Subject_["Subject"]();
    this.stop$ = new Subject_["Subject"]();
    this.eventInput$ = new Subject_["Subject"]();
    this.resv_event = opts.resv_event;
    this.initEventSubscription();
    /* this.query$ = this.queryInput$.debounceTime(300).switchMap(q => */

    this.query$ = this.queryInput$.switchMap(function (q) {
      return network_queryPromise(q).timeoutWith(TIMEOUT_THRESHOLD, TimoutObservable).takeUntil(_this.stop$);
    });
    /* this.mutate$ = this.mutateInput$.debounceTime(300).switchMap(q => */

    this.mutate$ = this.mutateInput$.switchMap(function (q) {
      return network_mutatePromise(q).timeoutWith(TIMEOUT_THRESHOLD, TimoutObservable).takeUntil(_this.stop$);
    });
    /* this.restGet$ = this.getInput$.debounceTime(300).switchMap(q => */

    this.restGet$ = this.getInput$.switchMap(function (q) {
      return network_restGetPromise(q).timeoutWith(TIMEOUT_THRESHOLD, TimoutObservable).takeUntil(_this.stop$);
    });
    /* this.event$ = this.eventInput$.debounceTime(100) */

    this.event$ = this.eventInput$;
    this.graphql$ = this.query$.merge(this.mutate$);
    this.data$ = this.graphql$.merge(this.restGet$, this.event$);
  } // Private


  _createClass(SR71, [{
    key: "initEventSubscription",
    value: function initEventSubscription() {
      var _this2 = this;

      if (Array.isArray(this.resv_event)) {
        forEach__default()(function (event) {
          _this2.subscriptEvent(event);
        }, this.resv_event);
      } else {
        this.subscriptEvent(this.resv_event);
      }
    } // Private

  }, {
    key: "subscriptEvent",
    value: function subscriptEvent(event) {
      var _this3 = this;

      // if (isEmptyValue(event)) return false
      // PubSub.unsubscribe(event)
      // avoid duplicate subscribe caused by HMR
      external__pubsub_js__default.a.subscribe(event, function (event, data) {
        return _this3.eventInput$.next(_defineProperty({}, event, data));
      });
    }
  }, {
    key: "stop",
    value: function stop() {
      this.stop$.next();
    }
  }, {
    key: "restGet",
    value: function restGet(url) {
      this.getInput$.next(url);
    }
  }, {
    key: "query",
    value: function query(_query) {
      var variables = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      this.queryInput$.next({
        query: _query,
        variables: variables
      });
    }
  }, {
    key: "mutate",
    value: function mutate(mutation, variables) {
      this.mutateInput$.next({
        mutation: mutation,
        variables: variables
      });
    }
  }, {
    key: "data",
    value: function data() {
      return this.data$;
    }
  }]);

  return SR71;
}();
/* const sr71$ = new SR71() */


/* harmony default export */ var sr71 = __webpack_exports__["a"] = (sr71_SR71); // export default new SR71()

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/isEmpty");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("shortid");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/compose");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/merge");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("polished");

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/not");

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/toLower");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/contains");

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/map");

/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/pickBy");

/***/ }),
/* 20 */
/***/ (function(module, exports) {

module.exports = require("timeago-react");

/***/ }),
/* 21 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/keys");

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/isNil");

/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/curry");

/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/toUpper");

/***/ }),
/* 25 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/findIndex");

/***/ }),
/* 26 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/range");

/***/ }),
/* 27 */
/***/ (function(module, exports) {

module.exports = require("react-content-loader");

/***/ }),
/* 28 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./containers/ThemeWrapper/index.js + 3 modules
var ThemeWrapper = __webpack_require__(84);

// EXTERNAL MODULE: ./containers/MultiLanguage/index.js
var MultiLanguage = __webpack_require__(85);

// EXTERNAL MODULE: ./containers/Route/index.js + 1 modules
var Route = __webpack_require__(86);

// EXTERNAL MODULE: ./containers/BodyLayout/index.js + 2 modules
var BodyLayout = __webpack_require__(87);

// EXTERNAL MODULE: ./containers/Header/index.js + 3 modules
var containers_Header = __webpack_require__(88);

// EXTERNAL MODULE: ./containers/Banner/index.js + 6 modules
var Banner = __webpack_require__(89);

// EXTERNAL MODULE: ./containers/Content/index.js + 7 modules
var Content = __webpack_require__(90);

// EXTERNAL MODULE: ./containers/Preview/index.js + 3 modules
var Preview = __webpack_require__(91);

// EXTERNAL MODULE: ./containers/Sidebar/index.js + 5 modules
var Sidebar = __webpack_require__(92);

// EXTERNAL MODULE: ./containers/Doraemon/index.js + 8 modules
var Doraemon = __webpack_require__(93);

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// CONCATENATED MODULE: ./containers/CommunityEditors/styles/index.js


var Container =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Container",
  componentId: "j9l1qs-0"
})(["margin:20px;padding:18px;background:", ";min-height:400px;box-shadow:0 1px 4px rgba(0,0,0,0.04);border-radius:3px;"], Object(utils["W" /* theme */])('preview.articleBg'));
var HeaderDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__HeaderDesc",
  componentId: "j9l1qs-1"
})(["color:", ";font-size:0.9rem;"], Object(utils["W" /* theme */])('banner.desc'));
// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// EXTERNAL MODULE: external "graphql-tag"
var external__graphql_tag_ = __webpack_require__(11);
var external__graphql_tag__default = /*#__PURE__*/__webpack_require__.n(external__graphql_tag_);

// CONCATENATED MODULE: ./containers/CommunityEditors/schema.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  query($filter: PagedUsersFilter!) {\n    pagedUsers(filter: $filter) {\n      entries {\n        id\n        nickname\n        avatar\n        location\n        bio\n      }\n      totalCount\n      pageSize\n      pageNumber\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedUsers = external__graphql_tag__default()(_templateObject);
var schema = {
  pagedUsers: pagedUsers
};
/* harmony default export */ var CommunityEditors_schema = (schema);
// EXTERNAL MODULE: ./utils/network/sr71.js + 3 modules
var sr71 = __webpack_require__(8);

// CONCATENATED MODULE: ./containers/CommunityEditors/logic.js
// import R from 'ramda'



var sr71$ = new sr71["a" /* default */]();
var sub$ = null;
/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:CommunityEditors');
/* eslint-enable no-unused-vars */

var store = null;
function loadCommunityEditors() {
  debug('loadCommunityEditors ..');
  sr71$.query(CommunityEditors_schema.pagedUsers, {
    filter: {
      page: 1,
      size: 20
    }
  });
} // ###############################
// Data & Error handlers
// ###############################

var DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedUsers'),
  action: function action(_ref) {
    var pagedUsers = _ref.pagedUsers;
    store.markState({
      pagedEditors: pagedUsers
    });
    /*
       let curView = TYPE.RESULT
       if (pagedPosts.entries.length === 0) {
       curView = TYPE.RESULT_EMPTY
       }
       store.markState({ curView, pagedPosts })
     */
  }
}];
var ErrSolver = [];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(utils["a" /* $solver */])(DataSolver, ErrSolver));
  loadCommunityEditors();
}
// CONCATENATED MODULE: ./containers/CommunityEditors/index.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * CommunityEditors
 *
 */

 // import Link from 'next/link'





/* eslint-disable no-unused-vars */

var CommunityEditors_debug = Object(utils["G" /* makeDebugger */])('C:CommunityEditors');
/* eslint-enable no-unused-vars */

var CommunityEditors_CommunityEditorsContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(CommunityEditorsContainer, _React$Component);

  function CommunityEditorsContainer() {
    _classCallCheck(this, CommunityEditorsContainer);

    return _possibleConstructorReturn(this, (CommunityEditorsContainer.__proto__ || Object.getPrototypeOf(CommunityEditorsContainer)).apply(this, arguments));
  }

  _createClass(CommunityEditorsContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var communityEditors = this.props.communityEditors;
      init(communityEditors);
    }
  }, {
    key: "render",
    value: function render() {
      var communityEditors = this.props.communityEditors;
      var pagedEditorsData = communityEditors.pagedEditorsData;
      return external__react__default.a.createElement(Container, null, external__react__default.a.createElement(HeaderDesc, null, "xxx \u793E\u533A\u5171\u6709\u7F16\u8F91/\u5FD7\u613F\u8005 14 \u4EBA\uFF0C\u540C\u65F6\u5BF9\u6240\u6709\u611F\u5174\u8DA3\u7684\u670B\u53CB\u5F00\u653E, ... \u8BE6\u60C5"), external__react__default.a.createElement("br", null), external__react__default.a.createElement("p", null, "\u53C2\u4E0E\u793E\u533A\u7684\u65E5\u5E38\u7EF4\u62A4\u7EF4\u62A4, \u5220\u9664\u704C\u6C34\u5E16\u7B49\u4F4E\u8D28\u91CF\u5185\u5BB9"), external__react__default.a.createElement("p", null, "\u7F16\u8F91\u793E\u533A wiki, \u4E0A\u4F20\u89C6\u9891\u8D44\u6599\u7B49"), external__react__default.a.createElement("p", null, "\u4E3A\u793E\u533A\u6587\u7AE0\u8BBE\u7F6E\u6807\u7B7E, \u4FBF\u4E8E\u66F4\u597D\u7684\u5206\u7C7B\u7B49"), external__react__default.a.createElement("div", null, "the user lists"), external__react__default.a.createElement(components["G" /* UserList */], {
        data: pagedEditorsData
      }));
    }
  }]);

  return CommunityEditorsContainer;
}(external__react__default.a.Component);

/* harmony default export */ var CommunityEditors = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('communityEditors'))(Object(external__mobx_react_["observer"])(CommunityEditors_CommunityEditorsContainer)));
// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: external "timeago-react"
var external__timeago_react_ = __webpack_require__(20);
var external__timeago_react__default = /*#__PURE__*/__webpack_require__.n(external__timeago_react_);

// EXTERNAL MODULE: external "ramda/src/mergeDeepRight"
var mergeDeepRight_ = __webpack_require__(154);
var mergeDeepRight__default = /*#__PURE__*/__webpack_require__.n(mergeDeepRight_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// CONCATENATED MODULE: ./containers/Comments/schema.js
var schema__templateObject = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  query pagedComments(\n    $id: ID!\n    $filter: CommentsFilter!\n    $userHasLogin: Boolean!\n  ) {\n    pagedComments(id: $id, filter: $filter) {\n      entries {\n        id\n        body\n        floor\n        author {\n          id\n          nickname\n          avatar\n        }\n        viewerHasLiked @include(if: $userHasLogin)\n        viewerHasDisliked @include(if: $userHasLogin)\n        replyTo {\n          id\n          body\n          floor\n          author {\n            id\n            avatar\n            nickname\n          }\n        }\n        replies(filter: { first: 5 }) {\n          id\n          author {\n            id\n            avatar\n            nickname\n          }\n        }\n        repliesCount\n        likesCount\n        dislikesCount\n        insertedAt\n        updatedAt\n      }\n      pageNumber\n      pageSize\n      totalCount\n      totalPages\n    }\n  }\n"]),
    _templateObject2 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!, $body: String!) {\n    createComment(thread: $thread, id: $id, body: $body) {\n      id\n      body\n    }\n  }\n"]),
    _templateObject3 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!, $body: String!) {\n    replyComment(thread: $thread, id: $id, body: $body) {\n      id\n      body\n    }\n  }\n"]),
    _templateObject4 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!) {\n    deleteComment(thread: $thread, id: $id) {\n      id\n    }\n  }\n"]),
    _templateObject5 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!) {\n    likeComment(thread: $thread, id: $id) {\n      id\n      viewerHasLiked\n      likesCount\n    }\n  }\n"]),
    _templateObject6 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!) {\n    undoLikeComment(thread: $thread, id: $id) {\n      id\n      viewerHasLiked\n      likesCount\n    }\n  }\n"]),
    _templateObject7 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!) {\n    dislikeComment(thread: $thread, id: $id) {\n      id\n      viewerHasDisliked\n      dislikesCount\n    }\n  }\n"]),
    _templateObject8 = /*#__PURE__*/ schema__taggedTemplateLiteral(["\n  mutation($thread: CmsThread, $id: ID!) {\n    undoDislikeComment(thread: $thread, id: $id) {\n      id\n      viewerHasDisliked\n      dislikesCount\n    }\n  }\n"]);

function schema__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedComments = external__graphql_tag__default()(schema__templateObject);
var schema_createComment = external__graphql_tag__default()(_templateObject2);
var schema_replyComment = external__graphql_tag__default()(_templateObject3);
var schema_deleteComment = external__graphql_tag__default()(_templateObject4);
var likeComment = external__graphql_tag__default()(_templateObject5);
var undoLikeComment = external__graphql_tag__default()(_templateObject6);
var dislikeComment = external__graphql_tag__default()(_templateObject7);
var undoDislikeComment = external__graphql_tag__default()(_templateObject8);
var schema_schema = {
  pagedComments: pagedComments,
  createComment: schema_createComment,
  replyComment: schema_replyComment,
  deleteComment: schema_deleteComment,
  likeComment: likeComment,
  undoLikeComment: undoLikeComment,
  dislikeComment: dislikeComment,
  undoDislikeComment: undoDislikeComment
};
/* harmony default export */ var Comments_schema = (schema_schema);
// CONCATENATED MODULE: ./containers/Comments/logic.js





var logic_sr71$ = new sr71["a" /* default */]();
var logic_sub$ = null;
/* eslint-disable no-unused-vars */

var logic_debug = Object(utils["G" /* makeDebugger */])('L:Comments');
/* eslint-enable no-unused-vars */

var logic_store = null;
/* DESC_INSERTED, ASC_INSERTED */

var defaultArgs = {
  fresh: false,
  filter: {
    page: 1,
    size: config["h" /* PAGE_SIZE */].COMMENTS,
    sort: utils["k" /* TYPE */].ASC_INSERTED
  }
};
var logic_loadComents = function loadComents() {
  var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  // debug('loadComents passed in: ', args)
  args = mergeDeepRight__default()(defaultArgs, args);
  args.id = logic_store.viewingArticle.id;
  args.userHasLogin = logic_store.isLogin;
  markLoading(args.fresh);
  logic_store.markState({
    filterType: args.filter.sort
  });
  logic_sr71$.query(Comments_schema.pagedComments, args);
};

var markLoading = function markLoading(fresh) {
  if (fresh) {
    return logic_store.markState({
      loadingFresh: true
    });
  }

  return logic_store.markState({
    loading: true
  });
};

function logic_createComment() {
  // TODO: validation...
  logic_store.markState({
    creating: true
  });
  var args = {
    id: logic_store.viewingArticle.id,
    body: logic_store.editContent
  };
  logic_debug('createComment args: ', args);
  logic_sr71$.mutate(Comments_schema.createComment, args);
}
function createCommentPreview() {
  logic_store.markState({
    showInputEditor: false,
    showInputPreview: true
  });
}
function backToEditor() {
  logic_store.markState({
    showInputEditor: true,
    showInputPreview: false
  });
}
function previewReply(data) {
  logic_debug('previewReply --> : ', data);
}
function openInputBox() {
  logic_store.markState({
    showInputBox: true,
    showInputEditor: true
  });
}
function openCommentEditor() {
  logic_store.markState({
    showInputEditor: true
  });
}
function onCommentInputBlur() {
  logic_store.markState({
    showInputBox: false,
    showInputPreview: false,
    showInputEditor: false
  });
}
function createReplyComment() {
  logic_sr71$.mutate(Comments_schema.replyComment, {
    id: logic_store.replyToComment.id,
    body: logic_store.replyContent
  });
}
function onCommentInputChange(editContent) {
  logic_store.markState({
    countCurrent: Object(utils["r" /* countWords */])(editContent),
    extractMentions: Object(utils["w" /* extractMentions */])(editContent),
    editContent: editContent
  });
}
function onReplyInputChange(replyContent) {
  logic_store.markState({
    countCurrent: Object(utils["r" /* countWords */])(replyContent),
    extractMentions: Object(utils["w" /* extractMentions */])(replyContent),
    replyContent: replyContent
  });
}
function openReplyEditor(data) {
  logic_store.markState({
    showReplyBox: true,
    showReplyEditor: true,
    showReplyPreview: false,
    replyToComment: data
  });
}
function replyCommentPreview() {
  logic_debug('replyCommentPreview');
  logic_store.markState({
    showReplyEditor: false,
    showReplyPreview: true
  });
}
function replyBackToEditor() {
  logic_store.markState({
    showReplyEditor: true,
    showReplyPreview: false
  });
}
function closeReplyBox() {
  logic_store.markState({
    showReplyBox: false,
    showReplyEditor: false,
    showReplyPreview: false
  });
}
function onFilterChange(filterType) {
  logic_store.markState({
    filterType: filterType
  });
  logic_loadComents({
    filter: {
      page: 1,
      sort: filterType
    }
  });
}
function toggleLikeComment(comment) {
  // TODO: check login first
  logic_debug('likeComment: ', comment);

  if (comment.viewerHasLiked) {
    return logic_sr71$.mutate(Comments_schema.undoLikeComment, {
      id: comment.id
    });
  }

  return logic_sr71$.mutate(Comments_schema.likeComment, {
    id: comment.id
  });
}
function toggleDislikeComment(comment) {
  // TODO: check login first
  if (comment.viewerHasDisliked) {
    return logic_sr71$.mutate(Comments_schema.undoDislikeComment, {
      id: comment.id
    });
  }

  return logic_sr71$.mutate(Comments_schema.dislikeComment, {
    id: comment.id
  });
}
function insertCode() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].DRAFT_INSERT_SNIPPET, {
    type: 'FUCK',
    data: '```javascript\n\n```'
  });
}
function onMention(user) {
  logic_debug('onMention: ', user);
  logic_store.addReferUser(user);
}
function logic_deleteComment() {
  logic_sr71$.mutate(Comments_schema.deleteComment, {
    id: logic_store.tobeDeleteId
  });
} // show delete confirm

function onDelete(comment) {
  logic_store.markState({
    tobeDeleteId: comment.id
  });
}
function cancleDelete() {
  logic_store.markState({
    tobeDeleteId: null
  });
}
function pageChange() {
  var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  Object(utils["Q" /* scrollIntoEle */])('lists-info');
  logic_loadComents({
    filter: {
      page: page,
      sort: logic_store.filterType
    }
  });
}

var cancelLoading = function cancelLoading() {
  logic_store.markState({
    loading: false,
    loadingFresh: false,
    creating: false
  });
}; // ###############################
// Data & Error handlers
// ###############################


var logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW),
  action: function action() {}
}, {
  match: Object(utils["n" /* asyncRes */])('pagedComments'),
  action: function action(_ref) {
    var pagedComments = _ref.pagedComments;
    cancelLoading();
    logic_store.markState({
      pagedComments: pagedComments
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('createComment'),
  action: function action(_ref2) {
    var createComment = _ref2.createComment;
    logic_debug('createComment', createComment);
    logic_store.markState({
      showInputEditor: false,
      editContent: ''
    });
    logic_loadComents({
      filter: {
        page: 1,
        sort: utils["k" /* TYPE */].DESC_INSERTED
      },
      fresh: true
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('replyComment'),
  action: function action(_ref3) {
    var replyComment = _ref3.replyComment;
    logic_debug('replyComment', replyComment);
    logic_store.markState({
      showReplyBox: false,
      replyToComment: null
    });
    Object(utils["Q" /* scrollIntoEle */])('lists-info');
    logic_loadComents({
      filter: {
        page: 1
      },
      fresh: true
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('likeComment'),
  action: function action(_ref4) {
    var likeComment = _ref4.likeComment;
    return logic_store.updateOneComment(likeComment.id, likeComment);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('undoLikeComment'),
  action: function action(_ref5) {
    var undoLikeComment = _ref5.undoLikeComment;
    return logic_store.updateOneComment(undoLikeComment.id, undoLikeComment);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('dislikeComment'),
  action: function action(_ref6) {
    var dislikeComment = _ref6.dislikeComment;
    return logic_store.updateOneComment(dislikeComment.id, dislikeComment);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('undoDislikeComment'),
  action: function action(_ref7) {
    var undoDislikeComment = _ref7.undoDislikeComment;
    return logic_store.updateOneComment(undoDislikeComment.id, undoDislikeComment);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('deleteComment'),
  action: function action(_ref8) {
    var deleteComment = _ref8.deleteComment;
    logic_debug('deleteComment', deleteComment);
    logic_store.markState({
      tobeDeleteId: null
    });
    Object(utils["Q" /* scrollIntoEle */])('lists-info');
    logic_loadComents({
      filter: {
        page: 1
      },
      fresh: true
    });
  }
}];
var logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref9) {
    var details = _ref9.details;
    logic_debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref10) {
    var details = _ref10.details;
    logic_debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref11) {
    var details = _ref11.details;
    logic_debug('ERR.NETWORK -->', details);
  }
}];
function logic_init(_store) {
  if (logic_store) {
    logic_loadComents();
    return false;
  }

  logic_store = _store;
  if (logic_sub$) logic_sub$.unsubscribe();
  logic_sub$ = logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(logic_DataSolver, logic_ErrSolver));
  logic_loadComents();
}
// EXTERNAL MODULE: external "react-click-outside"
var external__react_click_outside_ = __webpack_require__(76);
var external__react_click_outside__default = /*#__PURE__*/__webpack_require__.n(external__react_click_outside_);

// EXTERNAL MODULE: ./containers/TypeWriter/BodyEditor.js + 2 modules
var BodyEditor = __webpack_require__(52);

// CONCATENATED MODULE: ./containers/Comments/styles/comment_editor.js




var comment_editor_Container =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__Container",
  componentId: "s4o9j1a-0"
})(["background:", ";min-height:", ";height:auto;border-color:", ";display:flex;flex-direction:column;transition:all 0.3s;box-shadow:0 1px 4px rgba(0,0,0,0.04);border-radius:3px;"], Object(utils["W" /* theme */])('preview.articleBg'), function (_ref) {
  var show = _ref.show;
  return show ? '100px' : '70px';
}, Object(utils["W" /* theme */])('preview.articleBg'));
var InputHeaderWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__InputHeaderWrapper",
  componentId: "s4o9j1a-1"
})(["height:70px;display:flex;align-items:center;margin-right:20px;"]);
var InputEditorWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__InputEditorWrapper",
  componentId: "s4o9j1a-2"
})(["height:auto;margin:0 30px;margin-bottom:30px;display:", ";font-size:0.9em;"], function (_ref2) {
  var showInputEditor = _ref2.showInputEditor;
  return showInputEditor ? 'block' : 'none';
});
var UserAvatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "comment_editor__UserAvatar",
  componentId: "s4o9j1a-3"
})(["width:40px;height:40px;border-radius:50%;margin-left:4%;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var LeaveResponseText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__LeaveResponseText",
  componentId: "s4o9j1a-4"
})(["font-size:1.3em;margin-left:15px;color:", ";"], Object(utils["W" /* theme */])('comment.placeholder'));
var LeaveResponseUsername =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__LeaveResponseUsername",
  componentId: "s4o9j1a-5"
})(["font-size:1.3em;margin-left:12px;margin-right:10px;color:", ";"], Object(utils["W" /* theme */])('comment.username'));
var ReferToIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "comment_editor__ReferToIcon",
  componentId: "s4o9j1a-6"
})(["fill:", ";width:20px;height:20px;margin-right:5px;margin-top:5px;"], Object(utils["W" /* theme */])('comment.username'));
var ReplyAvatars =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__ReplyAvatars",
  componentId: "s4o9j1a-7"
})([""]);
var CounterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__CounterWrapper",
  componentId: "s4o9j1a-8"
})(["display:flex;align-items:center;color:#c2d9da;"]);
var CounterSpliter =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__CounterSpliter",
  componentId: "s4o9j1a-9"
})(["font-size:1.5em;font-weight:lighter;color:", ";"], Object(utils["W" /* theme */])('comment.placeholder'));

var comment_editor_getColor = function getColor(num) {
  if (num > config["j" /* WORD_LIMIT */].COMMENT) {
    return 'tomato';
  }

  if (num >= config["j" /* WORD_LIMIT */].COMMENT - 50 && num <= config["j" /* WORD_LIMIT */].COMMENT) {
    return 'orange';
  }

  return 'yellowgreen';
};

var CounterCur =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__CounterCur",
  componentId: "s4o9j1a-10"
})(["margin-right:5px;font-size:1em;color:", ";"], function (_ref3) {
  var num = _ref3.num;
  return comment_editor_getColor(num);
});
var CounterTotal =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__CounterTotal",
  componentId: "s4o9j1a-11"
})(["margin-left:5px;margin-right:5px;font-size:1em;color:", ";"], Object(utils["W" /* theme */])('comment.placeholder'));
var PreviewerWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_editor__PreviewerWrapper",
  componentId: "s4o9j1a-12"
})(["padding:0 33px;min-height:150px;"]);
// CONCATENATED MODULE: ./containers/Comments/styles/editor_footer.js



var InputFooter =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editor_footer__InputFooter",
  componentId: "bb6f4w-0"
})(["display:flex;padding:0 10px;margin-bottom:10px;margin-left:20px;margin-right:15px;"]);
var InputHelper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editor_footer__InputHelper",
  componentId: "bb6f4w-1"
})(["flex-grow:1;display:flex;"]);
var HelperIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "editor_footer__HelperIcon",
  componentId: "bb6f4w-2"
})(["fill:", ";width:20px;height:20px;margin-right:8px;&:hover{fill:#51abb2;cursor:pointer;}"], Object(utils["W" /* theme */])('comment.placeholder'));
var InputSubmit =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editor_footer__InputSubmit",
  componentId: "bb6f4w-3"
})([""]);
// CONCATENATED MODULE: ./containers/Comments/EditorFooter.js






var EditorFooter_EditorFooter = function EditorFooter(_ref) {
  var loading = _ref.loading,
      showPreview = _ref.showPreview,
      onCreate = _ref.onCreate,
      onBackEdit = _ref.onBackEdit,
      onPreview = _ref.onPreview;
  return external__react__default.a.createElement(InputFooter, null, showPreview ? external__react__default.a.createElement(InputHelper, null) : external__react__default.a.createElement(InputHelper, null, external__react__default.a.createElement("div", {
    onClick: insertCode
  }, external__react__default.a.createElement(HelperIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_code.svg")
  })), external__react__default.a.createElement(HelperIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_quote.svg")
  }), external__react__default.a.createElement(HelperIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_image.svg")
  })), external__react__default.a.createElement(InputSubmit, null, showPreview ? external__react__default.a.createElement(components["d" /* Button */], {
    type: "primary",
    ghost: true,
    size: "small",
    onClick: onBackEdit
  }, "\u8FD4\u56DE\u7F16\u8F91") : external__react__default.a.createElement(components["d" /* Button */], {
    type: "primary",
    ghost: true,
    size: "small",
    onClick: onPreview
  }, "\u9884", external__react__default.a.createElement(components["v" /* Space */], {
    right: "5px"
  }), "\u89C8"), external__react__default.a.createElement(components["v" /* Space */], {
    right: "10px"
  }), !loading ? external__react__default.a.createElement(components["d" /* Button */], {
    type: "primary",
    size: "small",
    onClick: onCreate
  }, "\u63D0", external__react__default.a.createElement(components["v" /* Space */], {
    right: "5px"
  }), "\u4EA4") : external__react__default.a.createElement(components["d" /* Button */], {
    type: "primary",
    size: "small"
  }, external__react__default.a.createElement(components["k" /* Icon */], {
    type: "loading"
  }), "\u63D0", external__react__default.a.createElement(components["v" /* Space */], {
    right: "5px"
  }), "\u4EA4")));
};

/* harmony default export */ var Comments_EditorFooter = (EditorFooter_EditorFooter);
// CONCATENATED MODULE: ./containers/Comments/CommentEditor.js
function CommentEditor__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { CommentEditor__typeof = function _typeof(obj) { return typeof obj; }; } else { CommentEditor__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return CommentEditor__typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function CommentEditor__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function CommentEditor__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function CommentEditor__createClass(Constructor, protoProps, staticProps) { if (protoProps) CommentEditor__defineProperties(Constructor.prototype, protoProps); if (staticProps) CommentEditor__defineProperties(Constructor, staticProps); return Constructor; }

function CommentEditor__possibleConstructorReturn(self, call) { if (call && (CommentEditor__typeof(call) === "object" || typeof call === "function")) { return call; } return CommentEditor__assertThisInitialized(self); }

function CommentEditor__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function CommentEditor__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }











var CommentEditor_WordsCounter = function WordsCounter(_ref) {
  var countCurrent = _ref.countCurrent;
  return external__react__default.a.createElement(CounterWrapper, null, external__react__default.a.createElement(CounterCur, {
    num: countCurrent
  }, countCurrent), external__react__default.a.createElement(CounterSpliter, null, "/"), external__react__default.a.createElement(CounterTotal, null, config["j" /* WORD_LIMIT */].COMMENT));
};

var CommentEditor_Header = function Header(_ref2) {
  var accountInfo = _ref2.accountInfo,
      showInputEditor = _ref2.showInputEditor,
      showInputPreview = _ref2.showInputPreview,
      countCurrent = _ref2.countCurrent,
      referUsers = _ref2.referUsers;

  if (showInputEditor) {
    return external__react__default.a.createElement(InputHeaderWrapper, null, external__react__default.a.createElement(UserAvatar, {
      src: accountInfo.avatar
    }), external__react__default.a.createElement(LeaveResponseUsername, null, accountInfo.nickname), referUsers.length > 0 ? external__react__default.a.createElement("div", {
      style: {
        display: 'flex'
      }
    }, external__react__default.a.createElement(ReferToIcon, {
      src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/refer.svg")
    }), external__react__default.a.createElement(ReplyAvatars, null, external__react__default.a.createElement(components["c" /* AvatarsRow */], {
      users: referUsers,
      total: referUsers.length,
      height: "20px"
    }))) : null, external__react__default.a.createElement(components["w" /* SpaceGrow */], null), external__react__default.a.createElement(CommentEditor_WordsCounter, {
      countCurrent: countCurrent
    }));
  }

  if (showInputPreview) {
    return external__react__default.a.createElement(InputHeaderWrapper, null, external__react__default.a.createElement(UserAvatar, {
      src: accountInfo.avatar
    }), external__react__default.a.createElement(LeaveResponseUsername, null, accountInfo.nickname));
  }

  return external__react__default.a.createElement(InputHeaderWrapper, null, external__react__default.a.createElement(UserAvatar, {
    src: accountInfo.avatar
  }), external__react__default.a.createElement(LeaveResponseText, {
    onClick: openInputBox
  }, "\u7559\u6761\u8BC4\u8BBA..."));
};

var CommentEditor_InputEditor = function InputEditor(_ref3) {
  var showInputEditor = _ref3.showInputEditor,
      showInputPreview = _ref3.showInputPreview,
      body = _ref3.body,
      mentions = _ref3.mentions,
      creating = _ref3.restProps.creating;
  return external__react__default.a.createElement("div", {
    className: "comment-editor"
  }, external__react__default.a.createElement(InputEditorWrapper, {
    showInputEditor: showInputEditor
  }, external__react__default.a.createElement(BodyEditor["a" /* default */], {
    mentions: mentions,
    onChange: Object(utils["t" /* debounce */])(onCommentInputChange, 450),
    onMention: onMention,
    body: body
  })), external__react__default.a.createElement(Comments_EditorFooter, {
    loading: creating,
    showPreview: showInputPreview,
    onCreate: logic_createComment,
    onBackEdit: backToEditor,
    onPreview: createCommentPreview
  }));
};

var CommentEditor_mentions = [{
  id: 112,
  name: 'mydearxym',
  avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4'
}, {
  id: 113,
  name: 'Julian',
  avatar: 'http://coderplanets.oss-cn-beijing.aliyuncs.com/mock/avatar4.png'
}];

var CommentEditor_CommentEditor =
/*#__PURE__*/
function (_React$Component) {
  CommentEditor__inherits(CommentEditor, _React$Component);

  function CommentEditor() {
    CommentEditor__classCallCheck(this, CommentEditor);

    return CommentEditor__possibleConstructorReturn(this, (CommentEditor.__proto__ || Object.getPrototypeOf(CommentEditor)).apply(this, arguments));
  }

  CommentEditor__createClass(CommentEditor, [{
    key: "handleClickOutside",

    /* eslint-disable */
    value: function handleClickOutside() {
      onCommentInputBlur();
    }
    /* eslint-enable */
    //  <Container show={!showInputEditor && !showInputPreview}>

  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          referUsers = _props.referUsers,
          accountInfo = _props.accountInfo,
          _props$restProps = _props.restProps,
          countCurrent = _props$restProps.countCurrent,
          showInputBox = _props$restProps.showInputBox,
          showInputEditor = _props$restProps.showInputEditor,
          showInputPreview = _props$restProps.showInputPreview,
          editContent = _props$restProps.editContent,
          creating = _props$restProps.creating;
      return external__react__default.a.createElement(comment_editor_Container, {
        show: showInputBox
      }, external__react__default.a.createElement(CommentEditor_Header, {
        accountInfo: accountInfo,
        showInputEditor: showInputEditor,
        showInputPreview: showInputPreview,
        countCurrent: countCurrent,
        referUsers: referUsers
      }), showInputEditor ? external__react__default.a.createElement(CommentEditor_InputEditor, {
        mentions: CommentEditor_mentions,
        showInputPreview: showInputPreview,
        showInputEditor: showInputEditor,
        body: editContent,
        restProps: _objectSpread({}, this.props)
      }) : external__react__default.a.createElement("div", null), showInputPreview ? external__react__default.a.createElement("div", null, external__react__default.a.createElement(PreviewerWrapper, null, external__react__default.a.createElement(components["n" /* MarkDownRender */], {
        body: editContent
      })), external__react__default.a.createElement(Comments_EditorFooter, {
        loading: creating,
        showPreview: showInputPreview,
        onCreate: logic_createComment,
        onBackEdit: backToEditor,
        onPreview: createCommentPreview
      })) : external__react__default.a.createElement("div", null));
    }
  }]);

  return CommentEditor;
}(external__react__default.a.Component);

/* harmony default export */ var Comments_CommentEditor = (external__react_click_outside__default()(CommentEditor_CommentEditor));
// EXTERNAL MODULE: external "ramda/src/pluck"
var pluck_ = __webpack_require__(155);
var pluck__default = /*#__PURE__*/__webpack_require__.n(pluck_);

// EXTERNAL MODULE: external "ramda/src/clone"
var clone_ = __webpack_require__(56);
var clone__default = /*#__PURE__*/__webpack_require__.n(clone_);

// EXTERNAL MODULE: external "ramda/src/forEach"
var forEach_ = __webpack_require__(43);
var forEach__default = /*#__PURE__*/__webpack_require__.n(forEach_);

// EXTERNAL MODULE: external "ramda/src/isEmpty"
var isEmpty_ = __webpack_require__(9);
var isEmpty__default = /*#__PURE__*/__webpack_require__.n(isEmpty_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// CONCATENATED MODULE: ./containers/Comments/styles/comments_filter.js
var comments_filter__templateObject = /*#__PURE__*/ comments_filter__taggedTemplateLiteral(["\n  animation: ", " 0.6s linear;\n"]);

function comments_filter__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var FilterWraper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_filter__FilterWraper",
  componentId: "s4i9jn7-0"
})(["margin-right:8px;margin-top:8px;display:", ";", ";"], function (_ref) {
  var show = _ref.show;
  return show ? 'block' : 'none';
}, utils["S" /* smokey */]);
var comments_filter_Header =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_filter__Header",
  componentId: "s4i9jn7-1"
})(["display:flex;color:", ";"], Object(utils["W" /* theme */])('comment.title'));
var FilterIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "comments_filter__FilterIcon",
  componentId: "s4i9jn7-2"
})(["fill:", ";margin-right:3px;width:20px;height:20px;transform:", ";"], Object(utils["W" /* theme */])('comment.title'), function (_ref2) {
  var reverse = _ref2.reverse;
  return reverse ? 'rotate(180deg)' : '';
});
var RecentlyIcon = FilterIcon.extend(comments_filter__templateObject, utils["b" /* Animate */].rotate360); // animation: ${Animate.rotate360} 1s cubic-bezier(0, 0.56, 0.24, 0.72);

var MenuWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_filter__MenuWrapper",
  componentId: "s4i9jn7-3"
})(["width:80px;display:flex;flex-direction:column;align-items:center;margin-top:10px;"]);
var MenuItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_filter__MenuItem",
  componentId: "s4i9jn7-4"
})(["margin-bottom:10px;color:", ";&:hover{cursor:pointer;color:", ";}"], function (_ref3) {
  var active = _ref3.active,
      type = _ref3.type;
  return active === type ? Object(utils["W" /* theme */])('comment.filterActive') : Object(utils["W" /* theme */])('comment.filter');
}, Object(utils["W" /* theme */])('comment.filterActive'));
// CONCATENATED MODULE: ./containers/Comments/CommentsFilter.js
var _this = this;







var filterDict = {
  DESC_INSERTED: '最新创建',
  ASC_INSERTED: '综合排序',
  MOST_LIKES: '最多顶',
  MOST_DISLIKES: '最多踩'
};

var CommentsFilter_Menus = function Menus(_ref) {
  var active = _ref.active;
  return external__react__default.a.createElement(MenuWrapper, null, external__react__default.a.createElement(MenuItem, {
    onClick: onFilterChange.bind(_this, utils["k" /* TYPE */].ASC_INSERTED),
    type: utils["k" /* TYPE */].ASC_INSERTED,
    active: active
  }, "\u7EFC\u5408\u6392\u5E8F"), external__react__default.a.createElement(MenuItem, {
    onClick: onFilterChange.bind(_this, utils["k" /* TYPE */].DESC_INSERTED),
    type: utils["k" /* TYPE */].DESC_INSERTED,
    active: active
  }, "\u6700\u8FD1\u521B\u5EFA"), external__react__default.a.createElement(MenuItem, {
    onClick: onFilterChange.bind(_this, utils["k" /* TYPE */].MOST_LIKES),
    type: utils["k" /* TYPE */].MOST_LIKES,
    active: active
  }, "\u6700\u591A\u9876"), external__react__default.a.createElement(MenuItem, {
    onClick: onFilterChange.bind(_this, utils["k" /* TYPE */].MOST_DISLIKES),
    type: utils["k" /* TYPE */].MOST_DISLIKES,
    active: active
  }, "\u6700\u591A\u8E29"));
};

var CommentsFilter_renderFilterIcon = function renderFilterIcon(filterType) {
  switch (filterType) {
    case utils["k" /* TYPE */].DESC_INSERTED:
      {
        return external__react__default.a.createElement(RecentlyIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/recent.svg")
        });
      }

    case utils["k" /* TYPE */].MOST_LIKES:
      {
        return external__react__default.a.createElement(FilterIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/up.svg")
        });
      }

    case utils["k" /* TYPE */].MOST_DISLIKES:
      {
        return external__react__default.a.createElement(FilterIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/up.svg"),
          reverse: true
        });
      }

    default:
      {
        return external__react__default.a.createElement(FilterIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/filter2.svg")
        });
      }
  }
};

var CommentsFilter_CommentsFilter = function CommentsFilter(_ref2) {
  var filterType = _ref2.filterType,
      show = _ref2.show;
  return external__react__default.a.createElement(FilterWraper, {
    show: show
  }, external__react__default.a.createElement(components["s" /* Popover */], {
    content: external__react__default.a.createElement(CommentsFilter_Menus, {
      active: filterType
    })
  }, external__react__default.a.createElement(comments_filter_Header, null, CommentsFilter_renderFilterIcon(filterType), filterDict[filterType])));
};

/* harmony default export */ var Comments_CommentsFilter = (CommentsFilter_CommentsFilter);
// CONCATENATED MODULE: ./containers/Comments/styles/index.js


var Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "kpb5uu-0"
})([""]);
var ReplyBarBase =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ReplyBarBase",
  componentId: "kpb5uu-1"
})(["color:", ";background:", ";border-radius:3px;padding:5px 10px;margin-left:10px;margin-right:10px;margin-bottom:8px;display:flex;"], Object(utils["W" /* theme */])('comment.reply'), Object(utils["W" /* theme */])('comment.replyBg'));
var ReplyToBodyBase =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ReplyToBodyBase",
  componentId: "kpb5uu-2"
})(["color:", ";margin-left:10px;margin-right:20px;width:350px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-style:italic;flex-grow:1;"], Object(utils["W" /* theme */])('comment.title'));
var ReplyToFloorBase =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ReplyToFloorBase",
  componentId: "kpb5uu-3"
})(["color:", ";margin-right:5px;"], Object(utils["W" /* theme */])('comment.floor'));
// CONCATENATED MODULE: ./containers/Comments/styles/comments_list.js
var comments_list__templateObject = /*#__PURE__*/ comments_list__taggedTemplateLiteral(["\n  margin-left: -2px;\n"]),
    comments_list__templateObject2 = /*#__PURE__*/ comments_list__taggedTemplateLiteral([""]);

function comments_list__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }





var ReplyBar = ReplyBarBase.extend(comments_list__templateObject);
var ReplyToBody = ReplyToBodyBase.extend(comments_list__templateObject2);
var ReplyToFloor = ReplyToFloorBase.extend(comments_list__templateObject2); // min-height: 300px;

var ListsContainer =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__ListsContainer",
  componentId: "s3ze478-0"
})(["", ";border-radius:4px;"], utils["p" /* column */]);
var TotalHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__TotalHeader",
  componentId: "s3ze478-1"
})(["display:flex;align-items:center;margin-top:25px;margin-bottom:10px;"]);
var TotalCountWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__TotalCountWrapper",
  componentId: "s3ze478-2"
})(["flex-grow:1;"]);
var ListTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__ListTitle",
  componentId: "s3ze478-3"
})(["color:", ";font-size:1rem;margin-left:2px;"], Object(utils["W" /* theme */])('comment.title'));
var TotalNum =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "comments_list__TotalNum",
  componentId: "s3ze478-4"
})(["color:", ";font-size:1.3em;"], Object(utils["W" /* theme */])('comment.number'));
var FloorNum =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__FloorNum",
  componentId: "s3ze478-5"
})(["color:", ";font-size:1rem;align-self:center;margin-left:5px;flex-grow:1;"], Object(utils["W" /* theme */])('comment.floor'));
var CommentBlock =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentBlock",
  componentId: "s3ze478-6"
})(["display:flex;margin-bottom:16px;padding:15px;padding-left:20px;position:relative;box-shadow:0 1px 4px rgba(0,0,0,0.04);border-radius:3px;background:", ";"], Object(utils["W" /* theme */])('preview.articleBg')); // filter: blur(3px);

var CommentWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentWrapper",
  componentId: "s3ze478-7"
})(["display:flex;flex-grow:1;filter:", ";"], function (_ref) {
  var tobeDelete = _ref.tobeDelete;
  return tobeDelete ? 'blur(3px)' : '';
});
var DeleteHintText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__DeleteHintText",
  componentId: "s3ze478-8"
})(["color:tomato;font-size:1.3em;margin-bottom:10px;"]);
var DeleteOverlay =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__DeleteOverlay",
  componentId: "s3ze478-9"
})(["position:absolute;margin-top:-15px;margin-left:-20px;width:100%;height:100%;border-radius:5px;z-index:10;display:flex;flex-direction:column;align-items:center;justify-content:center;visibility:", ";animation:", " 0.3s linear;"], function (_ref2) {
  var show = _ref2.show;
  return show ? 'visible' : 'hidden';
}, utils["b" /* Animate */].pulse);
var DeleteBtnGroup =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__DeleteBtnGroup",
  componentId: "s3ze478-10"
})(["display:flex;"]);
var CommentUserInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentUserInfo",
  componentId: "s3ze478-11"
})(["margin-right:15px;"]);
var CommentAvatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "comments_list__CommentAvatar",
  componentId: "s3ze478-12"
})(["width:45px;height:45px;border-radius:50%;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var CommentHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentHeader",
  componentId: "s3ze478-13"
})(["margin-bottom:12px;", ";"], utils["p" /* column */]);
var CommentHeaderFirst =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentHeaderFirst",
  componentId: "s3ze478-14"
})(["display:flex;"]);
var CommentUserName =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentUserName",
  componentId: "s3ze478-15"
})(["color:", ";font-size:1.3em;display:flex;flex-grow:1;"], Object(utils["W" /* theme */])('comment.username'));
var TimeStamps =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__TimeStamps",
  componentId: "s3ze478-16"
})(["color:", ";"], Object(utils["W" /* theme */])('comment.placeholder'));
var CommentBodyInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentBodyInfo",
  componentId: "s3ze478-17"
})(["width:100%;", ";"], utils["p" /* column */]);
var CommentContent =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentContent",
  componentId: "s3ze478-18"
})(["font-size:1.1em;"]);
var CommentFooter =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__CommentFooter",
  componentId: "s3ze478-19"
})(["margin-top:15px;display:flex;"]);
var Actions =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__Actions",
  componentId: "s3ze478-20"
})(["display:flex;flex-grow:1;margin-left:-4px;"]);
var ReplyUsers =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__ReplyUsers",
  componentId: "s3ze478-21"
})(["display:flex;margin-top:-4px;"]);
var ReplyTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__ReplyTitle",
  componentId: "s3ze478-22"
})(["color:", ";margin-top:4px;margin-right:5px;"], Object(utils["W" /* theme */])('comment.reply'));
var VisiableAction =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__VisiableAction",
  componentId: "s3ze478-23"
})(["display:flex;color:", ";margin-right:10px;&:hover{cursor:pointer;font-weight:bold;}"], Object(utils["W" /* theme */])('comment.action'));
var ActionNumber =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__ActionNumber",
  componentId: "s3ze478-24"
})(["font-size:1.2em;color:", ";"], Object(utils["W" /* theme */])('comment.action'));
var LikeIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "comments_list__LikeIcon",
  componentId: "s3ze478-25"
})(["fill:", ";margin-right:3px;margin-top:2px;width:20px;height:20px;"], Object(utils["W" /* theme */])('comment.icon'));
var UpIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "comments_list__UpIcon",
  componentId: "s3ze478-26"
})(["fill:", ";margin-right:3px;margin-top:2px;width:20px;height:20px;transform:", ";", ";"], function (_ref3) {
  var viewerDid = _ref3.viewerDid;
  return viewerDid ? Object(utils["W" /* theme */])('comment.didIcon') : Object(utils["W" /* theme */])('comment.icon');
}, function (_ref4) {
  var reverse = _ref4.reverse;
  return reverse ? 'rotate(180deg)' : '';
}, utils["S" /* smokey */]);
var ReplyIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "comments_list__ReplyIcon",
  componentId: "s3ze478-27"
})(["fill:", ";margin-right:5px;margin-top:1px;width:18px;height:18px;"], Object(utils["W" /* theme */])('comment.icon'));
var ReplyAction =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comments_list__ReplyAction",
  componentId: "s3ze478-28"
})(["display:flex;color:", ";margin-right:12px;cursor:pointer;font-weight:bold;margin-top:2px;opacity:0;", ":hover &{opacity:1;}transition:opacity 0.3s;"], Object(utils["W" /* theme */])('comment.action'), CommentBodyInfo);
// CONCATENATED MODULE: ./containers/Comments/CommentsList.js





var CommentsList__this = this;





/* import { fakeUsers, getRandomInt, Global, prettyNum } from '../../utils' */







var CommentsList_getSelection = function getSelection() {
  var selectText = utils["h" /* Global */].getSelection().toString();

  if (!isEmpty__default()(selectText)) {
    /* console.log('getSelection', selectText) */
    // TODO: then use window.getSelection().getRangeAt(0).getBoundingClientRect() to draw a button
  }
};

var CommentsList_DeleteMask = function DeleteMask(_ref) {
  var show = _ref.show;
  return external__react__default.a.createElement(DeleteOverlay, {
    show: show
  }, external__react__default.a.createElement(DeleteHintText, null, "\u5220\u9664\u540E\u8BE5\u8BE5\u8BC4\u8BBA\u5C06\u4E0D\u53EF\u6062\u590D"), external__react__default.a.createElement(DeleteBtnGroup, null, external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "red",
    ghost: true,
    onClick: cancleDelete
  }, "\u53D6\u6D88"), "\xA0\xA0", external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "red",
    onClick: logic_deleteComment
  }, "\u786E\u5B9A\u5220\u9664")));
};

var CommentsList_ActionBottom = function ActionBottom(_ref2) {
  var data = _ref2.data,
      accountInfo = _ref2.accountInfo;

  /* console.log('actionBottom data: ', data.author.id) */

  /* console.log('accountInfo --dd -->', accountInfo) */
  if (String(data.author.id) === accountInfo.id) {
    return external__react__default.a.createElement("div", {
      style: {
        display: 'flex'
      }
    }, external__react__default.a.createElement(ReplyAction, null, external__react__default.a.createElement(ReplyIcon, {
      src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/edit.svg")
    }), "\u7F16\u8F91"), external__react__default.a.createElement(ReplyAction, {
      onClick: onDelete.bind(CommentsList__this, data)
    }, external__react__default.a.createElement(ReplyIcon, {
      src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/delete.svg")
    }), "\u5220\u9664"));
  }

  return external__react__default.a.createElement("div", {
    style: {
      display: 'flex'
    }
  }, external__react__default.a.createElement(ReplyAction, {
    onClick: openReplyEditor.bind(CommentsList__this, data)
  }, external__react__default.a.createElement(ReplyIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/nest_comment.svg")
  }), "\u56DE\u590D"));
};

var CommentsList_getAuthors = function getAuthors(comment) {
  /* eslint-disable no-return-assign */
  var replies = forEach__default()(function (reply) {
    return reply.author.extra_id = reply.id;
  }, clone__default()(comment.replies));
  /* eslint-enable */


  return pluck__default()('author', replies);
};

var CommentsList_Comment = function Comment(_ref3) {
  var data = _ref3.data,
      tobeDeleteId = _ref3.tobeDeleteId,
      accountInfo = _ref3.accountInfo;
  return external__react__default.a.createElement(CommentBlock, null, external__react__default.a.createElement(CommentsList_DeleteMask, {
    show: data.id === tobeDeleteId
  }), external__react__default.a.createElement(CommentWrapper, {
    tobeDelete: data.id === tobeDeleteId
  }, external__react__default.a.createElement(CommentUserInfo, null, external__react__default.a.createElement(CommentAvatar, {
    src: data.author.avatar
  })), external__react__default.a.createElement(CommentBodyInfo, {
    onMouseUp: CommentsList_getSelection
  }, external__react__default.a.createElement(CommentHeader, null, external__react__default.a.createElement(CommentHeaderFirst, null, external__react__default.a.createElement(CommentUserName, null, data.author.nickname, external__react__default.a.createElement(FloorNum, null, "#", data.floor)), data.repliesCount !== 0 ? external__react__default.a.createElement(ReplyUsers, null, external__react__default.a.createElement(ReplyTitle, null, "\u6536\u5230\u56DE\u590D:"), external__react__default.a.createElement(components["c" /* AvatarsRow */], {
    users: CommentsList_getAuthors(data),
    onUserSelect: previewReply,
    total: data.repliesCount
  })) : null), external__react__default.a.createElement(TimeStamps, null, external__react__default.a.createElement(external__timeago_react__default.a, {
    datetime: data.insertedAt,
    locale: "zh_CN"
  }))), external__react__default.a.createElement(CommentContent, null, data.replyTo ? external__react__default.a.createElement(ReplyBar, null, "\u56DE\u590D\xA0", data.replyTo.author.nickname, ":", external__react__default.a.createElement(ReplyToBody, null, data.replyTo.body), external__react__default.a.createElement(ReplyToFloor, null, "#", data.replyTo.floor)) : null, external__react__default.a.createElement(components["n" /* MarkDownRender */], {
    body: data.body
  })), external__react__default.a.createElement(CommentFooter, null, external__react__default.a.createElement(Actions, null, external__react__default.a.createElement(VisiableAction, null, external__react__default.a.createElement("div", {
    onClick: toggleLikeComment.bind(CommentsList__this, data)
  }, external__react__default.a.createElement(UpIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/up.svg"),
    viewerDid: data.viewerHasLiked
  })), external__react__default.a.createElement(ActionNumber, null, Object(utils["O" /* prettyNum */])(data.likesCount))), external__react__default.a.createElement(VisiableAction, null, external__react__default.a.createElement("div", {
    onClick: toggleDislikeComment.bind(CommentsList__this, data)
  }, external__react__default.a.createElement(UpIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/up.svg"),
    reverse: true,
    viewerDid: data.viewerHasDisliked
  })), external__react__default.a.createElement(ActionNumber, null, Object(utils["O" /* prettyNum */])(data.dislikesCount))), external__react__default.a.createElement(components["w" /* SpaceGrow */], null), external__react__default.a.createElement(CommentsList_ActionBottom, {
    data: data,
    accountInfo: accountInfo
  }))))));
};

var CommentsList_Lists = function Lists(_ref4) {
  var entries = _ref4.entries,
      tobeDeleteId = _ref4.tobeDeleteId,
      accountInfo = _ref4.accountInfo;
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, entries.map(function (c) {
    return external__react__default.a.createElement("div", {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement(CommentsList_Comment, {
      data: c,
      tobeDeleteId: tobeDeleteId,
      accountInfo: accountInfo
    }));
  }));
};

var CommentsList_TotalCountText = function TotalCountText(_ref5) {
  var count = _ref5.count;
  return external__react__default.a.createElement(TotalCountWrapper, null, count > 0 ? external__react__default.a.createElement(ListTitle, {
    id: "lists-info"
  }, "\u6536\u5230 ", external__react__default.a.createElement(TotalNum, null, count), " \u6761\u8BC4\u8BBA:") : null);
};

var CommentsList_CommentsList = function CommentsList(_ref6) {
  var accountInfo = _ref6.accountInfo,
      _ref6$pagedComments = _ref6.pagedComments,
      entries = _ref6$pagedComments.entries,
      totalCount = _ref6$pagedComments.totalCount,
      pageSize = _ref6$pagedComments.pageSize,
      pageNumber = _ref6$pagedComments.pageNumber,
      _ref6$restProps = _ref6.restProps,
      loading = _ref6$restProps.loading,
      loadingFresh = _ref6$restProps.loadingFresh,
      tobeDeleteId = _ref6$restProps.tobeDeleteId,
      filterType = _ref6$restProps.filterType;
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(TotalHeader, null, external__react__default.a.createElement(CommentsList_TotalCountText, {
    count: totalCount
  }), external__react__default.a.createElement(Comments_CommentsFilter, {
    filterType: filterType,
    show: totalCount >= 2
  })), !loadingFresh ? null : external__react__default.a.createElement(CommentBlock, null, external__react__default.a.createElement(components["f" /* CommentLoading */], null)), external__react__default.a.createElement(ListsContainer, null, loading ? external__react__default.a.createElement(CommentBlock, null, external__react__default.a.createElement(components["f" /* CommentLoading */], null)) : external__react__default.a.createElement(CommentsList_Lists, {
    entries: entries,
    accountInfo: accountInfo,
    pageSize: pageSize,
    pageNumber: pageNumber,
    tobeDeleteId: tobeDeleteId
  })), external__react__default.a.createElement(components["r" /* Pagi */], {
    left: "-10px",
    pageNumber: pageNumber,
    pageSize: pageSize,
    totalCount: totalCount,
    onChange: pageChange,
    showBottomMsg: true,
    noMoreMsg: "\u6CA1\u6709\u66F4\u591A\u7684\u8BC4\u8BBA\u4E86",
    emptyMsg: "\u76EE\u524D\u8FD8\u6CA1\u6709\u8BC4\u8BBA"
  }));
};

/* harmony default export */ var Comments_CommentsList = (CommentsList_CommentsList);
// CONCATENATED MODULE: ./containers/Comments/styles/comment_replyer.js
var comment_replyer__templateObject = /*#__PURE__*/ comment_replyer__taggedTemplateLiteral(["\n  margin-left: 10px;\n"]),
    comment_replyer__templateObject2 = /*#__PURE__*/ comment_replyer__taggedTemplateLiteral([""]);

function comment_replyer__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }






var comment_replyer_ReplyBar = ReplyBarBase.extend(comment_replyer__templateObject);
var comment_replyer_ReplyToBody = ReplyToBodyBase.extend(comment_replyer__templateObject2);
var comment_replyer_ReplyToFloor = ReplyToFloorBase.extend(comment_replyer__templateObject2);
var comment_replyer_Container =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__Container",
  componentId: "s16hoxu1-0"
})(["background:", ";min-height:200px;height:100%;border-color:", ";display:flex;flex-direction:column;transition:all 0.3s;border-radius:3px;"], Object(utils["W" /* theme */])('preview.articleBg'), Object(utils["W" /* theme */])('preview.articleBg'));
var comment_replyer_InputHeaderWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__InputHeaderWrapper",
  componentId: "s16hoxu1-1"
})(["height:50px;display:flex;align-items:center;margin-right:20px;"]);
var comment_replyer_InputEditorWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__InputEditorWrapper",
  componentId: "s16hoxu1-2"
})(["min-height:180px;max-height:60vh;overflow-y:scroll;margin:0 10px;margin-bottom:10px;display:block;font-size:1.4em;"]);
var comment_replyer_UserAvatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "comment_replyer__UserAvatar",
  componentId: "s16hoxu1-3"
})(["width:25px;height:25px;border-radius:50%;margin-left:3%;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var comment_replyer_LeaveResponseText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__LeaveResponseText",
  componentId: "s16hoxu1-4"
})(["font-size:1.3em;margin-left:10px;color:lightgrey;"]);
var comment_replyer_LeaveResponseUsername =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__LeaveResponseUsername",
  componentId: "s16hoxu1-5"
})(["font-size:1.3em;margin-left:8px;color:#96b3b5;margin-right:10px;"]);
var comment_replyer_ReferToIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "comment_replyer__ReferToIcon",
  componentId: "s16hoxu1-6"
})(["fill:#b7cfd0;width:20px;height:20px;margin-right:5px;margin-top:5px;"]);
var comment_replyer_ReplyAvatars =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__ReplyAvatars",
  componentId: "s16hoxu1-7"
})([""]);
var comment_replyer_CounterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__CounterWrapper",
  componentId: "s16hoxu1-8"
})(["display:flex;align-items:center;color:#c2d9da;"]);
var comment_replyer_CounterSpliter =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__CounterSpliter",
  componentId: "s16hoxu1-9"
})(["font-size:1.5em;font-weight:lighter;color:", ";"], Object(utils["W" /* theme */])('comment.placeholder'));

var comment_replyer_getColor = function getColor(num) {
  if (num > config["j" /* WORD_LIMIT */].COMMENT) {
    return 'tomato';
  }

  if (num >= config["j" /* WORD_LIMIT */].COMMENT - 50 && num <= config["j" /* WORD_LIMIT */].COMMENT) {
    return 'orange';
  }

  return 'yellowgreen';
};

var comment_replyer_CounterCur =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__CounterCur",
  componentId: "s16hoxu1-10"
})(["margin-right:5px;font-size:1em;color:", ";"], function (_ref) {
  var num = _ref.num;
  return comment_replyer_getColor(num);
});
var comment_replyer_CounterTotal =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__CounterTotal",
  componentId: "s16hoxu1-11"
})(["margin-left:5px;margin-right:5px;font-size:1em;color:", ";"], Object(utils["W" /* theme */])('comment.placeholder'));
var PreviewWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "comment_replyer__PreviewWrapper",
  componentId: "s16hoxu1-12"
})(["min-height:200px;padding:0 20px;"]);
// CONCATENATED MODULE: ./containers/Comments/CommentReplyer.js
function CommentReplyer__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { CommentReplyer__typeof = function _typeof(obj) { return typeof obj; }; } else { CommentReplyer__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return CommentReplyer__typeof(obj); }

function CommentReplyer__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { CommentReplyer__defineProperty(target, key, source[key]); }); } return target; }

function CommentReplyer__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function CommentReplyer__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function CommentReplyer__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function CommentReplyer__createClass(Constructor, protoProps, staticProps) { if (protoProps) CommentReplyer__defineProperties(Constructor.prototype, protoProps); if (staticProps) CommentReplyer__defineProperties(Constructor, staticProps); return Constructor; }

function CommentReplyer__possibleConstructorReturn(self, call) { if (call && (CommentReplyer__typeof(call) === "object" || typeof call === "function")) { return call; } return CommentReplyer__assertThisInitialized(self); }

function CommentReplyer__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function CommentReplyer__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }










var fakeUser = {
  avatar: 'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/10.jpg'
};

var CommentReplyer_WordsCounter = function WordsCounter(_ref) {
  var countCurrent = _ref.countCurrent;
  return external__react__default.a.createElement(comment_replyer_CounterWrapper, null, external__react__default.a.createElement(comment_replyer_CounterCur, {
    num: countCurrent
  }, countCurrent), external__react__default.a.createElement(comment_replyer_CounterSpliter, null, "/"), external__react__default.a.createElement(comment_replyer_CounterTotal, null, config["j" /* WORD_LIMIT */].COMMENT));
};

var CommentReplyer_Header = function Header(_ref2) {
  var countCurrent = _ref2.countCurrent,
      referUsers = _ref2.referUsers,
      showPreview = _ref2.showPreview;
  return external__react__default.a.createElement(comment_replyer_InputHeaderWrapper, null, external__react__default.a.createElement(comment_replyer_UserAvatar, {
    src: fakeUser.avatar
  }), external__react__default.a.createElement(comment_replyer_LeaveResponseUsername, null, "mydearxym"), referUsers.length > 0 ? external__react__default.a.createElement("div", {
    style: {
      display: 'flex'
    }
  }, external__react__default.a.createElement(comment_replyer_ReferToIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/refer.svg")
  }), external__react__default.a.createElement(comment_replyer_ReplyAvatars, null, external__react__default.a.createElement(components["c" /* AvatarsRow */], {
    users: referUsers,
    total: referUsers.length,
    height: "20px"
  }))) : external__react__default.a.createElement("div", null), external__react__default.a.createElement(components["w" /* SpaceGrow */], null), showPreview ? external__react__default.a.createElement("div", null) : external__react__default.a.createElement(CommentReplyer_WordsCounter, {
    countCurrent: countCurrent
  }));
};

var CommentReplyer_InputEditor = function InputEditor(_ref3) {
  var body = _ref3.body,
      mentions = _ref3.mentions;
  return external__react__default.a.createElement("div", {
    className: "comment-reply-editor"
  }, external__react__default.a.createElement(comment_replyer_InputEditorWrapper, null, external__react__default.a.createElement(BodyEditor["a" /* default */], {
    mentions: mentions,
    onChange: Object(utils["t" /* debounce */])(onReplyInputChange, 450),
    onMention: onMention,
    body: body
  })));
};

var CommentReplyer_mentions = [{
  id: 112,
  name: 'mydearxym',
  avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4'
}, {
  id: 113,
  name: 'Julian',
  avatar: 'http://coderplanets.oss-cn-beijing.aliyuncs.com/mock/avatar4.png'
}];

var CommentReplyer_ReplyToBar = function ReplyToBar(_ref4) {
  var comment = _ref4.comment;
  if (!comment) return external__react__default.a.createElement("div", null);
  return external__react__default.a.createElement(comment_replyer_ReplyBar, null, "\u56DE\u590D\xA0", comment.author.nickname, ":", external__react__default.a.createElement(comment_replyer_ReplyToBody, null, comment.body), external__react__default.a.createElement(comment_replyer_ReplyToFloor, null, "#", comment.floor));
};

var CommentReplyer_CommentReplyEditor =
/*#__PURE__*/
function (_React$Component) {
  CommentReplyer__inherits(CommentReplyEditor, _React$Component);

  function CommentReplyEditor() {
    CommentReplyer__classCallCheck(this, CommentReplyEditor);

    return CommentReplyer__possibleConstructorReturn(this, (CommentReplyEditor.__proto__ || Object.getPrototypeOf(CommentReplyEditor)).apply(this, arguments));
  }

  CommentReplyer__createClass(CommentReplyEditor, [{
    key: "handleClickOutside",

    /* eslint-disable */
    value: function handleClickOutside() {
      console.log('点外面哈哈');
      closeReplyBox();
      onCommentInputBlur();
    }
    /* eslint-enable */

  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          referUsers = _props.referUsers,
          show = _props.show,
          showReplyPreview = _props.showReplyPreview,
          _props$restProps = _props.restProps,
          countCurrent = _props$restProps.countCurrent,
          replyContent = _props$restProps.replyContent,
          replyToComment = _props$restProps.replyToComment,
          replying = _props$restProps.replying;
      return external__react__default.a.createElement(comment_replyer_Container, null, external__react__default.a.createElement(CommentReplyer_Header, {
        countCurrent: countCurrent,
        referUsers: referUsers,
        showPreview: showReplyPreview
      }), external__react__default.a.createElement(CommentReplyer_ReplyToBar, {
        comment: replyToComment
      }), show ? external__react__default.a.createElement(CommentReplyer_InputEditor, {
        mentions: CommentReplyer_mentions,
        body: replyContent,
        restProps: CommentReplyer__objectSpread({}, this.props)
      }) : external__react__default.a.createElement(PreviewWrapper, null, external__react__default.a.createElement(components["n" /* MarkDownRender */], {
        body: replyContent
      })), external__react__default.a.createElement(Comments_EditorFooter, {
        loading: replying,
        showPreview: showReplyPreview,
        onCreate: createReplyComment,
        onBackEdit: replyBackToEditor,
        onPreview: replyCommentPreview
      }));
    }
  }]);

  return CommentReplyEditor;
}(external__react__default.a.Component);

/* harmony default export */ var CommentReplyer = (external__react_click_outside__default()(CommentReplyer_CommentReplyEditor));
// CONCATENATED MODULE: ./containers/Comments/index.js
function Comments__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { Comments__typeof = function _typeof(obj) { return typeof obj; }; } else { Comments__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return Comments__typeof(obj); }

function Comments__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { Comments__defineProperty(target, key, source[key]); }); } return target; }

function Comments__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Comments__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function Comments__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function Comments__createClass(Constructor, protoProps, staticProps) { if (protoProps) Comments__defineProperties(Constructor.prototype, protoProps); if (staticProps) Comments__defineProperties(Constructor, staticProps); return Constructor; }

function Comments__possibleConstructorReturn(self, call) { if (call && (Comments__typeof(call) === "object" || typeof call === "function")) { return call; } return Comments__assertThisInitialized(self); }

function Comments__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function Comments__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * Comments
 *
 */
 // import PropTypes from 'prop-types'









/* eslint-disable no-unused-vars */

var Comments_debug = Object(utils["G" /* makeDebugger */])('C:Comments');
/* eslint-enable no-unused-vars */

var Comments_CommentsContainer =
/*#__PURE__*/
function (_React$Component) {
  Comments__inherits(CommentsContainer, _React$Component);

  function CommentsContainer() {
    Comments__classCallCheck(this, CommentsContainer);

    return Comments__possibleConstructorReturn(this, (CommentsContainer.__proto__ || Object.getPrototypeOf(CommentsContainer)).apply(this, arguments));
  }

  Comments__createClass(CommentsContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var comments = this.props.comments;
      logic_init(comments);
    }
  }, {
    key: "render",
    value: function render() {
      var comments = this.props.comments;
      var pagedCommentsData = comments.pagedCommentsData,
          referUsersData = comments.referUsersData,
          accountInfo = comments.accountInfo,
          showReplyBox = comments.showReplyBox,
          showReplyEditor = comments.showReplyEditor,
          showReplyPreview = comments.showReplyPreview;
      return external__react__default.a.createElement(Wrapper, null, external__react__default.a.createElement(components["o" /* Modal */], {
        show: showReplyBox
      }, showReplyBox ? external__react__default.a.createElement(CommentReplyer, {
        accountInfo: accountInfo,
        referUsers: referUsersData,
        restProps: Comments__objectSpread({}, comments),
        show: showReplyEditor,
        showReplyPreview: showReplyPreview
      }) : external__react__default.a.createElement("div", null)), external__react__default.a.createElement(Comments_CommentEditor, {
        accountInfo: accountInfo,
        referUsers: referUsersData,
        restProps: Comments__objectSpread({}, comments)
      }), external__react__default.a.createElement(Comments_CommentsList, {
        accountInfo: accountInfo,
        pagedComments: pagedCommentsData,
        restProps: Comments__objectSpread({}, comments)
      }));
    }
  }]);

  return CommentsContainer;
}(external__react__default.a.Component); // CommentsContainer.propTypes = {
// https://www.npmjs.com/package/prop-types
// }
// CommentsContainer.defaultProps = {}


/* harmony default export */ var Comments = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('comments'))(Object(external__mobx_react_["observer"])(Comments_CommentsContainer)));
// CONCATENATED MODULE: ./containers/ArticleViwer/styles/header.js



var Divider =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "header__Divider",
  componentId: "s11oxy2q-0"
})(["margin:0 8px;display:inline-block;height:0.9em;align-self:center;border-right:1px solid;border-right-color:", ";"], Object(utils["W" /* theme */])('preview.divider')); // border-bottom: 1px solid #e0e0e0;

var PreviewHeaderWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__PreviewHeaderWrapper",
  componentId: "s11oxy2q-1"
})(["display:flex;margin-left:30px;margin-right:30px;padding-top:10px;padding-bottom:6px;"]);
var UserInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__UserInfo",
  componentId: "s11oxy2q-2"
})(["flex-grow:1;display:flex;"]);
var UserName =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__UserName",
  componentId: "s11oxy2q-3"
})(["margin-bottom:2px;font-size:1.2em;color:", ";"], Object(utils["W" /* theme */])('banner.title'));
var PublishAt =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__PublishAt",
  componentId: "s11oxy2q-4"
})(["font-size:0.9em;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var header_Avatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "header__Avatar",
  componentId: "s11oxy2q-5"
})(["border-radius:100%;width:40px;height:40px;margin-right:10px;"]);
var ReactionWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__ReactionWrapper",
  componentId: "s11oxy2q-6"
})(["display:flex;"]);
var ReactionAction =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__ReactionAction",
  componentId: "s11oxy2q-7"
})(["display:flex;padding:0 3px;&:hover{cursor:pointer;font-weight:bold;background:", ";border-radius:6px;}"], Object(utils["W" /* theme */])('article.reactionHoverBg'));
var ReactionName =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__ReactionName",
  componentId: "s11oxy2q-8"
})(["align-self:center;color:", ";font-size:0.9em;margin-left:1px;"], Object(utils["W" /* theme */])('article.reactionTitle'));
var ReactionUserNum =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__ReactionUserNum",
  componentId: "s11oxy2q-9"
})(["align-self:center;color:", ";font-size:0.9em;&:hover{cursor:pointer;text-decoration:underline;}"], Object(utils["W" /* theme */])('article.reactionTitle'));
var ReactionIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "header__ReactionIcon",
  componentId: "s11oxy2q-10"
})(["margin-top:4px;fill:", ";width:", ";height:", ";"], Object(utils["W" /* theme */])('article.reactionTitle'), function (_ref) {
  var width = _ref.width;
  return width || '1.5em';
}, function (_ref2) {
  var height = _ref2.height;
  return height || '1.5em';
});
var Reaction =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "header__Reaction",
  componentId: "s11oxy2q-11"
})(["align-self:center;font-size:1.2em;display:flex;"]);
// CONCATENATED MODULE: ./containers/ArticleViwer/styles/body.js



var BodyWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__BodyWrapper",
  componentId: "j94edp-0"
})(["padding:20px;background:", ";min-height:600px;margin-top:5px;margin-left:4%;margin-right:4%;border-radius:3px;flex-direction:column;display:flex;box-shadow:0 1px 4px rgba(0,0,0,0.04);"], Object(utils["W" /* theme */])('preview.articleBg'));
var CommentsWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__CommentsWrapper",
  componentId: "j94edp-1"
})(["min-height:600px;margin-top:20px;margin-left:4%;margin-right:4%;margin-bottom:10%;border-radius:5px;"]);
var ArticleHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__ArticleHeader",
  componentId: "j94edp-2"
})(["display:flex;justify-content:space-between;color:#cdd0d4;"]);
var MoreWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__MoreWrapper",
  componentId: "j94edp-3"
})(["display:flex;cursor:pointer;"]);
var MoreIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "body__MoreIcon",
  componentId: "j94edp-4"
})(["fill:#6a868a;width:15px;height:15px;"]);
var MoreOption =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__MoreOption",
  componentId: "j94edp-5"
})(["visibility:hidden;", ":hover &{visibility:visible;cursor:pointer;}"], MoreWrapper);
var LinkFrom =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__LinkFrom",
  componentId: "j94edp-6"
})(["display:flex;color:", ";"], Object(utils["W" /* theme */])('article.link'));
var RefinedLabel =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__RefinedLabel",
  componentId: "j94edp-7"
})(["color:tomato;border:1px solid tomato;padding:0 5px;margin-right:10px;border-radius:3px;"]);
var LinkSource =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__LinkSource",
  componentId: "j94edp-8"
})(["&:hover{color:", ";cursor:pointer;}"], Object(utils["W" /* theme */])('article.linkHover'));
var ArticleTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "body__ArticleTitle",
  componentId: "j94edp-9"
})(["color:", ";font-size:1.5em;align-self:center;padding-top:10px;padding-bottom:5px;border-bottom:1px solid;border-bottom-color:", ";"], Object(utils["W" /* theme */])('preview.title'), Object(utils["W" /* theme */])('preview.divider'));
var ArticleBody =
/*#__PURE__*/
external__styled_components__default.a.article.withConfig({
  displayName: "body__ArticleBody",
  componentId: "j94edp-10"
})(["padding:20px;font-size:1.2em;line-height:2em;"]);
// CONCATENATED MODULE: ./containers/ArticleViwer/schema.js
var ArticleViwer_schema__templateObject = /*#__PURE__*/ ArticleViwer_schema__taggedTemplateLiteral(["\n  query post($id: ID!, $userHasLogin: Boolean!) {\n    post(id: $id) {\n      id\n      title\n      body\n      views\n      linkAddr\n      insertedAt\n      updatedAt\n      favoritedCount\n      starredCount\n      viewerHasFavorited @include(if: $userHasLogin)\n      viewerHasStarred @include(if: $userHasLogin)\n    }\n  }\n"]),
    schema__templateObject2 = /*#__PURE__*/ ArticleViwer_schema__taggedTemplateLiteral(["\n  query post($id: ID!) {\n    post(id: $id) {\n      id\n      title\n      favoritedCount\n      starredCount\n      viewerHasFavorited\n      viewerHasStarred\n    }\n  }\n"]),
    schema__templateObject3 = /*#__PURE__*/ ArticleViwer_schema__taggedTemplateLiteral(["\n  mutation($id: ID!, $action: String!, $thread: CmsThread!) {\n    reaction(id: $id, action: $action, thread: $thread) {\n      id\n    }\n  }\n"]),
    schema__templateObject4 = /*#__PURE__*/ ArticleViwer_schema__taggedTemplateLiteral(["\n  mutation($id: ID!, $action: String!, $thread: CmsThread!) {\n    undoReaction(id: $id, action: $action, thread: $thread) {\n      id\n    }\n  }\n"]);

function ArticleViwer_schema__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var schema_post = external__graphql_tag__default()(ArticleViwer_schema__templateObject);
var reactionResult = external__graphql_tag__default()(schema__templateObject2);
var reaction = external__graphql_tag__default()(schema__templateObject3);
var undoReaction = external__graphql_tag__default()(schema__templateObject4);
var ArticleViwer_schema_schema = {
  post: schema_post,
  // viewerReactions,
  reaction: reaction,
  undoReaction: undoReaction,
  reactionResult: reactionResult
};
/* harmony default export */ var ArticleViwer_schema = (ArticleViwer_schema_schema);
// CONCATENATED MODULE: ./containers/ArticleViwer/logic.js



var ArticleViwer_logic_sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].PREVIEW_POST, utils["e" /* EVENT */].PREVIEW_CLOSED]
});
/* eslint-disable no-unused-vars */

var ArticleViwer_logic_debug = Object(utils["G" /* makeDebugger */])('L:ArticleViwer');
/* eslint-enable no-unused-vars */

var ArticleViwer_logic_store = null;
var ArticleViwer_logic_sub$ = null;
function logic_onReaction(thread, action, userDid, _ref) {
  var id = _ref.id;
  var args = {
    id: id,
    thread: thread,
    action: action
  };
  return userDid ? ArticleViwer_logic_sr71$.mutate(ArticleViwer_schema.undoReaction, args) : ArticleViwer_logic_sr71$.mutate(ArticleViwer_schema.reaction, args);
}
function gotoPostPage(data) {
  var id = data.id;
  Object(utils["o" /* closePreviewer */])();
  ArticleViwer_logic_store.markRoute({
    mainPath: utils["i" /* ROUTE */].POST,
    subPath: id
  });
}

function logic_loading() {
  var maybe = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  ArticleViwer_logic_store.markState({
    postLoading: maybe
  });
}

function loadPost(data) {
  var variables = {
    id: data.id,
    userHasLogin: ArticleViwer_logic_store.isLogin
  };
  logic_loading();
  ArticleViwer_logic_sr71$.query(ArticleViwer_schema.post, variables);
}

function reloadReactions(article) {
  var variables = {
    id: article.id
  };
  ArticleViwer_logic_debug('reloadReactions: ', variables);
  ArticleViwer_logic_sr71$.query(ArticleViwer_schema.reactionResult, variables);
}

var ArticleViwer_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW_POST),
  action: function action(res) {
    var info = res[utils["e" /* EVENT */].PREVIEW_POST];

    if (info.type === utils["k" /* TYPE */].POST) {
      var post = info.data;
      loadPost(post);
      ArticleViwer_logic_store.markState({
        type: utils["k" /* TYPE */].POST
      });
      ArticleViwer_logic_store.setViewing({
        post: post
      });
    }
  }
}, {
  match: Object(utils["n" /* asyncRes */])('reaction'),
  action: function action(_ref2) {
    var reaction = _ref2.reaction;
    // TODO: should be trigger
    ArticleViwer_logic_debug('get reaction: ', reaction);
    reloadReactions(reaction);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('undoReaction'),
  action: function action(_ref3) {
    var undoReaction = _ref3.undoReaction;
    ArticleViwer_logic_debug('get undoReaction: ', undoReaction);
    /* const info = res[TYPE.UNDO_REACTION] */

    reloadReactions(undoReaction);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW_CLOSED),
  action: function action() {
    ArticleViwer_logic_sr71$.stop();
    ArticleViwer_logic_store.load(utils["k" /* TYPE */].POST, {});
    logic_loading(false);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('post'),
  // GraphQL return
  action: function action(_ref4) {
    var post = _ref4.post;
    ArticleViwer_logic_store.setViewing({
      post: post
    });
    ArticleViwer_logic_store.markState({
      type: utils["k" /* TYPE */].POST
    });
    logic_loading(false);
  }
}];
var ArticleViwer_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref5) {
    var details = _ref5.details;
    ArticleViwer_logic_debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref6) {
    var details = _ref6.details;
    ArticleViwer_logic_debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref7) {
    var details = _ref7.details;
    ArticleViwer_logic_debug('ERR.NETWORK -->', details);
  }
}];
function ArticleViwer_logic_init(_store) {
  if (ArticleViwer_logic_store) return false;
  ArticleViwer_logic_store = _store;
  if (ArticleViwer_logic_sub$) ArticleViwer_logic_sub$.unsubscribe();
  ArticleViwer_logic_sub$ = ArticleViwer_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(ArticleViwer_logic_DataSolver, ArticleViwer_logic_ErrSolver));
}
// CONCATENATED MODULE: ./containers/ArticleViwer/PostViewer.js
var PostViewer__this = this;


 // import CommentsList from '../../components/CommentsList'







 // <PreviewHeader>Preview header</PreviewHeader>post
// TODO: extract a Avatar component

/*
   <Reaction>
   <ReactionAction>
   <ReactionIcon src={`${ICON_ASSETS}/cmd/uncollect.svg`} />
   <ReactionName>关注&nbsp;</ReactionName>
   </ReactionAction>
   <ReactionUserNum>22</ReactionUserNum>
   <Divider />
   </Reaction>
 */

var PostViewer_PreviewHeader = function PreviewHeader(_ref) {
  var data = _ref.data,
      onReaction = _ref.onReaction;
  return external__react__default.a.createElement(PreviewHeaderWrapper, null, external__react__default.a.createElement(UserInfo, null, external__react__default.a.createElement(header_Avatar, {
    src: "http://coderplanets.oss-cn-beijing.aliyuncs.com/mock/avatar13.png",
    alt: "user_avatar"
  }), external__react__default.a.createElement("div", null, external__react__default.a.createElement(UserName, null, "mydearxym"), external__react__default.a.createElement(PublishAt, null, "\u53D1\u8868\u4E8E: ", external__react__default.a.createElement(external__timeago_react__default.a, {
    datetime: data.insertedAt,
    locale: "zh_CN"
  })))), external__react__default.a.createElement(ReactionWrapper, null, external__react__default.a.createElement(Reaction, null, external__react__default.a.createElement(ReactionAction, {
    onClick: logic_onReaction.bind(PostViewer__this, utils["k" /* TYPE */].POST, utils["k" /* TYPE */].FAVORITE, data.viewerHasFavorited, data)
  }, external__react__default.a.createElement(ReactionIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/uncollect.svg")
  }), external__react__default.a.createElement(ReactionName, null, data.viewerHasFavorited ? external__react__default.a.createElement("span", null, "\u5DF2\u6536\u85CF\xA0") : external__react__default.a.createElement("span", null, "\u6536\u85CF\xA0"))), external__react__default.a.createElement(ReactionUserNum, null, data.favoritedCount), external__react__default.a.createElement(Divider, null)), external__react__default.a.createElement(Reaction, null, external__react__default.a.createElement(ReactionAction, {
    onClick: onReaction.bind(PostViewer__this, utils["k" /* TYPE */].POST, utils["k" /* TYPE */].STAR, data.viewerHasStarred, data)
  }, external__react__default.a.createElement(ReactionIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/like.svg")
  }), external__react__default.a.createElement(ReactionName, null, "\xA0\u8D5E\xA0")), external__react__default.a.createElement(ReactionUserNum, null, data.starredCount), external__react__default.a.createElement(Divider, null)), external__react__default.a.createElement(Reaction, null, external__react__default.a.createElement(ReactionAction, null, external__react__default.a.createElement(ReactionIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/watch.svg")
  }), external__react__default.a.createElement(ReactionName, null, "\xA0\u6D4F\u89C8\xA0")), external__react__default.a.createElement(ReactionUserNum, null, data.views))));
};

var PostViewer_PostViewer = function PostViewer(_ref2) {
  var data = _ref2.data,
      loading = _ref2.loading,
      onReaction = _ref2.onReaction;
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(PostViewer_PreviewHeader, {
    data: data,
    onReaction: onReaction
  }), external__react__default.a.createElement(BodyWrapper, null, external__react__default.a.createElement(ArticleHeader, null, external__react__default.a.createElement(MoreWrapper, null, external__react__default.a.createElement(MoreIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/more.svg")
  }), external__react__default.a.createElement(MoreOption, {
    onClick: gotoPostPage.bind(PostViewer__this, data)
  }, "\u6587\u7AE0\u9875")), external__react__default.a.createElement(LinkFrom, null, external__react__default.a.createElement("div", null, "\u8F6C\u8F7D\u81EA:\xA0"), external__react__default.a.createElement(LinkSource, null, "github.com/mydearxym/...")), external__react__default.a.createElement(RefinedLabel, null, "\u7CBE\u534E\u5E16")), external__react__default.a.createElement(ArticleTitle, null, data.title), loading ? external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(components["t" /* PostLoading */], {
    num: 2
  })) : external__react__default.a.createElement(ArticleBody, null, external__react__default.a.createElement(components["n" /* MarkDownRender */], {
    body: data.body
  }))), external__react__default.a.createElement(CommentsWrapper, null, external__react__default.a.createElement(Comments, null)));
};

/* harmony default export */ var ArticleViwer_PostViewer = (PostViewer_PostViewer);
// CONCATENATED MODULE: ./containers/ArticleViwer/index.js
function ArticleViwer__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { ArticleViwer__typeof = function _typeof(obj) { return typeof obj; }; } else { ArticleViwer__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return ArticleViwer__typeof(obj); }

function ArticleViwer__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function ArticleViwer__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function ArticleViwer__createClass(Constructor, protoProps, staticProps) { if (protoProps) ArticleViwer__defineProperties(Constructor.prototype, protoProps); if (staticProps) ArticleViwer__defineProperties(Constructor, staticProps); return Constructor; }

function ArticleViwer__possibleConstructorReturn(self, call) { if (call && (ArticleViwer__typeof(call) === "object" || typeof call === "function")) { return call; } return ArticleViwer__assertThisInitialized(self); }

function ArticleViwer__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function ArticleViwer__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * ArticleViwer
 *
 */


 // import Link from 'next/link'




/* eslint-disable no-unused-vars */

var ArticleViwer_debug = Object(utils["G" /* makeDebugger */])('C:ArticleViwer');
/* eslint-enable no-unused-vars */

var ArticleViwer_Viwer = function Viwer(_ref) {
  var type = _ref.type,
      data = _ref.data,
      loading = _ref.loading,
      onReaction = _ref.onReaction;

  switch (type) {
    case 'post':
      {
        return external__react__default.a.createElement(ArticleViwer_PostViewer, {
          data: data,
          loading: loading,
          onReaction: onReaction
        });
      }

    case 'job':
      {
        return external__react__default.a.createElement("div", null, "job");
      }

    case 'typewriter':
      {
        return external__react__default.a.createElement("div", null, "typewriter");
      }

    default:
      {
        return external__react__default.a.createElement("div", null, "default");
      }
  }
};

var ArticleViwer_ArticleViwerContainer =
/*#__PURE__*/
function (_React$Component) {
  ArticleViwer__inherits(ArticleViwerContainer, _React$Component);

  function ArticleViwerContainer() {
    ArticleViwer__classCallCheck(this, ArticleViwerContainer);

    return ArticleViwer__possibleConstructorReturn(this, (ArticleViwerContainer.__proto__ || Object.getPrototypeOf(ArticleViwerContainer)).apply(this, arguments));
  }

  ArticleViwer__createClass(ArticleViwerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var articleViwer = this.props.articleViwer;
      ArticleViwer_logic_init(articleViwer);
    }
  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          type = _props.type,
          articleViwer = _props.articleViwer;
      var viewingPost = articleViwer.viewingPost,
          postLoading = articleViwer.postLoading;
      return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(ArticleViwer_Viwer, {
        type: type,
        data: viewingPost,
        loading: postLoading,
        onReaction: logic_onReaction
      }));
    }
  }]);

  return ArticleViwerContainer;
}(external__react__default.a.Component);

ArticleViwer_ArticleViwerContainer.defaultProps = {
  type: 'post' // ArticleViwerContainer

};
/* harmony default export */ var ArticleViwer = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('articleViwer'))(Object(external__mobx_react_["observer"])(ArticleViwer_ArticleViwerContainer)));
// EXTERNAL MODULE: external "ramda/src/equals"
var equals_ = __webpack_require__(75);
var equals__default = /*#__PURE__*/__webpack_require__.n(equals_);

// EXTERNAL MODULE: external "ramda/src/pick"
var pick_ = __webpack_require__(74);
var pick__default = /*#__PURE__*/__webpack_require__.n(pick_);

// EXTERNAL MODULE: external "ramda/src/pickBy"
var pickBy_ = __webpack_require__(19);
var pickBy__default = /*#__PURE__*/__webpack_require__.n(pickBy_);

// EXTERNAL MODULE: external "ramda/src/not"
var not_ = __webpack_require__(15);
var not__default = /*#__PURE__*/__webpack_require__.n(not_);

// EXTERNAL MODULE: external "ramda/src/compose"
var compose_ = __webpack_require__(12);
var compose__default = /*#__PURE__*/__webpack_require__.n(compose_);

// EXTERNAL MODULE: external "ramda/src/curry"
var curry_ = __webpack_require__(23);
var curry__default = /*#__PURE__*/__webpack_require__.n(curry_);

// CONCATENATED MODULE: ./containers/AccountEditor/schema.js
var AccountEditor_schema__templateObject = /*#__PURE__*/ AccountEditor_schema__taggedTemplateLiteral(["\n  mutation($profile: UserProfileInput!) {\n    updateProfile(profile: $profile) {\n      id\n    }\n  }\n"]);

function AccountEditor_schema__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var updateProfile = external__graphql_tag__default()(AccountEditor_schema__templateObject);
var AccountEditor_schema_schema = {
  updateProfile: updateProfile
};
/* harmony default export */ var AccountEditor_schema = (AccountEditor_schema_schema);
// CONCATENATED MODULE: ./containers/AccountEditor/logic.js







function logic__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var AccountEditor_logic_sr71$ = new sr71["a" /* default */]();
/* eslint-disable no-unused-vars */

var AccountEditor_logic_debug = Object(utils["G" /* makeDebugger */])('L:AccountEditor');
/* eslint-enable no-unused-vars */

var AccountEditor_logic_store = null;
var AccountEditor_logic_sub$ = null;
function goBack() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW, {
    type: utils["k" /* TYPE */].PREVIEW_ACCOUNT_VIEW
  });
}
var profileChange = curry__default()(function (part, e) {
  AccountEditor_logic_store.updateUser(logic__defineProperty({}, part, e.target.value));
});
function sexChange(sex) {
  AccountEditor_logic_store.updateUser({
    sex: sex
  });
}
var updatableAttrs = ['nickname', 'email', 'location', 'company', 'education', 'qq', 'weibo', 'weichat', 'bio', 'sex'];

var hasValue = compose__default()(not__default.a, utils["K" /* nilOrEmpty */]);

var pickUpdatable = compose__default()(pickBy__default()(hasValue), pick__default()(updatableAttrs));

var logic_updateConfirm = function updateConfirm() {
  if (!AccountEditor_logic_store.statusClean) return false; // TODO: 只去除 null 的即可，如果为空也是合法的

  var editing = pickUpdatable(AccountEditor_logic_store.accountInfo);
  var origin = pickUpdatable(AccountEditor_logic_store.accountOrigin);
  /* debug('editing: ', editing) */

  /* debug('origin: ', origin) */
  // TODO: 唯一的限制是 昵称不能为空

  if (equals__default()(editing, origin)) {
    Object(utils["J" /* meteorState */])(AccountEditor_logic_store, 'warn', 3);
    return false;
  }

  AccountEditor_logic_store.markState({
    updating: true
  });
  AccountEditor_logic_sr71$.mutate(AccountEditor_schema.updateProfile, {
    profile: editing
  });
};
function cancleEdit() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW_CLOSE);
}
function updateDone() {
  var editing = pickUpdatable(AccountEditor_logic_store.accountInfo);
  AccountEditor_logic_store.updateOrign(editing);
}

var cancleLoading = function cancleLoading() {
  AccountEditor_logic_store.markState({
    updating: false
  });
};

var AccountEditor_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('updateProfile'),
  action: function action() {
    Object(utils["J" /* meteorState */])(AccountEditor_logic_store, 'success', 3);
    updateDone();
    cancleLoading(); // communitiesContent.loadCommunities(data)
  }
}];
var AccountEditor_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref) {
    var details = _ref.details;
    var errMsg = details[0].detail;
    Object(utils["J" /* meteorState */])(AccountEditor_logic_store, 'error', 5, errMsg);
    cancleLoading();
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref2) {
    var details = _ref2.details;
    AccountEditor_logic_debug('ERR.TIMEOUT -->', details);
    cancleLoading();
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref3) {
    var details = _ref3.details;
    AccountEditor_logic_debug('ERR.NETWORK -->', details);
    cancleLoading();
  }
}];
function AccountEditor_logic_init(_store) {
  if (AccountEditor_logic_store) return false;
  AccountEditor_logic_store = _store;
  AccountEditor_logic_store.copyAccountInfo();
  if (AccountEditor_logic_sub$) AccountEditor_logic_sub$.unsubscribe();
  AccountEditor_logic_sub$ = AccountEditor_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(AccountEditor_logic_DataSolver, AccountEditor_logic_ErrSolver));
}
// CONCATENATED MODULE: ./containers/AccountEditor/styles/index.js
var styles__templateObject = /*#__PURE__*/ styles__taggedTemplateLiteral(["\n  fill: ", ";\n"]),
    styles__templateObject2 = /*#__PURE__*/ styles__taggedTemplateLiteral(["\n  fill: ", ";\n  margin-top: 1px;\n"]);

function styles__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1ytxer4-0"
})(["padding-top:20px;padding-bottom:50px;height:100%;min-height:80vh;margin-top:15px;margin-left:15px;margin-right:15px;background:", ";border-radius:5px;display:flex;flex-direction:column;align-items:center;position:relative;animation:", " 0.2s linear;"], Object(utils["W" /* theme */])('content.cardBg'), utils["b" /* Animate */].fadeInRight);
var AvatarPic =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__AvatarPic",
  componentId: "s1ytxer4-1"
})(["width:70px;height:70px;border-radius:100%;margin-bottom:30px;"]);
var BackIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__BackIcon",
  componentId: "s1ytxer4-2"
})(["fill:", ";width:20px;height:20px;position:absolute;top:13px;left:18px;cursor:pointer;opacity:0.6;&:hover{opacity:1;}transition:opacity 0.2s;"], Object(utils["W" /* theme */])('font'));
var SexIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__SexIcon",
  componentId: "s1ytxer4-3"
})(["width:20px;height:20px;margin-right:10px;margin-left:5px;cursor:pointer;"]);
/* fill: ${props => */

/* props.active === props.item ? theme('font', props) : 'grey'}; */

var Dude =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Dude",
  componentId: "s1ytxer4-4"
})([""]);
var Girl =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Girl",
  componentId: "s1ytxer4-5"
})([""]);
var DudeIcon = SexIcon.extend(styles__templateObject, function (_ref) {
  var value = _ref.value;
  return value === 'dude' ? '#869eec' : Object(utils["W" /* theme */])('preview.divider');
});
var GirlIcon = SexIcon.extend(styles__templateObject2, function (_ref2) {
  var value = _ref2.value;
  return value === 'girl' ? 'pink' : Object(utils["W" /* theme */])('preview.divider');
});
var SexLable =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SexLable",
  componentId: "s1ytxer4-6"
})(["font-size:1em;color:", ";margin-right:10px;"], Object(utils["W" /* theme */])('form.label'));
var SexInput =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SexInput",
  componentId: "s1ytxer4-7"
})(["width:250px;display:flex;"]);
var FormItemWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FormItemWrapper",
  componentId: "s1ytxer4-8"
})(["display:flex;margin-bottom:25px;"]);
var FormLable =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FormLable",
  componentId: "s1ytxer4-9"
})(["font-size:1em;color:", ";margin-right:10px;margin-top:5px;"], Object(utils["W" /* theme */])('form.label'));
var FormInput =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FormInput",
  componentId: "s1ytxer4-10"
})(["width:250px;"]);
var styles_Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Divider",
  componentId: "s1ytxer4-11"
})(["border-top:1px solid;border-top-color:", ";margin-top:15px;width:75%;margin-bottom:20px;"], Object(utils["W" /* theme */])('preview.divider'));
var ActionBtns =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ActionBtns",
  componentId: "s1ytxer4-12"
})([""]);
// CONCATENATED MODULE: ./containers/AccountEditor/index.js
var AccountEditor__this = this;

function AccountEditor__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { AccountEditor__typeof = function _typeof(obj) { return typeof obj; }; } else { AccountEditor__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return AccountEditor__typeof(obj); }

function AccountEditor__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function AccountEditor__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function AccountEditor__createClass(Constructor, protoProps, staticProps) { if (protoProps) AccountEditor__defineProperties(Constructor.prototype, protoProps); if (staticProps) AccountEditor__defineProperties(Constructor, staticProps); return Constructor; }

function AccountEditor__possibleConstructorReturn(self, call) { if (call && (AccountEditor__typeof(call) === "object" || typeof call === "function")) { return call; } return AccountEditor__assertThisInitialized(self); }

function AccountEditor__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function AccountEditor__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * AccountEditor
 *
 */


 // import Link from 'next/link'





/* eslint-disable no-unused-vars */

var AccountEditor_debug = Object(utils["G" /* makeDebugger */])('C:AccountEditor');
/* eslint-enable no-unused-vars */

var TextArea = components["m" /* Input */].TextArea;

var AccountEditor_Avatar = function Avatar(_ref) {
  var src = _ref.src;
  return external__react__default.a.createElement("div", null, external__react__default.a.createElement(AvatarPic, {
    src: src
  }));
};

var AccountEditor_SexItem = function SexItem(_ref2) {
  var label = _ref2.label,
      value = _ref2.value;
  return external__react__default.a.createElement(FormItemWrapper, null, external__react__default.a.createElement(SexLable, null, label), external__react__default.a.createElement(SexInput, null, external__react__default.a.createElement(Dude, {
    onClick: sexChange.bind(AccountEditor__this, 'dude')
  }, external__react__default.a.createElement(DudeIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/dude.svg"),
    value: value
  })), external__react__default.a.createElement(Girl, {
    onClick: sexChange.bind(AccountEditor__this, 'girl')
  }, external__react__default.a.createElement(GirlIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/girl.svg"),
    value: value
  }))));
};

var AccountEditor_FormItem = function FormItem(_ref3) {
  var label = _ref3.label,
      textarea = _ref3.textarea,
      value = _ref3.value,
      onChange = _ref3.onChange;
  return external__react__default.a.createElement(FormItemWrapper, null, external__react__default.a.createElement(FormLable, null, label), external__react__default.a.createElement(FormInput, null, textarea ? external__react__default.a.createElement(TextArea, {
    value: value,
    placeholder: value,
    autosize: {
      minRows: 3,
      maxRows: 6
    },
    onChange: onChange
  }) : external__react__default.a.createElement(components["m" /* Input */], {
    size: "default",
    value: value,
    onChange: onChange
  })));
};

var AccountEditor_AccountEditorContainer =
/*#__PURE__*/
function (_React$Component) {
  AccountEditor__inherits(AccountEditorContainer, _React$Component);

  function AccountEditorContainer() {
    AccountEditor__classCallCheck(this, AccountEditorContainer);

    return AccountEditor__possibleConstructorReturn(this, (AccountEditorContainer.__proto__ || Object.getPrototypeOf(AccountEditorContainer)).apply(this, arguments));
  }

  AccountEditor__createClass(AccountEditorContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var accountEditor = this.props.accountEditor;
      AccountEditor_logic_init(accountEditor);
    }
  }, {
    key: "render",
    value: function render() {
      var _props$accountEditor = this.props.accountEditor,
          accountInfo = _props$accountEditor.accountInfo,
          updating = _props$accountEditor.updating,
          success = _props$accountEditor.success,
          error = _props$accountEditor.error,
          warn = _props$accountEditor.warn,
          statusMsg = _props$accountEditor.statusMsg;
      /* debug('accountInfo editing->: ', accountInfo) */

      return external__react__default.a.createElement(styles_Wrapper, {
        className: "normal-form"
      }, external__react__default.a.createElement("div", {
        onClick: goBack
      }, external__react__default.a.createElement(BackIcon, {
        src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/goback.svg")
      })), external__react__default.a.createElement(AccountEditor_Avatar, {
        src: accountInfo.avatar
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u6635\u79F0:",
        value: accountInfo.nickname,
        onChange: profileChange('nickname')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u90AE\u7BB1:",
        value: accountInfo.email,
        onChange: profileChange('email')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u57CE\u5E02:",
        value: accountInfo.location,
        onChange: profileChange('location')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u516C\u53F8:",
        value: accountInfo.company,
        onChange: profileChange('company')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u5B66\u6821:",
        value: accountInfo.education,
        onChange: profileChange('education')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "QQ:",
        value: accountInfo.qq,
        onChange: profileChange('qq')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u5FAE\u535A:",
        value: accountInfo.weibo,
        onChange: profileChange('weibo')
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u5FAE\u4FE1:",
        value: accountInfo.weichat,
        onChange: profileChange('weichat')
      }), external__react__default.a.createElement(AccountEditor_SexItem, {
        label: "\u6027\u522B:",
        value: accountInfo.sex
      }), external__react__default.a.createElement(AccountEditor_FormItem, {
        label: "\u7B80\u4ECB:",
        textarea: true,
        value: accountInfo.bio,
        onChange: profileChange('bio')
      }), external__react__default.a.createElement("br", null), external__react__default.a.createElement(components["y" /* StatusBox */], {
        success: success,
        error: error,
        warn: warn,
        msg: statusMsg
      }), external__react__default.a.createElement(styles_Divider, null), external__react__default.a.createElement(ActionBtns, null, external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        ghost: true,
        onClick: cancleEdit
      }, "\u53D6\u6D88"), "\xA0\xA0\xA0\xA0\xA0\xA0", updating ? external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        disabled: true
      }, external__react__default.a.createElement(components["k" /* Icon */], {
        type: "loading"
      }), " \u4FDD\u5B58\u4E2D") : external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        onClick: logic_updateConfirm
      }, "\u4FDD\u5B58")));
    }
  }]);

  return AccountEditorContainer;
}(external__react__default.a.Component);

/* harmony default export */ var AccountEditor = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('accountEditor'))(Object(external__mobx_react_["observer"])(AccountEditor_AccountEditorContainer)));
// EXTERNAL MODULE: external "react-tooltip"
var external__react_tooltip_ = __webpack_require__(40);
var external__react_tooltip__default = /*#__PURE__*/__webpack_require__.n(external__react_tooltip_);

// CONCATENATED MODULE: ./containers/AccountViewer/styles/user_header.js



var UserWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_header__UserWrapper",
  componentId: "lnebi4-0"
})(["display:flex;"]);
var UserHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_header__UserHeader",
  componentId: "lnebi4-1"
})(["display:flex;width:100%;padding-bottom:5px;"]);
var user_header_UserInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_header__UserInfo",
  componentId: "lnebi4-2"
})(["display:flex;flex-grow:1;"]);
var user_header_Avatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "user_header__Avatar",
  componentId: "lnebi4-3"
})(["border-radius:100%;width:40px !important;height:40px;margin-right:10px;"]);
var user_header_UserBrief =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_header__UserBrief",
  componentId: "lnebi4-4"
})(["display:flex;flex-direction:column;"]);
var BriefInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_header__BriefInfo",
  componentId: "lnebi4-5"
})(["color:", ";margin-left:5px;font-size:1em;display:flex;"], Object(utils["W" /* theme */])('preview.desc'));
var user_header_UserName =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_header__UserName",
  componentId: "lnebi4-6"
})(["margin-left:5px;margin-bottom:3px;font-size:1.3em;color:", ";display:flex;"], Object(utils["W" /* theme */])('preview.title'));
var EditIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "user_header__EditIcon",
  componentId: "lnebi4-7"
})(["fill:", ";width:20px;height:20px;cursor:pointer;opacity:0.4;margin-left:5px;margin-top:4px;&:hover{opacity:0.8;}transition:opacity 0.2s;"], Object(utils["W" /* theme */])('preview.icon'));
var SocalIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "user_header__SocalIcon",
  componentId: "lnebi4-8"
})(["fill:", ";margin-top:10px;margin-right:7px;width:22px;height:22px;cursor:pointer;opacity:0.4;&:hover{opacity:0.8;}transition:opacity 0.2s;"], Object(utils["W" /* theme */])('preview.icon'));
// CONCATENATED MODULE: ./containers/AccountViewer/UserHeader.js





var tooltipOffset = JSON.stringify({
  top: 5,
  left: 3
});

var UserHeader_SocalIcons = function SocalIcons(_ref) {
  var githubProfile = _ref.accountInfo.githubProfile;
  return external__react__default.a.createElement(BriefInfo, null, external__react__default.a.createElement("div", {
    key: external__shortid__default.a.generate(),
    "data-tip": "\u7AD9\u5185\u4E3B\u9875",
    "data-offset": tooltipOffset,
    "data-delay-show": "500"
  }, external__react__default.a.createElement(SocalIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/home.svg")
  })), githubProfile ? external__react__default.a.createElement(components["a" /* A */], {
    href: githubProfile.htmlUrl
  }, external__react__default.a.createElement("div", {
    key: external__shortid__default.a.generate(),
    "data-tip": githubProfile.htmlUrl,
    "data-offset": tooltipOffset,
    "data-delay-show": "500"
  }, external__react__default.a.createElement(SocalIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/github.svg")
  }))) : external__react__default.a.createElement("div", null));
};

var UserHeader_UserHeaderSection = function UserHeaderSection(_ref2) {
  var accountInfo = _ref2.accountInfo,
      logout = _ref2.logout,
      editProfile = _ref2.editProfile;
  return external__react__default.a.createElement(UserWrapper, null, external__react__default.a.createElement(UserHeader, null, external__react__default.a.createElement(user_header_UserInfo, null, external__react__default.a.createElement(user_header_Avatar, {
    src: accountInfo.avatar,
    alt: "user_avatar"
  }), external__react__default.a.createElement(user_header_UserBrief, null, external__react__default.a.createElement(user_header_UserName, null, accountInfo.nickname, external__react__default.a.createElement("div", {
    onClick: editProfile
  }, external__react__default.a.createElement(EditIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/edit.svg")
  }))), external__react__default.a.createElement(BriefInfo, null, "\u6559\u80B2\u7ECF\u5386:\xA0 \u6210\u90FD\u4FE1\u606F\u5DE5\u7A0B\u5B66\u9662"), external__react__default.a.createElement(BriefInfo, null, "bio:\xA0 ", accountInfo.bio), external__react__default.a.createElement(BriefInfo, null, "\u6240\u5728\u5730\u533A:\xA0 \u6210\u90FD"), external__react__default.a.createElement(UserHeader_SocalIcons, {
    accountInfo: accountInfo
  }))), external__react__default.a.createElement("div", null, external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: logout
  }, external__react__default.a.createElement(components["k" /* Icon */], {
    type: "logout"
  }), "\u767B\xA0\u51FA"))));
};

/* harmony default export */ var AccountViewer_UserHeader = (UserHeader_UserHeaderSection);
// CONCATENATED MODULE: ./containers/AccountViewer/styles/planets.js



var planets_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "planets__Wrapper",
  componentId: "vhe35f-0"
})([""]);
var HeaderWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "planets__HeaderWrapper",
  componentId: "vhe35f-1"
})(["display:flex;"]);
var Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "planets__Title",
  componentId: "vhe35f-2"
})(["font-size:1em;color:", ";margin-bottom:10px;flex-grow:1;"], Object(utils["W" /* theme */])('preview.title'));
var HelpText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "planets__HelpText",
  componentId: "vhe35f-3"
})(["color:", ";", ":hover &{color:", ";cursor:pointer;}transition:color 0.2s;"], Object(utils["W" /* theme */])('preview.helper'), HeaderWrapper, Object(utils["W" /* theme */])('preview.helperHover'));
var IconList =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "planets__IconList",
  componentId: "vhe35f-4"
})(["display:flex;flex-wrap:wrap;"]);
var PlanetsIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "planets__PlanetsIcon",
  componentId: "vhe35f-5"
})(["width:30px;height:30px;margin-right:10px;margin-bottom:3px;cursor:pointer;opacity:0.6;&:hover{opacity:1;}transition:opacity 0.2s;"]);
// CONCATENATED MODULE: ./containers/AccountViewer/Planets.js



var Planets_tooltipOffset = JSON.stringify({
  top: 10,
  left: 5
});

var Planets_Planets = function Planets(_ref) {
  var subscribedCommunities = _ref.subscribedCommunities;
  return external__react__default.a.createElement(planets_Wrapper, null, external__react__default.a.createElement(HeaderWrapper, null, external__react__default.a.createElement(Title, null, "\u6211/Ta\u7684\u5173\u6CE8"), external__react__default.a.createElement(HelpText, null, "\u5171\xA0", subscribedCommunities.totalCount, "\xA0\u4E2A")), external__react__default.a.createElement(IconList, null, subscribedCommunities.entries.map(function (community) {
    return external__react__default.a.createElement("div", {
      key: community.raw,
      "data-tip": community.title,
      "data-for": "planet_icon",
      "data-offset": Planets_tooltipOffset
    }, external__react__default.a.createElement(PlanetsIcon, {
      src: community.logo
    }));
  })), external__react__default.a.createElement(external__react_tooltip__default.a, {
    effect: "solid",
    place: "bottom",
    id: "planet_icon"
  }));
};

/* harmony default export */ var AccountViewer_Planets = (Planets_Planets);
// EXTERNAL MODULE: external "react-calendar-heatmap"
var external__react_calendar_heatmap_ = __webpack_require__(77);
var external__react_calendar_heatmap__default = /*#__PURE__*/__webpack_require__.n(external__react_calendar_heatmap_);

// CONCATENATED MODULE: ./containers/AccountViewer/styles/contribute_map.js


var contribute_map_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__Wrapper",
  componentId: "ub2zez-0"
})([""]);
var TitleWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__TitleWrapper",
  componentId: "ub2zez-1"
})(["display:flex;"]);
var contribute_map_HelpText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__HelpText",
  componentId: "ub2zez-2"
})(["color:", ";margin-top:2px;&:hover{color:", ";cursor:pointer;}", ":hover &{color:", ";}transition:color 0.2s;"], Object(utils["W" /* theme */])('preview.helper'), Object(utils["W" /* theme */])('preview.helperHover'), TitleWrapper, Object(utils["W" /* theme */])('preview.helperHover'));
var contribute_map_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__Title",
  componentId: "ub2zez-3"
})(["font-size:1em;color:", ";margin-bottom:7px;flex-grow:1;"], Object(utils["W" /* theme */])('preview.title'));
var DotWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__DotWrapper",
  componentId: "ub2zez-4"
})(["margin-top:4px;display:flex;justify-content:flex-end;"]);
var DotText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__DotText",
  componentId: "ub2zez-5"
})(["font-size:0.9em;color:", ";", ":hover &{color:", ";}"], Object(utils["W" /* theme */])('preview.helper'), DotWrapper, Object(utils["W" /* theme */])('preview.helperHover'));
var DotList =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__DotList",
  componentId: "ub2zez-6"
})(["margin-left:5px;margin-right:3px;display:flex;"]);

var contribute_map_dotColor = function dotColor(scale) {
  var key = "heatmap.scale_".concat(scale);

  if (scale === 'empty') {
    key = 'heatmap.empty';
  }

  return Object(utils["W" /* theme */])(key);
};
/* eslint-disable */


var ColorDot =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__ColorDot",
  componentId: "ub2zez-7"
})(["width:12px;height:12px;border-radius:3px;margin-top:2px;margin-right:2px;background-color:", ";"], function (props) {
  return contribute_map_dotColor(props.scale)(props);
});
/* eslint-enable */
// CONCATENATED MODULE: ./containers/AccountViewer/ContributeMap.js


/*
 *
 * Contribution heat map, inspired by github
 * TODO: this component use global class as style
 *
 */





var ContributeMap_debug = Object(utils["G" /* makeDebugger */])('C:Comments');

var customTooltipDataAttrs = function customTooltipDataAttrs(value) {
  return {
    'data-tip': value.date === null ? '' : "".concat(value.count, " \u6B21 (").concat(value.date, ")"),
    'data-for': 'user_comtribute_map',
    'data-offset': JSON.stringify({
      right: 7
    })
  };
}; // const monthLabels = ['8月', '9月', '10月', '11月', '12月', '1月']


var monthLabels = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
/*
   const startDate = '2017-10-21'
   const endDate = '2018-04-21'
   const records = [
   { date: '2018-01-03', count: 1 },
   { date: '2018-01-04', count: 1 },
   { date: '2018-01-20', count: 1 },
   { date: '2018-01-21', count: 17 },
   ]
 */
// TODO

var getClass = function getClass(value) {
  if (!value) {
    return 'color-empty';
  }

  switch (true) {
    case value.count >= 1 && value.count < 6:
      return 'color-scale-1';

    case value.count >= 6 && value.count < 16:
      return 'color-scale-2';

    case value.count >= 16 && value.count < 26:
      return 'color-scale-3';

    case value.count >= 26 && value.count < 36:
      return 'color-scale-4';

    default:
      return 'color-scale-5';
    // 5 is the largest
  }
};

var ContributeMap_ContributeMap = function ContributeMap(_ref) {
  var data = _ref.data;

  /* if don't jadge empty(first load), the tool tip will not work */
  if (isEmpty__default()(data.records)) {
    return external__react__default.a.createElement("div", null);
  }

  return external__react__default.a.createElement(contribute_map_Wrapper, null, external__react__default.a.createElement(TitleWrapper, null, external__react__default.a.createElement(contribute_map_Title, null, "6\u4E2A\u6708\u5185\u521B\u4F5C ", data.totalCount, " \u6B21\u5185\u5BB9"), external__react__default.a.createElement(contribute_map_HelpText, null, "\u8BB0\u5F55\u89C4\u5219\uFF1F")), external__react__default.a.createElement(external__react_calendar_heatmap__default.a, {
    startDate: data.startDate,
    endDate: data.endDate,
    showMonthLabels: true,
    onClick: function onClick(value) {
      ContributeMap_debug(value);
    },
    gutterSize: 3,
    tooltipDataAttrs: customTooltipDataAttrs,
    monthLabels: monthLabels,
    values: data.records,
    classForValue: getClass
  }), external__react__default.a.createElement(external__react_tooltip__default.a, {
    type: "error",
    effect: "solid",
    place: "top",
    id: "user_comtribute_map"
  }), external__react__default.a.createElement(DotWrapper, null, external__react__default.a.createElement(DotList, null, external__react__default.a.createElement(DotText, null, "\u6F5C\u6C34\xA0\xA0"), external__react__default.a.createElement(ColorDot, {
    scale: "empty"
  }), external__react__default.a.createElement(ColorDot, {
    scale: "1"
  }), external__react__default.a.createElement(ColorDot, {
    scale: "2"
  }), external__react__default.a.createElement(ColorDot, {
    scale: "3"
  }), external__react__default.a.createElement(ColorDot, {
    scale: "4"
  }), external__react__default.a.createElement(ColorDot, {
    scale: "5"
  }), external__react__default.a.createElement(DotText, null, "\xA0\u9AD8\u4EA7"))));
};

/* harmony default export */ var AccountViewer_ContributeMap = (ContributeMap_ContributeMap);
// CONCATENATED MODULE: ./containers/AccountViewer/styles/index.js


var AccountWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__AccountWrapper",
  componentId: "s17sk34s-0"
})(["height:100%;min-height:100vh;background:", ";padding:22px;padding-top:30px;border-radius:3px;display:flex;flex-direction:column;border-top:3px solid;border-top-color:", ";"], Object(utils["W" /* theme */])('preview.accountBg'), Object(utils["W" /* theme */])('preview.topLine'));
var AccountContent =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__AccountContent",
  componentId: "s17sk34s-1"
})(["flex-grow:1;"]);
var AccountViewer_styles_Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Divider",
  componentId: "s17sk34s-2"
})(["margin-top:", ";margin-bottom:", ";border-bottom:1px solid;border-bottom-color:", ";"], function (_ref) {
  var top = _ref.top;
  return top || '10px';
}, function (_ref2) {
  var bottom = _ref2.bottom;
  return bottom || '10px';
}, Object(utils["W" /* theme */])('preview.divider'));
var styles_ThemeWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ThemeWrapper",
  componentId: "s17sk34s-3"
})(["margin-bottom:15px;"]);
var PanerWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PanerWrapper",
  componentId: "s17sk34s-4"
})(["border:1px solid;border-color:", ";border-top:none;margin-top:-16px;min-height:260px;padding:12px;background:", ";"], Object(utils["W" /* theme */])('tabs.border'), Object(utils["W" /* theme */])('tabs.contentBg'));
// EXTERNAL MODULE: ./containers/AccountViewer/schema.js
var AccountViewer_schema = __webpack_require__(94);

// CONCATENATED MODULE: ./containers/AccountViewer/logic.js
// import R from 'ramda'



/* eslint-disable no-unused-vars */

var AccountViewer_logic_debug = Object(utils["G" /* makeDebugger */])('L:AccountViewer');
/* eslint-enable no-unused-vars */

var AccountViewer_logic_sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].LOGIN]
});
var AccountViewer_logic_store = null;
var AccountViewer_logic_sub$ = null;
function loadUser() {}
function loadAccount() {
  // load contributes ..
  // load posts ...
  AccountViewer_logic_sr71$.query(AccountViewer_schema["a" /* default */].account, {});
}
function changeTheme(name) {
  AccountViewer_logic_store.changeTheme(name);
}
function logic_logout() {
  AccountViewer_logic_store.logout();
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].LOGOUT);
}
function logic_editProfile() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].NAV_EDIT, {
    type: utils["k" /* TYPE */].PREVIEW_ACCOUNT_EDIT
  });
}
var AccountViewer_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('account'),
  action: function action(res) {
    var data = res.account;
    AccountViewer_logic_store.updateAccount(data);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].LOGIN),
  action: function action() {
    return loadAccount();
  }
}];
var AccountViewer_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref) {
    var details = _ref.details;
    AccountViewer_logic_debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref2) {
    var details = _ref2.details;
    AccountViewer_logic_debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref3) {
    var details = _ref3.details;
    AccountViewer_logic_debug('ERR.NETWORK -->', details);
  }
}];
function AccountViewer_logic_init(_store) {
  if (AccountViewer_logic_store) return false;
  AccountViewer_logic_store = _store;
  if (AccountViewer_logic_sub$) AccountViewer_logic_sub$.unsubscribe();
  AccountViewer_logic_sub$ = AccountViewer_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(AccountViewer_logic_DataSolver, AccountViewer_logic_ErrSolver));
}
// CONCATENATED MODULE: ./containers/AccountViewer/index.js
function AccountViewer__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { AccountViewer__typeof = function _typeof(obj) { return typeof obj; }; } else { AccountViewer__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return AccountViewer__typeof(obj); }

function AccountViewer__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function AccountViewer__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function AccountViewer__createClass(Constructor, protoProps, staticProps) { if (protoProps) AccountViewer__defineProperties(Constructor.prototype, protoProps); if (staticProps) AccountViewer__defineProperties(Constructor, staticProps); return Constructor; }

function AccountViewer__possibleConstructorReturn(self, call) { if (call && (AccountViewer__typeof(call) === "object" || typeof call === "function")) { return call; } return AccountViewer__assertThisInitialized(self); }

function AccountViewer__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function AccountViewer__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * AccountViewer
 *
 */

 // import Link from 'next/link'









/* eslint-disable no-unused-vars */

var AccountViewer_debug = Object(utils["G" /* makeDebugger */])('C:AccountViewer');
/* eslint-enable no-unused-vars */

var TabPane = components["A" /* Tabs */].TabPane;

var AccountViewer_ThemeSection = function ThemeSection(_ref) {
  var curTheme = _ref.curTheme;
  return external__react__default.a.createElement(styles_ThemeWrapper, null, external__react__default.a.createElement(components["C" /* ThemeSelector */], {
    curTheme: curTheme,
    changeTheme: changeTheme
  }));
};

var AccountViewer_AccountViewerContainer =
/*#__PURE__*/
function (_React$Component) {
  AccountViewer__inherits(AccountViewerContainer, _React$Component);

  function AccountViewerContainer() {
    AccountViewer__classCallCheck(this, AccountViewerContainer);

    return AccountViewer__possibleConstructorReturn(this, (AccountViewerContainer.__proto__ || Object.getPrototypeOf(AccountViewerContainer)).apply(this, arguments));
  }

  AccountViewer__createClass(AccountViewerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var accountViewer = this.props.accountViewer;
      AccountViewer_logic_init(accountViewer);
      loadAccount();
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      /* force rebuild the tooltip, otherwise it won't work in some async cases */

      /* if you want to custom see: */

      /* https://github.com/wwayne/react-tooltip/blob/2364dc61332aa947b106dd4bbdd1f2b0e4b1e51d/src/index.scss */
      setTimeout(function () {
        external__react_tooltip__default.a.rebuild();
      }, 2000);
    }
  }, {
    key: "render",
    value: function render() {
      var _props$accountViewer = this.props.accountViewer,
          curTheme = _props$accountViewer.curTheme,
          accountInfo = _props$accountViewer.accountInfo,
          subscribedCommunities = _props$accountViewer.subscribedCommunities;
      var contributes = accountInfo.contributes;
      return external__react__default.a.createElement(AccountWrapper, null, external__react__default.a.createElement(external__react_tooltip__default.a, {
        effect: "solid",
        place: "bottom"
      }), external__react__default.a.createElement(AccountContent, null, external__react__default.a.createElement(AccountViewer_UserHeader, {
        accountInfo: accountInfo,
        logout: logic_logout,
        editProfile: logic_editProfile
      }), external__react__default.a.createElement(AccountViewer_styles_Divider, {
        top: "10px",
        bottom: "20px"
      }), external__react__default.a.createElement(AccountViewer_Planets, {
        subscribedCommunities: subscribedCommunities
      }), external__react__default.a.createElement(AccountViewer_styles_Divider, {
        top: "10px",
        bottom: "20px"
      }), external__react__default.a.createElement(AccountViewer_ContributeMap, {
        data: contributes
      }), external__react__default.a.createElement(AccountViewer_styles_Divider, {
        top: "18px"
      }), external__react__default.a.createElement(components["A" /* Tabs */], {
        onChange: AccountViewer_debug,
        type: "card"
      }, external__react__default.a.createElement(TabPane, {
        tab: "\u6700\u8FD1",
        key: "1"
      }, external__react__default.a.createElement(PanerWrapper, null, "Content of Tab Pane 1")), external__react__default.a.createElement(TabPane, {
        tab: "\u6536\u85CF 456",
        key: "2"
      }, external__react__default.a.createElement(PanerWrapper, null, "Content of Tab Pane 2")), external__react__default.a.createElement(TabPane, {
        tab: "\u5173\u6CE8\u4E2D 34",
        key: "4"
      }, external__react__default.a.createElement(PanerWrapper, null, "Content of Tab Pane 3")), external__react__default.a.createElement(TabPane, {
        tab: "\u5173\u6CE8\u8005 28",
        key: "5"
      }, external__react__default.a.createElement(PanerWrapper, null, "Content of Tab Pane 4")))), external__react__default.a.createElement(AccountViewer_styles_Divider, {
        top: "10px",
        bottom: "12px"
      }), external__react__default.a.createElement(AccountViewer_ThemeSection, {
        curTheme: curTheme
      }));
    }
  }]);

  return AccountViewerContainer;
}(external__react__default.a.Component);

/* harmony default export */ var AccountViewer = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('accountViewer'))(Object(external__mobx_react_["observer"])(AccountViewer_AccountViewerContainer)));
// CONCATENATED MODULE: ./containers/UserBanner/styles/index.js


var BannerContainer =
/*#__PURE__*/
external__styled_components__default.a.nav.withConfig({
  displayName: "styles__BannerContainer",
  componentId: "o4tsmi-0"
})(["position:relative;min-height:180px;border-bottom:1px solid tomato;display:flex;flex-direction:column;justify-content:center;background:", ";border-bottom:1px solid;border-bottom-color:", ";@media (max-height:800px){min-height:130px;}"], Object(utils["W" /* theme */])('banner.bg'), Object(utils["W" /* theme */])('banner.spliter'));
/* export const TabberWrapper = BaseTabber.extend`` */

var BannerContentWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BannerContentWrapper",
  componentId: "o4tsmi-1"
})(["display:flex;margin-left:8%;margin-right:8%;"]);
var UserBriefWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UserBriefWrapper",
  componentId: "o4tsmi-2"
})(["flex-grow:1;align-self:center;"]);
var UserContributesWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UserContributesWrapper",
  componentId: "o4tsmi-3"
})(["width:40%;max-width:400px;"]);
// CONCATENATED MODULE: ./containers/UserBanner/styles/user_brief.js



var user_brief_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_brief__Wrapper",
  componentId: "s11ozojf-0"
})(["display:flex;"]);
var AvatarWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_brief__AvatarWrapper",
  componentId: "s11ozojf-1"
})(["margin-right:12px;"]);
var user_brief_Avatar =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "user_brief__Avatar",
  componentId: "s11ozojf-2"
})(["border-radius:50%;width:65px;height:65px;"]);
var UserTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_brief__UserTitle",
  componentId: "s11ozojf-3"
})(["font-size:1.2rem;color:", ";margin-bottom:5px;"], Object(utils["W" /* theme */])('banner.title'));
var UserDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "user_brief__UserDesc",
  componentId: "s11ozojf-4"
})(["font-size:0.9rem;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
// CONCATENATED MODULE: ./containers/UserBanner/UserBrief.js



var UserBrief_UserBrief = function UserBrief() {
  return external__react__default.a.createElement(user_brief_Wrapper, null, external__react__default.a.createElement(AvatarWrapper, null, external__react__default.a.createElement(user_brief_Avatar, {
    src: "https://avatars2.githubusercontent.com/u/6184465?v=4"
  })), external__react__default.a.createElement("div", null, external__react__default.a.createElement(UserTitle, null, "Mydearxym(\u8C22\u4E00\u9762)"), external__react__default.a.createElement(UserDesc, null, "\u6240\u5C5E\u884C\u4E1A: xxx"), external__react__default.a.createElement(UserDesc, null, "\u4E2A\u4EBA\u4ECB\u7ECD: \u6211\u6765\u4E2A\u6BD4\u8F83\u957F\u4E00\u70B9\u70B9\u7684\u4E2A\u4EBA\u4ECB\u7ECD\u54C8\uFF0C\u770B\u770B\u5E03\u5C40\u6548\u679C"), external__react__default.a.createElement(UserDesc, null, "\u516C\u53F8: xxx"), external__react__default.a.createElement(UserDesc, null, "\u5404\u79CD\u4E3B\u9875: xxx")));
};

/* harmony default export */ var UserBanner_UserBrief = (UserBrief_UserBrief);
// CONCATENATED MODULE: ./containers/UserBanner/styles/contribute_map.js


var styles_contribute_map_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__Wrapper",
  componentId: "s1ld0l2u-0"
})([""]);
var contribute_map_TitleWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__TitleWrapper",
  componentId: "s1ld0l2u-1"
})(["display:flex;"]);
var styles_contribute_map_HelpText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__HelpText",
  componentId: "s1ld0l2u-2"
})(["color:", ";margin-top:2px;&:hover{color:", ";cursor:pointer;}", ":hover &{color:", ";}transition:color 0.2s;"], Object(utils["W" /* theme */])('preview.helper'), Object(utils["W" /* theme */])('preview.helperHover'), contribute_map_TitleWrapper, Object(utils["W" /* theme */])('preview.helperHover'));
var styles_contribute_map_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__Title",
  componentId: "s1ld0l2u-3"
})(["font-size:0.8rem;color:", ";margin-bottom:7px;flex-grow:1;opacity:0.6;", ":hover &{opacity:1;font-weight:bold;}"], Object(utils["W" /* theme */])('banner.desc'), styles_contribute_map_Wrapper);
var contribute_map_DotWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__DotWrapper",
  componentId: "s1ld0l2u-4"
})(["margin-top:4px;display:flex;justify-content:flex-end;"]);
var contribute_map_DotText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__DotText",
  componentId: "s1ld0l2u-5"
})(["font-size:0.8rem;color:", ";opacity:0.6;", ":hover &{opacity:1;font-weight:bold;}"], Object(utils["W" /* theme */])('banner.desc'), styles_contribute_map_Wrapper);
var contribute_map_DotList =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__DotList",
  componentId: "s1ld0l2u-6"
})(["margin-left:5px;margin-right:3px;display:flex;"]);

var styles_contribute_map_dotColor = function dotColor(scale) {
  var key = "heatmap.scale_".concat(scale);

  if (scale === 'empty') {
    key = 'heatmap.empty';
  }

  return Object(utils["W" /* theme */])(key);
};
/* eslint-disable */


var contribute_map_ColorDot =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "contribute_map__ColorDot",
  componentId: "s1ld0l2u-7"
})(["width:12px;height:12px;border-radius:3px;margin-top:2px;margin-right:2px;background-color:", ";"], function (props) {
  return styles_contribute_map_dotColor(props.scale)(props);
});
/* eslint-enable */
// CONCATENATED MODULE: ./containers/UserBanner/UserContributeMap.js


/*
 *
 * Contribution heat map, inspired by github
 * TODO: this component use global class as style
 *
 */





var UserContributeMap_debug = Object(utils["G" /* makeDebugger */])('C:Comments');

var UserContributeMap_customTooltipDataAttrs = function customTooltipDataAttrs(value) {
  return {
    'data-tip': value.date === null ? '' : "".concat(value.count, " \u6B21 (").concat(value.date, ")"),
    'data-for': 'user_comtribute_map',
    'data-offset': JSON.stringify({
      right: 7
    })
  };
}; // const monthLabels = ['8月', '9月', '10月', '11月', '12月', '1月']


var UserContributeMap_monthLabels = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']; // TODO

var UserContributeMap_getClass = function getClass(value) {
  if (!value) {
    return 'color-empty';
  }

  switch (true) {
    case value.count >= 1 && value.count < 6:
      return 'color-scale-1';

    case value.count >= 6 && value.count < 16:
      return 'color-scale-2';

    case value.count >= 16 && value.count < 26:
      return 'color-scale-3';

    case value.count >= 26 && value.count < 36:
      return 'color-scale-4';

    default:
      return 'color-scale-5';
    // 5 is the largest
  }
};

var UserContributeMap_UserContributeMap = function UserContributeMap(_ref) {
  var data = _ref.data;

  /* if don't jadge empty(first load), the tool tip will not work */
  if (isEmpty__default()(data.records)) {
    return null;
  }
  /*
     <TitleWrapper>
     <Title>6个月内贡献 {data.totalCount} 次内容</Title>
     <HelpText>记录规则？</HelpText>
     </TitleWrapper>
   */


  return external__react__default.a.createElement(styles_contribute_map_Wrapper, {
    className: "banner-heatmap"
  }, external__react__default.a.createElement(external__react_calendar_heatmap__default.a, {
    startDate: data.startDate,
    endDate: data.endDate,
    showMonthLabels: true,
    onClick: function onClick(value) {
      UserContributeMap_debug(value);
    },
    gutterSize: 3,
    tooltipDataAttrs: UserContributeMap_customTooltipDataAttrs,
    monthLabels: UserContributeMap_monthLabels,
    values: data.records,
    classForValue: UserContributeMap_getClass
  }), external__react__default.a.createElement(external__react_tooltip__default.a, {
    type: "error",
    effect: "solid",
    place: "top",
    id: "user_comtribute_map"
  }), external__react__default.a.createElement(contribute_map_DotWrapper, null, external__react__default.a.createElement(styles_contribute_map_Title, null, "6\u4E2A\u6708\u5185\u521B\u4F5C ", data.totalCount, " \u6B21\u5185\u5BB9"), external__react__default.a.createElement(contribute_map_DotList, null, external__react__default.a.createElement(contribute_map_DotText, null, "\u6F5C\u6C34\xA0\xA0"), external__react__default.a.createElement(contribute_map_ColorDot, {
    scale: "empty"
  }), external__react__default.a.createElement(contribute_map_ColorDot, {
    scale: "1"
  }), external__react__default.a.createElement(contribute_map_ColorDot, {
    scale: "2"
  }), external__react__default.a.createElement(contribute_map_ColorDot, {
    scale: "3"
  }), external__react__default.a.createElement(contribute_map_ColorDot, {
    scale: "4"
  }), external__react__default.a.createElement(contribute_map_ColorDot, {
    scale: "5"
  }), external__react__default.a.createElement(contribute_map_DotText, null, "\xA0\u9AD8\u4EA7"))));
};

/* harmony default export */ var UserBanner_UserContributeMap = (UserContributeMap_UserContributeMap);
// CONCATENATED MODULE: ./containers/UserBanner/logic.js
// import R from 'ramda'


var UserBanner_logic_sr71$ = new sr71["a" /* default */]();
var UserBanner_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var UserBanner_logic_debug = Object(utils["G" /* makeDebugger */])('L:UserBanner');
/* eslint-enable no-unused-vars */

var UserBanner_logic_store = null;
function someMethod() {} // ###############################
// Data & Error handlers
// ###############################

var UserBanner_logic_DataSolver = [];
var UserBanner_logic_ErrSolver = [];
function UserBanner_logic_init(_store) {
  if (UserBanner_logic_store) return false;
  UserBanner_logic_store = _store;
  UserBanner_logic_debug(UserBanner_logic_store);
  if (UserBanner_logic_sub$) UserBanner_logic_sub$.unsubscribe();
  UserBanner_logic_sub$ = UserBanner_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(UserBanner_logic_DataSolver, UserBanner_logic_ErrSolver));
}
// CONCATENATED MODULE: ./containers/UserBanner/index.js
function UserBanner__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { UserBanner__typeof = function _typeof(obj) { return typeof obj; }; } else { UserBanner__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return UserBanner__typeof(obj); }

function UserBanner__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function UserBanner__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function UserBanner__createClass(Constructor, protoProps, staticProps) { if (protoProps) UserBanner__defineProperties(Constructor.prototype, protoProps); if (staticProps) UserBanner__defineProperties(Constructor, staticProps); return Constructor; }

function UserBanner__possibleConstructorReturn(self, call) { if (call && (UserBanner__typeof(call) === "object" || typeof call === "function")) { return call; } return UserBanner__assertThisInitialized(self); }

function UserBanner__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function UserBanner__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * UserBanner
 *
 */

 // import Link from 'next/link'






/* eslint-disable no-unused-vars */

var UserBanner_debug = Object(utils["G" /* makeDebugger */])('C:UserBanner');
/* eslint-enable no-unused-vars */

var fakeRecors = {
  endDate: '2018-07-07',
  startDate: '2018-01-07',
  totalCount: 70,
  records: [{
    date: '2018-03-11',
    count: 1
  }, {
    date: '2018-03-10',
    count: 4
  }, {
    date: '2018-05-20',
    count: 29
  }, {
    date: '2018-05-21',
    count: 6
  }, {
    date: '2018-04-03',
    count: 18
  }, {
    date: '2017-03-11',
    count: 2
  }, {
    date: '2018-02-03',
    count: 10
  }]
};

var UserBanner_UserBannerContainer =
/*#__PURE__*/
function (_React$Component) {
  UserBanner__inherits(UserBannerContainer, _React$Component);

  function UserBannerContainer() {
    UserBanner__classCallCheck(this, UserBannerContainer);

    return UserBanner__possibleConstructorReturn(this, (UserBannerContainer.__proto__ || Object.getPrototypeOf(UserBannerContainer)).apply(this, arguments));
  }

  UserBanner__createClass(UserBannerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var userBanner = this.props.userBanner;
      UserBanner_logic_init(userBanner);
    }
  }, {
    key: "render",
    value: function render() {
      return external__react__default.a.createElement(BannerContainer, null, external__react__default.a.createElement(BannerContentWrapper, null, external__react__default.a.createElement(UserBriefWrapper, null, external__react__default.a.createElement(UserBanner_UserBrief, null)), external__react__default.a.createElement(UserContributesWrapper, null, external__react__default.a.createElement(UserBanner_UserContributeMap, {
        data: fakeRecors
      }))));
    }
  }]);

  return UserBannerContainer;
}(external__react__default.a.Component);

/* harmony default export */ var UserBanner = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('userBanner'))(Object(external__mobx_react_["observer"])(UserBanner_UserBannerContainer)));
// EXTERNAL MODULE: external "ramda/src/isNil"
var isNil_ = __webpack_require__(22);
var isNil__default = /*#__PURE__*/__webpack_require__.n(isNil_);

// CONCATENATED MODULE: ./containers/PostBanner/styles/index.js
var PostBanner_styles__templateObject = /*#__PURE__*/ PostBanner_styles__taggedTemplateLiteral(["\n  margin-top: 0;\n"]),
    PostBanner_styles__templateObject2 = /*#__PURE__*/ PostBanner_styles__taggedTemplateLiteral(["\n  height: 100px;\n  min-height: 100px;\n"]),
    styles__templateObject3 = /*#__PURE__*/ PostBanner_styles__taggedTemplateLiteral(["\n  display: flex;\n"]);

function PostBanner_styles__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var BaseBanner =
/*#__PURE__*/
external__styled_components__default.a.nav.withConfig({
  displayName: "styles__BaseBanner",
  componentId: "fqfuwy-0"
})(["position:relative;min-height:140px;border-bottom:1px solid tomato;display:flex;flex-direction:column;justify-content:center;background:", ";border-bottom:", ";@media (max-height:800px){min-height:130px;}"], Object(utils["W" /* theme */])('banner.bg'), Object(utils["W" /* theme */])('banner.spliter'));
var BaseBannerContent =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseBannerContent",
  componentId: "fqfuwy-1"
})(["display:flex;margin-left:8%;margin-right:12%;"]);
var NumbersWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumbersWrapper",
  componentId: "fqfuwy-2"
})(["display:flex;text-align:center;margin-top:-2.1rem;"]);
var styles_NumbersInfo = NumbersWrapper.extend(PostBanner_styles__templateObject);
var styles_BannerContainer = BaseBanner.extend(PostBanner_styles__templateObject2);
var styles_BannerContentWrapper = BaseBannerContent.extend(styles__templateObject3);
var PostBrief =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PostBrief",
  componentId: "fqfuwy-3"
})(["width:60%;flex-grow:1;display:flex;flex-direction:column;"]);
var styles_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Title",
  componentId: "fqfuwy-4"
})(["font-size:1.6em;color:", ";width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"], Object(utils["W" /* theme */])('thread.articleTitle'));
var Desc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Desc",
  componentId: "fqfuwy-5"
})(["margin-top:5px;display:flex;font-size:1.1em;color:", ";"], Object(utils["W" /* theme */])('thread.articleDigest'));
var styles_Avatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__Avatar",
  componentId: "fqfuwy-6"
})(["width:25px;height:25px;border-radius:100%;margin-right:5px;"]);
var PrintTag =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PrintTag",
  componentId: "fqfuwy-7"
})(["font-size:0.8em;padding:1px 8px;border-radius:3px;border:1px solid;border-color:", ";color:", ";margin-right:8px;"], Object(utils["W" /* theme */])('thread.extraInfo'), Object(utils["W" /* theme */])('thread.extraInfo'));
var Username =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Username",
  componentId: "fqfuwy-8"
})(["margin-right:3px;&:hover{cursor:pointer;color:#719a9b;}"]); // background: ${theme('banner.numberHoverBg')};

var NumberSection =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberSection",
  componentId: "fqfuwy-9"
})(["display:flex;flex-direction:column;justify-content:center;padding:0 5px;border-radius:4px;&:hover{background:", ";cursor:", ";}"], function (_ref) {
  var dead = _ref.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.numberHoverBg');
}, function (_ref2) {
  var dead = _ref2.dead;
  return dead ? '' : 'pointer';
});
var NumberTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberTitle",
  componentId: "fqfuwy-10"
})(["color:", ";&:hover{color:", ";text-decoration:", ";animation:", " 0.4s linear;}"], Object(utils["W" /* theme */])('banner.numberDesc'), function (_ref3) {
  var dead = _ref3.dead;
  return dead ? '' : '#f1c48f';
}, function (_ref4) {
  var dead = _ref4.dead;
  return dead ? '' : 'underline';
}, utils["b" /* Animate */].pulse);
var NumberItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberItem",
  componentId: "fqfuwy-11"
})(["font-size:1.5rem;color:", ";&:hover{color:", ";text-decoration:", ";animation:", " 0.4s linear;}"], Object(utils["W" /* theme */])('banner.number'), function (_ref5) {
  var dead = _ref5.dead;
  return dead ? '' : '#f1c48f';
}, function (_ref6) {
  var dead = _ref6.dead;
  return dead ? '' : 'underline';
}, utils["b" /* Animate */].pulse);
var NumberDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberDivider",
  componentId: "fqfuwy-12"
})(["border:1px solid;border-color:", ";height:70%;align-self:center;margin-left:10px;margin-right:10px;"], Object(utils["W" /* theme */])('banner.numberDivider'));
// EXTERNAL MODULE: ./containers/PostBanner/schema.js
var PostBanner_schema = __webpack_require__(95);

// CONCATENATED MODULE: ./containers/PostBanner/logic.js
// import R from 'ramda'



var PostBanner_logic_sr71$ = new sr71["a" /* default */]();
var PostBanner_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var PostBanner_logic_debug = Object(utils["G" /* makeDebugger */])('L:PostBanner');
/* eslint-enable no-unused-vars */

var PostBanner_logic_store = null;
function logic_loadPost() {
  var id = PostBanner_logic_store.curRoute.subPath;
  PostBanner_logic_sr71$.query(PostBanner_schema["a" /* default */].post, {
    id: id
  });
} // ###############################
// Data & Error handlers
// ###############################

var PostBanner_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('post'),
  action: function action(_ref) {
    var post = _ref.post;
    return PostBanner_logic_store.setViewing({
      post: post
    });
  }
}];
var PostBanner_logic_ErrSolver = [];
function PostBanner_logic_init(_store) {
  if (PostBanner_logic_store) return false;
  PostBanner_logic_store = _store;
  if (PostBanner_logic_sub$) PostBanner_logic_sub$.unsubscribe();
  PostBanner_logic_sub$ = PostBanner_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(PostBanner_logic_DataSolver, PostBanner_logic_ErrSolver));
  /* loadPost() */
}
// CONCATENATED MODULE: ./containers/PostBanner/index.js


function PostBanner__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { PostBanner__typeof = function _typeof(obj) { return typeof obj; }; } else { PostBanner__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return PostBanner__typeof(obj); }

function PostBanner__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function PostBanner__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function PostBanner__createClass(Constructor, protoProps, staticProps) { if (protoProps) PostBanner__defineProperties(Constructor.prototype, protoProps); if (staticProps) PostBanner__defineProperties(Constructor, staticProps); return Constructor; }

function PostBanner__possibleConstructorReturn(self, call) { if (call && (PostBanner__typeof(call) === "object" || typeof call === "function")) { return call; } return PostBanner__assertThisInitialized(self); }

function PostBanner__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function PostBanner__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }







/* eslint-disable no-unused-vars */

var PostBanner_debug = Object(utils["G" /* makeDebugger */])('C:PostBanner');
/* eslint-enable no-unused-vars */

var PostBanner_PostNumbers = function PostNumbers(_ref) {
  var _ref$data = _ref.data,
      views = _ref$data.views,
      favoritedCount = _ref$data.favoritedCount,
      starredCount = _ref$data.starredCount;
  return external__react__default.a.createElement(styles_NumbersInfo, null, external__react__default.a.createElement(NumberSection, {
    dead: true
  }, external__react__default.a.createElement(NumberTitle, {
    dead: true
  }, "\u9605\u8BFB"), external__react__default.a.createElement(NumberItem, {
    dead: true
  }, Object(utils["O" /* prettyNum */])(views))), external__react__default.a.createElement(NumberDivider, null), external__react__default.a.createElement(NumberSection, null, external__react__default.a.createElement(NumberTitle, null, "\u559C\u6B22"), external__react__default.a.createElement(NumberItem, null, Object(utils["O" /* prettyNum */])(starredCount))), external__react__default.a.createElement(NumberDivider, null), external__react__default.a.createElement(NumberSection, null, external__react__default.a.createElement(NumberTitle, null, "\u6536\u85CF"), external__react__default.a.createElement(NumberItem, null, Object(utils["O" /* prettyNum */])(favoritedCount))), external__react__default.a.createElement(NumberDivider, null), external__react__default.a.createElement(NumberSection, null, external__react__default.a.createElement(NumberTitle, null, "\u5173\u6CE8"), external__react__default.a.createElement(NumberItem, null, "TD")));
};

var PostBanner_PostBannerContainer =
/*#__PURE__*/
function (_React$Component) {
  PostBanner__inherits(PostBannerContainer, _React$Component);

  function PostBannerContainer() {
    PostBanner__classCallCheck(this, PostBannerContainer);

    return PostBanner__possibleConstructorReturn(this, (PostBannerContainer.__proto__ || Object.getPrototypeOf(PostBannerContainer)).apply(this, arguments));
  }

  PostBanner__createClass(PostBannerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var postBanner = this.props.postBanner;
      PostBanner_logic_init(postBanner);
    }
  }, {
    key: "render",
    value: function render() {
      var postData = this.props.postBanner.postData;
      return external__react__default.a.createElement(styles_BannerContainer, null, isNil__default()(postData.id) ? null : external__react__default.a.createElement(styles_BannerContentWrapper, null, external__react__default.a.createElement(PostBrief, null, external__react__default.a.createElement(styles_Title, null, postData.title), external__react__default.a.createElement(Desc, null, external__react__default.a.createElement(PrintTag, null, "\u8F6C\u8F7D"), external__react__default.a.createElement(Username, null, postData.author.nickname), " \u53D1\u5E03\u4E8E", ' ', external__react__default.a.createElement(external__timeago_react__default.a, {
        datetime: postData.insertedAt,
        locale: "zh_CN"
      }), " * \u5B57\u6570: ", postData.length)), external__react__default.a.createElement(PostBanner_PostNumbers, {
        data: postData
      })));
    }
  }]);

  return PostBannerContainer;
}(external__react__default.a.Component);

/* harmony default export */ var PostBanner = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('postBanner'))(Object(external__mobx_react_["observer"])(PostBanner_PostBannerContainer)));
// EXTERNAL MODULE: ./components/Tabber/index.js
var Tabber = __webpack_require__(44);

// CONCATENATED MODULE: ./containers/CommunityBanner/styles/numbers_info.js


var numbers_info_NumbersWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "numbers_info__NumbersWrapper",
  componentId: "e63ev9-0"
})(["display:flex;text-align:center;margin-top:-2rem;"]);
var numbers_info_NumberSection =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "numbers_info__NumberSection",
  componentId: "e63ev9-1"
})(["display:flex;flex-direction:column;justify-content:center;padding:0 5px;border-radius:4px;&:hover{background:", ";}"], function (_ref) {
  var dead = _ref.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.numberHoverBg');
}); // text-decoration: ${({ dead }) => (dead ? '' : 'underline')};

var numbers_info_NumberTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "numbers_info__NumberTitle",
  componentId: "e63ev9-2"
})(["color:", ";&:hover{color:", ";animation:", " 0.4s linear;cursor:", ";}"], Object(utils["W" /* theme */])('banner.numberDesc'), function (_ref2) {
  var dead = _ref2.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.active');
}, utils["b" /* Animate */].pulse, function (_ref3) {
  var dead = _ref3.dead;
  return dead ? '' : 'pointer';
}); // text-decoration: ${({ dead }) => (dead ? '' : 'underline')};

var numbers_info_NumberItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "numbers_info__NumberItem",
  componentId: "e63ev9-3"
})(["font-size:1.5rem;color:", ";&:hover{color:", ";animation:", " 0.4s linear;cursor:", ";}"], Object(utils["W" /* theme */])('banner.number'), function (_ref4) {
  var dead = _ref4.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.active');
}, utils["b" /* Animate */].pulse, function (_ref5) {
  var dead = _ref5.dead;
  return dead ? '' : 'pointer';
});
var numbers_info_NumberDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "numbers_info__NumberDivider",
  componentId: "e63ev9-4"
})(["border:1px solid;border-color:", ";height:70%;align-self:center;margin-left:10px;margin-right:10px;"], Object(utils["W" /* theme */])('banner.numberDivider'));
// EXTERNAL MODULE: ./containers/CommunityBanner/schema.js
var CommunityBanner_schema = __webpack_require__(78);

// CONCATENATED MODULE: ./containers/CommunityBanner/logic.js
// import R from 'ramda'



var CommunityBanner_logic_sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].COMMUNITY_CHANGE]
});
var CommunityBanner_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var CommunityBanner_logic_debug = Object(utils["G" /* makeDebugger */])('L:CommunityBanner');
/* eslint-enable no-unused-vars */

var CommunityBanner_logic_store = null;
function loadCommunity() {
  // NOTE: do not use viewing.community, it's too slow
  var mainPath = CommunityBanner_logic_store.curRoute.mainPath;
  CommunityBanner_logic_sr71$.query(CommunityBanner_schema["a" /* default */].community, {
    raw: mainPath
  });
}
function tabberChange(activeThread) {
  // console.log('store is :', store)
  // console.log('tabberChange thread: ', thread2Subpath(activeThread))
  CommunityBanner_logic_debug('subPath set to: ', Object(utils["_1" /* thread2Subpath */])(activeThread));
  CommunityBanner_logic_store.markRoute({
    subPath: Object(utils["_1" /* thread2Subpath */])(activeThread)
  });
  CommunityBanner_logic_store.setViewing({
    activeThread: activeThread
  });
}
function showEditorList() {
  CommunityBanner_logic_debug('showEditorList ...');
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW, {
    type: utils["k" /* TYPE */].PREVIEW_COMMUNITY_EDITORS
  });
} // ###############################
// Data & Error handlers
// ###############################
// TODO: load cur community
// 两种情形: 1. 浏览器刷新页面. 2. 事件： Switch_Community

var CommunityBanner_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('community'),
  action: function action(_ref) {
    var community = _ref.community;
    var subPath = CommunityBanner_logic_store.curRoute.subPath;
    CommunityBanner_logic_store.setViewing({
      community: community,
      activeThread: Object(utils["V" /* subPath2Thread */])(subPath)
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].COMMUNITY_CHANGE),
  action: function action() {
    return loadCommunity();
  }
}];
var CommunityBanner_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref2) {
    var details = _ref2.details;
    CommunityBanner_logic_debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref3) {
    var details = _ref3.details;
    CommunityBanner_logic_debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref4) {
    var details = _ref4.details;
    CommunityBanner_logic_debug('ERR.NETWORK -->', details);
  }
}];
/*
   const loadIfNeed = () => {
   const { viewing, curRoute } = banner
   const community = viewing.community.raw
   const { mainPath } = curRoute

   if (community !== mainPath) {
   debug('>>>>>>>>> need load banner')
   loadCommunity()
   }
   }
 */

function CommunityBanner_logic_init(_store) {
  if (CommunityBanner_logic_store) return false;
  CommunityBanner_logic_store = _store;
  if (CommunityBanner_logic_sub$) CommunityBanner_logic_sub$.unsubscribe();
  CommunityBanner_logic_sub$ = CommunityBanner_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(CommunityBanner_logic_DataSolver, CommunityBanner_logic_ErrSolver));
  /* loadIfNeed() */
}
// CONCATENATED MODULE: ./containers/CommunityBanner/NumbersInfo.js
/*
 *
 * NumbersInfo
 *
 */





var NumbersInfo_NumbersInfo = function NumbersInfo(_ref) {
  var _ref$content = _ref.content,
      subscribersCount = _ref$content.subscribersCount,
      editorsCount = _ref$content.editorsCount,
      postsCount = _ref$content.postsCount;
  return external__react__default.a.createElement(numbers_info_NumbersWrapper, null, external__react__default.a.createElement(numbers_info_NumberSection, null, external__react__default.a.createElement(numbers_info_NumberTitle, null, "\u5173\u6CE8"), external__react__default.a.createElement(numbers_info_NumberItem, null, Object(utils["O" /* prettyNum */])(subscribersCount))), external__react__default.a.createElement(numbers_info_NumberDivider, null), external__react__default.a.createElement(numbers_info_NumberSection, {
    dead: true
  }, external__react__default.a.createElement(numbers_info_NumberTitle, {
    dead: true
  }, "\u5185\u5BB9"), external__react__default.a.createElement(numbers_info_NumberItem, {
    dead: true
  }, Object(utils["O" /* prettyNum */])(postsCount))), external__react__default.a.createElement(numbers_info_NumberDivider, null), external__react__default.a.createElement(numbers_info_NumberSection, null, external__react__default.a.createElement(numbers_info_NumberTitle, {
    dead: true
  }, "\u7F16\u8F91"), external__react__default.a.createElement(numbers_info_NumberItem, {
    onClick: showEditorList
  }, Object(utils["O" /* prettyNum */])(editorsCount))));
};

/* harmony default export */ var CommunityBanner_NumbersInfo = (NumbersInfo_NumbersInfo);
// CONCATENATED MODULE: ./containers/CommunityBanner/styles/index.js
var CommunityBanner_styles__templateObject = /*#__PURE__*/ CommunityBanner_styles__taggedTemplateLiteral(["\n  min-height: 125px;\n"]),
    CommunityBanner_styles__templateObject2 = /*#__PURE__*/ CommunityBanner_styles__taggedTemplateLiteral([""]);

function CommunityBanner_styles__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



 // TODO: extract it

var styles_BaseBanner =
/*#__PURE__*/
external__styled_components__default.a.nav.withConfig({
  displayName: "styles__BaseBanner",
  componentId: "s1rlmbhd-0"
})(["position:relative;min-height:140px;border-bottom:1px solid tomato;display:flex;flex-direction:column;justify-content:center;background:", ";border-bottom:1px solid;border-bottom-color:", ";@media (max-height:800px){min-height:130px;}"], Object(utils["W" /* theme */])('banner.bg'), Object(utils["W" /* theme */])('banner.spliter'));
var BaseTabber =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseTabber",
  componentId: "s1rlmbhd-1"
})(["position:absolute;bottom:-16px;width:80vw;display:flex;"]);
var styles_BaseBannerContent =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseBannerContent",
  componentId: "s1rlmbhd-2"
})(["display:flex;margin-left:8%;margin-right:8%;"]);
var CommunityBanner_styles_BannerContainer = styles_BaseBanner.extend(CommunityBanner_styles__templateObject);
var TabberWrapper = BaseTabber.extend(CommunityBanner_styles__templateObject2);
var CommunityBanner_styles_BannerContentWrapper = styles_BaseBannerContent.extend(CommunityBanner_styles__templateObject2);
var CommunityWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CommunityWrapper",
  componentId: "s1rlmbhd-3"
})(["display:flex;flex-grow:1;margin-top:-2rem;"]);
var LogoWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LogoWrapper",
  componentId: "s1rlmbhd-4"
})(["position:relative;width:60px;@media (max-height:800px){width:50px;}"]);
var CommunityLogo =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__CommunityLogo",
  componentId: "s1rlmbhd-5"
})(["width:60px;height:60px;@media (max-height:800px){width:50px;height:50px;}"]);
var CommunityInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CommunityInfo",
  componentId: "s1rlmbhd-6"
})(["display:flex;flex-direction:column;justify-content:center;margin-top:-6px;margin-left:1em;"]);
var CommunityBanner_styles_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Title",
  componentId: "s1rlmbhd-7"
})(["font-size:1.4rem;color:", ";@media (max-height:800px){font-size:1.3rem;}"], Object(utils["W" /* theme */])('banner.title')); // color: ${theme('font')};

var styles_Desc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Desc",
  componentId: "s1rlmbhd-8"
})(["font-size:1rem;color:", ";@media (max-height:800px){font-size:1rem;}"], Object(utils["W" /* theme */])('banner.desc'));
var LogoHolder =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__LogoHolder",
  componentId: "s1rlmbhd-9"
})(["fill:", ";width:50px;height:50px;@media (max-height:800px){width:40px;height:40px;}opacity:0.6;margin-top:3px;"], Object(utils["W" /* theme */])('banner.desc'));
// CONCATENATED MODULE: ./containers/CommunityBanner/index.js
function CommunityBanner__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { CommunityBanner__typeof = function _typeof(obj) { return typeof obj; }; } else { CommunityBanner__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return CommunityBanner__typeof(obj); }

function CommunityBanner__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function CommunityBanner__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function CommunityBanner__createClass(Constructor, protoProps, staticProps) { if (protoProps) CommunityBanner__defineProperties(Constructor.prototype, protoProps); if (staticProps) CommunityBanner__defineProperties(Constructor, staticProps); return Constructor; }

function CommunityBanner__possibleConstructorReturn(self, call) { if (call && (CommunityBanner__typeof(call) === "object" || typeof call === "function")) { return call; } return CommunityBanner__assertThisInitialized(self); }

function CommunityBanner__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function CommunityBanner__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * CommunityBanner
 *
 */








/* eslint-disable no-unused-vars */

var CommunityBanner_debug = Object(utils["G" /* makeDebugger */])('C:CommunityBanner');
/* eslint-enable no-unused-vars */

var CommunityLogoHolder = "".concat(config["e" /* ICON_ASSETS */], "/cmd/community_logo_holder.svg");

var CommunityBanner_CommunityBrief = function CommunityBrief(_ref) {
  var content = _ref.content;
  return external__react__default.a.createElement(CommunityWrapper, null, external__react__default.a.createElement(LogoWrapper, null, content.logo ? external__react__default.a.createElement(CommunityLogo, {
    src: content.logo || CommunityLogoHolder
  }) : external__react__default.a.createElement(LogoHolder, {
    src: CommunityLogoHolder
  })), external__react__default.a.createElement(CommunityInfo, null, external__react__default.a.createElement(CommunityBanner_styles_Title, null, content.title), external__react__default.a.createElement(styles_Desc, null, content.desc)));
};

var CommunityBanner_CommunityBannerContainer =
/*#__PURE__*/
function (_React$Component) {
  CommunityBanner__inherits(CommunityBannerContainer, _React$Component);

  function CommunityBannerContainer() {
    CommunityBanner__classCallCheck(this, CommunityBannerContainer);

    return CommunityBanner__possibleConstructorReturn(this, (CommunityBannerContainer.__proto__ || Object.getPrototypeOf(CommunityBannerContainer)).apply(this, arguments));
  }

  CommunityBanner__createClass(CommunityBannerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var communityBanner = this.props.communityBanner;
      CommunityBanner_logic_init(communityBanner);
    }
  }, {
    key: "render",
    value: function render() {
      var communityBanner = this.props.communityBanner;
      var _communityBanner$view = communityBanner.viewing,
          community = _communityBanner$view.community,
          activeThread = _communityBanner$view.activeThread;
      return external__react__default.a.createElement(CommunityBanner_styles_BannerContainer, null, external__react__default.a.createElement(CommunityBanner_styles_BannerContentWrapper, null, external__react__default.a.createElement(CommunityBanner_CommunityBrief, {
        content: community
      }), external__react__default.a.createElement(CommunityBanner_NumbersInfo, {
        content: community
      }), external__react__default.a.createElement(TabberWrapper, null, external__react__default.a.createElement(Tabber["a" /* default */], {
        source: community.threads,
        onChange: tabberChange,
        active: activeThread
      }))));
    }
  }]);

  return CommunityBannerContainer;
}(external__react__default.a.Component);

/* harmony default export */ var CommunityBanner = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('communityBanner'))(Object(external__mobx_react_["observer"])(CommunityBanner_CommunityBannerContainer)));
// CONCATENATED MODULE: ./containers/CommunitiesBanner/schema.js
var CommunitiesBanner_schema__templateObject = /*#__PURE__*/ CommunitiesBanner_schema__taggedTemplateLiteral(["\n  query($filter: PagedFilter!) {\n    pagedCategories(filter: $filter) {\n      entries {\n        id\n        title\n        raw\n      }\n      totalCount\n      totalPages\n      pageSize\n      pageNumber\n    }\n  }\n"]);

function CommunitiesBanner_schema__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedCategories = external__graphql_tag__default()(CommunitiesBanner_schema__templateObject);
var CommunitiesBanner_schema_schema = {
  pagedCategories: pagedCategories
};
/* harmony default export */ var CommunitiesBanner_schema = (CommunitiesBanner_schema_schema);
// CONCATENATED MODULE: ./containers/CommunitiesBanner/logic.js



var CommunitiesBanner_logic_sr71$ = new sr71["a" /* default */]();
var CommunitiesBanner_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var CommunitiesBanner_logic_debug = Object(utils["G" /* makeDebugger */])('L:CommunitiesBanner');
/* eslint-enable no-unused-vars */

var CommunitiesBanner_logic_store = null;
function loadCategories() {
  CommunitiesBanner_logic_sr71$.query(CommunitiesBanner_schema.pagedCategories, {
    filter: {}
  });
}
function tabOnChange(activeRaw) {
  CommunitiesBanner_logic_store.markRoute({
    subPath: activeRaw
  });
  CommunitiesBanner_logic_store.markState({
    activeRaw: activeRaw
  });
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].REFRESH_COMMUNITIES, {
    data: activeRaw
  });
} // ###############################
// Data & Error handlers
// ###############################

var CommunitiesBanner_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedCategories'),
  action: function action(_ref) {
    var pagedCategories = _ref.pagedCategories;
    CommunitiesBanner_logic_store.markState({
      pagedCategories: pagedCategories
    });
  }
}];
var CommunitiesBanner_logic_ErrSolver = [];
function CommunitiesBanner_logic_init(_store) {
  if (CommunitiesBanner_logic_store) return false;
  CommunitiesBanner_logic_store = _store;
  if (CommunitiesBanner_logic_sub$) CommunitiesBanner_logic_sub$.unsubscribe();
  CommunitiesBanner_logic_sub$ = CommunitiesBanner_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(CommunitiesBanner_logic_DataSolver, CommunitiesBanner_logic_ErrSolver));
  loadCategories();
}
// CONCATENATED MODULE: ./containers/CommunitiesBanner/styles/index.js


var CommunitiesBanner_styles_BannerContainer =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BannerContainer",
  componentId: "v7x52v-0"
})(["position:relative;min-height:140px;border-bottom:1px solid tomato;display:flex;flex-direction:column;justify-content:center;background:", ";border-bottom:", ";@media (max-height:800px){min-height:130px;}"], Object(utils["W" /* theme */])('banner.bg'), Object(utils["W" /* theme */])('banner.spliter'));
var styles_TabberWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TabberWrapper",
  componentId: "v7x52v-1"
})(["position:absolute;bottom:-16px;width:80vw;display:flex;justify-content:center;"]);
var CommunitiesBanner_styles_BannerContentWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BannerContentWrapper",
  componentId: "v7x52v-2"
})(["display:flex;margin-left:8%;margin-right:8%;"]);
// CONCATENATED MODULE: ./containers/CommunitiesBanner/index.js
function CommunitiesBanner__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { CommunitiesBanner__typeof = function _typeof(obj) { return typeof obj; }; } else { CommunitiesBanner__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return CommunitiesBanner__typeof(obj); }

function CommunitiesBanner__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function CommunitiesBanner__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function CommunitiesBanner__createClass(Constructor, protoProps, staticProps) { if (protoProps) CommunitiesBanner__defineProperties(Constructor.prototype, protoProps); if (staticProps) CommunitiesBanner__defineProperties(Constructor, staticProps); return Constructor; }

function CommunitiesBanner__possibleConstructorReturn(self, call) { if (call && (CommunitiesBanner__typeof(call) === "object" || typeof call === "function")) { return call; } return CommunitiesBanner__assertThisInitialized(self); }

function CommunitiesBanner__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function CommunitiesBanner__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * CommunitiesBanner
 *
 */


 // import Link from 'next/link'




/* eslint-disable no-unused-vars */

var CommunitiesBanner_debug = Object(utils["G" /* makeDebugger */])('C:CommunitiesBanner');
/* eslint-enable no-unused-vars */

var CommunitiesBanner_CommunitiesBannerContainer =
/*#__PURE__*/
function (_React$Component) {
  CommunitiesBanner__inherits(CommunitiesBannerContainer, _React$Component);

  function CommunitiesBannerContainer() {
    CommunitiesBanner__classCallCheck(this, CommunitiesBannerContainer);

    return CommunitiesBanner__possibleConstructorReturn(this, (CommunitiesBannerContainer.__proto__ || Object.getPrototypeOf(CommunitiesBannerContainer)).apply(this, arguments));
  }

  CommunitiesBanner__createClass(CommunitiesBannerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var communitiesBanner = this.props.communitiesBanner;
      CommunitiesBanner_logic_init(communitiesBanner);
    }
  }, {
    key: "render",
    value: function render() {
      var _props$communitiesBan = this.props.communitiesBanner,
          pagedCategoriesData = _props$communitiesBan.pagedCategoriesData,
          activeRaw = _props$communitiesBan.activeRaw;
      return external__react__default.a.createElement(CommunitiesBanner_styles_BannerContainer, null, external__react__default.a.createElement(CommunitiesBanner_styles_BannerContentWrapper, null, external__react__default.a.createElement("h2", null, "this is all communities"), pagedCategoriesData ? external__react__default.a.createElement(styles_TabberWrapper, null, external__react__default.a.createElement(Tabber["a" /* default */], {
        source: pagedCategoriesData.entries,
        active: activeRaw,
        onChange: tabOnChange
      })) : null));
    }
  }]);

  return CommunitiesBannerContainer;
}(external__react__default.a.Component);

/* harmony default export */ var CommunitiesBanner = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('communitiesBanner'))(Object(external__mobx_react_["observer"])(CommunitiesBanner_CommunitiesBannerContainer)));
// CONCATENATED MODULE: ./containers/UserContent/styles/index.js


var styles_Container =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Container",
  componentId: "a4rzb8-0"
})(["display:flex;margin-top:30px;margin-left:7%;margin-right:5%;"]);
var MainWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MainWrapper",
  componentId: "a4rzb8-1"
})(["padding:20px;padding-top:10px;min-height:600px;background:", ";margin-right:35px;box-shadow:0 1px 4px rgba(0,0,0,0.04);width:65%;display:flex;flex-direction:column;"], Object(utils["W" /* theme */])('preview.articleBg'));
var UserContent_styles_TabberWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TabberWrapper",
  componentId: "a4rzb8-2"
})(["width:80vw;display:flex;"]);
var SidebarWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SidebarWrapper",
  componentId: "a4rzb8-3"
})(["width:300px;"]);
var CardWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CardWrapper",
  componentId: "a4rzb8-4"
})(["background:", ";box-shadow:0 1px 4px rgba(0,0,0,0.04);padding:20px;min-height:100px;margin-bottom:15px;"], Object(utils["W" /* theme */])('preview.articleBg'));
// CONCATENATED MODULE: ./containers/UserContent/logic.js
// import R from 'ramda'


var UserContent_logic_sr71$ = new sr71["a" /* default */]();
var UserContent_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var UserContent_logic_debug = Object(utils["G" /* makeDebugger */])('L:UserContent');
/* eslint-enable no-unused-vars */

var UserContent_logic_store = null;
function logic_someMethod() {} // ###############################
// Data & Error handlers
// ###############################

var UserContent_logic_DataSolver = [];
var UserContent_logic_ErrSolver = [];
function UserContent_logic_init(_store) {
  if (UserContent_logic_store) return false;
  UserContent_logic_store = _store;
  UserContent_logic_debug(UserContent_logic_store);
  if (UserContent_logic_sub$) UserContent_logic_sub$.unsubscribe();
  UserContent_logic_sub$ = UserContent_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(UserContent_logic_DataSolver, UserContent_logic_ErrSolver));
}
// CONCATENATED MODULE: ./containers/UserContent/index.js
function UserContent__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { UserContent__typeof = function _typeof(obj) { return typeof obj; }; } else { UserContent__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return UserContent__typeof(obj); }

function UserContent__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function UserContent__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function UserContent__createClass(Constructor, protoProps, staticProps) { if (protoProps) UserContent__defineProperties(Constructor.prototype, protoProps); if (staticProps) UserContent__defineProperties(Constructor, staticProps); return Constructor; }

function UserContent__possibleConstructorReturn(self, call) { if (call && (UserContent__typeof(call) === "object" || typeof call === "function")) { return call; } return UserContent__assertThisInitialized(self); }

function UserContent__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function UserContent__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * UserContent
 *
 */

 // import Link from 'next/link'





/* eslint-disable no-unused-vars */

var UserContent_debug = Object(utils["G" /* makeDebugger */])('C:UserContent');
/* eslint-enable no-unused-vars */

var fakeThreads = [{
  title: '动态',
  raw: 'activity'
}, {
  title: '帖子',
  raw: 'post'
}, {
  title: '评论',
  raw: 'comment'
}, {
  title: '收藏',
  raw: 'favorite'
}, {
  title: '喜欢',
  raw: 'like'
}, {
  title: '自定义',
  raw: 'customization'
}];

var UserContent_UserContentContainer =
/*#__PURE__*/
function (_React$Component) {
  UserContent__inherits(UserContentContainer, _React$Component);

  function UserContentContainer() {
    UserContent__classCallCheck(this, UserContentContainer);

    return UserContent__possibleConstructorReturn(this, (UserContentContainer.__proto__ || Object.getPrototypeOf(UserContentContainer)).apply(this, arguments));
  }

  UserContent__createClass(UserContentContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var userContent = this.props;
      UserContent_logic_init(userContent);
    }
  }, {
    key: "render",
    value: function render() {
      return external__react__default.a.createElement(styles_Container, null, external__react__default.a.createElement(MainWrapper, null, external__react__default.a.createElement(UserContent_styles_TabberWrapper, {
        className: "tabs-with-bottom"
      }, external__react__default.a.createElement(components["z" /* Tabber */], {
        source: fakeThreads,
        onChange: UserContent_debug,
        active: "activity"
      })), external__react__default.a.createElement("h2", null, "UserContent container!")), external__react__default.a.createElement(SidebarWrapper, null, external__react__default.a.createElement(CardWrapper, null, external__react__default.a.createElement("h3", null, "\u4E2A\u4EBA\u6210\u5C31"), external__react__default.a.createElement("div", null, "\u5171\u83B7\u5F97 xx \u8D5E"), external__react__default.a.createElement("div", null, "\u521B\u4F5C\u7684\u5185\u5BB9\u88AB\u6536\u85CF xx \u6B21"), external__react__default.a.createElement("br", null), external__react__default.a.createElement("br", null), external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary"
      }, external__react__default.a.createElement(components["k" /* Icon */], {
        type: "plus"
      }), "\u5173\u6CE8\u4ED6")), external__react__default.a.createElement(CardWrapper, null, external__react__default.a.createElement("div", null, "\u5173\u6CE8\u4E2D"), external__react__default.a.createElement("div", null, "\u5173\u6CE8\u8005")), external__react__default.a.createElement(CardWrapper, null, external__react__default.a.createElement("div", null, "Javascript \u793E\u533A\u7F16\u8F91"))));
    }
  }]);

  return UserContentContainer;
}(external__react__default.a.Component);

/* harmony default export */ var UserContent = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('userContent'))(Object(external__mobx_react_["observer"])(UserContent_UserContentContainer)));
// CONCATENATED MODULE: ./containers/CommunitiesContent/styles/index.js



var CommunityIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__CommunityIcon",
  componentId: "s1mmkonn-0"
})(["width:60px;height:60px;margin-top:-40px;"]);
var Card =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Card",
  componentId: "s1mmkonn-1"
})(["position:relative;padding-top:12px;padding:10px;padding-bottom:0;width:250px;height:250px;margin-right:30px;background:", ";border:1px solid;border-color:", ";&:hover{border:1px solid;border-color:", ";}border-radius:3px;display:flex;flex-direction:column;align-items:center;margin-bottom:60px;"], Object(utils["W" /* theme */])('content.cardBg'), Object(utils["W" /* theme */])('content.cardBorder'), Object(utils["W" /* theme */])('content.cardBorderHover'));
var CardTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CardTitle",
  componentId: "s1mmkonn-2"
})(["font-size:1.2em;font-weight:bold;margin-top:5px;text-align:center;color:", ";"], Object(utils["W" /* theme */])('banner.title'));
var CardDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CardDesc",
  componentId: "s1mmkonn-3"
})(["font-size:1em;text-align:center;min-height:50px;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var ActivitySpark =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ActivitySpark",
  componentId: "s1mmkonn-4"
})(["width:60%;"]);
var CardFooter =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CardFooter",
  componentId: "s1mmkonn-5"
})(["display:flex;width:100%;justify-content:space-around;position:absolute;bottom:16px;color:", ";"], Object(utils["W" /* theme */])('banner.desc'));
var CommunitiesContent_styles_Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Divider",
  componentId: "s1mmkonn-6"
})(["width:90%;margin-top:12px;border-top:1px solid;border-top-color:", ";margin-bottom:5px;"], Object(utils["W" /* theme */])('content.cardBorder'));
var GridWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__GridWrapper",
  componentId: "s1mmkonn-7"
})(["display:flex;flex-wrap:wrap;justify-content:center;"]);
var CommunitiesContent_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1mmkonn-8"
})(["margin-top:45px;display:flex;flex-direction:column;justify-content:center;"]);
// EXTERNAL MODULE: ./containers/CommunitiesContent/schema.js
var CommunitiesContent_schema = __webpack_require__(96);

// CONCATENATED MODULE: ./containers/CommunitiesContent/logic.js
// import R from 'ramda'



var CommunitiesContent_logic_sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].LOGOUT, utils["e" /* EVENT */].LOGIN, utils["e" /* EVENT */].REFRESH_COMMUNITIES]
});
/* eslint-disable no-unused-vars */

var CommunitiesContent_logic_debug = Object(utils["G" /* makeDebugger */])('L:CommunitiesContent');
/* eslint-enable no-unused-vars */

var CommunitiesContent_logic_store = null;
var CommunitiesContent_logic_sub$ = null;
function loadCommunities() {
  var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  var category = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'all';
  var args = {
    filter: {
      page: page,
      size: 20
    },
    userHasLogin: CommunitiesContent_logic_store.isLogin
  };

  if (category !== 'all') {
    args.filter.category = category;
  }

  CommunitiesContent_logic_sr71$.query(CommunitiesContent_schema["a" /* default */].pagedCommunities, args);
}
function logic_pageChange(page) {
  // TODO: merge category args
  loadCommunities(page);
}
function subscribe(id) {
  CommunitiesContent_logic_debug('subscribe', id);
  CommunitiesContent_logic_sr71$.mutate(CommunitiesContent_schema["a" /* default */].subscribeCommunity, {
    communityId: id
  });
  CommunitiesContent_logic_store.markState({
    subscribing: true,
    subscribingId: id
  });
}
function unSubscribe(id) {
  CommunitiesContent_logic_debug('unSubscribe', id);
  CommunitiesContent_logic_sr71$.mutate(CommunitiesContent_schema["a" /* default */].unsubscribeCommunity, {
    communityId: id
  });
  CommunitiesContent_logic_store.markState({
    subscribing: true,
    subscribingId: id
  });
}
/* when error occured cancle all the loading state */

var logic_cancleLoading = function cancleLoading() {
  CommunitiesContent_logic_store.markState({
    subscribing: false
  });
};

var CommunitiesContent_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedCommunities'),
  action: function action(_ref) {
    var pagedCommunities = _ref.pagedCommunities;
    return CommunitiesContent_logic_store.markState({
      pagedCommunities: pagedCommunities
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('subscribeCommunity'),
  action: function action(_ref2) {
    var subscribeCommunity = _ref2.subscribeCommunity;
    CommunitiesContent_logic_store.addSubscribedCommunity(subscribeCommunity);
    CommunitiesContent_logic_store.markState({
      subscribing: false
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('unsubscribeCommunity'),
  action: function action(_ref3) {
    var unsubscribeCommunity = _ref3.unsubscribeCommunity;
    CommunitiesContent_logic_store.removeSubscribedCommunity(unsubscribeCommunity);
    CommunitiesContent_logic_store.markState({
      subscribing: false
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].REFRESH_COMMUNITIES),
  action: function action(res) {
    var data = res[utils["e" /* EVENT */].REFRESH_COMMUNITIES].data;
    loadCommunities(1, data);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].LOGOUT),
  action: function action() {
    return loadCommunities();
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].LOGIN),
  action: function action() {
    return loadCommunities();
  }
}];
var CommunitiesContent_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref4) {
    var details = _ref4.details;
    CommunitiesContent_logic_debug('ERR.CRAPHQL -->', details);
    logic_cancleLoading();
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref5) {
    var details = _ref5.details;
    CommunitiesContent_logic_debug('ERR.TIMEOUT -->', details);
    logic_cancleLoading();
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref6) {
    var details = _ref6.details;
    CommunitiesContent_logic_debug('ERR.NETWORK -->', details);
    logic_cancleLoading();
  }
}];
function CommunitiesContent_logic_init(_store) {
  if (CommunitiesContent_logic_store) return false;
  CommunitiesContent_logic_store = _store;
  if (CommunitiesContent_logic_sub$) CommunitiesContent_logic_sub$.unsubscribe();
  CommunitiesContent_logic_sub$ = CommunitiesContent_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(CommunitiesContent_logic_DataSolver, CommunitiesContent_logic_ErrSolver));
  /* loadCommunities() */

  var user = utils["c" /* BStore */].get('user');

  if (user) {
    utils["c" /* BStore */].cookie.set('jwtToken', user.token);
  }
}
// CONCATENATED MODULE: ./containers/CommunitiesContent/index.js
var CommunitiesContent__this = this;

function CommunitiesContent__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { CommunitiesContent__typeof = function _typeof(obj) { return typeof obj; }; } else { CommunitiesContent__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return CommunitiesContent__typeof(obj); }

function CommunitiesContent__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { CommunitiesContent__defineProperty(target, key, source[key]); }); } return target; }

function CommunitiesContent__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function CommunitiesContent__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function CommunitiesContent__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function CommunitiesContent__createClass(Constructor, protoProps, staticProps) { if (protoProps) CommunitiesContent__defineProperties(Constructor.prototype, protoProps); if (staticProps) CommunitiesContent__defineProperties(Constructor, staticProps); return Constructor; }

function CommunitiesContent__possibleConstructorReturn(self, call) { if (call && (CommunitiesContent__typeof(call) === "object" || typeof call === "function")) { return call; } return CommunitiesContent__assertThisInitialized(self); }

function CommunitiesContent__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function CommunitiesContent__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * CommunitiesContent
 *
 */






/* eslint-disable no-unused-vars */

var CommunitiesContent_debug = Object(utils["G" /* makeDebugger */])('C:CommunitiesContent');
/* eslint-enable no-unused-vars */

var CommunitiesContent_SubscribeBtn = function SubscribeBtn(_ref) {
  var community = _ref.community,
      _ref$restProps = _ref.restProps,
      subscribing = _ref$restProps.subscribing,
      subscribingId = _ref$restProps.subscribingId;

  if (subscribing && community.id === subscribingId) {
    return external__react__default.a.createElement("div", null, external__react__default.a.createElement(components["d" /* Button */], {
      size: "small",
      type: "primary"
    }, external__react__default.a.createElement(components["k" /* Icon */], {
      type: "loading"
    }), " \u5173\u6CE8"));
  }

  return external__react__default.a.createElement("div", null, community.viewerHasSubscribed ? external__react__default.a.createElement(components["D" /* Tooltip */], {
    title: "\u53D6\u6D88\u5173\u6CE8",
    mouseEnterDelay: 1,
    placement: "bottom"
  }, external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: unSubscribe.bind(CommunitiesContent__this, community.id)
  }, external__react__default.a.createElement(components["k" /* Icon */], {
    type: "check"
  }), "\u5DF2\u5173\u6CE8")) : external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "primary",
    onClick: subscribe.bind(CommunitiesContent__this, community.id)
  }, external__react__default.a.createElement(components["k" /* Icon */], {
    type: "plus"
  }), "\u5173\u6CE8"));
};

var CommunitiesContent_CommunityCard = function CommunityCard(_ref2) {
  var community = _ref2.community,
      restProps = _ref2.restProps;
  return external__react__default.a.createElement(Card, null, external__react__default.a.createElement(CommunityIcon, {
    src: community.logo
  }), external__react__default.a.createElement(CardTitle, null, community.title), external__react__default.a.createElement(CardDesc, null, community.desc), external__react__default.a.createElement(ActivitySpark, null, external__react__default.a.createElement(components["E" /* TrendLine */], {
    data: community.contributesDigest
  })), external__react__default.a.createElement(CommunitiesContent_styles_Divider, null), external__react__default.a.createElement(CardFooter, null, external__react__default.a.createElement(external__react__default.a.Fragment, null, Object(utils["O" /* prettyNum */])(community.subscribersCount), ' ', community.subscribersCount < 1000 ? '人关注' : '关注'), external__react__default.a.createElement(CommunitiesContent_SubscribeBtn, {
    community: community,
    restProps: restProps
  })));
};

var CommunitiesContent_CommunitiesGrid = function CommunitiesGrid(_ref3) {
  var entries = _ref3.entries,
      restProps = _ref3.restProps;
  return external__react__default.a.createElement(GridWrapper, null, entries.map(function (community) {
    return external__react__default.a.createElement(CommunitiesContent_CommunityCard, {
      key: community.raw,
      community: community,
      restProps: restProps
    });
  }));
};

var CommunitiesContent_CommunitiesContentContainer =
/*#__PURE__*/
function (_React$Component) {
  CommunitiesContent__inherits(CommunitiesContentContainer, _React$Component);

  function CommunitiesContentContainer() {
    CommunitiesContent__classCallCheck(this, CommunitiesContentContainer);

    return CommunitiesContent__possibleConstructorReturn(this, (CommunitiesContentContainer.__proto__ || Object.getPrototypeOf(CommunitiesContentContainer)).apply(this, arguments));
  }

  CommunitiesContent__createClass(CommunitiesContentContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var communitiesContent = this.props.communitiesContent;
      CommunitiesContent_logic_init(communitiesContent);
    }
  }, {
    key: "render",
    value: function render() {
      var communitiesContent = this.props.communitiesContent;
      var pagedCommunitiesData = communitiesContent.pagedCommunitiesData;
      return external__react__default.a.createElement(CommunitiesContent_styles_Wrapper, null, pagedCommunitiesData ? external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(CommunitiesContent_CommunitiesGrid, {
        entries: pagedCommunitiesData.entries,
        restProps: CommunitiesContent__objectSpread({}, communitiesContent)
      }), external__react__default.a.createElement(components["r" /* Pagi */], {
        left: "-10px",
        pageNumber: pagedCommunitiesData.pageNumber,
        pageSize: pagedCommunitiesData.pageSize,
        totalCount: pagedCommunitiesData.totalCount,
        onChange: logic_pageChange
      })) : null);
    }
  }]);

  return CommunitiesContentContainer;
}(external__react__default.a.Component);

/* harmony default export */ var CommunitiesContent = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('communitiesContent'))(Object(external__mobx_react_["observer"])(CommunitiesContent_CommunitiesContentContainer)));
// CONCATENATED MODULE: ./containers/PostContent/logic.js
// import R from 'ramda'


var PostContent_logic_sr71$ = new sr71["a" /* default */]();
var PostContent_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var PostContent_logic_debug = Object(utils["G" /* makeDebugger */])('L:PostContent');
/* eslint-enable no-unused-vars */

var PostContent_logic_store = null;
function PostContent_logic_someMethod() {} // ###############################
// Data & Error handlers
// ###############################

var PostContent_logic_DataSolver = [];
var PostContent_logic_ErrSolver = [];
function PostContent_logic_init(_store) {
  if (PostContent_logic_store) return false;
  PostContent_logic_store = _store;
  PostContent_logic_debug(PostContent_logic_store);
  if (PostContent_logic_sub$) PostContent_logic_sub$.unsubscribe();
  PostContent_logic_sub$ = PostContent_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(PostContent_logic_DataSolver, PostContent_logic_ErrSolver));
}
// CONCATENATED MODULE: ./containers/PostContent/styles/index.js



var PostContent_styles_Container =
/*#__PURE__*/
external__styled_components__default.a.article.withConfig({
  displayName: "styles__Container",
  componentId: "s1thb3gq-0"
})(["padding:20px;min-height:300px;display:flex;"]);
var styles_MainWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MainWrapper",
  componentId: "s1thb3gq-1"
})(["width:70%;margin-left:2.5rem;"]);
/* background: ${theme('preview.articleBg')}; */

var ArticleWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ArticleWrapper",
  componentId: "s1thb3gq-2"
})(["font-size:1.1rem;margin-left:2vw;margin-right:1.6vw;background:", ";border-radius:5px;padding:35px 40px;min-height:60vh;box-shadow:0 1px 4px rgba(0,0,0,0.04);"], Object(utils["W" /* theme */])('preview.articleBg'));
var styles_CommentsWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CommentsWrapper",
  componentId: "s1thb3gq-3"
})(["margin-top:30px;margin:25px;"]); // TODO: use media

var styles_BodyWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BodyWrapper",
  componentId: "s1thb3gq-4"
})([""]);
var SideWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SideWrapper",
  componentId: "s1thb3gq-5"
})(["min-height:180px;margin-top:20px;height:100%;padding-left:20px;max-width:200px;flex-wrap:wrap;"]);
var CommunityTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CommunityTitle",
  componentId: "s1thb3gq-6"
})(["color:#56868a;font-size:1em;"]);
var SidebarTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SidebarTitle",
  componentId: "s1thb3gq-7"
})(["color:#56868a;font-size:1em;"]);
var SidebarDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SidebarDesc",
  componentId: "s1thb3gq-8"
})(["display:flex;margin-top:15px;margin-bottom:10px;padding-bottom:15px;flex-direction:", ";border-bottom:", ";border-color:", ";max-width:100%;flex-wrap:wrap;"], function (_ref) {
  var column = _ref.column;
  return column ? 'column' : 'row';
}, function (_ref2) {
  var noBottom = _ref2.noBottom;
  return noBottom ? '' : '1px solid';
}, Object(utils["W" /* theme */])('preview.divider'));
var NomoreDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NomoreDesc",
  componentId: "s1thb3gq-9"
})(["color:", ";font-style:italic;"], Object(utils["W" /* theme */])('preview.divider'));
var styles_CommunityIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__CommunityIcon",
  componentId: "s1thb3gq-10"
})(["width:25px;height:25px;margin-right:6px;"]);
var TagWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagWrapper",
  componentId: "s1thb3gq-11"
})(["display:flex;margin-bottom:12px;margin-left:2px;"]);
var TagDot =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagDot",
  componentId: "s1thb3gq-12"
})(["width:10px;height:10px;background:tomato;border-radius:50%;margin-right:5px;"]);
var TagTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagTitle",
  componentId: "s1thb3gq-13"
})(["margin-top:-5px;"]);
var RelatedUser =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__RelatedUser",
  componentId: "s1thb3gq-14"
})(["border-radius:100%;width:25px;height:25px;margin-right:8px;margin-bottom:5px;"]);
// CONCATENATED MODULE: ./containers/PostContent/index.js



function PostContent__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { PostContent__typeof = function _typeof(obj) { return typeof obj; }; } else { PostContent__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return PostContent__typeof(obj); }

function PostContent__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function PostContent__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function PostContent__createClass(Constructor, protoProps, staticProps) { if (protoProps) PostContent__defineProperties(Constructor.prototype, protoProps); if (staticProps) PostContent__defineProperties(Constructor, staticProps); return Constructor; }

function PostContent__possibleConstructorReturn(self, call) { if (call && (PostContent__typeof(call) === "object" || typeof call === "function")) { return call; } return PostContent__assertThisInitialized(self); }

function PostContent__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function PostContent__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * PostContent
 *
 */








/* eslint-disable no-unused-vars */

var PostContent_debug = Object(utils["G" /* makeDebugger */])('C:PostContent');
/* eslint-enable no-unused-vars */

var PostContent_Communities = function Communities(_ref) {
  var data = _ref.data;
  if (isEmpty__default()(data)) return external__react__default.a.createElement(NomoreDesc, null, "\u4E0D\u5C5E\u4E8E\u4EFB\u4F55\u793E\u533A");
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, data.map(function (c) {
    return external__react__default.a.createElement(styles_CommunityIcon, {
      key: external__shortid__default.a.generate(),
      src: c.logo
    });
  }));
};

var PostContent_Tags = function Tags(_ref2) {
  var data = _ref2.data;
  if (isEmpty__default()(data)) return external__react__default.a.createElement(NomoreDesc, null, "\u65E0\u6807\u7B7E");
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, data.map(function (t) {
    return external__react__default.a.createElement(TagWrapper, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement(TagDot, {
      color: t.color
    }), external__react__default.a.createElement(TagTitle, null, t.title));
  }));
};

var PostContent_PostContentContainer =
/*#__PURE__*/
function (_React$Component) {
  PostContent__inherits(PostContentContainer, _React$Component);

  function PostContentContainer() {
    PostContent__classCallCheck(this, PostContentContainer);

    return PostContent__possibleConstructorReturn(this, (PostContentContainer.__proto__ || Object.getPrototypeOf(PostContentContainer)).apply(this, arguments));
  }

  PostContent__createClass(PostContentContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var postContent = this.props.postContent;
      PostContent_logic_init(postContent);
    }
  }, {
    key: "render",
    value: function render() {
      var postData = this.props.postContent.postData;
      return external__react__default.a.createElement(PostContent_styles_Container, null, isNil__default()(postData.id) ? null : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(styles_MainWrapper, null, external__react__default.a.createElement(ArticleWrapper, null, external__react__default.a.createElement(components["n" /* MarkDownRender */], {
        body: postData.body
      })), external__react__default.a.createElement(styles_CommentsWrapper, null, external__react__default.a.createElement(Comments, null))), external__react__default.a.createElement(SideWrapper, null, external__react__default.a.createElement(SidebarTitle, null, "\u6240\u5C5E\u793E\u533A"), external__react__default.a.createElement(SidebarDesc, null, external__react__default.a.createElement(PostContent_Communities, {
        data: postData.communities
      })), external__react__default.a.createElement(SidebarTitle, null, "\u6807\u7B7E"), external__react__default.a.createElement(SidebarDesc, {
        column: true,
        noBottom: true
      }, external__react__default.a.createElement(PostContent_Tags, {
        data: postData.tags
      })))));
    }
  }]);

  return PostContentContainer;
}(external__react__default.a.Component);

/* harmony default export */ var PostContent = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('postContent'))(Object(external__mobx_react_["observer"])(PostContent_PostContentContainer)));
// EXTERNAL MODULE: external "react-waypoint"
var external__react_waypoint_ = __webpack_require__(47);
var external__react_waypoint__default = /*#__PURE__*/__webpack_require__.n(external__react_waypoint_);

// CONCATENATED MODULE: ./containers/PostsThread/styles/item.js



var item_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.article.withConfig({
  displayName: "item__Wrapper",
  componentId: "s3etalk-0"
})(["display:flex;padding-left:8px;padding-right:8px;padding-top:6px;padding-bottom:6px;border-radius:4px;background:", ";background:", ";opacity:", ";&:hover{cursor:pointer;background:", ";}"], function (_ref) {
  var current = _ref.current,
      active = _ref.active;
  return current.id === active.id ? Object(utils["W" /* theme */])('thread.articleHover') : '';
}, function (_ref2) {
  var index = _ref2.index;
  return index % 2 === 0 ? Object(utils["W" /* theme */])('thread.articleStrip') : '';
}, function (_ref3) {
  var current = _ref3.current,
      active = _ref3.active;
  return active.id && current.id !== active.id ? 0.6 : 1;
}, Object(utils["W" /* theme */])('thread.articleHover'));
var Main =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Main",
  componentId: "s3etalk-1"
})(["display:flex;flex-grow:1;flex-direction:column;"]);
var TopHalf =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TopHalf",
  componentId: "s3etalk-2"
})(["display:flex;"]);
var SecondHalf =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "item__SecondHalf",
  componentId: "s3etalk-3"
})(["margin-left:10px;margin-top:-10px;"]);
var item_Avatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "item__Avatar",
  componentId: "s3etalk-4"
})(["width:42px;height:42px;border-radius:100%;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var Breif =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Breif",
  componentId: "s3etalk-5"
})(["display:flex;flex-grow:1;margin-left:10px;color:", ";"], Object(utils["W" /* theme */])('thread.articleTitle'));
var item_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Title",
  componentId: "s3etalk-6"
})(["margin-bottom:10px;font-size:1rem;@media (max-width:1450px){max-width:500px;}@media (max-width:1250px){max-width:450px;}@media (max-width:1100px){max-width:350px;}"]);
var TitleTagDot =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "item__TitleTagDot",
  componentId: "s3etalk-7"
})(["width:10px;height:10px;margin-right:4px;border-radius:50%;background-color:#9cd090;display:inline-block;opacity:", ";"], Object(utils["W" /* theme */])('tags.dotOpacity'));
var TitleLink =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleLink",
  componentId: "s3etalk-8"
})(["position:relative;font-size:0.9rem;margin-top:2px;color:", ";margin-left:10px;opacity:0.8;text-decoration:underline;"], Object(utils["W" /* theme */])('thread.articleLink'));
var TitleTag =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleTag",
  componentId: "s3etalk-9"
})(["color:", ";margin-left:10px;margin-top:2px;opacity:0.8;font-size:0.9rem;"], Object(utils["W" /* theme */])('thread.articleTag'));
var LinkIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__LinkIcon",
  componentId: "s3etalk-10"
})(["fill:", ";position:absolute;top:6px;left:-5px;width:12px;height:12px;"], Object(utils["W" /* theme */])('thread.articleLink'));
var Extra =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__Extra",
  componentId: "s3etalk-11"
})(["display:inline;opacity:0.7;transition:opacity 0.2s;font-size:0.85rem;color:", ";"], Object(utils["W" /* theme */])('thread.extraInfo'));
var BodyDigest =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__BodyDigest",
  componentId: "s3etalk-12"
})(["margin-top:5px;color:", ";margin-right:20px;white-space:normal;display:block;font-size:0.85rem;"], Object(utils["W" /* theme */])('thread.articleDigest'));
// EXTERNAL MODULE: external "ramda/src/toUpper"
var toUpper_ = __webpack_require__(24);
var toUpper__default = /*#__PURE__*/__webpack_require__.n(toUpper_);

// EXTERNAL MODULE: ./containers/PostsThread/schema.js
var PostsThread_schema = __webpack_require__(79);

// CONCATENATED MODULE: ./containers/PostsThread/logic.js






function logic__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { PostsThread_logic__defineProperty(target, key, source[key]); }); } return target; }

function PostsThread_logic__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // import sr71$ from '../../utils/network/sr71_simple'

var PostsThread_logic_sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].REFRESH_POSTS, utils["e" /* EVENT */].PREVIEW_CLOSED, utils["e" /* EVENT */].COMMUNITY_CHANGE]
});
/* eslint-disable no-unused-vars */

var PostsThread_logic_debug = Object(utils["G" /* makeDebugger */])('L:PostsThread');
/* eslint-enable no-unused-vars */

var PostsThread_logic_store = null;
var PostsThread_logic_sub$ = null; // TODO: move to utils

var validFilter = pickBy__default()(compose__default()(not__default.a, isEmpty__default.a));

var inAnchor = function inAnchor() {
  return PostsThread_logic_store.setHeaderFix(false);
};
var outAnchor = function outAnchor() {
  return PostsThread_logic_store.setHeaderFix(true);
};
function loadPosts() {
  var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  // NOTE: do not use viewing.community, it's too slow
  var mainPath = PostsThread_logic_store.curRoute.mainPath;
  var community = mainPath;
  PostsThread_logic_store.markState({
    curView: utils["k" /* TYPE */].LOADING
  });
  var args = {
    filter: logic__objectSpread({
      page: page,
      size: config["h" /* PAGE_SIZE */].COMMON
    }, PostsThread_logic_store.filtersData, {
      tag: PostsThread_logic_store.activeTagData.raw,
      community: community
    })
  };
  args.filter = validFilter(args.filter);
  Object(utils["Q" /* scrollIntoEle */])(utils["k" /* TYPE */].APP_HEADER_ID);
  PostsThread_logic_debug('load posts --> ', args);
  PostsThread_logic_sr71$.query(PostsThread_schema["a" /* default */].pagedPosts, args);
  PostsThread_logic_store.markRoute({
    page: page
  });
}
function loadTags() {
  // NOTE: do not use viewing.community, it's too slow
  var mainPath = PostsThread_logic_store.curRoute.mainPath;
  var community = mainPath;

  var thread = toUpper__default()(utils["j" /* THREAD */].POST);

  var args = {
    community: community,
    thread: thread
  };
  PostsThread_logic_debug('loadTags --> ', args);
  PostsThread_logic_sr71$.query(PostsThread_schema["a" /* default */].partialTags, args);
}
function onFilterSelect(option) {
  PostsThread_logic_store.selectFilter(option);
  loadPosts();
}
function onTagSelect(tag) {
  PostsThread_logic_store.selectTag(tag);
  loadPosts();
}
function onTitleSelect(post) {
  PostsThread_logic_store.setViewing({
    post: post
  });
  /* store.setActive(post) */

  PostsThread_logic_debug('onTitleSelect publish post: ', post); // dispatchEvent(EVENT.PREVIEW, { type: TYPE.POST_PREVIEW_VIEW, data: post })

  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].NAV_EDIT, {
    type: utils["k" /* TYPE */].POST_PREVIEW_VIEW,
    data: post
  });
  utils["g" /* GA */].event({
    action: post.title,
    category: '浏览',
    label: '社区'
  });
}
function createContent() {
  PostsThread_logic_debug('onTitleSelect createContent ');
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].NAV_CREATE_POST, {
    type: utils["k" /* TYPE */].PREVIEW_CREATE_POST
  });
}
var PostsThread_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedPosts'),
  action: function action(_ref) {
    var pagedPosts = _ref.pagedPosts;
    var curView = utils["k" /* TYPE */].RESULT;

    if (pagedPosts.entries.length === 0) {
      curView = utils["k" /* TYPE */].RESULT_EMPTY;
    }

    PostsThread_logic_store.markState({
      curView: curView,
      pagedPosts: pagedPosts
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('partialTags'),
  action: function action(_ref2) {
    var partialTags = _ref2.partialTags;
    PostsThread_logic_store.markState({
      tags: partialTags
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].COMMUNITY_CHANGE),
  action: function action() {
    loadPosts();
    Object(utils["F" /* later */])(loadTags, 500);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].REFRESH_POSTS),
  action: function action(res) {
    PostsThread_logic_debug('EVENT.REFRESH_POSTS: ', res);
    loadPosts();
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW_CLOSED),
  action: function action() {
    return PostsThread_logic_store.setViewing({
      post: {}
    });
  }
}];
var PostsThread_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref3) {
    var details = _ref3.details;
    PostsThread_logic_debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref4) {
    var details = _ref4.details;
    PostsThread_logic_debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref5) {
    var details = _ref5.details;
    PostsThread_logic_debug('ERR.NETWORK -->', details);
  }
}];

var logic_loadIfNeed = function loadIfNeed() {
  if (!PostsThread_logic_store.pagedPosts) {
    loadPosts();
    Object(utils["F" /* later */])(loadTags, 300);
  }
};

function PostsThread_logic_init(_store) {
  if (PostsThread_logic_store) return false;
  PostsThread_logic_store = _store;
  if (PostsThread_logic_sub$) PostsThread_logic_sub$.unsubscribe();
  PostsThread_logic_sub$ = PostsThread_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(PostsThread_logic_DataSolver, PostsThread_logic_ErrSolver));
  logic_loadIfNeed();
}
// CONCATENATED MODULE: ./containers/PostsThread/Item.js
var Item__this = this;









var Item_Item = function Item(_ref) {
  var data = _ref.data,
      active = _ref.active,
      index = _ref.index;
  return external__react__default.a.createElement(item_Wrapper, {
    current: data,
    active: active,
    index: index
  }, external__react__default.a.createElement("div", null, external__react__default.a.createElement(item_Avatar, {
    src: data.author.avatar,
    alt: "avatar"
  })), external__react__default.a.createElement(Main, null, external__react__default.a.createElement(TopHalf, null, external__react__default.a.createElement(Breif, {
    onClick: onTitleSelect.bind(Item__this, data)
  }, external__react__default.a.createElement(item_Title, null, data.title), external__react__default.a.createElement(TitleLink, null, external__react__default.a.createElement(LinkIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/link.svg")
  }), external__react__default.a.createElement("span", {
    style: {
      marginLeft: 9
    }
  }, "github")), external__react__default.a.createElement(TitleTag, null, external__react__default.a.createElement(TitleTagDot, null), "\u95EE\u7B54")), external__react__default.a.createElement("div", null, external__react__default.a.createElement(components["c" /* AvatarsRow */], {
    users: data.commentsParticipators,
    total: data.commentsParticipatorsCount
  }))), external__react__default.a.createElement(SecondHalf, null, external__react__default.a.createElement(Extra, null, data.author.nickname, " \u53D1\u5E03\u4E8E:", ' ', external__react__default.a.createElement(external__timeago_react__default.a, {
    datetime: data.insertedAt,
    locale: "zh_CN"
  }), " \u205D \u6D4F\u89C8:", ' ', data.views), external__react__default.a.createElement(BodyDigest, null, Object(utils["s" /* cutFrom */])(data.digest, 90)))));
};

/* harmony default export */ var PostsThread_Item = (Item_Item);
// CONCATENATED MODULE: ./containers/PostsThread/styles/index.js



var PostsThread_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "ycwni3-0"
})(["display:flex;max-width:1400px;"]);
var LeftPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPadding",
  componentId: "ycwni3-1"
})(["width:2.5vw;"]);
var RightPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPadding",
  componentId: "ycwni3-2"
})(["width:4vw;"]);
var LeftPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPart",
  componentId: "ycwni3-3"
})(["flex-grow:1;width:100%;"]);
var RightPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPart",
  componentId: "ycwni3-4"
})(["width:20vw;margin-left:30px;"]);
/* fill: ${theme('shell.searchIcon')}; */
// TODO: rename to PublishButn

var PublishBtn =
/*#__PURE__*/
external__styled_components__default()(components["d" /* Button */]).withConfig({
  displayName: "styles__PublishBtn",
  componentId: "ycwni3-5"
})(["margin-top:8px;width:100%;max-width:180px;margin-left:8%;"]);
var FilterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterWrapper",
  componentId: "ycwni3-6"
})(["margin-bottom:8px;margin-left:8px;display:", ";"], function (_ref) {
  var show = _ref.show;
  return show ? 'flex' : 'none';
});
var FilterResultHint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterResultHint",
  componentId: "ycwni3-7"
})(["margin-top:4px;margin-right:10px;color:", ";"], Object(utils["W" /* theme */])('thread.filterResultHint'));
/* border-bottom: 1px solid #ececec; */

var TagDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagDivider",
  componentId: "ycwni3-8"
})(["width:80%;margin-top:40px;margin-bottom:30px;margin-left:8%;"]);
// CONCATENATED MODULE: ./containers/PostsThread/index.js


function PostsThread__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { PostsThread__typeof = function _typeof(obj) { return typeof obj; }; } else { PostsThread__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return PostsThread__typeof(obj); }

function PostsThread__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function PostsThread__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function PostsThread__createClass(Constructor, protoProps, staticProps) { if (protoProps) PostsThread__defineProperties(Constructor.prototype, protoProps); if (staticProps) PostsThread__defineProperties(Constructor, staticProps); return Constructor; }

function PostsThread__possibleConstructorReturn(self, call) { if (call && (PostsThread__typeof(call) === "object" || typeof call === "function")) { return call; } return PostsThread__assertThisInitialized(self); }

function PostsThread__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function PostsThread__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * PostsThread
 *
 */









/* eslint-disable no-unused-vars */

var PostsThread_debug = Object(utils["G" /* makeDebugger */])('C:PostsThread');
/* eslint-enable no-unused-vars */
// TODO: move to common componnet

var PostsThread_View = function View(_ref) {
  var community = _ref.community,
      thread = _ref.thread,
      entries = _ref.entries,
      curView = _ref.curView,
      active = _ref.active;

  switch (curView) {
    case utils["k" /* TYPE */].RESULT:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, entries.map(function (entry, index) {
          return external__react__default.a.createElement(PostsThread_Item, {
            data: entry,
            key: external__shortid__default.a.generate(),
            active: active,
            index: index
          });
        }));
      }

    case utils["k" /* TYPE */].RESULT_EMPTY:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(components["h" /* EmptyThread */], {
          community: community,
          thread: thread
        }));
      }

    default:
      return external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 5
      });
  }
};

var PostsThread_PostsThreadContainer =
/*#__PURE__*/
function (_React$Component) {
  PostsThread__inherits(PostsThreadContainer, _React$Component);

  function PostsThreadContainer() {
    PostsThread__classCallCheck(this, PostsThreadContainer);

    return PostsThread__possibleConstructorReturn(this, (PostsThreadContainer.__proto__ || Object.getPrototypeOf(PostsThreadContainer)).apply(this, arguments));
  }

  PostsThread__createClass(PostsThreadContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var postsThread = this.props.postsThread;
      PostsThread_logic_init(postsThread);
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {}
  }, {
    key: "render",
    value: function render() {
      var _props$postsThread = this.props.postsThread,
          pagedPostsData = _props$postsThread.pagedPostsData,
          tagsData = _props$postsThread.tagsData,
          curView = _props$postsThread.curView,
          filtersData = _props$postsThread.filtersData,
          activeTagData = _props$postsThread.activeTagData,
          activePost = _props$postsThread.activePost,
          curRoute = _props$postsThread.curRoute;
      var mainPath = curRoute.mainPath,
          subPath = curRoute.subPath;
      var entries = pagedPostsData.entries,
          totalCount = pagedPostsData.totalCount,
          pageNumber = pagedPostsData.pageNumber,
          pageSize = pagedPostsData.pageSize;
      return external__react__default.a.createElement(PostsThread_styles_Wrapper, null, external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(LeftPadding, null), external__react__default.a.createElement(LeftPart, null, external__react__default.a.createElement(external__react_waypoint__default.a, {
        onEnter: inAnchor,
        onLeave: outAnchor
      }), external__react__default.a.createElement(FilterWrapper, {
        show: true
      }, external__react__default.a.createElement(components["g" /* ContentFilter */], {
        onSelect: onFilterSelect,
        activeFilter: filtersData
      }), external__react__default.a.createElement(FilterResultHint, null, "\u7ED3\u679C\u7EA6 ", totalCount, " \u6761")), isEmpty__default()(entries) ? external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 5
      }) : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(PostsThread_View, {
        community: mainPath,
        thread: subPath,
        entries: entries,
        curView: curView,
        active: activePost
      }), external__react__default.a.createElement(components["r" /* Pagi */], {
        left: "-10px",
        pageNumber: pageNumber,
        pageSize: pageSize,
        totalCount: totalCount,
        onChange: loadPosts
      }))), external__react__default.a.createElement(RightPart, null, isEmpty__default()(entries) ? null : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(PublishBtn, {
        type: "primary",
        onClick: createContent
      }, "\u53D1", external__react__default.a.createElement(components["v" /* Space */], {
        right: "20px"
      }), "\u5E16"), external__react__default.a.createElement(components["b" /* Affix */], {
        offsetTop: 50
      }, external__react__default.a.createElement(TagDivider, null), external__react__default.a.createElement(components["B" /* TagList */], {
        tags: tagsData,
        active: activeTagData,
        onSelect: onTagSelect
      })))), external__react__default.a.createElement(RightPadding, null)));
    }
  }]);

  return PostsThreadContainer;
}(external__react__default.a.Component);

/* harmony default export */ var PostsThread = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('postsThread'))(Object(external__mobx_react_["observer"])(PostsThread_PostsThreadContainer)));
// CONCATENATED MODULE: ./containers/VideosThread/styles/item.js



var styles_item_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.article.withConfig({
  displayName: "item__Wrapper",
  componentId: "dmnyc3-0"
})(["display:flex;padding-left:8px;padding-right:8px;padding-top:10px;padding-bottom:10px;border-radius:4px;background:", ";background:", ";opacity:", ";&:hover{background:", ";}"], function (_ref) {
  var current = _ref.current,
      active = _ref.active;
  return current.id === active.id ? Object(utils["W" /* theme */])('thread.articleHover') : '';
}, function (_ref2) {
  var index = _ref2.index;
  return index % 2 === 0 ? Object(utils["W" /* theme */])('thread.articleStrip') : '';
}, function (_ref3) {
  var current = _ref3.current,
      active = _ref3.active;
  return active.id && current.id !== active.id ? 0.6 : 1;
}, Object(utils["W" /* theme */])('thread.articleHover'));
var PosterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__PosterWrapper",
  componentId: "dmnyc3-1"
})(["position:relative;"]);
var Poster =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "item__Poster",
  componentId: "dmnyc3-2"
})(["height:138px;width:246px;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var Duration =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Duration",
  componentId: "dmnyc3-3"
})(["position:absolute;bottom:0;right:0;background:#2e2e2f;color:white;font-size:0.8rem;padding:0 4px;"]);
var styles_item_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Title",
  componentId: "dmnyc3-4"
})(["margin-bottom:10px;font-size:1rem;&:hover{cursor:pointer;}@media (max-width:1450px){max-width:500px;}@media (max-width:1250px){max-width:450px;}@media (max-width:1100px){max-width:350px;}"]);
var item_Main =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Main",
  componentId: "dmnyc3-5"
})(["margin-left:10px;display:flex;flex-grow:1;flex-direction:column;"]);
var item_TopHalf =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TopHalf",
  componentId: "dmnyc3-6"
})(["display:flex;"]);
var item_SecondHalf =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "item__SecondHalf",
  componentId: "dmnyc3-7"
})(["margin-left:10px;margin-top:-10px;flex-grow:1;"]);
var item_Breif =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Breif",
  componentId: "dmnyc3-8"
})(["display:flex;flex-grow:1;margin-left:10px;color:", ";"], Object(utils["W" /* theme */])('thread.articleTitle'));
var item_TitleTagDot =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "item__TitleTagDot",
  componentId: "dmnyc3-9"
})(["width:10px;height:10px;margin-right:4px;border-radius:50%;background-color:#9cd090;display:inline-block;opacity:", ";"], Object(utils["W" /* theme */])('tags.dotOpacity'));
var item_TitleLink =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleLink",
  componentId: "dmnyc3-10"
})(["position:relative;font-size:0.9rem;margin-top:2px;color:", ";margin-left:10px;opacity:0.8;text-decoration:underline;"], Object(utils["W" /* theme */])('thread.articleLink'));
var item_TitleTag =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleTag",
  componentId: "dmnyc3-11"
})(["color:", ";margin-left:10px;margin-top:2px;opacity:0.8;font-size:0.9rem;"], Object(utils["W" /* theme */])('thread.articleTag'));
var item_LinkIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__LinkIcon",
  componentId: "dmnyc3-12"
})(["fill:", ";position:absolute;top:6px;left:-5px;width:12px;height:12px;"], Object(utils["W" /* theme */])('thread.articleLink'));
var ViewInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__ViewInfo",
  componentId: "dmnyc3-13"
})(["display:flex;"]);
var ViewIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__ViewIcon",
  componentId: "dmnyc3-14"
})(["fill:", ";width:12px;height:12px;"], Object(utils["W" /* theme */])('thread.articleLink'));
var item_Extra =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__Extra",
  componentId: "dmnyc3-15"
})(["display:flex;opacity:0.7;transition:opacity 0.2s;font-size:0.85rem;color:", ";"], Object(utils["W" /* theme */])('thread.extraInfo'));
var item_BodyDigest =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__BodyDigest",
  componentId: "dmnyc3-16"
})(["margin-top:5px;color:", ";margin-right:20px;white-space:normal;display:block;font-size:0.85rem;&:hover{cursor:pointer;}"], Object(utils["W" /* theme */])('thread.articleDigest'));
var OriginalAuthorLink =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "item__OriginalAuthorLink",
  componentId: "dmnyc3-17"
})(["transition:color 0.3s;color:", ";&:hover{cursor:pointer;color:", ";text-decoration:underline;}"], Object(utils["W" /* theme */])('thread.extraInfo'), Object(utils["W" /* theme */])('thread.extraInfo'));
var BottomAuthorWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__BottomAuthorWrapper",
  componentId: "dmnyc3-18"
})(["display:flex;margin-left:10px;margin-bottom:2px;"]);
var ButtonAvatar =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__ButtonAvatar",
  componentId: "dmnyc3-19"
})(["width:20px;height:20px;border-radius:50%;opacity:0.8;"]);
var ButtonNickname =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__ButtonNickname",
  componentId: "dmnyc3-20"
})(["color:", ";margin-left:5px;"], Object(utils["W" /* theme */])('thread.articleDigest'));
// EXTERNAL MODULE: ./containers/VideosThread/schema.js
var VideosThread_schema = __webpack_require__(80);

// CONCATENATED MODULE: ./containers/VideosThread/logic.js






function VideosThread_logic__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { VideosThread_logic__defineProperty(target, key, source[key]); }); } return target; }

function VideosThread_logic__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var VideosThread_logic_sr71$ = new sr71["a" /* default */]();
var VideosThread_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var VideosThread_logic_debug = Object(utils["G" /* makeDebugger */])('L:VideosThread');
/* eslint-enable no-unused-vars */

var VideosThread_logic_store = null;

var logic_validFilter = pickBy__default()(compose__default()(not__default.a, isEmpty__default.a));

function loadVideos() {
  var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  var mainPath = VideosThread_logic_store.curRoute.mainPath;
  var community = mainPath;
  VideosThread_logic_store.markState({
    curView: utils["k" /* TYPE */].LOADING
  });
  var args = {
    filter: VideosThread_logic__objectSpread({
      page: page,
      size: config["h" /* PAGE_SIZE */].COMMON
    }, VideosThread_logic_store.filtersData, {
      tag: VideosThread_logic_store.activeTagData.raw,
      community: community
    })
  };
  args.filter = logic_validFilter(args.filter);
  Object(utils["Q" /* scrollIntoEle */])(utils["k" /* TYPE */].APP_HEADER_ID);
  VideosThread_logic_debug('load videos --> ', args);
  VideosThread_logic_sr71$.query(VideosThread_schema["a" /* default */].pagedVideos, args);
  VideosThread_logic_store.markRoute({
    page: page
  });
}
function logic_loadTags() {
  // NOTE: do not use viewing.community, it's too slow
  var mainPath = VideosThread_logic_store.curRoute.mainPath;
  var community = mainPath;

  var thread = toUpper__default()(utils["j" /* THREAD */].VIDEO);

  var args = {
    community: community,
    thread: thread
  };
  VideosThread_logic_debug('loadTags --> ', args);
  VideosThread_logic_sr71$.query(VideosThread_schema["a" /* default */].partialTags, args);
}
function logic_onTitleSelect() {
  VideosThread_logic_debug('onTitleSelect');
}
function logic_createContent() {
  VideosThread_logic_debug('createContent');
}
function logic_onTagSelect() {
  VideosThread_logic_debug('onTagSelect');
}
function logic_onFilterSelect() {
  VideosThread_logic_debug('onFilterSelect');
} // ###############################
// Data & Error handlers
// ###############################

var VideosThread_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedVideos'),
  action: function action(_ref) {
    var pagedVideos = _ref.pagedVideos;

    /* debug('========> pagedVideos: ', pagedVideos) */
    var curView = utils["k" /* TYPE */].RESULT;

    if (pagedVideos.entries.length === 0) {
      curView = utils["k" /* TYPE */].RESULT_EMPTY;
    }

    VideosThread_logic_store.markState({
      curView: curView,
      pagedVideos: pagedVideos
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('partialTags'),
  action: function action(_ref2) {
    var partialTags = _ref2.partialTags;
    VideosThread_logic_store.markState({
      tags: partialTags
    });
  }
}];
var VideosThread_logic_ErrSolver = [];

var VideosThread_logic_loadIfNeed = function loadIfNeed() {
  /* loadVideos() */

  /* console.log('store.pagedVideos.entries --> ', store.pagedVideosData.entries) */
  if (isEmpty__default()(VideosThread_logic_store.pagedVideosData.entries)) {
    loadVideos();
    Object(utils["F" /* later */])(logic_loadTags, 500);
  }
};

function VideosThread_logic_init(_store) {
  if (VideosThread_logic_store) {
    VideosThread_logic_loadIfNeed();
    return false;
  }

  VideosThread_logic_store = _store;
  VideosThread_logic_debug(VideosThread_logic_store);
  if (VideosThread_logic_sub$) VideosThread_logic_sub$.unsubscribe();
  VideosThread_logic_sub$ = VideosThread_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(VideosThread_logic_DataSolver, VideosThread_logic_ErrSolver));
  VideosThread_logic_loadIfNeed();
}
// CONCATENATED MODULE: ./containers/VideosThread/Item.js
var VideosThread_Item__this = this;









var VideosThread_Item_Item = function Item(_ref) {
  var data = _ref.data,
      active = _ref.active,
      index = _ref.index;
  return external__react__default.a.createElement(styles_item_Wrapper, {
    current: data,
    active: active,
    index: index
  }, external__react__default.a.createElement(PosterWrapper, null, external__react__default.a.createElement(Poster, {
    src: data.author.avatar,
    alt: "poster"
  }), external__react__default.a.createElement(Duration, null, data.duration)), external__react__default.a.createElement(item_Main, null, external__react__default.a.createElement(item_TopHalf, null, external__react__default.a.createElement(item_Breif, {
    onClick: logic_onTitleSelect.bind(VideosThread_Item__this, data)
  }, external__react__default.a.createElement(styles_item_Title, null, data.title), external__react__default.a.createElement(item_TitleLink, null, external__react__default.a.createElement(item_LinkIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/link.svg")
  }), external__react__default.a.createElement("span", {
    style: {
      marginLeft: 9
    }
  }, "youtube")), external__react__default.a.createElement(item_TitleTag, null, external__react__default.a.createElement(item_TitleTagDot, null), "elixir"))), external__react__default.a.createElement(item_SecondHalf, null, external__react__default.a.createElement(item_Extra, null, external__react__default.a.createElement(OriginalAuthorLink, {
    href: data.originalAuthorLink,
    target: "_blank"
  }, data.originalAuthor), ' ', external__react__default.a.createElement(components["v" /* Space */], {
    right: "2px"
  }), "\u205D", external__react__default.a.createElement(components["v" /* Space */], {
    right: "2px"
  }), external__react__default.a.createElement(external__timeago_react__default.a, {
    datetime: data.insertedAt,
    locale: "zh_CN"
  }), external__react__default.a.createElement(components["v" /* Space */], {
    right: "2px"
  }), "\u205D", external__react__default.a.createElement(components["v" /* Space */], {
    right: "2px"
  }), external__react__default.a.createElement(ViewIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/refer.svg")
  }), ' ', external__react__default.a.createElement(components["v" /* Space */], {
    right: "2px"
  }), data.views), external__react__default.a.createElement(item_BodyDigest, null, Object(utils["s" /* cutFrom */])(data.desc, 90))), external__react__default.a.createElement(BottomAuthorWrapper, null, external__react__default.a.createElement(ButtonAvatar, {
    src: data.author.avatar
  }), external__react__default.a.createElement(ButtonNickname, null, data.author.nickname))));
};

/* harmony default export */ var VideosThread_Item = (VideosThread_Item_Item);
// CONCATENATED MODULE: ./containers/VideosThread/styles/index.js



var VideosThread_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1oowgtt-0"
})(["display:flex;max-width:1400px;"]);
var styles_LeftPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPadding",
  componentId: "s1oowgtt-1"
})(["width:2.5vw;"]);
var styles_RightPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPadding",
  componentId: "s1oowgtt-2"
})(["width:4vw;"]);
var styles_LeftPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPart",
  componentId: "s1oowgtt-3"
})(["flex-grow:1;width:100%;"]);
var styles_RightPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPart",
  componentId: "s1oowgtt-4"
})(["width:20vw;margin-left:30px;"]);
/* fill: ${theme('shell.searchIcon')}; */

var styles_PublishBtn =
/*#__PURE__*/
external__styled_components__default()(components["d" /* Button */]).withConfig({
  displayName: "styles__PublishBtn",
  componentId: "s1oowgtt-5"
})(["margin-top:8px;width:100%;max-width:180px;margin-left:8%;"]);
var styles_FilterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterWrapper",
  componentId: "s1oowgtt-6"
})(["margin-bottom:8px;margin-left:8px;display:", ";"], function (_ref) {
  var show = _ref.show;
  return show ? 'flex' : 'none';
});
var styles_FilterResultHint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterResultHint",
  componentId: "s1oowgtt-7"
})(["margin-top:4px;margin-right:10px;color:", ";"], Object(utils["W" /* theme */])('thread.filterResultHint'));
/* border-bottom: 1px solid #ececec; */

var styles_TagDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagDivider",
  componentId: "s1oowgtt-8"
})(["width:80%;margin-top:40px;margin-bottom:30px;margin-left:8%;"]);
// CONCATENATED MODULE: ./containers/VideosThread/index.js


function VideosThread__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { VideosThread__typeof = function _typeof(obj) { return typeof obj; }; } else { VideosThread__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return VideosThread__typeof(obj); }

function VideosThread__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function VideosThread__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function VideosThread__createClass(Constructor, protoProps, staticProps) { if (protoProps) VideosThread__defineProperties(Constructor.prototype, protoProps); if (staticProps) VideosThread__defineProperties(Constructor, staticProps); return Constructor; }

function VideosThread__possibleConstructorReturn(self, call) { if (call && (VideosThread__typeof(call) === "object" || typeof call === "function")) { return call; } return VideosThread__assertThisInitialized(self); }

function VideosThread__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function VideosThread__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * VideosThread
 *
 */








/* eslint-disable no-unused-vars */

var VideosThread_debug = Object(utils["G" /* makeDebugger */])('C:VideosThread');
/* eslint-enable no-unused-vars */

var VideosThread_View = function View(_ref) {
  var community = _ref.community,
      thread = _ref.thread,
      entries = _ref.entries,
      curView = _ref.curView,
      active = _ref.active;

  switch (curView) {
    case utils["k" /* TYPE */].RESULT:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, entries.map(function (video, index) {
          return external__react__default.a.createElement(VideosThread_Item, {
            data: video,
            key: external__shortid__default.a.generate(),
            active: active,
            index: index
          });
        }));
      }

    case utils["k" /* TYPE */].RESULT_EMPTY:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(components["h" /* EmptyThread */], {
          community: community,
          thread: thread
        }));
      }

    default:
      return external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 5
      });
  }
};

var VideosThread_VideosThreadContainer =
/*#__PURE__*/
function (_React$Component) {
  VideosThread__inherits(VideosThreadContainer, _React$Component);

  function VideosThreadContainer() {
    VideosThread__classCallCheck(this, VideosThreadContainer);

    return VideosThread__possibleConstructorReturn(this, (VideosThreadContainer.__proto__ || Object.getPrototypeOf(VideosThreadContainer)).apply(this, arguments));
  }

  VideosThread__createClass(VideosThreadContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var videosThread = this.props.videosThread;
      VideosThread_logic_init(videosThread);
    }
  }, {
    key: "render",
    value: function render() {
      var _props$videosThread = this.props.videosThread,
          pagedVideosData = _props$videosThread.pagedVideosData,
          filtersData = _props$videosThread.filtersData,
          tagsData = _props$videosThread.tagsData,
          curRoute = _props$videosThread.curRoute,
          curView = _props$videosThread.curView,
          activeVideo = _props$videosThread.activeVideo,
          activeTagData = _props$videosThread.activeTagData;
      var entries = pagedVideosData.entries,
          pageNumber = pagedVideosData.pageNumber,
          pageSize = pagedVideosData.pageSize,
          totalCount = pagedVideosData.totalCount;
      var mainPath = curRoute.mainPath,
          subPath = curRoute.subPath;
      return external__react__default.a.createElement(VideosThread_styles_Wrapper, null, external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(styles_LeftPadding, null), external__react__default.a.createElement(styles_LeftPart, null, external__react__default.a.createElement(styles_FilterWrapper, {
        show: true
      }, external__react__default.a.createElement(components["g" /* ContentFilter */], {
        onSelect: logic_onFilterSelect,
        activeFilter: filtersData
      }), external__react__default.a.createElement(styles_FilterResultHint, null, "\u7ED3\u679C\u7EA6 ", totalCount, " \u6761")), isEmpty__default()(entries) ? external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 5
      }) : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(VideosThread_View, {
        community: mainPath,
        thread: subPath,
        entries: entries,
        curView: curView,
        active: activeVideo
      }), external__react__default.a.createElement(components["r" /* Pagi */], {
        left: "-10px",
        pageNumber: pageNumber,
        pageSize: pageSize,
        totalCount: totalCount,
        onChange: loadVideos
      }))), external__react__default.a.createElement(styles_RightPart, null, isEmpty__default()(pagedVideosData.entries) ? null : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(styles_PublishBtn, {
        type: "primary",
        onClick: logic_createContent
      }, "\u63D0", external__react__default.a.createElement(components["v" /* Space */], {
        right: "10px"
      }), "\u4EA4", external__react__default.a.createElement(components["v" /* Space */], {
        right: "10px"
      }), "\u89C6", external__react__default.a.createElement(components["v" /* Space */], {
        right: "10px"
      }), "\u9891"), external__react__default.a.createElement(components["b" /* Affix */], {
        offsetTop: 50
      }, external__react__default.a.createElement(styles_TagDivider, null), external__react__default.a.createElement(components["B" /* TagList */], {
        tags: tagsData,
        active: activeTagData,
        onSelect: logic_onTagSelect
      })))), external__react__default.a.createElement(styles_RightPadding, null)));
    }
  }]);

  return VideosThreadContainer;
}(external__react__default.a.Component);

/* harmony default export */ var VideosThread = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('videosThread'))(Object(external__mobx_react_["observer"])(VideosThread_VideosThreadContainer)));
// CONCATENATED MODULE: ./containers/JobsThread/styles/item.js



var JobsThread_styles_item_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.article.withConfig({
  displayName: "item__Wrapper",
  componentId: "gol2ft-0"
})(["display:flex;padding-left:8px;padding-right:8px;padding-top:6px;padding-bottom:6px;border-radius:4px;background:", ";opacity:", ";&:hover{cursor:pointer;background:", ";}"], function (_ref) {
  var current = _ref.current,
      active = _ref.active;
  return current.id === active.id ? Object(utils["W" /* theme */])('thread.articleHover') : '';
}, function (_ref2) {
  var current = _ref2.current,
      active = _ref2.active;
  return active.id && current.id !== active.id ? 0.6 : 1;
}, Object(utils["W" /* theme */])('thread.articleHover'));
var styles_item_Main =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Main",
  componentId: "gol2ft-1"
})(["display:flex;flex-grow:1;flex-direction:column;"]);
var styles_item_TopHalf =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TopHalf",
  componentId: "gol2ft-2"
})(["display:flex;"]);
var styles_item_SecondHalf =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "item__SecondHalf",
  componentId: "gol2ft-3"
})(["margin-left:11px;margin-top:-10px;"]);
var styles_item_Avatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "item__Avatar",
  componentId: "gol2ft-4"
})(["width:42px;height:42px;border-radius:100%;"]);
var styles_item_Breif =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Breif",
  componentId: "gol2ft-5"
})(["display:flex;flex-grow:1;margin-left:10px;color:", ";"], Object(utils["W" /* theme */])('thread.articleTitle'));
var JobsThread_styles_item_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Title",
  componentId: "gol2ft-6"
})(["margin-bottom:10px;font-size:1rem;@media (max-width:1450px){max-width:500px;}@media (max-width:1250px){max-width:450px;}@media (max-width:1100px){max-width:350px;}"]);
var styles_item_TitleTagDot =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "item__TitleTagDot",
  componentId: "gol2ft-7"
})(["width:10px;height:10px;margin-right:3px;border-radius:50%;background-color:#9cd090;display:inline-block;"]);
var styles_item_TitleLink =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleLink",
  componentId: "gol2ft-8"
})(["position:relative;font-size:0.9rem;margin-top:2px;color:#a8b8c6;margin-left:10px;opacity:0.8;"]);
var styles_item_TitleTag =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleTag",
  componentId: "gol2ft-9"
})(["font-size:0.9rem;color:#a8b8c6;margin-left:10px;margin-top:2px;opacity:0.8;"]);
var styles_item_LinkIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__LinkIcon",
  componentId: "gol2ft-10"
})(["position:absolute;top:6px;left:-5px;width:12px;height:12px;"]);
var styles_item_Extra =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__Extra",
  componentId: "gol2ft-11"
})(["display:inline;opacity:0.7;transition:opacity 0.2s;font-size:0.9rem;"]);
var styles_item_BodyDigest =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__BodyDigest",
  componentId: "gol2ft-12"
})(["margin-top:5px;color:", ";margin-right:20px;white-space:normal;display:block;font-size:0.85rem;"], Object(utils["W" /* theme */])('thread.articleDigest'));
var RightInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__RightInfo",
  componentId: "gol2ft-13"
})(["display:flex;flex-direction:column;border:1px solid;height:60px;justify-content:space-between;border-radius:3px;align-self:center;"]);
var SalaryWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__SalaryWrapper",
  componentId: "gol2ft-14"
})(["font-size:1.1rem;color:orange;padding:3px;", ":hover &{animation:", " 0.3s linear;}"], JobsThread_styles_item_Wrapper, utils["b" /* Animate */].pulse);
var CompanyTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__CompanyTitle",
  componentId: "gol2ft-15"
})(["font-size:1rem;text-align:center;background:#84acaf;color:white;"]);
// EXTERNAL MODULE: ./containers/JobsThread/schema.js
var JobsThread_schema = __webpack_require__(81);

// CONCATENATED MODULE: ./containers/JobsThread/logic.js






function JobsThread_logic__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { JobsThread_logic__defineProperty(target, key, source[key]); }); } return target; }

function JobsThread_logic__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // import sr71$ from '../../utils/network/sr71_simple'

var JobsThread_logic_sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].REFRESH_POSTS, utils["e" /* EVENT */].PREVIEW_CLOSED, utils["e" /* EVENT */].COMMUNITY_CHANGE]
});
/* eslint-disable no-unused-vars */

var JobsThread_logic_debug = Object(utils["G" /* makeDebugger */])('L:JobsThread');
/* eslint-enable no-unused-vars */

var JobsThread_logic_store = null;
var JobsThread_logic_sub$ = null;

var JobsThread_logic_validFilter = pickBy__default()(compose__default()(not__default.a, isEmpty__default.a));

function logic_inAnchor() {
  JobsThread_logic_store.setHeaderFix(false);
}
function logic_outAnchor() {
  JobsThread_logic_store.setHeaderFix(true);
}
function loadJobs() {
  var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

  /* const { mainPath, subPath } = store.curRoute */
  Object(utils["Q" /* scrollIntoEle */])(utils["k" /* TYPE */].APP_HEADER_ID); // NOTE: do not use viewing.community, it's too slow

  var mainPath = JobsThread_logic_store.curRoute.mainPath;
  var community = mainPath;
  JobsThread_logic_store.markState({
    curView: utils["k" /* TYPE */].LOADING
  });
  var args = {
    /* first: 4, */
    filter: JobsThread_logic__objectSpread({
      page: page,
      size: config["h" /* PAGE_SIZE */].POSTSPAPER_POSTS
    }, JobsThread_logic_store.filtersData, {
      tag: JobsThread_logic_store.activeTagData.raw,
      community: community
    })
  };
  args.filter = JobsThread_logic_validFilter(args.filter);
  JobsThread_logic_debug('loadJobs args: ', args);
  JobsThread_logic_store.markRoute({
    page: page
  });
  JobsThread_logic_sr71$.query(JobsThread_schema["a" /* default */].pagedJobs, args);
}
function JobsThread_logic_loadTags() {
  // NOTE: do not use viewing.community, it's too slow
  var mainPath = JobsThread_logic_store.curRoute.mainPath;
  var community = mainPath;
  var args = {
    thread: toUpper__default()(utils["j" /* THREAD */].JOB),
    community: community
  };
  JobsThread_logic_sr71$.query(JobsThread_schema["a" /* default */].partialTags, args);
}
function JobsThread_logic_onFilterSelect(option) {
  JobsThread_logic_store.selectFilter(option);
  loadJobs();
}
function JobsThread_logic_onTagSelect(obj) {
  JobsThread_logic_store.selectTag(obj);
  loadJobs();
}
function JobsThread_logic_onTitleSelect(activeJob) {
  JobsThread_logic_store.markState({
    activeJob: activeJob
  });
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].NAV_EDIT, {
    type: utils["k" /* TYPE */].POST_PREVIEW_VIEW,
    data: activeJob
  });
  JobsThread_logic_debug('activeJob: ', activeJob);
  utils["g" /* GA */].event({
    action: activeJob.title,
    category: '浏览',
    label: '社区'
  });
}
function JobsThread_logic_createContent() {
  JobsThread_logic_debug('onTitleSelect createContent ');
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].NAV_CREATE_POST, {
    type: utils["k" /* TYPE */].PREVIEW_CREATE_POST
  });
}
var JobsThread_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedJobs'),
  action: function action(_ref) {
    var pagedJobs = _ref.pagedJobs;
    var curView = utils["k" /* TYPE */].RESULT;

    if (pagedJobs.entries.length === 0) {
      curView = utils["k" /* TYPE */].RESULT_EMPTY;
    }

    JobsThread_logic_store.markState({
      curView: curView,
      pagedJobs: pagedJobs
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('partialTags'),
  action: function action(_ref2) {
    var partialTags = _ref2.partialTags;
    return JobsThread_logic_store.markState({
      tags: partialTags
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].COMMUNITY_CHANGE),
  action: function action() {
    loadJobs();
    Object(utils["F" /* later */])(JobsThread_logic_loadTags, 300);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].REFRESH_JOBS),
  action: function action() {
    return loadJobs();
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW_CLOSED),
  action: function action() {
    return JobsThread_logic_store.markState({
      activeJob: {}
    });
  }
}];
var JobsThread_logic_ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref3) {
    var details = _ref3.details;
    JobsThread_logic_debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref4) {
    var details = _ref4.details;
    JobsThread_logic_debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref5) {
    var details = _ref5.details;
    JobsThread_logic_debug('ERR.NETWORK -->', details);
  }
}];

var JobsThread_logic_loadIfNeed = function loadIfNeed() {
  if (!JobsThread_logic_store.pagedJobs) {
    JobsThread_logic_debug('loadIfNeed');
    loadJobs();
    Object(utils["F" /* later */])(JobsThread_logic_loadTags, 300);
  }
};

function JobsThread_logic_init(_store) {
  if (JobsThread_logic_store) return false;
  JobsThread_logic_store = _store;
  if (JobsThread_logic_sub$) JobsThread_logic_sub$.unsubscribe();
  JobsThread_logic_sub$ = JobsThread_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(JobsThread_logic_DataSolver, JobsThread_logic_ErrSolver));
  JobsThread_logic_loadIfNeed();
}
// CONCATENATED MODULE: ./containers/JobsThread/Item.js
var JobsThread_Item__this = this;








var JobsThread_Item_Item = function Item(_ref) {
  var entry = _ref.entry,
      active = _ref.active;
  return external__react__default.a.createElement(JobsThread_styles_item_Wrapper, {
    current: entry,
    active: active
  }, external__react__default.a.createElement("div", null, external__react__default.a.createElement(styles_item_Avatar, {
    src: "http://coderplanets.oss-cn-beijing.aliyuncs.com/mock/me.jpg",
    alt: "avatar"
  })), external__react__default.a.createElement(styles_item_Main, null, external__react__default.a.createElement(styles_item_TopHalf, null, external__react__default.a.createElement(styles_item_Breif, {
    onClick: JobsThread_logic_onTitleSelect.bind(JobsThread_Item__this, entry)
  }, external__react__default.a.createElement(JobsThread_styles_item_Title, null, entry.title), external__react__default.a.createElement(styles_item_TitleLink, null, external__react__default.a.createElement(styles_item_LinkIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/link.svg")
  }), external__react__default.a.createElement("span", {
    style: {
      marginLeft: 9
    }
  }, "\u62C9\u94A9")), external__react__default.a.createElement(styles_item_TitleTag, null, external__react__default.a.createElement(styles_item_TitleTagDot, null), "\u6210\u90FD"))), external__react__default.a.createElement(styles_item_SecondHalf, null, external__react__default.a.createElement(styles_item_Extra, null, "mydearxym \u53D1\u5E03\u4E8E:", ' ', external__react__default.a.createElement(external__timeago_react__default.a, {
    datetime: entry.insertedAt,
    locale: "zh_CN"
  }), " \u205D \u6D4F\u89C8:", ' ', entry.views), external__react__default.a.createElement(styles_item_BodyDigest, null, Object(utils["s" /* cutFrom */])(entry.digest, 90)))), external__react__default.a.createElement(RightInfo, null, external__react__default.a.createElement(CompanyTitle, null, "\u4E2D\u592E\u516C\u56ED"), external__react__default.a.createElement(SalaryWrapper, null, "15k - 30k")));
};

/* harmony default export */ var JobsThread_Item = (JobsThread_Item_Item);
// CONCATENATED MODULE: ./containers/JobsThread/styles/index.js



var JobsThread_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "jgs6vi-0"
})(["display:flex;max-width:1400px;"]);
var JobsThread_styles_LeftPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPadding",
  componentId: "jgs6vi-1"
})(["width:4vw;"]);
var JobsThread_styles_RightPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPadding",
  componentId: "jgs6vi-2"
})(["width:4vw;"]);
var JobsThread_styles_LeftPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPart",
  componentId: "jgs6vi-3"
})(["flex-grow:1;width:100%;"]);
var JobsThread_styles_RightPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPart",
  componentId: "jgs6vi-4"
})(["width:20vw;margin-left:30px;"]);
/* fill: ${theme('shell.searchIcon')}; */

var JobsThread_styles_PublishBtn =
/*#__PURE__*/
external__styled_components__default()(components["d" /* Button */]).withConfig({
  displayName: "styles__PublishBtn",
  componentId: "jgs6vi-5"
})(["margin-top:8px;width:100%;max-width:180px;margin-left:8%;"]);
var JobsThread_styles_FilterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterWrapper",
  componentId: "jgs6vi-6"
})(["margin-bottom:8px;margin-left:8px;display:", ";"], function (_ref) {
  var show = _ref.show;
  return show ? 'flex' : 'none';
});
var JobsThread_styles_FilterResultHint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterResultHint",
  componentId: "jgs6vi-7"
})(["margin-top:4px;margin-right:10px;color:", ";"], Object(utils["W" /* theme */])('thread.filterResultHint'));
/* border-bottom: 1px solid #ececec; */

var JobsThread_styles_TagDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagDivider",
  componentId: "jgs6vi-8"
})(["width:80%;margin-top:40px;margin-bottom:30px;margin-left:8%;"]);
// CONCATENATED MODULE: ./containers/JobsThread/index.js
function JobsThread__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { JobsThread__typeof = function _typeof(obj) { return typeof obj; }; } else { JobsThread__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return JobsThread__typeof(obj); }

function JobsThread__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function JobsThread__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function JobsThread__createClass(Constructor, protoProps, staticProps) { if (protoProps) JobsThread__defineProperties(Constructor.prototype, protoProps); if (staticProps) JobsThread__defineProperties(Constructor, staticProps); return Constructor; }

function JobsThread__possibleConstructorReturn(self, call) { if (call && (JobsThread__typeof(call) === "object" || typeof call === "function")) { return call; } return JobsThread__assertThisInitialized(self); }

function JobsThread__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function JobsThread__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * PostsThread
 *
 */









/* eslint-disable no-unused-vars */

var JobsThread_debug = Object(utils["G" /* makeDebugger */])('C:JobsThread');
/* eslint-enable no-unused-vars */

var JobsThread_View = function View(_ref) {
  var community = _ref.community,
      thread = _ref.thread,
      jobs = _ref.jobs,
      curView = _ref.curView,
      active = _ref.active;

  switch (curView) {
    case utils["k" /* TYPE */].RESULT:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, jobs.map(function (job) {
          return external__react__default.a.createElement(JobsThread_Item, {
            entry: job,
            key: external__shortid__default.a.generate(),
            active: active
          });
        }));
      }

    case utils["k" /* TYPE */].RESULT_EMPTY:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(components["h" /* EmptyThread */], {
          community: community,
          thread: thread
        }));
      }

    default:
      return external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 3
      });
  }
};

var JobsThread_JobsThreadContainer =
/*#__PURE__*/
function (_React$Component) {
  JobsThread__inherits(JobsThreadContainer, _React$Component);

  function JobsThreadContainer() {
    JobsThread__classCallCheck(this, JobsThreadContainer);

    return JobsThread__possibleConstructorReturn(this, (JobsThreadContainer.__proto__ || Object.getPrototypeOf(JobsThreadContainer)).apply(this, arguments));
  }

  JobsThread__createClass(JobsThreadContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var jobsThread = this.props.jobsThread;
      JobsThread_logic_init(jobsThread);
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {}
  }, {
    key: "render",
    value: function render() {
      var _props$jobsThread = this.props.jobsThread,
          pagedJobsData = _props$jobsThread.pagedJobsData,
          tagsData = _props$jobsThread.tagsData,
          curView = _props$jobsThread.curView,
          filtersData = _props$jobsThread.filtersData,
          activeTagData = _props$jobsThread.activeTagData,
          active = _props$jobsThread.active,
          accountInfo = _props$jobsThread.accountInfo,
          curRoute = _props$jobsThread.curRoute;
      var mainPath = curRoute.mainPath,
          subPath = curRoute.subPath;
      return external__react__default.a.createElement(external__react__default.a.Fragment, null, pagedJobsData ? external__react__default.a.createElement(JobsThread_styles_Wrapper, null, external__react__default.a.createElement(JobsThread_styles_LeftPadding, null), external__react__default.a.createElement(components["e" /* BuyMeChuanChuan */], {
        fromUser: accountInfo
      }), external__react__default.a.createElement(JobsThread_styles_LeftPart, null, external__react__default.a.createElement(external__react_waypoint__default.a, {
        onEnter: logic_inAnchor,
        onLeave: logic_outAnchor
      }), external__react__default.a.createElement(JobsThread_styles_FilterWrapper, {
        show: curView === utils["k" /* TYPE */].RESULT
      }, external__react__default.a.createElement(components["g" /* ContentFilter */], {
        onSelect: JobsThread_logic_onFilterSelect,
        activeFilter: filtersData
      }), external__react__default.a.createElement(JobsThread_styles_FilterResultHint, null, "\u7ED3\u679C\u7EA6 ", pagedJobsData.totalCount, " \u6761")), external__react__default.a.createElement(JobsThread_View, {
        community: mainPath,
        thread: subPath,
        jobs: pagedJobsData.entries,
        curView: curView,
        active: active
      }), external__react__default.a.createElement(components["r" /* Pagi */], {
        left: "-10px",
        pageNumber: pagedJobsData.pageNumber,
        pageSize: pagedJobsData.pageSize,
        totalCount: pagedJobsData.totalCount,
        onChange: loadJobs
      })), external__react__default.a.createElement(JobsThread_styles_RightPart, null, external__react__default.a.createElement(JobsThread_styles_PublishBtn, {
        type: "primary",
        onClick: JobsThread_logic_createContent
      }, "\u62DB\u8D24\u7EB3\u58EB"), external__react__default.a.createElement(components["b" /* Affix */], {
        offsetTop: 50
      }, external__react__default.a.createElement(JobsThread_styles_TagDivider, null), external__react__default.a.createElement(components["B" /* TagList */], {
        tags: tagsData,
        active: activeTagData,
        onSelect: JobsThread_logic_onTagSelect
      }))), external__react__default.a.createElement(JobsThread_styles_RightPadding, null)) : external__react__default.a.createElement(JobsThread_styles_Wrapper, null, external__react__default.a.createElement(JobsThread_styles_LeftPadding, null), external__react__default.a.createElement(JobsThread_styles_LeftPart, null, external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 3
      })), external__react__default.a.createElement(JobsThread_styles_RightPart, null), external__react__default.a.createElement(JobsThread_styles_RightPadding, null)));
    }
  }]);

  return JobsThreadContainer;
}(external__react__default.a.Component);

/* harmony default export */ var JobsThread = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('jobsThread'))(Object(external__mobx_react_["observer"])(JobsThread_JobsThreadContainer)));
/*
   <iframe
   id="ytplayer"
   type="text/html"
   width="640"
   height="360"
   allowfullscreen="allowfullscreen"
   mozallowfullscreen="mozallowfullscreen"
   msallowfullscreen="msallowfullscreen"
   oallowfullscreen="oallowfullscreen"
   webkitallowfullscreen="webkitallowfullscreen"
   src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin=http://example.com"
   frameborder="0"
   />
 */
// CONCATENATED MODULE: ./containers/ReposThread/styles/builder_list.js

 // import { theme } from '../../../utils'

var builder_list_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "builder_list__Wrapper",
  componentId: "s16gjjg4-0"
})(["display:flex;"]);
var Builder =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "builder_list__Builder",
  componentId: "s16gjjg4-1"
})([""]);
var builder_list_Avatar =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "builder_list__Avatar",
  componentId: "s16gjjg4-2"
})(["width:20px;height:20px;border-radius:3px;margin-left:6px;opacity:0.8;&:hover{cursor:pointer;opacity:1;}"]);
// CONCATENATED MODULE: ./containers/ReposThread/BuilderList.js
//





var BuilderList_BuilderList = function BuilderList(_ref) {
  var entries = _ref.entries;
  return external__react__default.a.createElement(builder_list_Wrapper, null, entries.map(function (builder) {
    return external__react__default.a.createElement(components["s" /* Popover */], {
      placement: "bottom",
      trigger: "hover",
      key: external__shortid__default.a.generate(),
      content: external__react__default.a.createElement("div", null, builder.nickname, "...")
    }, external__react__default.a.createElement(Builder, null, external__react__default.a.createElement(builder_list_Avatar, {
      src: builder.avatar
    })));
  }));
};

/* harmony default export */ var ReposThread_BuilderList = (BuilderList_BuilderList);
// CONCATENATED MODULE: ./containers/ReposThread/styles/item.js
var item__templateObject = /*#__PURE__*/ item__taggedTemplateLiteral([""]),
    item__templateObject2 = /*#__PURE__*/ item__taggedTemplateLiteral(["\n  margin-top: 3px;\n"]);

function item__taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }




var ReposThread_styles_item_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.article.withConfig({
  displayName: "item__Wrapper",
  componentId: "gq1did-0"
})(["display:flex;padding-left:8px;padding-right:8px;padding-top:22px;padding-bottom:22px;border-radius:4px;border-bottom:1px solid;border-bottom-color:", ";opacity:", ";"], Object(utils["W" /* theme */])('thread.articleSpliter'), function (_ref) {
  var current = _ref.current,
      active = _ref.active;
  return active.id && current.id !== active.id ? 0.6 : 1;
});
/*
   &:hover {
   cursor: pointer;
   background: ${theme('thread.articleHover')};
   }
 */

var ReposThread_styles_item_Main =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Main",
  componentId: "gq1did-1"
})(["display:flex;flex-grow:1;flex-direction:column;"]);
var ReposThread_styles_item_TopHalf =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TopHalf",
  componentId: "gq1did-2"
})(["display:flex;"]);
var ReposThread_styles_item_SecondHalf =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "item__SecondHalf",
  componentId: "gq1did-3"
})(["margin-left:10px;margin-top:-10px;"]);
var item_Builder =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "item__Builder",
  componentId: "gq1did-4"
})(["width:42px;height:42px;border-radius:100%;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var ReposThread_styles_item_Breif =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Breif",
  componentId: "gq1did-5"
})(["display:flex;flex-grow:1;margin-left:10px;color:", ";"], Object(utils["W" /* theme */])('thread.articleTitle'));
var ReposThread_styles_item_Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__Title",
  componentId: "gq1did-6"
})(["margin-bottom:10px;font-size:1.2rem;max-width:450px;display:flex;"]);
var Producer =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "item__Producer",
  componentId: "gq1did-7"
})(["color:", ";margin-right:5px;&:hover{text-decoration:underline;color:", ";}"], Object(utils["W" /* theme */])('banner.title'), Object(utils["W" /* theme */])('thread.articleTitle'));
var RepoName =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "item__RepoName",
  componentId: "gq1did-8"
})(["color:", ";&:hover{text-decoration:underline;color:", ";}"], Object(utils["W" /* theme */])('banner.title'), Object(utils["W" /* theme */])('thread.articleTitle'));
var ReposThread_styles_item_TitleTag =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleTag",
  componentId: "gq1did-9"
})(["color:", ";margin-left:10px;margin-top:4px;opacity:0.8;font-size:0.9rem;flex-grow:1;"], Object(utils["W" /* theme */])('thread.articleTag'));
var StatusInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__StatusInfo",
  componentId: "gq1did-10"
})(["display:flex;margin-top:3px;"]);
var StatusSection =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__StatusSection",
  componentId: "gq1did-11"
})(["display:flex;margin-right:6px;"]);
var StatusNum =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__StatusNum",
  componentId: "gq1did-12"
})([""]);
var StatusIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__StatusIcon",
  componentId: "gq1did-13"
})(["fill:", ";width:15px;height:15px;margin-right:3px;margin-top:2px;"], Object(utils["W" /* theme */])('thread.articleTitle'));
var StarIcon = StatusIcon.extend(item__templateObject);
var ForkIcon = StatusIcon.extend(item__templateObject2);
var ReposThread_styles_item_TitleLink =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__TitleLink",
  componentId: "gq1did-14"
})(["position:relative;font-size:0.9rem;margin-top:2px;color:", ";margin-left:10px;opacity:0.8;text-decoration:underline;"], Object(utils["W" /* theme */])('thread.articleLink'));
var ReposThread_styles_item_TitleTagDot =
/*#__PURE__*/
external__styled_components__default.a.span.withConfig({
  displayName: "item__TitleTagDot",
  componentId: "gq1did-15"
})(["width:10px;height:10px;margin-right:4px;border-radius:50%;background-color:#9cd090;display:inline-block;opacity:", ";"], Object(utils["W" /* theme */])('tags.dotOpacity'));
var ReposThread_styles_item_LinkIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "item__LinkIcon",
  componentId: "gq1did-16"
})(["fill:", ";position:absolute;top:6px;left:-5px;width:12px;height:12px;"], Object(utils["W" /* theme */])('thread.articleLink'));
var ReposThread_styles_item_BodyDigest =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "item__BodyDigest",
  componentId: "gq1did-17"
})(["color:", ";margin-top:5px;margin-right:20px;white-space:normal;display:block;font-size:0.85rem;max-width:85%;&:hover{cursor:pointer;background:", ";}"], Object(utils["W" /* theme */])('thread.articleDigest'), Object(utils["W" /* theme */])('thread.articleHover'));
var BuildByWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "item__BuildByWrapper",
  componentId: "gq1did-18"
})(["display:flex;margin-left:10px;margin-top:12px;"]);
// EXTERNAL MODULE: ./containers/ReposThread/schema.js
var ReposThread_schema = __webpack_require__(82);

// CONCATENATED MODULE: ./containers/ReposThread/logic.js






function ReposThread_logic__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { ReposThread_logic__defineProperty(target, key, source[key]); }); } return target; }

function ReposThread_logic__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var ReposThread_logic_sr71$ = new sr71["a" /* default */]();
var ReposThread_logic_sub$ = null;
/* eslint-disable no-unused-vars */

var ReposThread_logic_debug = Object(utils["G" /* makeDebugger */])('L:ReposThread');
/* eslint-enable no-unused-vars */

var ReposThread_logic_store = null;

var ReposThread_logic_validFilter = pickBy__default()(compose__default()(not__default.a, isEmpty__default.a));

var ReposThread_logic_inAnchor = function inAnchor() {
  return ReposThread_logic_store.setHeaderFix(false);
};
var ReposThread_logic_outAnchor = function outAnchor() {
  return ReposThread_logic_store.setHeaderFix(true);
};
function loadRepos() {
  var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
  var mainPath = ReposThread_logic_store.curRoute.mainPath;
  var community = mainPath;
  ReposThread_logic_store.markState({
    curView: utils["k" /* TYPE */].LOADING
  });
  var args = {
    filter: ReposThread_logic__objectSpread({
      page: page,
      size: config["h" /* PAGE_SIZE */].COMMON
    }, ReposThread_logic_store.filtersData, {
      tag: ReposThread_logic_store.activeTagData.raw,
      community: community
    })
  };
  args.filter = ReposThread_logic_validFilter(args.filter);
  Object(utils["Q" /* scrollIntoEle */])(utils["k" /* TYPE */].APP_HEADER_ID);
  ReposThread_logic_debug('load repos --> ', args);
  ReposThread_logic_sr71$.query(ReposThread_schema["a" /* default */].pagedRepos, args);
  ReposThread_logic_store.markRoute({
    page: page
  });
}
function ReposThread_logic_loadTags() {
  // NOTE: do not use viewing.community, it's too slow
  var mainPath = ReposThread_logic_store.curRoute.mainPath;
  var community = mainPath;

  var thread = toUpper__default()(utils["j" /* THREAD */].REPO);

  var args = {
    community: community,
    thread: thread
  };
  ReposThread_logic_debug('loadTags --> ', args);
  ReposThread_logic_sr71$.query(ReposThread_schema["a" /* default */].partialTags, args);
}
function ReposThread_logic_onTitleSelect() {
  ReposThread_logic_debug('onTitleSelect');
}
function ReposThread_logic_createContent() {
  ReposThread_logic_debug('createContent');
}
function ReposThread_logic_onTagSelect() {
  ReposThread_logic_debug('onTagSelect');
}
function ReposThread_logic_onFilterSelect() {
  ReposThread_logic_debug('onFilterSelect');
} // ###############################
// Data & Error handlers
// ###############################

var ReposThread_logic_DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('pagedRepos'),
  action: function action(_ref) {
    var pagedRepos = _ref.pagedRepos;
    ReposThread_logic_debug('========> pagedRepos: ', pagedRepos);
    var curView = utils["k" /* TYPE */].RESULT;

    if (pagedRepos.entries.length === 0) {
      curView = utils["k" /* TYPE */].RESULT_EMPTY;
    }

    ReposThread_logic_store.markState({
      curView: curView,
      pagedRepos: pagedRepos
    });
  }
}, {
  match: Object(utils["n" /* asyncRes */])('partialTags'),
  action: function action(_ref2) {
    var partialTags = _ref2.partialTags;
    ReposThread_logic_store.markState({
      tags: partialTags
    });
  }
}];
var ReposThread_logic_ErrSolver = [];

var ReposThread_logic_loadIfNeed = function loadIfNeed() {
  /* loadVideos() */

  /* console.log('store.pagedVideos.entries --> ', store.pagedVideosData.entries) */
  if (isEmpty__default()(ReposThread_logic_store.pagedReposData.entries)) {
    loadRepos();
    Object(utils["F" /* later */])(ReposThread_logic_loadTags, 500);
  }
};

function ReposThread_logic_init(_store) {
  if (ReposThread_logic_store) {
    ReposThread_logic_loadIfNeed();
    return false;
  }

  ReposThread_logic_store = _store;
  ReposThread_logic_debug(ReposThread_logic_store);
  if (ReposThread_logic_sub$) ReposThread_logic_sub$.unsubscribe();
  ReposThread_logic_sub$ = ReposThread_logic_sr71$.data().subscribe(Object(utils["a" /* $solver */])(ReposThread_logic_DataSolver, ReposThread_logic_ErrSolver));
  ReposThread_logic_loadIfNeed();
}
// CONCATENATED MODULE: ./containers/ReposThread/Item.js
var ReposThread_Item__this = this;


/* import TimeAgo from 'timeago-react' */







var fakeBuilders = [{
  avatar: 'http://robohash.org/set_set2/bgset_bg1/ivxebJQeJz',
  link: 'xxx',
  nickname: 'user1'
}, {
  avatar: 'http://robohash.org/set_set1/bgset_bg2/K9q2gg',
  link: 'xxx',
  nickname: 'user1'
}, {
  avatar: 'http://robohash.org/set_set1/bgset_bg2/K9q2gg',
  link: 'xxx',
  nickname: 'user1'
}, {
  avatar: 'http://robohash.org/set_set1/bgset_bg2/K9q2gg',
  link: 'xxx',
  nickname: 'user1'
}, {
  avatar: 'http://robohash.org/set_set3/bgset_bg1/bURifG',
  link: 'xxx',
  nickname: 'user1'
}, {
  avatar: 'http://robohash.org/set_set1/bgset_bg1/poWVpD',
  link: 'xxx',
  nickname: 'user1'
}, {
  avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
  link: 'xxx',
  nickname: 'user1'
}];

var ReposThread_Item_Item = function Item(_ref) {
  var data = _ref.data,
      active = _ref.active,
      index = _ref.index;
  return external__react__default.a.createElement(ReposThread_styles_item_Wrapper, {
    current: data,
    active: active,
    index: index
  }, external__react__default.a.createElement(ReposThread_styles_item_Main, null, external__react__default.a.createElement(ReposThread_styles_item_TopHalf, null, external__react__default.a.createElement(ReposThread_styles_item_Breif, {
    onClick: ReposThread_logic_onTitleSelect.bind(ReposThread_Item__this, data)
  }, external__react__default.a.createElement(ReposThread_styles_item_Title, null, external__react__default.a.createElement(Producer, null, data.producer), external__react__default.a.createElement(RepoName, null, " / ", data.repoName)), external__react__default.a.createElement(ReposThread_styles_item_TitleTag, null, external__react__default.a.createElement(ReposThread_styles_item_TitleTagDot, null), "\u97F3\u9891"), external__react__default.a.createElement(StatusInfo, null, external__react__default.a.createElement(StatusSection, null, external__react__default.a.createElement(StarIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/repo_star.svg")
  }), external__react__default.a.createElement(StatusNum, null, data.repoStarCount)), external__react__default.a.createElement(components["v" /* Space */], {
    right: "3px"
  }), external__react__default.a.createElement(StatusSection, null, external__react__default.a.createElement(ForkIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/repo_fork.svg")
  }), external__react__default.a.createElement(StatusNum, null, data.repoForkCount))))), external__react__default.a.createElement(ReposThread_styles_item_SecondHalf, null, external__react__default.a.createElement(ReposThread_styles_item_BodyDigest, null, Object(utils["s" /* cutFrom */])(data.desc, 180))), external__react__default.a.createElement(BuildByWrapper, null, external__react__default.a.createElement("div", null, "Build by "), external__react__default.a.createElement(ReposThread_BuilderList, {
    entries: fakeBuilders
  }))));
};

/* harmony default export */ var ReposThread_Item = (ReposThread_Item_Item);
// CONCATENATED MODULE: ./containers/ReposThread/styles/index.js



var ReposThread_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1p7vurv-0"
})(["display:flex;max-width:1400px;"]);
var ReposThread_styles_LeftPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPadding",
  componentId: "s1p7vurv-1"
})(["width:2.5vw;"]);
var ReposThread_styles_RightPadding =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPadding",
  componentId: "s1p7vurv-2"
})(["width:4vw;"]);
var ReposThread_styles_LeftPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LeftPart",
  componentId: "s1p7vurv-3"
})(["flex-grow:1;width:100%;"]);
var ReposThread_styles_RightPart =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RightPart",
  componentId: "s1p7vurv-4"
})(["width:20vw;margin-left:30px;"]);
/* fill: ${theme('shell.searchIcon')}; */

var ReposThread_styles_PublishBtn =
/*#__PURE__*/
external__styled_components__default()(components["d" /* Button */]).withConfig({
  displayName: "styles__PublishBtn",
  componentId: "s1p7vurv-5"
})(["margin-top:8px;width:100%;max-width:180px;margin-left:8%;"]);
var ReposThread_styles_FilterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterWrapper",
  componentId: "s1p7vurv-6"
})(["margin-bottom:8px;margin-left:8px;display:", ";"], function (_ref) {
  var show = _ref.show;
  return show ? 'flex' : 'none';
});
var ReposThread_styles_FilterResultHint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__FilterResultHint",
  componentId: "s1p7vurv-7"
})(["margin-top:4px;margin-right:10px;color:", ";"], Object(utils["W" /* theme */])('thread.filterResultHint'));
/* border-bottom: 1px solid #ececec; */

var ReposThread_styles_TagDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__TagDivider",
  componentId: "s1p7vurv-8"
})(["width:80%;margin-top:40px;margin-bottom:30px;margin-left:8%;"]);
// CONCATENATED MODULE: ./containers/ReposThread/index.js


function ReposThread__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { ReposThread__typeof = function _typeof(obj) { return typeof obj; }; } else { ReposThread__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return ReposThread__typeof(obj); }

function ReposThread__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function ReposThread__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function ReposThread__createClass(Constructor, protoProps, staticProps) { if (protoProps) ReposThread__defineProperties(Constructor.prototype, protoProps); if (staticProps) ReposThread__defineProperties(Constructor, staticProps); return Constructor; }

function ReposThread__possibleConstructorReturn(self, call) { if (call && (ReposThread__typeof(call) === "object" || typeof call === "function")) { return call; } return ReposThread__assertThisInitialized(self); }

function ReposThread__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function ReposThread__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * ReposThread
 *
 */









/* eslint-disable no-unused-vars */

var ReposThread_debug = Object(utils["G" /* makeDebugger */])('C:ReposThread');
/* eslint-enable no-unused-vars */

var ReposThread_View = function View(_ref) {
  var community = _ref.community,
      thread = _ref.thread,
      entries = _ref.entries,
      curView = _ref.curView,
      active = _ref.active;

  switch (curView) {
    case utils["k" /* TYPE */].RESULT:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, entries.map(function (entry, index) {
          return external__react__default.a.createElement(ReposThread_Item, {
            data: entry,
            key: external__shortid__default.a.generate(),
            active: active,
            index: index
          });
        }));
      }

    case utils["k" /* TYPE */].RESULT_EMPTY:
      {
        return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(components["h" /* EmptyThread */], {
          community: community,
          thread: thread
        }));
      }

    default:
      return external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 5
      });
  }
};

var ReposThread_ReposThreadContainer =
/*#__PURE__*/
function (_React$Component) {
  ReposThread__inherits(ReposThreadContainer, _React$Component);

  function ReposThreadContainer() {
    ReposThread__classCallCheck(this, ReposThreadContainer);

    return ReposThread__possibleConstructorReturn(this, (ReposThreadContainer.__proto__ || Object.getPrototypeOf(ReposThreadContainer)).apply(this, arguments));
  }

  ReposThread__createClass(ReposThreadContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var reposThread = this.props.reposThread;
      ReposThread_logic_init(reposThread);
    }
  }, {
    key: "render",
    value: function render() {
      var _props$reposThread = this.props.reposThread,
          pagedReposData = _props$reposThread.pagedReposData,
          tagsData = _props$reposThread.tagsData,
          curView = _props$reposThread.curView,
          filtersData = _props$reposThread.filtersData,
          activeTagData = _props$reposThread.activeTagData,
          activeRepo = _props$reposThread.activeRepo,
          curRoute = _props$reposThread.curRoute;
      var mainPath = curRoute.mainPath,
          subPath = curRoute.subPath;
      var entries = pagedReposData.entries,
          totalCount = pagedReposData.totalCount,
          pageNumber = pagedReposData.pageNumber,
          pageSize = pagedReposData.pageSize;
      return external__react__default.a.createElement(ReposThread_styles_Wrapper, null, external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(ReposThread_styles_LeftPadding, null), external__react__default.a.createElement(ReposThread_styles_LeftPart, null, external__react__default.a.createElement(external__react_waypoint__default.a, {
        onEnter: ReposThread_logic_inAnchor,
        onLeave: ReposThread_logic_outAnchor
      }), external__react__default.a.createElement(ReposThread_styles_FilterWrapper, {
        show: true
      }, external__react__default.a.createElement(components["g" /* ContentFilter */], {
        onSelect: ReposThread_logic_onFilterSelect,
        activeFilter: filtersData
      }), external__react__default.a.createElement(ReposThread_styles_FilterResultHint, null, "\u7ED3\u679C\u7EA6 ", pagedReposData.totalCount, " \u6761")), isEmpty__default()(entries) ? external__react__default.a.createElement(components["u" /* PostsLoading */], {
        num: 5
      }) : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(ReposThread_View, {
        community: mainPath,
        thread: subPath,
        entries: entries,
        curView: curView,
        active: activeRepo
      }), external__react__default.a.createElement(components["r" /* Pagi */], {
        left: "-10px",
        pageNumber: pageNumber,
        pageSize: pageSize,
        totalCount: totalCount,
        onChange: loadRepos
      }))), external__react__default.a.createElement(ReposThread_styles_RightPart, null, isEmpty__default()(entries) ? null : external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(ReposThread_styles_PublishBtn, {
        type: "primary",
        onClick: ReposThread_logic_createContent
      }, "\u53D1", external__react__default.a.createElement(components["v" /* Space */], {
        right: "20px"
      }), "\u5E03"), external__react__default.a.createElement(components["b" /* Affix */], {
        offsetTop: 50
      }, external__react__default.a.createElement(ReposThread_styles_TagDivider, null), external__react__default.a.createElement(components["B" /* TagList */], {
        tags: tagsData,
        active: activeTagData,
        onSelect: ReposThread_logic_onTagSelect
      })))), external__react__default.a.createElement(ReposThread_styles_RightPadding, null)));
    }
  }]);

  return ReposThreadContainer;
}(external__react__default.a.Component);

/* harmony default export */ var ReposThread = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('reposThread'))(Object(external__mobx_react_["observer"])(ReposThread_ReposThreadContainer)));
// EXTERNAL MODULE: external "remarkable"
var external__remarkable_ = __webpack_require__(48);
var external__remarkable__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_);

// EXTERNAL MODULE: external "remarkable-mentions"
var external__remarkable_mentions_ = __webpack_require__(50);
var external__remarkable_mentions__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_mentions_);

// EXTERNAL MODULE: external "remarkable-emoji"
var external__remarkable_emoji_ = __webpack_require__(49);
var external__remarkable_emoji__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_emoji_);

// EXTERNAL MODULE: external "react-masonry-component"
var external__react_masonry_component_ = __webpack_require__(65);
var external__react_masonry_component__default = /*#__PURE__*/__webpack_require__.n(external__react_masonry_component_);

// EXTERNAL MODULE: external "mastani-codehighlight"
var external__mastani_codehighlight_ = __webpack_require__(41);
var external__mastani_codehighlight__default = /*#__PURE__*/__webpack_require__.n(external__mastani_codehighlight_);

// EXTERNAL MODULE: ./components/LoadingEffects/index.js + 4 modules
var LoadingEffects = __webpack_require__(64);

// EXTERNAL MODULE: external "ramda/src/replace"
var replace_ = __webpack_require__(156);
var replace__default = /*#__PURE__*/__webpack_require__.n(replace_);

// EXTERNAL MODULE: external "ramda/src/map"
var map_ = __webpack_require__(18);
var map__default = /*#__PURE__*/__webpack_require__.n(map_);

// EXTERNAL MODULE: external "ramda/src/nth"
var nth_ = __webpack_require__(157);
var nth__default = /*#__PURE__*/__webpack_require__.n(nth_);

// EXTERNAL MODULE: external "ramda/src/split"
var split_ = __webpack_require__(33);
var split__default = /*#__PURE__*/__webpack_require__.n(split_);

// EXTERNAL MODULE: external "ramda/src/head"
var head_ = __webpack_require__(34);
var head__default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "ramda/src/trim"
var trim_ = __webpack_require__(51);
var trim__default = /*#__PURE__*/__webpack_require__.n(trim_);

// CONCATENATED MODULE: ./containers/CheatSheetPaper/logic.js











/* eslint-disable no-unused-vars */

var CheatSheetPaper_logic_debug = Object(utils["G" /* makeDebugger */])('L:cheatSheetPaper');
/* eslint-enable no-unused-vars */

var CheatSheetPaper_logic_sr71$ = new sr71["a" /* default */]();
var CheatSheetPaper_logic_store = null;
var CheatSheetPaper_logic_sub$ = null;
/* store logic */

var groupSpliter = '{{ ::group:: }}';
var cardsHeaderSpliter = '{{ ::cards-header:: }}';
var cardItemSpliter = '{{ ::card-item:: }}';

var getCardHeader = compose__default()(trim__default.a, head__default.a, split__default()(cardsHeaderSpliter));

var getCardList = compose__default()(trim__default.a, nth__default()(1), split__default()(cardsHeaderSpliter));

var getCardItems = compose__default()(map__default()(trim__default.a), split__default()(cardItemSpliter), getCardList);

var formatFromer = function formatFromer(v) {
  return {
    header: getCardHeader(v),
    cards: getCardItems(v)
  };
};

var transMarkDownforRender = compose__default()(map__default()(formatFromer), split__default()(groupSpliter), trim__default.a);
var convertTaskTag = compose__default()(replace__default()(/<li>\[ \] /g, '<li class="task-pending">'), replace__default()(/<li>\[x\] /g, '<li class="task-done">'));
var CheatsheetCDN = 'https://raw.githubusercontent.com/mydearxym/mastani-cheatsheets/master';
function getData(which) {
  var url = "".concat(CheatsheetCDN, "/").concat(which, ".md");
  CheatSheetPaper_logic_store.markState({
    state: 'loading'
  });
  CheatSheetPaper_logic_sr71$.restGet(url);
}

function handleParseError(errMsg) {
  CheatSheetPaper_logic_store.markState({
    current: '',
    state: 'parse_error',
    errMsg: String(errMsg)
  });
  external__mastani_codehighlight__default.a.highlightAll();
}

function handle404Error() {
  CheatSheetPaper_logic_store.markState({
    current: '',
    state: '404'
  });
}

var logic_maybeEmptyState = function maybeEmptyState(v) {
  return isEmpty__default()(v) ? 'empty' : 'loaded';
};

function handleLoaded(source) {
  CheatSheetPaper_logic_store.markState({
    source: source,
    state: logic_maybeEmptyState(source)
  });

  try {
    // in case document is undefined
    external__mastani_codehighlight__default.a.highlightAll();
  } catch (e) {
    CheatSheetPaper_logic_debug(e);
  }
}

function handleError(res) {
  switch (res.error) {
    case utils["d" /* ERR */].PARSE_CHEATSHEET_MD:
      return handleParseError();

    case utils["d" /* ERR */].NETWORK:
      CheatSheetPaper_logic_debug("".concat(res.error, ": ").concat(res.details));
      return false;

    case utils["d" /* ERR */].NOT_FOUND:
      return handle404Error();

    case utils["d" /* ERR */].TIMEOUT:
      CheatSheetPaper_logic_debug("".concat(res.error, ": ").concat(res.details)); // sr71$.stop()

      return false;

    default:
      CheatSheetPaper_logic_debug('un handleError in ', CheatSheetPaper_logic_store);
      CheatSheetPaper_logic_debug('un handleError: ', res);
  }
}

function CheatSheetPaper_logic_init(_store) {
  if (CheatSheetPaper_logic_store) return false;
  CheatSheetPaper_logic_store = _store;
  if (CheatSheetPaper_logic_sub$) CheatSheetPaper_logic_sub$.unsubscribe();
  CheatSheetPaper_logic_sub$ = CheatSheetPaper_logic_sr71$.data().subscribe(function (res) {
    if (res.error) return handleError(res);
    var source = '';
    CheatSheetPaper_logic_debug('sr71 res: ', res);

    try {
      source = transMarkDownforRender(res);
    } catch (err) {
      return handleError({
        error: utils["d" /* ERR */].PARSE_CHEATSHEET_MD
      });
    }

    handleLoaded(source);
  });
  getData('elixir');
}
function unInit() {// TODO
  // avoid the duplicate subscribe caused by HMR
  // sub$.unsubscribe()
}
// CONCATENATED MODULE: ./containers/CheatSheetPaper/styles/CheatSheetStyle.js


var CheatSheetStyle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "CheatSheetStyle",
  componentId: "s17xnrdl-0"
})(["@font-face{font-family:octicons-link;src:url(data:font/woff;charset=utf-8;base64,d09GRgABAAAAAAZwABAAAAAACFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEU0lHAAAGaAAAAAgAAAAIAAAAAUdTVUIAAAZcAAAACgAAAAoAAQAAT1MvMgAAAyQAAABJAAAAYFYEU3RjbWFwAAADcAAAAEUAAACAAJThvmN2dCAAAATkAAAABAAAAAQAAAAAZnBnbQAAA7gAAACyAAABCUM+8ihnyxnwaaagtaaaabaaaaaqaboai2dsewyaaafsaaabpaaaazwceq9tagvhzaaaasgaaaa0aaaangh4a91oagvhaaadcaaaaboaaaakca8drghtdhgaaal8aaaadaaaaawgaacfbg9jyqaaasaaaaaiaaaacabiatbtyxhwaaacqaaaabgaaaagaa8asm5hbwuaaatoaaabqgaaalxu73socg9zdaaabiwaaaaeaaaame3qpobwcmvwaaaebaaaahyaaab/aFGpk3jaTY6xa8JAGMW/O62BDi0tJLYQincXEypYIiGJjSgHniQ6umTsUEyLm5BV6NDBP8Tpts6F0v+k/0an2i+itHDw3v2+9+DBKTzsJNnWJNTgHEy4BgG3EMI9DCEDOGEXzDADU5hBKMIgNPZqoD3SilVaXZCER3/I7AtxEJLtzzuZfI+VVkprxTlXShWKb3TBecG11rwoNlmmn1P2WYcJczl32etSpKnziC7lQyWe1smVPy/Lt7Kc+0vwy/gAgIIEqAN9we0pwKXreiMasxvabDQMM4riO+qxM2ogwDGOZTXxwxDiycQIcoYFBLj5K3EIaSctAq2kTYiw+ymhce7vwM9jSqO8JyVd5RH9gyTt2+J/yUmYlIR0s04n6+7vm1ozezueleaujhadsuxhwvrgvljn1tq7xiuvv/ocTRF42mNgZGBgYGbwZOBiAAFGJBIMAAizAFoAAABiAGIAznjaY2BkYGAA4in8zwXi+W2+MjCzMIDApSwvXzC97Z4Ig8N/BxYGZgcgl52BCSQKAA3jCV8CAABfAAAAAAQAAEB42mNgZGBg4f3vACQZQABIMjKgAmYAKEgBXgAAeNpjYGY6wTiBgZWBg2kmUxoDA4MPhGZMYzBi1AHygVLYQUCaawqDA4PChxhmh/8ODDEsvAwHgMKMIDnGL0x7gJQCAwMAJd4MFwAAAHjaY2BgYGaA4DAGRgYQkAHyGMF8NgYrIM3JIAGVYYDT+AEjAwuDFpBmA9KMDEwMCh9i/v8H8sH0/4dQc1iAmAkALaUKLgAAAHjaTY9LDsIgEIbtgqHUPpDi3gPoBVyRTmTddOmqTXThEXqrob2gQ1FjwpDvfwCBdmdXC5AVKFu3e5MfNFJ29KTQT48Ob9/lqYwOGZxeUelN2U2R6+cArgtCJpauW7UQBqnFkUsjAY/kOU1cP+DAgvxwn1chZDwUbd6CFimGXwzwF6tPbFIcjEl+vvmM/byA48e6tWrKArm4ZJlCbdsrxksL1AwWn/yBSJKpYbq8AXaaTb8AAHja28jAwOC00ZrBeQNDQOWO//sdBBgYGRiYWYAEELEwMTE4uzo5Zzo5b2BxdnFOcALxNjA6b2ByTswC8jYwg0VlNuoCTWAMqNzMzsoK1rEhNqByEyerg5PMJlYuVueETKcd/89uBpnpvIEVomeHLoMsAAe1Id4AAAAAAAB42oWQT07CQBTGv0JBhagk7HQzKxca2sJCE1hDt4QF+9jos0nbaaydcqfwcj7au3ahj+LO13FMmm6cl7785vven0kBjHCBhfpYuNa5Ph1c0e2Xu3jEvWG7UdPDLZ4N92nOm+EBXuAbHmIMSRMs+4aued4nd3chd8ndvoltsa2gl8m9podbcl+hD7C1xoaHeLJSEao0FEW14ckxC+TU8TxvsY6X0eLPmRhry2WVioLpkrbp84LLQPGI7c6sOiUzpWIWS5GzlSgUzzLBSikOPFTOXqly7rqx0Z1Q5BAIoZBSFihQYQOOBEdkCOgXTOHA07HAGjGWiIjaPZNW13/+lm6S9FT7rLHFJ6fQbkATOG1j2OFMucKJJsxIVfQORl+9jyda6sl1duyhscm1dyclfoedve4qmydlebfqhf3o/AdDumsjAAB42mNgYoAAZQYjBmyAGYQZmdhL8zLdDEydARfoAqIAAAABAAMABwAKABMAB///AA8AAQAAAAAAAAAAAAAAAAABAAAAAA==);}.cheatsheet-body{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;line-height:1.5;color:", ";font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol';font-size:16px;line-height:1.5;word-wrap:break-word;}.cheatsheet-body .pl-c{color:#6a737d;}.cheatsheet-body .pl-c1,.cheatsheet-body .pl-s .pl-v{color:#005cc5;}.cheatsheet-body .pl-e,.cheatsheet-body .pl-en{color:#6f42c1;}.cheatsheet-body .pl-smi,.cheatsheet-body .pl-s .pl-s1{color:#24292e;}.cheatsheet-body .pl-ent{color:#22863a;}.cheatsheet-body .pl-k{color:#d73a49;}.cheatsheet-body .pl-s,.cheatsheet-body .pl-pds,.cheatsheet-body .pl-s .pl-pse .pl-s1,.cheatsheet-body .pl-sr,.cheatsheet-body .pl-sr .pl-cce,.cheatsheet-body .pl-sr .pl-sre,.cheatsheet-body .pl-sr .pl-sra{color:#032f62;}.cheatsheet-body .pl-v,.cheatsheet-body .pl-smw{color:#e36209;}.cheatsheet-body .pl-bu{color:#b31d28;}.cheatsheet-body .pl-ii{color:#fafbfc;background-color:#b31d28;}.cheatsheet-body .pl-c2{color:#fafbfc;background-color:#d73a49;}.cheatsheet-body .pl-c2::before{content:'^M';}.cheatsheet-body .pl-sr .pl-cce{font-weight:bold;color:#22863a;}.cheatsheet-body .pl-ml{color:#735c0f;}.cheatsheet-body .pl-mh,.cheatsheet-body .pl-mh .pl-en,.cheatsheet-body .pl-ms{font-weight:bold;color:#005cc5;}.cheatsheet-body .pl-mi{font-style:italic;color:#24292e;}.cheatsheet-body .pl-mb{font-weight:bold;color:#24292e;}.cheatsheet-body .pl-md{color:#b31d28;background-color:#ffeef0;}.cheatsheet-body .pl-mi1{color:#22863a;background-color:#f0fff4;}.cheatsheet-body .pl-mc{color:#e36209;background-color:#ffebda;}.cheatsheet-body .pl-mi2{color:#f6f8fa;background-color:#005cc5;}.cheatsheet-body .pl-mdr{font-weight:bold;color:#6f42c1;}.cheatsheet-body .pl-ba{color:#586069;}.cheatsheet-body .pl-sg{color:#959da5;}.cheatsheet-body .pl-corl{text-decoration:underline;color:#032f62;}.cheatsheet-body .octicon{display:inline-block;vertical-align:text-top;fill:currentColor;}.cheatsheet-body a{background-color:transparent;-webkit-text-decoration-skip:objects;}.cheatsheet-body a:active,.cheatsheet-body a:hover{outline-width:0;}.cheatsheet-body strong{font-weight:inherit;}.cheatsheet-body strong{font-weight:normal !important;color:", ";background-color:", ";}.cheatsheet-body h1{font-size:2em;margin:0.67em 0;}.cheatsheet-body img{border-style:none;}.cheatsheet-body svg:not(:root){overflow:hidden;}.cheatsheet-body code,.cheatsheet-body kbd,.cheatsheet-body pre{font-family:monospace,monospace;font-size:1em;}.cheatsheet-body hr{box-sizing:content-box;height:0;overflow:visible;}.cheatsheet-body *{box-sizing:border-box;}.cheatsheet-body a{color:", ";text-decoration:none;}.cheatsheet-body a:hover{text-decoration:underline;}.cheatsheet-body strong{font-weight:600;}.cheatsheet-body hr{height:0;margin:15px 0;overflow:hidden;background:transparent;border:0;border-bottom:1px solid #dfe2e5;}.cheatsheet-body hr::before{display:table;content:'';}.cheatsheet-body hr::after{display:table;clear:both;content:'';}.cheatsheet-body table{border-spacing:0;border-collapse:collapse;}.cheatsheet-body td,.cheatsheet-body th{padding:0;}.cheatsheet-body h1,.cheatsheet-body h2,.cheatsheet-body h3,.cheatsheet-body h4,.cheatsheet-body h5,.cheatsheet-body h6{margin-top:0;margin-bottom:0;color:", ";}.cheatsheet-body h1{font-size:32px;font-weight:600;}.cheatsheet-body h2{font-size:24px;font-weight:600;}.cheatsheet-body h4{font-size:16px;font-weight:600;}.cheatsheet-body h5{font-size:14px;font-weight:600;}.cheatsheet-body h6{font-size:12px;font-weight:600;}.cheatsheet-body p{margin-top:0;margin-bottom:10px;padding-left:1em;}.cheatsheet-body blockquote{margin:0;}.cheatsheet-body ul,.cheatsheet-body ol{padding-left:0;margin-top:0;margin-bottom:0;}.cheatsheet-body ol ol,.cheatsheet-body ul ol{list-style-type:lower-roman;}.cheatsheet-body ul ul ol,.cheatsheet-body ul ol ol,.cheatsheet-body ol ul ol,.cheatsheet-body ol ol ol{list-style-type:lower-alpha;}.cheatsheet-body dd{margin-left:0;}.cheatsheet-body code{font-family:'SFMono-Regular',Consolas,'Liberation Mono',Menlo,Courier,monospace;font-size:12px;}.cheatsheet-body pre{margin-top:0;margin-bottom:0;font-family:'SFMono-Regular',Consolas,'Liberation Mono',Menlo,Courier,monospace;font-size:12px;}.cheatsheet-body .octicon{vertical-align:text-bottom;}.cheatsheet-body .pl-0{padding-left:0 !important;}.cheatsheet-body .pl-1{padding-left:4px !important;}.cheatsheet-body .pl-2{padding-left:8px !important;}.cheatsheet-body .pl-3{padding-left:16px !important;}.cheatsheet-body .pl-4{padding-left:24px !important;}.cheatsheet-body .pl-5{padding-left:32px !important;}.cheatsheet-body .pl-6{padding-left:40px !important;}.cheatsheet-body::before{display:table;content:'';}.cheatsheet-body::after{display:table;clear:both;content:'';}.cheatsheet-body > *:first-child{margin-top:0 !important;}.cheatsheet-body > *:last-child{margin-bottom:0 !important;}.cheatsheet-body a:not([href]){color:inherit;text-decoration:none;}.cheatsheet-body .anchor{float:left;padding-right:4px;margin-left:-20px;line-height:1;}.cheatsheet-body .anchor:focus{outline:none;}.cheatsheet-body p,.cheatsheet-body blockquote,.cheatsheet-body ul,.cheatsheet-body ol,.cheatsheet-body dl,.cheatsheet-body table,.cheatsheet-body pre{margin-top:0;margin-bottom:16px;}.cheatsheet-body hr{height:0.25em;padding:0;margin:24px 0;background-color:#e1e4e8;border:0;}.cheatsheet-body blockquote{padding:0 1em;color:", ";border-left:", ";font-style:italic;}.cheatsheet-body blockquote >:first-child{margin-top:0;}.cheatsheet-body blockquote >:last-child{margin-bottom:0;}.cheatsheet-body kbd{display:inline-block;padding:3px 5px;font-size:11px;line-height:10px;color:#444d56;vertical-align:middle;background-color:#fafbfc;border:solid 1px #c6cbd1;border-bottom-color:#959da5;border-radius:3px;box-shadow:inset 0 -1px 0 #959da5;}.cheatsheet-body h1,.cheatsheet-body h2,.cheatsheet-body h3,.cheatsheet-body h4,.cheatsheet-body h5,.cheatsheet-body h6{margin-top:24px;margin-bottom:16px;font-weight:600;line-height:1.25;}.cheatsheet-body h1 .octicon-link,.cheatsheet-body h2 .octicon-link,.cheatsheet-body h3 .octicon-link,.cheatsheet-body h4 .octicon-link,.cheatsheet-body h5 .octicon-link,.cheatsheet-body h6 .octicon-link{color:#1b1f23;vertical-align:middle;visibility:hidden;}.cheatsheet-body h1:hover .anchor,.cheatsheet-body h2:hover .anchor,.cheatsheet-body h3:hover .anchor,.cheatsheet-body h4:hover .anchor,.cheatsheet-body h5:hover .anchor,.cheatsheet-body h6:hover .anchor{text-decoration:none;}.cheatsheet-body h1:hover .anchor .octicon-link,.cheatsheet-body h2:hover .anchor .octicon-link,.cheatsheet-body h3:hover .anchor .octicon-link,.cheatsheet-body h4:hover .anchor .octicon-link,.cheatsheet-body h5:hover .anchor .octicon-link,.cheatsheet-body h6:hover .anchor .octicon-link{visibility:visible;}.cheatsheet-body h1{padding-bottom:0.3em;font-size:2em;border-bottom:1px solid;border-bottom-color:", ";}.cheatsheet-body h2{padding-bottom:0.3em;font-size:1.5em;border-bottom:1px solid;border-bottom-color:", ";}.cheatsheet-body h3{font-size:1.25em;font-weight:600;background:", ";margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px;padding-left:0.1em;color:", ";}.cheatsheet-body h4{font-size:1em;margin-left:1em;color:", ";}.cheatsheet-body h5{font-size:0.875em;}.cheatsheet-body h6{font-size:0.85em;color:", ";}.cheatsheet-body ul,.cheatsheet-body ol{padding-left:2em !important;}.cheatsheet-body ol{display:block;list-style-type:decimal;-webkit-margin-before:1em;-webkit-margin-after:1em;-webkit-margin-start:0px;-webkit-margin-end:0px;-webkit-padding-start:40px;}.cheatsheet-body ul{display:block;list-style-type:disc;-webkit-margin-before:1em;-webkit-margin-after:1em;-webkit-margin-start:0px;-webkit-margin-end:0px;-webkit-padding-start:40px;}.cheatsheet-body ul ul,.cheatsheet-body ul ol,.cheatsheet-body ol ol,.cheatsheet-body ol ul{margin-top:0;margin-bottom:0;}.cheatsheet-body li > p{margin-top:16px;}.cheatsheet-body li + li{margin-top:0.25em;}.cheatsheet-body dl{padding:0;}.cheatsheet-body dl dt{padding:0;margin-top:16px;font-size:1em;font-style:italic;font-weight:600;}.cheatsheet-body dl dd{padding:0 16px;margin-bottom:16px;}.cheatsheet-body table{display:block;width:100%;overflow:auto;}.cheatsheet-body table th{font-weight:600;}.cheatsheet-body table th,.cheatsheet-body table td{padding:6px 13px;border:", ";width:100%;}.cheatsheet-body table tr{background-color:", ";border-top:", ";}.cheatsheet-body table tr:nth-child(2n){background-color:", ";}.cheatsheet-body code{padding:0;padding-top:0.2em;padding-bottom:0.2em;margin:0;font-size:85%;background-color:", ";border-radius:3px;}.cheatsheet-body code::before,.cheatsheet-body code::after{letter-spacing:-0.2em;content:'\0a0';}.cheatsheet-body pre{word-wrap:normal;}.cheatsheet-body pre > code{padding:0;margin:0;font-size:100%;word-break:normal;white-space:pre;background:transparent;border:0;}.cheatsheet-body .highlight{margin-bottom:16px;}.cheatsheet-body .highlight pre{margin-bottom:0;word-break:normal;}.cheatsheet-body pre{padding:16px;overflow:auto;font-size:85%;line-height:1.45;background-color:", ";border-radius:3px;}.cheatsheet-body pre code{display:inline;max-width:auto;padding:0;margin:0;overflow:visible;line-height:inherit;word-wrap:normal;background-color:transparent;border:0;}.cheatsheet-body pre code::before,.cheatsheet-body pre code::after{content:normal;}.cheatsheet-body .full-commit .btn-outline:not(:disabled):hover{color:#005cc5;border-color:#005cc5;}.cheatsheet-body kbd{display:inline-block;padding:3px 5px;font:11px 'SFMono-Regular',Consolas,'Liberation Mono',Menlo,Courier,monospace;line-height:10px;color:#444d56;vertical-align:middle;background-color:#fafbfc;border:solid 1px #d1d5da;border-bottom-color:#c6cbd1;border-radius:3px;box-shadow:inset 0 -1px 0 #c6cbd1;}.cheatsheet-body .task-list-item{list-style-type:none;}.cheatsheet-body .task-list-item + .task-list-item{margin-top:3px;}.cheatsheet-body .task-list-item input{margin:0 0.2em 0.25em -1.6em;vertical-align:middle;}.cheatsheet-body hr{border-bottom-color:", ";}.cheatsheet-body .task-done{margin-left:-1.2em;list-style-type:none;&:before{content:'[o]';color:", ";margin-right:0.5em;}}.cheatsheet-body .task-pending{margin-left:-1.2em;list-style-type:none;&:before{content:'[-]';color:", ";margin-right:0.5em;}}"], Object(utils["W" /* theme */])('markdown.fg'), Object(utils["W" /* theme */])('markdown.strongFg'), Object(utils["W" /* theme */])('markdown.strongBg'), Object(utils["W" /* theme */])('markdown.link'), Object(utils["W" /* theme */])('markdown.title'), Object(utils["W" /* theme */])('markdown.blockquoteFg'), Object(utils["W" /* theme */])('markdown.blockquoteBorder'), Object(utils["W" /* theme */])('markdown.titleBottom'), Object(utils["W" /* theme */])('markdown.titleBottom'), Object(utils["W" /* theme */])('content.bg'), Object(utils["W" /* theme */])('font'), Object(utils["W" /* theme */])('font'), Object(utils["W" /* theme */])('markdown.title'), Object(utils["W" /* theme */])('markdown.tableborder'), Object(utils["W" /* theme */])('markdown.tableBg'), Object(utils["W" /* theme */])('markdown.tableborder'), Object(utils["W" /* theme */])('markdown.tableBg2n'), Object(utils["W" /* theme */])('code.bg'), Object(utils["W" /* theme */])('code.bg'), Object(utils["W" /* theme */])('markdown.hrColor'), Object(utils["W" /* theme */])('markdown.taskDone'), Object(utils["W" /* theme */])('markdown.taskPeding'));
/* harmony default export */ var styles_CheatSheetStyle = (CheatSheetStyle);
/*
   background: #0A2A35;
   margin-top: 0;
   margin-bottom: 0;
   padding-top: 10px;
   padding-bottom: 10px;
   padding-left: 0.6em;
   color: #3B6E9D;
 */
// CONCATENATED MODULE: ./containers/CheatSheetPaper/styles/index.js


var CheatSheetPaper_styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "da4ol-0"
})(["display:flex;flex-direction:column;"]);
var styles_CardWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CardWrapper",
  componentId: "da4ol-1"
})(["width:550px;height:auto;background:", ";margin:10px;margin-right:20px;overflow-y:scroll;@media (max-width:1450px){width:500px;}@media (max-width:1250px){width:450px;}@media (max-width:1100px){width:350px;}"], Object(utils["W" /* theme */])('code.bg'));

// CONCATENATED MODULE: ./containers/CheatSheetPaper/index.js
function CheatSheetPaper__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { CheatSheetPaper__typeof = function _typeof(obj) { return typeof obj; }; } else { CheatSheetPaper__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return CheatSheetPaper__typeof(obj); }

function CheatSheetPaper__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function CheatSheetPaper__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function CheatSheetPaper__createClass(Constructor, protoProps, staticProps) { if (protoProps) CheatSheetPaper__defineProperties(Constructor.prototype, protoProps); if (staticProps) CheatSheetPaper__defineProperties(Constructor, staticProps); return Constructor; }

function CheatSheetPaper__possibleConstructorReturn(self, call) { if (call && (CheatSheetPaper__typeof(call) === "object" || typeof call === "function")) { return call; } return CheatSheetPaper__assertThisInitialized(self); }

function CheatSheetPaper__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function CheatSheetPaper__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * CheatSheetViewer
 *
 */












 // import code from './es7'

/* eslint-disable no-unused-vars */

var CheatSheetPaper_debug = Object(utils["G" /* makeDebugger */])('C:CheatSheetViewer');
/* eslint-enable no-unused-vars */

var md = new external__remarkable__default.a();
md.use(external__remarkable_mentions__default()({
  url: 'http:coderplanets.com/users/'
}));
md.use(external__remarkable_emoji__default.a);
/* eslint-disable react/no-danger */

var CheatSheetPaper_Cards = function Cards(_ref) {
  var cards = _ref.cards;
  return cards.map(function (item) {
    return external__react__default.a.createElement(styles_CardWrapper, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement("div", null, external__react__default.a.createElement("div", {
      dangerouslySetInnerHTML: {
        __html: md.render(item)
      }
    })));
  });
};

var CheatSheetPaper_CheatSheets = function CheatSheets(_ref2) {
  var source = _ref2.source;
  return source.map(function (item) {
    return external__react__default.a.createElement(styles_CheatSheetStyle, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement("div", {
      className: "cheatsheet-body"
    }, external__react__default.a.createElement("div", {
      dangerouslySetInnerHTML: {
        __html: md.render(item.header)
      }
    }), external__react__default.a.createElement(external__react_masonry_component__default.a, null, external__react__default.a.createElement(CheatSheetPaper_Cards, {
      cards: item.cards
    }))));
  });
};

var CheatSheetPaper_ParseError = function ParseError(_ref3) {
  var msg = _ref3.msg;
  var errorMsg = "#### \u89E3\u6790\u51FA\u9519!\n ```bash\n    ".concat(msg, "\n ```\n\n@hello\n\n* \u5E38\u89C1\u539F\u56E0\u53EF\u5AE9\u662F`\u5206\u9694\u7B26`\u9519\u8BEF\u4F7F\u7528\u4E86?\n* \u8BF7\u4FEE\u6539\u540E\u91CD\u65B0\u5C1D\u8BD5, \u6216\u67E5\u770B\u8303\u4F8B [\u793A\u8303\u6587\u6863](https://github.com/mydearxym/mastani-cheatsheets/blob/master/react.md)\n    ");
  return external__react__default.a.createElement(styles_CheatSheetStyle, null, external__react__default.a.createElement("div", {
    className: "cheatsheet-body",
    style: {
      marginTop: '3em'
    },
    dangerouslySetInnerHTML: {
      __html: md.render(errorMsg)
    }
  }));
};

var CheatSheetPaper_renderContent = function renderContent(source, state, errMsg) {
  // state = 'loading'
  switch (state) {
    case 'init':
      {
        return external__react__default.a.createElement("div", null, "init la");
      }

    case 'loading':
      {
        return external__react__default.a.createElement(LoadingEffects["a" /* CheatSheetLoading */], null);
      }

    case '404':
      {
        return external__react__default.a.createElement(components["q" /* NotFound */], null);
      }

    case 'empty':
      {
        return external__react__default.a.createElement("div", null, "isEmpty");
      }

    case 'loaded':
      {
        return external__react__default.a.createElement(CheatSheetPaper_CheatSheets, {
          source: source
        });
      }

    case 'parse_error':
      {
        return external__react__default.a.createElement(CheatSheetPaper_ParseError, {
          msg: errMsg
        });
      }

    default:
      return external__react__default.a.createElement("div", null, "default");
  }
};

var CheatSheetPaper_CheatSheetViewerContainer =
/*#__PURE__*/
function (_React$Component) {
  CheatSheetPaper__inherits(CheatSheetViewerContainer, _React$Component);

  function CheatSheetViewerContainer() {
    CheatSheetPaper__classCallCheck(this, CheatSheetViewerContainer);

    return CheatSheetPaper__possibleConstructorReturn(this, (CheatSheetViewerContainer.__proto__ || Object.getPrototypeOf(CheatSheetViewerContainer)).apply(this, arguments));
  }

  CheatSheetPaper__createClass(CheatSheetViewerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var cheatSheetPaper = this.props.cheatSheetPaper;
      CheatSheetPaper_logic_init(cheatSheetPaper);
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      external__mastani_codehighlight__default.a.highlightAll();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      unInit();
    }
  }, {
    key: "render",
    value: function render() {
      //    const data = logic.transMarkDownforRender(code)
      var cheatSheetPaper = this.props.cheatSheetPaper;
      var source = cheatSheetPaper.source,
          state = cheatSheetPaper.state,
          errMsg = cheatSheetPaper.errMsg;
      return external__react__default.a.createElement("div", null, external__react__default.a.createElement("div", {
        style: {
          display: 'none'
        }
      }, external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        onClick: getData.bind(this, 'elixir')
      }, "Elixir"), "\xA0\xA0", external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        onClick: getData.bind(this, 'go')
      }, "go"), "\xA0\xA0", external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        onClick: getData.bind(this, 'react')
      }, "react"), "\xA0\xA0", external__react__default.a.createElement(components["d" /* Button */], {
        type: "primary",
        ghost: true,
        onClick: getData.bind(this, 'ruby')
      }, "not found")), external__react__default.a.createElement(CheatSheetPaper_styles_Wrapper, null, external__react__default.a.createElement("div", null, CheatSheetPaper_renderContent(source, state, errMsg))));
    }
  }]);

  return CheatSheetViewerContainer;
}(external__react__default.a.Component);
/* eslint-enable react/no-danger */


/* harmony default export */ var CheatSheetPaper = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('cheatSheetPaper'))(Object(external__mobx_react_["observer"])(CheatSheetPaper_CheatSheetViewerContainer)));
// CONCATENATED MODULE: ./containers/index.js
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "w", function() { return ThemeWrapper["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "o", function() { return MultiLanguage["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "u", function() { return Route["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "e", function() { return BodyLayout["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "m", function() { return containers_Header["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "d", function() { return Banner["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "k", function() { return Content["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "s", function() { return Preview["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "v", function() { return Sidebar["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "l", function() { return Doraemon["a" /* default */]; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "j", function() { return CommunityEditors; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "c", function() { return ArticleViwer; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "a", function() { return AccountEditor; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "b", function() { return AccountViewer; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "x", function() { return UserBanner; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "p", function() { return PostBanner; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "i", function() { return CommunityBanner; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "g", function() { return CommunitiesBanner; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "y", function() { return UserContent; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "h", function() { return CommunitiesContent; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "q", function() { return PostContent; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "r", function() { return PostsThread; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "z", function() { return VideosThread; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "n", function() { return JobsThread; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "t", function() { return ReposThread; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "f", function() { return CheatSheetPaper; });
/*
   index of all the containers
 */

/* import ThemeWrapper from '../containers/ThemeWrapper' */














/* banners */





/* contents */




/* threads */







/***/ }),
/* 29 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/slice");

/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/filter");

/***/ }),
/* 31 */
/***/ (function(module, exports) {

module.exports = require("pubsub-js");

/***/ }),
/* 32 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ASSETS_ENDPOINT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return ICON_ASSETS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DEFAULT_ICON; });
var ASSETS_ENDPOINT = 'https://coderplanets.oss-cn-beijing.aliyuncs.com';
var ICON_ASSETS = "".concat(ASSETS_ENDPOINT, "/icons");
var DEFAULT_ICON = "".concat(ASSETS_ENDPOINT, "/icons/cmd/cheatsheet.svg");

/***/ }),
/* 33 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/split");

/***/ }),
/* 34 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/head");

/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/path");

/***/ }),
/* 36 */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),
/* 37 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/propEq");

/***/ }),
/* 38 */
/***/ (function(module, exports) {

module.exports = require("next/dynamic");

/***/ }),
/* 39 */
/***/ (function(module, exports) {

module.exports = require("rxjs/Observable");

/***/ }),
/* 40 */
/***/ (function(module, exports) {

module.exports = require("react-tooltip");

/***/ }),
/* 41 */
/***/ (function(module, exports) {

module.exports = require("mastani-codehighlight");

/***/ }),
/* 42 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/values");

/***/ }),
/* 43 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/forEach");

/***/ }),
/* 44 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_values__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_values___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ramda_src_values__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_antd_lib_tabs__ = __webpack_require__(119);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_antd_lib_tabs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_antd_lib_tabs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utils__ = __webpack_require__(0);



/*
 * Tabber
 */



/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_4__utils__["G" /* makeDebugger */])('c:Tabber:index');
/* eslint-enable no-unused-vars */

var TabPane = __WEBPACK_IMPORTED_MODULE_1_antd_lib_tabs___default.a.TabPane;

var Tabber = function Tabber(_ref) {
  var source = _ref.source,
      active = _ref.active,
      onChange = _ref.onChange;

  var tabitems = __WEBPACK_IMPORTED_MODULE_0_ramda_src_values___default()(source);

  return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_antd_lib_tabs___default.a, {
    onChange: onChange,
    activeKey: active
  }, tabitems.map(function (item) {
    return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(TabPane, {
      tab: Object(__WEBPACK_IMPORTED_MODULE_4__utils__["l" /* Trans */])(item.title),
      key: item.raw
    });
  }));
};

Tabber.defaultProps = {
  active: __WEBPACK_IMPORTED_MODULE_4__utils__["j" /* THREAD */].POST,
  onChange: debug
};
/* harmony default export */ __webpack_exports__["a"] = (Tabber);

/***/ }),
/* 45 */
/***/ (function(module, exports) {

module.exports = require("react-keydown");

/***/ }),
/* 46 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/last");

/***/ }),
/* 47 */
/***/ (function(module, exports) {

module.exports = require("react-waypoint");

/***/ }),
/* 48 */
/***/ (function(module, exports) {

module.exports = require("remarkable");

/***/ }),
/* 49 */
/***/ (function(module, exports) {

module.exports = require("remarkable-emoji");

/***/ }),
/* 50 */
/***/ (function(module, exports) {

module.exports = require("remarkable-mentions");

/***/ }),
/* 51 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/trim");

/***/ }),
/* 52 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: external "draft-js"
var external__draft_js_ = __webpack_require__(73);
var external__draft_js__default = /*#__PURE__*/__webpack_require__.n(external__draft_js_);

// EXTERNAL MODULE: external "draft-js-plugins-editor"
var external__draft_js_plugins_editor_ = __webpack_require__(135);
var external__draft_js_plugins_editor__default = /*#__PURE__*/__webpack_require__.n(external__draft_js_plugins_editor_);

// EXTERNAL MODULE: external "pubsub-js"
var external__pubsub_js_ = __webpack_require__(31);
var external__pubsub_js__default = /*#__PURE__*/__webpack_require__.n(external__pubsub_js_);

// EXTERNAL MODULE: external "draft-js-mention-plugin"
var external__draft_js_mention_plugin_ = __webpack_require__(136);
var external__draft_js_mention_plugin__default = /*#__PURE__*/__webpack_require__.n(external__draft_js_mention_plugin_);

// CONCATENATED MODULE: ./containers/TypeWriter/exportContent.js
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

/*
 * util functions from https://github.com/react-component/editor-mention/blob/master/src/utils/exportContent.js
 */


function encodeContent(text) {
  return text.split('&').join('&amp;').split('<').join('&lt;').split('>').join('&gt;').split('\xA0').join('&nbsp;').split('\n').join('<br > \n');
}

var exportContent_MentionGenerator =
/*#__PURE__*/
function () {
  function MentionGenerator(contentState, options) {
    _classCallCheck(this, MentionGenerator);

    this.contentState = contentState;
    this.options = options;
  }

  _createClass(MentionGenerator, [{
    key: "generate",
    value: function generate() {
      var contentRaw = Object(external__draft_js_["convertToRaw"])(this.contentState);
      return this.processContent(contentRaw);
    }
  }, {
    key: "processContent",
    value: function processContent(contentRaw) {
      var blocks = contentRaw.blocks;
      var encode = this.options.encode;
      return blocks.map(function (block) {
        return encode ? encodeContent(block.text) : block.text;
      }).join(encode ? '<br />\n' : '\n');
    }
  }]);

  return MentionGenerator;
}();

function exportContent(contentState) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return new exportContent_MentionGenerator(contentState, options).generate();
}
// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./containers/TypeWriter/styles/editorStyle.js

var Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editorStyle__Wrapper",
  componentId: "s54llg-0"
})(["margin-left:10px;margin-right:10px;"]);
var holder = false;
// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// CONCATENATED MODULE: ./containers/TypeWriter/BodyEditor.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function BodyEditor__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function BodyEditor__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function BodyEditor__createClass(Constructor, protoProps, staticProps) { if (protoProps) BodyEditor__defineProperties(Constructor.prototype, protoProps); if (staticProps) BodyEditor__defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

/*
 * Editor based on Draft
 */









var themeClass = {
  mention: 'typewriter-mention',
  mentionSuggestions: 'typewriter-suggestions',
  mentionSuggestionsEntry: 'typewriter-mentionSuggestionsEntry',
  mentionSuggestionsEntryFocused: 'typewriter-mentionSuggestionsEntryFocused',
  mentionSuggestionsEntryAvatar: 'typewriter-mentionSuggestionsEntryAvatar',
  mentionSuggestionsEntryText: 'typewriter-mentionSuggestionsEntryText'
  /* eslint-disable no-unused-vars */

};
var debug = Object(utils["G" /* makeDebugger */])('C:Comments');
/* eslint-enable no-unused-vars */

var BodyEditor_MastaniEditor =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MastaniEditor, _React$Component);

  function MastaniEditor(props) {
    var _this;

    BodyEditor__classCallCheck(this, MastaniEditor);

    _this = _possibleConstructorReturn(this, (MastaniEditor.__proto__ || Object.getPrototypeOf(MastaniEditor)).call(this, props));
    Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        editorState: external__draft_js_["EditorState"].createEmpty(),
        suggestions: [],
        pub: null
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "insertSnippet", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(data) {
        /*
           const curString = toRawString(this.state.editorState.getCurrentContent())
           const contentState = ContentState.createFromText(
           `${curString}\n\n${data}\n\n`
           )
           const editorState = EditorState.push(this.state.editorState, contentState)
            this.setState({ editorState })
         */
        var editorState = _this.state.editorState;
        /* const contentState = ContentState.createFromText('ni ma') */

        var contentState = editorState.getCurrentContent();
        var selection = editorState.getSelection();
        var nextContentState = external__draft_js_["Modifier"].insertText(contentState, selection, "\n".concat(data, "\n"));
        var nextEditorState = external__draft_js_["EditorState"].push(editorState, nextContentState);

        _this.setState({
          editorState: nextEditorState
        }, function () {
          _this.focus();
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "onBlur", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        /*
        const selectionState = this.state.editorState.getSelection()
        const { editorState } = this.state
        const fuck = Modifier.splitBlock(
          editorState.getCurrentContent(),
          selectionState,
          'this-is-me'
        )
         const fff = toRawString(fuck)
        console.log('fffff: ', fff.split('\n'))
        */
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "onChange", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(editorState) {
        var onChange = _this.props.onChange; // const oldString = toRawString(this.state.editorState.getCurrentContent())

        var newString = exportContent(editorState.getCurrentContent()); // console.log('onChange raw: ', newString)

        onChange(newString);

        _this.setState({
          editorState: editorState
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "onSearchChange", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(_ref) {
        var _value = _ref.value;

        /*
        this.setState({
          suggestions: defaultSuggestionsFilter(value, this.state.mentions),
        })
        */
        _this.setState(function (prevState) {
          return {
            suggestions: Object(external__draft_js_mention_plugin_["defaultSuggestionsFilter"])(_value, prevState.mentions)
          };
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "onAddMention", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value(user) {
        // console.log('onAddMention: ', user)
        var onMention = _this.props.onMention;
        onMention(user); // get the mention object selected
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "focus", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        if (_this.editor) {
          _this.editor.focus();
        }
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "loadUserSuggestions", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var mentions = _this.props.mentions;
        /* debug('loadUserSuggestions --->', mentions) */

        _this.setState({
          suggestions: mentions,
          mentions: mentions
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "clearContent", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var editorState = external__draft_js_["EditorState"].createWithContent(external__draft_js_["ContentState"].createFromText(''));

        _this.setState({
          editorState: editorState
        });
      }
    });
    Object.defineProperty(_assertThisInitialized(_this), "loadDraft", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function value() {
        var body = _this.props.body;
        var editorState = external__draft_js_["EditorState"].createWithContent(external__draft_js_["ContentState"].createFromText(body)); // somehow the onCHange behave strange
        // see issue: https://github.com/facebook/draft-js/issues/1198
        //     setTimeout(() => {
        //   this.focus()
        //    }, 150)

        _this.setState({
          editorState: editorState
        });
      }
    });
    _this.mentionPlugin = external__draft_js_mention_plugin__default()({
      theme: themeClass,
      mentionPrefix: '@'
    });
    return _this;
  }

  BodyEditor__createClass(MastaniEditor, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      this.loadDraft();
      this.loadUserSuggestions();
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      /* DONT use loadDraft in componentDidMount, it will cause strange bug of mentions */

      /* also onCHange empty issue in Draft.js */

      /*
         see: https://stackoverflow.com/questions/35884112/draftjs-how-to-initiate-an-editor-with-content
         import {  ContentState } from 'draft-js'
          const editorState={EditorState.createWithContent(
         ContentState.createFromText('fuck')
         )}
       */

      /* TODO: has to use setTimeout otherwise the mention not work */
      setTimeout(function () {
        _this2.focus();
      }, 100);
      this.initPubSub();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      var pub = this.state.pub;
      external__pubsub_js__default.a.unsubscribe(pub);
      this.clearContent();
    }
  }, {
    key: "initPubSub",
    value: function initPubSub() {
      var _this3 = this;

      var pub = external__pubsub_js__default.a.subscribe(utils["e" /* EVENT */].DRAFT_INSERT_SNIPPET, function (event, data) {
        _this3.insertSnippet(data.data);
      });
      this.setState({
        pub: pub
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this4 = this;

      var MentionSuggestions = this.mentionPlugin.MentionSuggestions;
      var plugins = [this.mentionPlugin];
      var _state = this.state,
          editorState = _state.editorState,
          suggestions = _state.suggestions;
      return external__react__default.a.createElement(Wrapper, {
        onClick: this.focus
      }, external__react__default.a.createElement(external__draft_js_plugins_editor__default.a, {
        editorState: editorState,
        onChange: this.onChange,
        onBlur: this.onBlur,
        plugins: plugins,
        ref: function ref(element) {
          _this4.editor = element;
        }
      }), external__react__default.a.createElement(MentionSuggestions, {
        onSearchChange: this.onSearchChange,
        suggestions: suggestions,
        onAddMention: this.onAddMention
      }));
    }
  }]);

  return MastaniEditor;
}(external__react__default.a.Component);

BodyEditor_MastaniEditor.defaultProps = {
  body: '',
  mentions: [],
  onMention: debug,
  onChange: debug
};
/* harmony default export */ var BodyEditor = __webpack_exports__["a"] = (BodyEditor_MastaniEditor);

/***/ }),
/* 53 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/has");

/***/ }),
/* 54 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/and");

/***/ }),
/* 55 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return PAGE_SIZE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return WORD_LIMIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ATATARS_LIST_LENGTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return TAG_COLORS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return CMS_THREADS; });
/*
   general behavior of the site
 */
var PAGE_SIZE = {
  COMMON: 20,
  POSTSPAPER_POSTS: 25,
  COMMENTS: 20
};
var WORD_LIMIT = {
  COMMENT: 300
};
var ATATARS_LIST_LENGTH = {
  POSTS: 4,
  COMMENTS: 5
};
var TAG_COLORS = ['red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'purple'];
var CMS_THREADS = ['post', 'job', 'video', 'repo', 'wiki'];

/***/ }),
/* 56 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/clone");

/***/ }),
/* 57 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/endsWith");

/***/ }),
/* 58 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/prop");

/***/ }),
/* 59 */
/***/ (function(module, exports) {

module.exports = require("store");

/***/ }),
/* 60 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/insert");

/***/ }),
/* 61 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/append");

/***/ }),
/* 62 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/row");

/***/ }),
/* 63 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/col");

/***/ }),
/* 64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "ramda/src/range"
var range_ = __webpack_require__(26);
var range__default = /*#__PURE__*/__webpack_require__.n(range_);

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: external "react-masonry-component"
var external__react_masonry_component_ = __webpack_require__(65);
var external__react_masonry_component__default = /*#__PURE__*/__webpack_require__.n(external__react_masonry_component_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: external "react-content-loader"
var external__react_content_loader_ = __webpack_require__(27);
var external__react_content_loader__default = /*#__PURE__*/__webpack_require__.n(external__react_content_loader_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// CONCATENATED MODULE: ./components/LoadingEffects/CheatSheetLoading.js





 // import Loading, { Rect, Circle } from 'react-content-loader'



/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('c:LoadingEffects:index');
/* eslint-enable no-unused-vars */

/* eslint-disable no-unused-vars */

var CheatSheetLoading_LoadingBlock = function LoadingBlock(_ref) {
  var theme = _ref.theme;
  return (
    /* eslint-enable no-unused-vars */
    external__react__default.a.createElement("div", {
      style: {
        width: '45%',
        overflow: 'hidden',
        marginTop: 20,
        height: 180
      }
    }, external__react__default.a.createElement(external__react_content_loader__default.a, {
      height: 200,
      width: 280,
      speed: 2,
      primaryColor: "#f3f3f3",
      secondaryColor: "#ecebeb"
    }, external__react__default.a.createElement("rect", {
      x: "0",
      y: "0",
      rx: "3",
      ry: "3",
      width: "70",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "80",
      y: "0",
      rx: "3",
      ry: "3",
      width: "100",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "190",
      y: "0",
      rx: "3",
      ry: "3",
      width: "10",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "15",
      y: "20",
      rx: "3",
      ry: "3",
      width: "130",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "155",
      y: "20",
      rx: "3",
      ry: "3",
      width: "130",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "15",
      y: "40",
      rx: "3",
      ry: "3",
      width: "90",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "115",
      y: "40",
      rx: "3",
      ry: "3",
      width: "60",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "185",
      y: "40",
      rx: "3",
      ry: "3",
      width: "60",
      height: "10"
    }), external__react__default.a.createElement("rect", {
      x: "0",
      y: "60",
      rx: "3",
      ry: "3",
      width: "30",
      height: "10"
    })))
  );
};

var CheatSheetLoading_CheatSheetLoading = function CheatSheetLoading(_ref2) {
  var column = _ref2.column,
      theme = _ref2.theme;
  return external__react__default.a.createElement(external__react_masonry_component__default.a, null, range__default()(0, column).map(function () {
    return external__react__default.a.createElement(CheatSheetLoading_LoadingBlock, {
      key: external__shortid__default.a.generate(),
      theme: theme
    });
  }));
};

CheatSheetLoading_CheatSheetLoading.defaultProps = {
  column: 4
};
/* harmony default export */ var LoadingEffects_CheatSheetLoading = (Object(external__styled_components_["withTheme"])(CheatSheetLoading_CheatSheetLoading));
// CONCATENATED MODULE: ./components/LoadingEffects/CommentLoading.js


 // Config-page: http://danilowoz.com/create-react-content-loader/

var LoadingWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "CommentLoading__LoadingWrapper",
  componentId: "s1805x95-0"
})(["width:100%;overflow:hidden;"]);

var CommentLoading_CommentLoading = function CommentLoading(_ref) {
  var theme = _ref.theme;
  // const ukey = shortid.generate()
  return external__react__default.a.createElement(LoadingWrapper, null, external__react__default.a.createElement(external__react_content_loader__default.a, {
    height: 60,
    width: 400,
    speed: 2,
    primaryColor: theme.loading.basic,
    secondaryColor: theme.loading.animate
  }, external__react__default.a.createElement("rect", {
    x: "35",
    y: "6",
    rx: "4",
    ry: "4",
    width: "117",
    height: "5.25"
  }), external__react__default.a.createElement("rect", {
    x: "37",
    y: "20",
    rx: "3",
    ry: "3",
    width: "85",
    height: "5.25"
  }), external__react__default.a.createElement("rect", {
    x: "37",
    y: "37.68",
    rx: "3",
    ry: "3",
    width: "318.5",
    height: "4.6"
  }), external__react__default.a.createElement("rect", {
    x: "37",
    y: "51",
    rx: "3",
    ry: "3",
    width: "319.2",
    height: "5.11"
  }), external__react__default.a.createElement("rect", {
    x: "71",
    y: "104",
    rx: "3",
    ry: "3",
    width: "201",
    height: "6.4"
  }), external__react__default.a.createElement("circle", {
    cx: "14.0",
    cy: "14.0",
    r: "14.0"
  })));
};

/* harmony default export */ var LoadingEffects_CommentLoading = (Object(external__styled_components_["withTheme"])(CommentLoading_CommentLoading));
// CONCATENATED MODULE: ./components/LoadingEffects/PostLoading.js





 // Config-page: http://danilowoz.com/create-react-content-loader/

var PostLoading_LoadingWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "PostLoading__LoadingWrapper",
  componentId: "s1eg9vax-0"
})(["width:100%;overflow:hidden;"]);

var PostLoading_LoadingItem = function LoadingItem(_ref) {
  var theme = _ref.theme;
  return external__react__default.a.createElement(external__react_content_loader__default.a, {
    height: 100,
    width: 400,
    speed: 2,
    primaryColor: theme.loading.basic,
    secondaryColor: theme.loading.animate
  }, external__react__default.a.createElement("rect", {
    x: "25",
    y: "16.05",
    rx: "5",
    ry: "5",
    width: "363",
    height: "8"
  }), external__react__default.a.createElement("rect", {
    x: "25",
    y: "46.05",
    rx: "5",
    ry: "5",
    width: "358.0",
    height: "8"
  }), external__react__default.a.createElement("rect", {
    x: "25",
    y: "75",
    rx: "5",
    ry: "5",
    width: "355",
    height: "8"
  }), external__react__default.a.createElement("rect", {
    x: "25",
    y: "16.05",
    rx: "5",
    ry: "5",
    width: "363",
    height: "8"
  }), external__react__default.a.createElement("rect", {
    x: "25",
    y: "46.05",
    rx: "5",
    ry: "5",
    width: "358.0",
    height: "8"
  }), external__react__default.a.createElement("rect", {
    x: "25",
    y: "75",
    rx: "5",
    ry: "5",
    width: "355",
    height: "8"
  }));
};

var PostLoading_PostLoading = function PostLoading(_ref2) {
  var num = _ref2.num,
      theme = _ref2.theme;

  // const ukey = shortid.generate()
  var range = range__default()(0, num);

  return range.map(function () {
    return external__react__default.a.createElement(PostLoading_LoadingWrapper, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement(PostLoading_LoadingItem, {
      uniquekey: external__shortid__default.a.generate(),
      theme: theme
    }));
  });
};

PostLoading_PostLoading.defaultProps = {
  num: 1
};
/* harmony default export */ var LoadingEffects_PostLoading = (Object(external__styled_components_["withTheme"])(PostLoading_PostLoading));
// CONCATENATED MODULE: ./components/LoadingEffects/PostsLoading.js





 // Config-page: http://danilowoz.com/create-react-content-loader/

var PostsLoading_LoadingWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "PostsLoading__LoadingWrapper",
  componentId: "s1m5ocjh-0"
})(["width:100%;height:100px;margin-bottom:30px;overflow:hidden;"]);

var PostsLoading_LoadingItem = function LoadingItem(_ref) {
  var theme = _ref.theme;
  return external__react__default.a.createElement(external__react_content_loader__default.a, {
    height: 560,
    width: 500,
    speed: 2,
    primaryColor: theme.loading.basic,
    secondaryColor: theme.loading.animate
  }, external__react__default.a.createElement("rect", {
    x: "38",
    y: "5.58",
    rx: "4",
    ry: "4",
    width: "195.55",
    height: "8.69"
  }), external__react__default.a.createElement("rect", {
    x: "38",
    y: "19.93",
    rx: "3",
    ry: "3",
    width: "130.05",
    height: "5.36"
  }), external__react__default.a.createElement("rect", {
    x: "38",
    y: "48.02",
    rx: "3",
    ry: "3",
    width: "329.47",
    height: "5.3"
  }), external__react__default.a.createElement("rect", {
    x: "38",
    y: "35.16",
    rx: "3",
    ry: "3",
    width: "454.96",
    height: "6.05"
  }), external__react__default.a.createElement("circle", {
    cx: "16.8",
    cy: "19",
    r: "15"
  }), external__react__default.a.createElement("circle", {
    cx: "449",
    cy: "14",
    r: "8"
  }), external__react__default.a.createElement("circle", {
    cx: "467",
    cy: "14",
    r: "8"
  }), external__react__default.a.createElement("circle", {
    cx: "485",
    cy: "14",
    r: "8"
  }));
};

var PostsLoading_PostsLoading = function PostsLoading(_ref2) {
  var num = _ref2.num,
      theme = _ref2.theme;

  // const ukey = shortid.generate()
  var range = range__default()(0, num);

  return range.map(function () {
    return external__react__default.a.createElement(PostsLoading_LoadingWrapper, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement(PostsLoading_LoadingItem, {
      uniquekey: external__shortid__default.a.generate(),
      theme: theme
    }));
  });
};

PostsLoading_PostsLoading.defaultProps = {
  num: 1
};
/* harmony default export */ var LoadingEffects_PostsLoading = (Object(external__styled_components_["withTheme"])(PostsLoading_PostsLoading));
// CONCATENATED MODULE: ./components/LoadingEffects/index.js
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "a", function() { return LoadingEffects_CheatSheetLoading; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "b", function() { return LoadingEffects_CommentLoading; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "c", function() { return LoadingEffects_PostLoading; });
/* concated harmony reexport */__webpack_require__.d(__webpack_exports__, "d", function() { return LoadingEffects_PostsLoading; });
/*
 *
 * LoadingEffects
 *
 */





/***/ }),
/* 65 */
/***/ (function(module, exports) {

module.exports = require("react-masonry-component");

/***/ }),
/* 66 */
/***/ (function(module, exports) {

module.exports = require("rxjs/Subject");

/***/ }),
/* 67 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/debounceTime");

/***/ }),
/* 68 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/do");

/***/ }),
/* 69 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/switchMap");

/***/ }),
/* 70 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/merge");

/***/ }),
/* 71 */
/***/ (function(module, exports) {

module.exports = require("isomorphic-fetch");

/***/ }),
/* 72 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/observable/fromPromise");

/***/ }),
/* 73 */
/***/ (function(module, exports) {

module.exports = require("draft-js");

/***/ }),
/* 74 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/pick");

/***/ }),
/* 75 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/equals");

/***/ }),
/* 76 */
/***/ (function(module, exports) {

module.exports = require("react-click-outside");

/***/ }),
/* 77 */
/***/ (function(module, exports) {

module.exports = require("react-calendar-heatmap");

/***/ }),
/* 78 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var communityRaw = "\n  query community($id: ID, $raw: String) {\n    community(id: $id, raw: $raw) {\n      id\n      title\n      desc\n      raw\n      logo\n      threads {\n        title\n        raw\n      }\n      subscribersCount\n      editorsCount\n      postsCount\n    }\n  }\n";
var community = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, communityRaw);
var schema = {
  community: community,
  communityRaw: communityRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 79 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedPostsRaw = "\n  query($filter: PagedArticleFilter) {\n    pagedPosts(filter: $filter) {\n      entries {\n        id\n        title\n        digest\n        insertedAt\n        updatedAt\n        views\n        author {\n          id\n          avatar\n          nickname\n        }\n        commentsParticipatorsCount\n        commentsParticipators(filter: { first: 5 }) {\n          id\n          nickname\n          avatar\n        }\n      }\n      totalCount\n      pageSize\n      pageNumber\n    }\n  }\n"; // TODO: mvoe to SharedSchema

var partialTagsRaw = "\n  query($communityId: ID, $community: String, $thread: CmsThread!) {\n    partialTags(communityId: $communityId, community: $community, thread: $thread) {\n      id\n      title\n      color\n      thread\n    }\n  }\n";
var pagedPosts = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, pagedPostsRaw);
var partialTags = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, partialTagsRaw);
var schema = {
  pagedPosts: pagedPosts,
  pagedPostsRaw: pagedPostsRaw,
  partialTags: partialTags,
  partialTagsRaw: partialTagsRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 80 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedVideosRaw = "\n  query($filter: PagedArticleFilter) {\n    pagedVideos(filter: $filter) {\n      entries {\n        id\n        title\n        desc\n        duration\n        views\n        originalAuthor\n        originalAuthorLink\n        author {\n          id\n          avatar\n          nickname\n        }\n        insertedAt\n      }\n      totalCount\n      pageSize\n      pageNumber\n    }\n  }\n"; // TODO: mvoe to SharedSchema

var partialTagsRaw = "\n  query($communityId: ID, $community: String, $thread: CmsThread!) {\n    partialTags(communityId: $communityId, community: $community, thread: $thread) {\n      id\n      title\n      color\n      thread\n    }\n  }\n";
var pagedVideos = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, pagedVideosRaw);
var partialTags = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, partialTagsRaw);
var schema = {
  pagedVideos: pagedVideos,
  pagedVideosRaw: pagedVideosRaw,
  partialTags: partialTags,
  partialTagsRaw: partialTagsRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 81 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedJobsRaw = "\n  query pagedJobs($filter: PagedArticleFilter) {\n    pagedJobs(filter: $filter) {\n      entries {\n        id\n        title\n        digest\n        insertedAt\n        updatedAt\n        views\n      }\n      totalCount\n      pageSize\n      pageNumber\n    }\n  }\n";
var partialTagsRaw = "\n  query($communityId: ID, $community: String, $thread: CmsThread!) {\n    partialTags(communityId: $communityId, community: $community, thread: $thread) {\n      id\n      title\n      color\n      thread\n    }\n  }\n";
var pagedJobs = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, pagedJobsRaw);
var partialTags = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, partialTagsRaw);
var schema = {
  pagedJobs: pagedJobs,
  pagedJobsRaw: pagedJobsRaw,
  partialTags: partialTags,
  partialTagsRaw: partialTagsRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 82 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedReposRaw = "\n  query($filter: PagedArticleFilter) {\n    pagedRepos(filter: $filter) {\n      entries {\n        id\n        repoName\n        desc\n        readme\n        language\n        repoLink\n        producer\n        producerLink\n        repoStarCount\n        repoForkCount\n        repoWatchCount\n        views\n        author {\n          id\n          avatar\n          nickname\n        }\n        insertedAt\n      }\n      totalCount\n      pageSize\n      pageNumber\n    }\n  }\n"; // TODO: mvoe to SharedSchema

var partialTagsRaw = "\n  query($communityId: ID, $community: String, $thread: CmsThread!) {\n    partialTags(communityId: $communityId, community: $community, thread: $thread) {\n      id\n      title\n      color\n      thread\n    }\n  }\n";
var pagedRepos = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, pagedReposRaw);
var partialTags = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, partialTagsRaw);
var schema = {
  pagedRepos: pagedRepos,
  pagedReposRaw: pagedReposRaw,
  partialTags: partialTags,
  partialTagsRaw: partialTagsRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 83 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_router__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utils__ = __webpack_require__(0);




__WEBPACK_IMPORTED_MODULE_1_next_router___default.a.onRouteChangeComplete = function (url) {
  __WEBPACK_IMPORTED_MODULE_2__utils__["g" /* GA */].pageview(url);
};
/* eslint-disable */


/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var children = _ref.children;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", null, children);
});
/* eslint-enable */

/***/ }),
/* 84 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(121);
var style__default = /*#__PURE__*/__webpack_require__.n(style_);

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "polished"
var external__polished_ = __webpack_require__(14);
var external__polished__default = /*#__PURE__*/__webpack_require__.n(external__polished_);

// CONCATENATED MODULE: ./containers/ThemeWrapper/AntOverWrite.js



var AntOverWrite =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "AntOverWrite",
  componentId: "s5pau6-0"
})([".react-calendar-heatmap rect:hover{stroke:", ";}.react-calendar-heatmap-month-label{fill:", ";font-size:0.7em;}.banner-heatmap{.react-calendar-heatmap-month-label{fill:", ";font-size:0.7em;}}.react-calendar-heatmap .color-scale-1{fill:", ";}.react-calendar-heatmap .color-scale-2{fill:", ";}.react-calendar-heatmap .color-scale-3{fill:", ";}.react-calendar-heatmap .color-scale-4{fill:", ";}.react-calendar-heatmap .color-scale-5{fill:", ";}.react-calendar-heatmap .color-empty{fill:", ";}.comment-editor{.public-DraftEditor-content{min-height:150px;font-size:1.3em;color:", ";}}.comment-reply-editor{.public-DraftEditor-content{min-height:200px;font-size:0.9em;color:", ";}}.public-DraftEditor-content{min-height:500px;font-size:1.3em;color:", ";}.typewriter-mention{color:", ";cursor:pointer;display:inline-block;background:", ";padding-left:5px;padding-right:5px;border-radius:3px;text-decoration:none;}.typewriter-mention:hover,.typewriter-mention:focus{color:#677584;background:", ";outline:0;}.typewriter-suggestions{border:1px solid;border-color:", ";margin-top:10px;position:absolute;min-width:220px;max-width:440px;background:", ";border-radius:2px;box-shadow:", ";cursor:pointer;padding-top:8px;padding-bottom:8px;z-index:2;display:-webkit-box;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;flex-direction:column;box-sizing:border-box;-webkit-transform:scale(0);transform:scale(0);}.typewriter-mentionSuggestionsEntry{transition:background-color 0.4s cubic-bezier(0.27,1.27,0.48,0.56);padding:7px 10px 3px 10px;padding-left:10px;display:flex;}.typewriter-mentionSuggestionsEntry:active{background-color:tomato;}.typewriter-mentionSuggestionsEntryFocused{background-color:", ";padding:7px 10px 3px 10px;display:flex;}.typewriter-mentionSuggestionsEntryText{display:inline-block;margin-left:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:368px;font-size:1.1rem;margin-bottom:0.2em;color:#6d999d;}.typewriter-mentionSuggestionsEntryAvatar{display:inline-block;width:24px;height:24px;border-radius:12px;}.ant-modal-mask{background-color:rgba(0,0,0,0.15) !important;}.ant-popover-inner-content{padding:0;}.ant-popover .ant-popover-content .ant-popover-inner{background:tomato;}.ant-popover-inner{background:tomato !important;}.normal-form{.ant-input{background-color:", ";color:", ";border-color:", ";}}.ant-checkbox-wrapper{color:#87c5ca;}.ant-checkbox-wrapper:hover .ant-checkbox-inner,.ant-checkbox:hover .ant-checkbox-inner,.ant-checkbox-input:focus + .ant-checkbox-inner{border-color:#51abb2;}.ant-checkbox-checked .ant-checkbox-inner,.ant-checkbox-indeterminate .ant-checkbox-inner{background-color:#51abb2;border-color:#51abb2;}.ant-checkbox-inner{border-radius:8px;transition:all 0.2s;}.ant-divider-horizontal.ant-divider-with-text{color:lightgrey;}.ant-radio-wrapper{color:grey;}.ant-radio-wrapper-checked{color:", ";}.ant-radio-checked .ant-radio-inner{border-color:", " !important;margin-top:50px;}.ant-radio-inner:after{background-color:", " !important;}.ant-pagination-item:focus,.ant-pagination-item:hover{border-color:", ";}.ant-pagination-item{border-radius:50%;background-color:", ";border-color:", ";}.ant-pagination-item a{color:", ";}.ant-pagination-prev a,.ant-pagination-next a{color:", ";}.ant-pagination-prev a:hover,.ant-pagination-next a:hover{font-weight:bold;}.ant-pagination-disabled a,.ant-pagination-disabled:hover a,.ant-pagination-disabled:focus a,.ant-pagination-disabled .ant-pagination-item-link,.ant-pagination-disabled:hover .ant-pagination-item-link,.ant-pagination-disabled:focus .ant-pagination-item-link{color:", ";}.ant-pagination-item-active{background:", ";border-radius:50%;}.ant-pagination-item-active a{color:", ";font-size:1.1em;}.ant-btn-background-ghost.ant-btn-primary{color:", ";border-color:", ";}.ant-btn:focus,.ant-btn:hover{background-color:", ";}.ant-btn:active{background-color:", ";}.ant-btn-primary{color:", ";background-color:", ";border-color:", ";}.ant-btn-primary.disabled,.ant-btn-primary[disabled],.ant-btn-primary.disabled:hover,.ant-btn-primary[disabled]:hover,.ant-btn-primary.disabled:focus,.ant-btn-primary[disabled]:focus,.ant-btn-primary.disabled:active,.ant-btn-primary[disabled]:active,.ant-btn-primary.disabled.active,.ant-btn-primary[disabled].active{color:white;}.ant-btn-red:hover{background-color:", ";border-color:", ";color:white;}.ant-btn-red:active{background-color:", ";border-color:", ";}.ant-btn-red:focus{background-color:", ";border-color:", ";}.ant-btn-red{color:white;background-color:tomato;border-color:tomato;}.ant-btn-background-ghost.ant-btn-red{color:tomato;border-color:tomato;}.ant-btn-clicked:after{border:0px solid;border-color:", ";}.ant-tabs-bar{border-bottom:", ";}.tabs-with-bottom{.ant-tabs-nav-container{border-bottom:1px solid;border-bottom-color:", ";}}.ant-tabs-ink-bar{background-color:", ";}.ant-tabs-nav .ant-tabs-tab{color:", ";&:hover{color:", ";}}.ant-tabs-nav .ant-tabs-tab-active{color:", ";font-weight:bold;}.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab{border-color:", ";background:", ";border-bottom:1px solid;border-bottom-color:", ";}.ant-tabs.ant-tabs-card .ant-tabs-bar .ant-tabs-tab-active{border-top:2px solid;border-top-color:", ";color:", ";background:", ";font-weight:bold;}ul{margin-bottom:0;}.ant-tag,.ant-tag a,.ant-tag a:hover{color:", ";}.ant-tag{border:1px solid;border-color:", ";background:", ";}.ant-tag .anticon-cross{color:", ";}"], Object(utils["W" /* theme */])('heatmap.borderHover'), Object(utils["W" /* theme */])('heatmap.monthLabel'), Object(utils["W" /* theme */])('bannerHeatmap.monthLabel'), Object(utils["W" /* theme */])('heatmap.scale_1'), Object(utils["W" /* theme */])('heatmap.scale_2'), Object(utils["W" /* theme */])('heatmap.scale_3'), Object(utils["W" /* theme */])('heatmap.scale_4'), Object(utils["W" /* theme */])('heatmap.scale_5'), Object(utils["W" /* theme */])('heatmap.empty'), Object(utils["W" /* theme */])('editor.content'), Object(utils["W" /* theme */])('editor.content'), Object(utils["W" /* theme */])('editor.content'), Object(utils["W" /* theme */])('comment.mentionText'), Object(utils["W" /* theme */])('comment.mentionTextBg'), Object(utils["W" /* theme */])('comment.mentionActiveBg'), Object(utils["W" /* theme */])('comment.mentionBorder'), Object(utils["W" /* theme */])('comment.mentionBg'), Object(utils["W" /* theme */])('comment.mentionShadow'), Object(utils["W" /* theme */])('comment.mentionActiveBg'), Object(utils["W" /* theme */])('form.inputBg'), Object(utils["W" /* theme */])('form.text'), Object(utils["W" /* theme */])('form.border'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('pagination.itemBg'), Object(utils["W" /* theme */])('pagination.itemBorderColor'), Object(utils["W" /* theme */])('pagination.inactiveNum'), Object(utils["W" /* theme */])('pagination.text'), Object(utils["W" /* theme */])('pagination.disableText'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('pagination.activeNum'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('button.hoverBg'), Object(utils["W" /* theme */])('button.activeBg'), Object(utils["W" /* theme */])('button.fg'), Object(utils["W" /* theme */])('button.primary'), Object(utils["W" /* theme */])('button.primary'), Object(external__polished_["lighten"])(0.1, 'tomato'), Object(external__polished_["lighten"])(0.1, 'tomato'), Object(external__polished_["lighten"])(0.1, 'tomato'), Object(external__polished_["lighten"])(0.1, 'tomato'), Object(external__polished_["lighten"])(0.2, 'tomato'), Object(external__polished_["lighten"])(0.2, 'tomato'), Object(utils["W" /* theme */])('button.clicked'), Object(utils["W" /* theme */])('tabs.headerActive'), Object(utils["W" /* theme */])('tabs.bottomLine'), Object(utils["W" /* theme */])('tabs.headerActive'), Object(utils["W" /* theme */])('tabs.header'), Object(utils["W" /* theme */])('tabs.headerActive'), Object(utils["W" /* theme */])('tabs.headerActive'), Object(utils["W" /* theme */])('tabs.border'), Object(utils["W" /* theme */])('tabs.headerBg'), Object(utils["W" /* theme */])('tabs.border'), Object(utils["W" /* theme */])('tabs.headerActiveTop'), Object(utils["W" /* theme */])('tabs.header'), Object(utils["W" /* theme */])('tabs.contentBg'), Object(utils["W" /* theme */])('tagger.text'), Object(utils["W" /* theme */])('tagger.border'), Object(utils["W" /* theme */])('tagger.bg'), Object(utils["W" /* theme */])('tagger.closeBtn'));
/* harmony default export */ var ThemeWrapper_AntOverWrite = (AntOverWrite);
// CONCATENATED MODULE: ./containers/ThemeWrapper/NormalizeStyle.js
/*
 * use normalize.css to reset global css
 * https://github.com/necolas/normalize.css
 *
 */
// TODO' html background-color
var NormalizeStyle = "\n  html {\n    line-height: 1.15; /* 1 */\n    -ms-text-size-adjust: 100%; /* 2 */\n    -webkit-text-size-adjust: 100%; /* 2 */\n  }\n\n  body {\n    font-size: 14px !important;\n    line-height: 1.5;\n    font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB, Microsoft YaHei, Noto Sans CJK SC, WenQuanYi Micro Hei, Arial, sans-serif;\n  }\n\n  html,body{\n    width: 100%;\n    height: 100%;\n }\n\n  ol, ul {\n    list-style: none;\n  }\n\n  *, *:before, *:after {\n    -moz-box-sizing: border-box;\n    -webkit-box-sizing: border-box;\n    margin:0;\n    padding:0;\n    box-sizing: border-box;\n  }\n\n  article,\n  aside,\n  footer,\n  header,\n  nav,\n  section {\n    display: block;\n  }\n\n  h1 {\n    font-size: 2em;\n    margin: 0.67em 0;\n  }\n\n\n  figcaption,\n  figure,\n  main {\n    display: block;\n  }\n\n  figure {\n    margin: 1em 40px;\n  }\n\n  hr {\n    box-sizing: content-box;\n    height: 0;\n    overflow: visible;\n  }\n\n  pre {\n    font-family: monospace, monospace; /* 1 */\n    font-size: 1em; /* 2 */\n  }\n\n  a {\n    background-color: transparent; /* 1 */\n    -webkit-text-decoration-skip: objects; /* 2 */\n  }\n\n  abbr[title] {\n    border-bottom: none; /* 1 */\n    text-decoration: underline; /* 2 */\n    text-decoration: underline dotted; /* 2 */\n  }\n\n  b,\n  img {\n    border-style: none;\n  }\n\n  svg:not(:root) {\n    overflow: hidden;\n  }\n\n  button,\n  input,\n  optgroup,\n  select,\n  textarea {\n    font-family: sans-serif;\n    font-size: 100%;\n    line-height: 1.15;\n    margin: 0;\n  }\n\n  button,\n  input {\n    overflow: visible;\n  }\n\n  button,\n  select {\n    text-transform: none;\n  }\n\n  button,\n  html [type=\"button\"],\n  [type=\"reset\"],\n  [type=\"submit\"] {\n    -webkit-appearance: button;\n  }\n\n  button::-moz-focus-inner,\n  [type=\"button\"]::-moz-focus-inner,\n  [type=\"reset\"]::-moz-focus-inner,\n  [type=\"submit\"]::-moz-focus-inner {\n    border-style: none;\n    padding: 0;\n  }\n\n  button:-moz-focusring,\n  [type=\"button\"]:-moz-focusring,\n  [type=\"reset\"]:-moz-focusring,\n  [type=\"submit\"]:-moz-focusring {\n    outline: 1px dotted ButtonText;\n  }\n\n  textarea {\n    overflow: auto;\n  }\n\n  [type=\"checkbox\"],\n  [type=\"radio\"] {\n    box-sizing: border-box;\n    padding: 0;\n  }\n\n  [type=\"number\"]::-webkit-inner-spin-button,\n  [type=\"number\"]::-webkit-outer-spin-button {\n    height: auto;\n  }\n\n  [type=\"search\"] {\n    -webkit-appearance: textfield;\n    outline-offset: -2px;\n  }\n\n  [type=\"search\"]::-webkit-search-cancel-button,\n  [type=\"search\"]::-webkit-search-decoration {\n    -webkit-appearance: none;\n  }\n\n  ::-webkit-file-upload-button {\n    -webkit-appearance: button; /* 1 */\n    font: inherit; /* 2 */\n  }\n\n  canvas {\n    display: inline-block;\n  }\n\n  [hidden] {\n    display: none;\n  }\n\n  body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,code,form,fieldset,legend,input,textarea,p,blockquote,th,td,hr,button,article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section {\n    margin: 0;\n    padding: 0;\n  }\n  abbr[title] {\n    border-bottom: none;\n    text-decoration: underline;\n    text-decoration: underline dotted;\n  }\n";
/* harmony default export */ var ThemeWrapper_NormalizeStyle = (NormalizeStyle);
// CONCATENATED MODULE: ./containers/ThemeWrapper/CodeHighlight.js


/*
   Solarized Color Schemes originally by Ethan Schoonover
   http://ethanschoonover.com/solarized

   Ported for PrismJS by Hector Matos
   Website: https://krakendev.io
   Twitter Handle: https://twitter.com/allonsykraken)
 */

/*
   SOLARIZED HEX
   --------- -------
   base03    #002b36
   base02    #073642
   base01    #586e75
   base00    #657b83
   base0     #839496
   base1     #93a1a1
   base2     #eee8d5
   base3     #fdf6e3
   yellow    #b58900
   orange    #cb4b16
   red       #dc322f
   magenta   #d33682
   violet    #6c71c4
   blue      #268bd2
   cyan      #2aa198
   green     #859900
 */

var CodeHighlight =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "CodeHighlight",
  componentId: "s1trxy9e-0"
})(["code[class*='language-'],pre[class*='language-']{color:#657b83;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;-moz-tab-size:4;-o-tab-size:4;tab-size:4;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none;}pre[class*='language-']::-moz-selection,pre[class*='language-']::-moz-selection,code[class*='language-']::-moz-selection,code[class*='language-']::-moz-selection{background:#073642;}pre[class*='language-']::selection,pre[class*='language-']::selection,code[class*='language-']::selection,code[class*='language-']::selection{background:#073642;}pre[class*='language-']{padding:1em;margin:0.5em 0;overflow:auto;border-radius:0.3em;}:not(pre) > code[class*='language-'],pre[class*='language-']{background-color:", ";}:not(pre) > code[class*='language-']{padding:0.1em;border-radius:0.3em;}.token.comment,.token.prolog,.token.doctype,.token.cdata{color:#93a1a1;}.token.punctuation{color:#586e75;}.namespace{opacity:0.7;}.token.property,.token.tag,.token.boolean,.token.number,.token.constant,.token.symbol,.token.deleted{color:#268bd2;}.token.selector,.token.attr-name,.token.string,.token.char,.token.builtin,.token.url,.token.inserted{color:#2aa198;}.token.entity{color:#657b83;background:#eee8d5;}.token.atrule,.token.attr-value,.token.keyword{color:#859900;}.token.function{color:#b58900;}.token.regex,.token.important,.token.variable{color:#cb4b16;}.token.important,.token.bold{font-weight:bold;}.token.italic{font-style:italic;}.token.entity{cursor:help;}"], Object(utils["W" /* theme */])('code.bg'));
/* harmony default export */ var ThemeWrapper_CodeHighlight = (CodeHighlight);
// CONCATENATED MODULE: ./containers/ThemeWrapper/index.js


/*
 * make children compoent cound reach the props.theme object
 * because mobx's observer mechanism, we should manually watch the theme
 * otherwhise the render will not be triggled
*/





 // import MarkDownStyle from './MarkDownStyle'

 // TODO: mv MarkDownStyle && CodeHighlight to it's own container

var ThemeWrapper_ThemeObserver = function ThemeObserver(_ref) {
  var children = _ref.children,
      theme = _ref.theme;
  return external__react__default.a.createElement(external__styled_components_["ThemeProvider"], {
    theme: theme.themeData
  }, external__react__default.a.createElement(ThemeWrapper_AntOverWrite, null, external__react__default.a.createElement(ThemeWrapper_CodeHighlight, null, external__react__default.a.createElement(style__default.a, {
    styleId: ThemeWrapper_NormalizeStyle.__hash,
    css: ThemeWrapper_NormalizeStyle
  }), external__react__default.a.createElement(style__default.a, {
    styleId: "2429496428",
    css: ["html{background-color:".concat(theme.themeData.htmlBg, ";}"), "*::-moz-selection{background-color:".concat(theme.themeData.selectionBg, " !important;}"), "*::selection{background-color:".concat(theme.themeData.selectionBg, " !important;}"), "a:hover{color:".concat(theme.themeData.a.hover, ";}"), "a:active{color:".concat(theme.themeData.a.active, ";}")],
    dynamic: [theme.themeData.htmlBg, theme.themeData.selectionBg, theme.themeData.selectionBg, theme.themeData.a.hover, theme.themeData.a.active]
  }), external__react__default.a.createElement("div", {
    className: style__default.a.dynamic([["2429496428", [theme.themeData.htmlBg, theme.themeData.selectionBg, theme.themeData.selectionBg, theme.themeData.a.hover, theme.themeData.a.active]]])
  }, children))));
};

/* harmony default export */ var ThemeWrapper = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('theme'))(Object(external__mobx_react_["observer"])(ThemeWrapper_ThemeObserver)));

/***/ }),
/* 85 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_intl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_intl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utils__ = __webpack_require__(0);
/*
 * because mobx's observer mechanism, we should manually watch the langs
 * otherwhise the render will not be triggled
 */




var selector = function selector(_ref) {
  var store = _ref.store;
  return {
    locale: store.locale,
    messages: store.langMessages
  };
};

var IntlObserver = Object(__WEBPACK_IMPORTED_MODULE_2__utils__["M" /* observerHoc */])(selector, function (_ref2) {
  var children = _ref2.children,
      locale = _ref2.locale,
      messages = _ref2.messages;
  return (// key is important, see https://github.com/yahoo/react-intl/issues/234
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_react_intl__["IntlProvider"], {
      key: locale,
      locale: locale,
      messages: messages
    }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", null, children))
  );
});
/* harmony default export */ __webpack_exports__["a"] = (IntlObserver);

/***/ }),
/* 86 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(36);
var router__default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "ramda/src/contains"
var contains_ = __webpack_require__(17);
var contains__default = /*#__PURE__*/__webpack_require__.n(contains_);

// CONCATENATED MODULE: ./containers/Route/logic.js


/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:Route');
/* eslint-enable no-unused-vars */

Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].COMMUNITY_CHANGE);
var store = null;
function routeChange() {
  if (utils["N" /* onClient */]) {
    var browserMainPath = Object(utils["z" /* getMainPath */])({
      asPath: utils["h" /* Global */].location.pathname
    });
    var browserSubPath = Object(utils["A" /* getSubPath */])({
      asPath: utils["h" /* Global */].location.pathname
    });
    var notCommunityPage = ['user', 'post', 'job'];
    /*
       debug('browserMainPath -> ', browserMainPath)
       debug('browserSubPath -> ', browserSubPath)
        debug('store.mainPath: ', store.mainPath)
       debug('store.subPath: ', store.subPath)
     */

    var pathChange = store.mainPath !== browserMainPath || store.subPath !== browserSubPath;

    if (pathChange) {
      store.markState({
        mainPath: browserMainPath,
        subPath: browserSubPath
      });
      if (!contains__default()(browserMainPath, notCommunityPage)) return Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].COMMUNITY_CHANGE);
    }
  }
}
function init(_store, routeObj) {
  if (store) return false;
  store = _store; // sync init router info

  var mainPath = Object(utils["z" /* getMainPath */])(routeObj);
  var subPath = Object(utils["A" /* getSubPath */])(routeObj);
  var query = routeObj.query;
  store.markState({
    mainPath: mainPath,
    subPath: subPath,
    query: query
  });
}
// CONCATENATED MODULE: ./containers/Route/index.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * Route
 *
 */


 // import Link from 'next/link'



/* eslint-disable no-unused-vars */

var Route_debug = Object(utils["G" /* makeDebugger */])('C:Route');
/* eslint-enable no-unused-vars */

var Route_RouteContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(RouteContainer, _React$Component);

  function RouteContainer() {
    _classCallCheck(this, RouteContainer);

    return _possibleConstructorReturn(this, (RouteContainer.__proto__ || Object.getPrototypeOf(RouteContainer)).apply(this, arguments));
  }

  _createClass(RouteContainer, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this = this;

      var _props = this.props,
          route = _props.route,
          router = _props.router;
      init(route, router);

      router__default.a.onRouteChangeComplete = function () {
        var route = _this.props.route;
        routeChange(route);
      };
    }
  }, {
    key: "render",
    value: function render() {
      return external__react__default.a.createElement("div", null);
    }
  }]);

  return RouteContainer;
}(external__react__default.a.Component);

/* harmony default export */ var Route = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('route'))(Object(external__mobx_react_["observer"])(Object(router_["withRouter"])(Route_RouteContainer))));

/***/ }),
/* 87 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "react-keydown"
var external__react_keydown_ = __webpack_require__(45);
var external__react_keydown__default = /*#__PURE__*/__webpack_require__.n(external__react_keydown_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./containers/BodyLayout/styles/index.js

 // transition: background-color 0.2s;

var Body =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Body",
  componentId: "s9q3nd9-0"
})(["padding-left:56px;position:relative;height:100%;min-height:100vh;background:", ";display:flex;flex-direction:column;margin-left:", ";transition:all 0.2s;overflow-x:", ";"], Object(utils["W" /* theme */])('bodyBg'), function (_ref) {
  var sidebarPin = _ref.sidebarPin;
  return sidebarPin ? '180px' : '0';
}, function (_ref2) {
  var sidebarPin = _ref2.sidebarPin;
  return sidebarPin ? 'hidden' : '';
});
/* overflow-x: hidden; */

/* harmony default export */ var styles = (Body);
// CONCATENATED MODULE: ./containers/BodyLayout/logic.js

/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:BodyLayout');
/* eslint-enable no-unused-vars */

var store = null;
function logic_openDoraemon() {
  store.openDoraemon();
}
function init(_store) {
  if (store) return false;
  store = _store;
}
// CONCATENATED MODULE: ./containers/BodyLayout/index.js
var _dec, _desc, _value, _class;

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
  var desc = {};
  Object['ke' + 'ys'](descriptor).forEach(function (key) {
    desc[key] = descriptor[key];
  });
  desc.enumerable = !!desc.enumerable;
  desc.configurable = !!desc.configurable;

  if ('value' in desc || desc.initializer) {
    desc.writable = true;
  }

  desc = decorators.slice().reverse().reduce(function (desc, decorator) {
    return decorator(target, property, desc) || desc;
  }, desc);

  if (context && desc.initializer !== void 0) {
    desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
    desc.initializer = undefined;
  }

  if (desc.initializer === void 0) {
    Object['define' + 'Property'](target, property, desc);
    desc = null;
  }

  return desc;
}

/*
*
* BodyLayout
*
*/



 // import Link from 'next/link'




var BodyLayout_BodyLayoutContainer = (_dec = external__react_keydown__default()(['ctrl+p']), (_class =
/*#__PURE__*/
function (_React$Component) {
  _inherits(BodyLayoutContainer, _React$Component);

  function BodyLayoutContainer() {
    _classCallCheck(this, BodyLayoutContainer);

    return _possibleConstructorReturn(this, (BodyLayoutContainer.__proto__ || Object.getPrototypeOf(BodyLayoutContainer)).apply(this, arguments));
  }

  _createClass(BodyLayoutContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var bodylayout = this.props.bodylayout;
      init(bodylayout);
    }
    /* eslint-disable class-methods-use-this */

  }, {
    key: "openDoraemon",
    value: function openDoraemon() {
      // debug('openDoraemon')
      logic_openDoraemon();
    }
    /* eslint-enable class-methods-use-this */

  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          sidebarPin = _props.bodylayout.sidebarPin,
          children = _props.children;
      return external__react__default.a.createElement(styles, {
        sidebarPin: sidebarPin
      }, children);
    }
  }]);

  return BodyLayoutContainer;
}(external__react__default.a.Component), (_applyDecoratedDescriptor(_class.prototype, "openDoraemon", [_dec], Object.getOwnPropertyDescriptor(_class.prototype, "openDoraemon"), _class.prototype)), _class));
BodyLayout_BodyLayoutContainer.defaultProps = {
  children: external__react__default.a.createElement("div", null)
};
/* harmony default export */ var BodyLayout = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('bodylayout'))(Object(external__mobx_react_["observer"])(BodyLayout_BodyLayoutContainer)));

/***/ }),
/* 88 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "react-keydown"
var external__react_keydown_ = __webpack_require__(45);
var external__react_keydown__default = /*#__PURE__*/__webpack_require__.n(external__react_keydown_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// EXTERNAL MODULE: ./config/assets.js
var assets = __webpack_require__(32);

// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./containers/Header/styles/index.js



var HeaderWrapper =
/*#__PURE__*/
external__styled_components__default.a.header.withConfig({
  displayName: "styles__HeaderWrapper",
  componentId: "m50mcu-0"
})(["height:33px;display:flex;flex-direction:row;background:", ";border-bottom:1px solid;border-bottom-color:", ";align-items:center;padding:0 4vw;margin-left:", ";transition:all 0.2s;box-shadow:", ";"], function (_ref) {
  var fixed = _ref.fixed;
  return fixed ? Object(utils["W" /* theme */])('header.fixed') : Object(utils["W" /* theme */])('header.bg');
}, Object(utils["W" /* theme */])('header.spliter'), function (_ref2) {
  var leftOffset = _ref2.leftOffset;
  return leftOffset;
}, Object(utils["W" /* theme */])('preview.shadow')); // box-shadow: 0 0 4px rgba(0, 0, 0, 0.14), 0 4px 8px rgba(234, 234, 234, 0.28);
// margin-left: ${props => (props.offsetLeft ? '180px' : '0')};

var RouterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RouterWrapper",
  componentId: "m50mcu-1"
})(["flex-grow:1;display:flex;height:100%;margin-top:1px;"]);
var MiniMapWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MiniMapWrapper",
  componentId: "m50mcu-2"
})(["display:flex;align-items:flex-end;margin-left:4vw;"]);
var CommunityLogo =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__CommunityLogo",
  componentId: "m50mcu-3"
})(["width:26px;height:26px;margin-right:25px;display:block;margin-bottom:2px;"]);
/*
   border-bottom: 2px solid;
   border-bottom-color: ${props =>
   props.active ? theme('thread.articleTitle') : theme('header.fixed')};
 */
// ${theme('thread.articleTitle', props)}
// border-bottom: ${props => (props.active ? '2px solid tomato' : '')};

var MiniTab =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MiniTab",
  componentId: "m50mcu-4"
})(["border-bottom:", ";border-bottom-color:", ";padding-bottom:", ";padding-right:5px;padding-left:5px;margin-right:6px;color:", ";cursor:pointer;"], function (_ref3) {
  var active = _ref3.active;
  return active ? '3px solid' : '';
}, function (_ref4) {
  var active = _ref4.active;
  return active ? Object(utils["W" /* theme */])('thread.articleTitle') : '';
}, function (_ref5) {
  var active = _ref5.active;
  return active ? '2px' : '5px';
}, function (_ref6) {
  var active = _ref6.active;
  return active ? Object(utils["W" /* theme */])('header.tabActive') : Object(utils["W" /* theme */])('header.tabOthers');
});
var Admin =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Admin",
  componentId: "m50mcu-5"
})(["display:flex;flex-direction:column;justify-content:center;"]);
var DividerIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__DividerIcon",
  componentId: "m50mcu-6"
})(["fill:", ";width:18px;height:20px;margin-top:2px;margin-left:3px;margin-right:3px;"], Object(utils["W" /* theme */])('header.fg'));
var StateButton =
/*#__PURE__*/
external__styled_components__default()(components["d" /* Button */]).withConfig({
  displayName: "styles__StateButton",
  componentId: "m50mcu-7"
})(["width:80px;display:flex;"]);
var StateIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__StateIcon",
  componentId: "m50mcu-8"
})(["width:12px;height:100%;cursor:pointer;margin-right:8px;margin-top:2px;"]);
var HeaderIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__HeaderIcon",
  componentId: "m50mcu-9"
})(["fill:", ";width:20px;height:20px;cursor:pointer;margin-top:2px;margin-right:12px;"], Object(utils["W" /* theme */])('header.fg'));
var UserAvatar =
/*#__PURE__*/
external__styled_components__default.a.img.withConfig({
  displayName: "styles__UserAvatar",
  componentId: "m50mcu-10"
})(["width:20px;height:20px;cursor:pointer;margin-right:12px;border-radius:3px;opacity:", ";"], Object(utils["W" /* theme */])('avatarOpacity'));
var Operations =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Operations",
  componentId: "m50mcu-11"
})(["display:flex;"]);
var Search =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Search",
  componentId: "m50mcu-12"
})(["color:", ";"], Object(utils["W" /* theme */])('header.fg'));
var Notification =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Notification",
  componentId: "m50mcu-13"
})([""]);
var User =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__User",
  componentId: "m50mcu-14"
})(["margin-right:20px;"]);
var AffixHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__AffixHeader",
  componentId: "m50mcu-15"
})(["display:", ";"], function (_ref7) {
  var fixed = _ref7.fixed;
  return fixed ? 'block' : 'none';
});
var RawHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RawHeader",
  componentId: "m50mcu-16"
})(["display:", ";"], function (_ref8) {
  var fixed = _ref8.fixed;
  return !fixed ? 'block' : 'none';
}); // animation: ${Animate.fadeInRight} 0.2s linear;
// EXTERNAL MODULE: ./utils/network/sr71.js + 3 modules
var sr71 = __webpack_require__(8);

// EXTERNAL MODULE: external "graphql-tag"
var external__graphql_tag_ = __webpack_require__(11);
var external__graphql_tag__default = /*#__PURE__*/__webpack_require__.n(external__graphql_tag_);

// CONCATENATED MODULE: ./containers/Header/schema.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  mutation($code: String!) {\n    githubSignin(code: $code) {\n      token\n      user {\n        nickname\n        bio\n      }\n    }\n  }\n"]),
    _templateObject2 = /*#__PURE__*/ _taggedTemplateLiteral(["\n  query user($id: ID!) {\n    user(id: $id) {\n      id\n      nickname\n      avatar\n      bio\n      fromGithub\n      company\n      education\n      location\n      qq\n      weibo\n      weichat\n      sex\n      githubProfile {\n        htmlUrl\n        login\n      }\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var githubSigninRes = 'githubSignin';
var githubSignin = external__graphql_tag__default()(_templateObject);
var schema_user = external__graphql_tag__default()(_templateObject2);
var schema = {
  user: schema_user,
  githubSignin: githubSignin,
  githubSigninRes: githubSigninRes
};
/* harmony default export */ var Header_schema = (schema);
// CONCATENATED MODULE: ./containers/Header/logic.js
// import R from 'ramda'

 // import sr71$ from '../../utils/network/sr71_simple'


var sr71$ = new sr71["a" /* default */]();
/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:Header');
/* eslint-enable no-unused-vars */

var store = null;
var sub$ = null;
/* const sub$ = null */

/* const user_token = */

function previewState() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW, {
    type: utils["k" /* TYPE */].PREVIEW_ROOT_STORE
  });
}
function signinGithub(code) {
  debug('signin_github: ', code);
  var args = {
    code: code
  };
  sr71$.mutate(Header_schema.githubSignin, args);
}
function checkUserAccount() {
  // debug('checkUserAccount: to get user breif')
  var user = utils["c" /* BStore */].get('user');

  if (user) {
    // NOTICE: if store is not valid json, user will be typeof string
    sr71$.query(Header_schema.user, {
      id: user.id
    });
  } else {// not shoe
  }
}
function previewAccount() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW, {
    type: utils["k" /* TYPE */].PREVIEW_ACCOUNT_VIEW,
    data: {
      hello: 'world --- fuck'
    }
  });
}
function onThreadChange(thread) {
  var activeThread = thread.raw;
  /* store.markRoute({ community, thread: thread2Subpath(activeThread) }) */

  store.markRoute({
    subPath: Object(utils["_1" /* thread2Subpath */])(activeThread)
  });
  store.setViewing({
    activeThread: activeThread
  });
}
function login() {
  debug('do login');
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].LOGIN_PANEL);
}
function openPreview() {
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW, {
    type: utils["k" /* TYPE */].PREVIEW_ACCOUNT_VIEW,
    data: {
      hello: 'world'
    }
  });
}
function logic_openDoraemon() {
  store.openDoraemon();
}
var DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('user'),
  action: function action(_ref) {
    var user = _ref.user;
    return store.updateAccount(user);
  }
}, {
  // TODO move it to user side view
  match: Object(utils["n" /* asyncRes */])('githubSigninRes'),
  action: function action(_ref2) {
    var githubSigninRes = _ref2.githubSigninRes;
    debug('dataResolver  --->', githubSigninRes);
  }
}, {
  match: Object(utils["n" /* asyncRes */])('user'),
  action: function action(_ref3) {
    var user = _ref3.user;
    debug('dataResolver userRes  --->', user);
    store.updateAccount(user);
  }
}];
var ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref4) {
    var details = _ref4.details;
    debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref5) {
    var details = _ref5.details;
    debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref6) {
    var details = _ref6.details;
    debug('ERR.NETWORK -->', details);
  }
}];
function init(_store) {
  if (store) return false;
  store = _store; // if (sub$) sub$.unsubscribe()

  /* sub$ = sr71$.data().subscribe(handleData) */
  // sub$ = sr71$.data().subscribe($solver(DataSolver, ErrSolver))

  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(utils["a" /* $solver */])(DataSolver, ErrSolver));
  checkUserAccount();
}
// CONCATENATED MODULE: ./containers/Header/index.js
var _this = this,
    _dec,
    _desc,
    _value,
    _class;

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
  var desc = {};
  Object['ke' + 'ys'](descriptor).forEach(function (key) {
    desc[key] = descriptor[key];
  });
  desc.enumerable = !!desc.enumerable;
  desc.configurable = !!desc.configurable;

  if ('value' in desc || desc.initializer) {
    desc.writable = true;
  }

  desc = decorators.slice().reverse().reduce(function (desc, decorator) {
    return decorator(target, property, desc) || desc;
  }, desc);

  if (context && desc.initializer !== void 0) {
    desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
    desc.initializer = undefined;
  }

  if (desc.initializer === void 0) {
    Object['define' + 'Property'](target, property, desc);
    desc = null;
  }

  return desc;
}

/*
 *
 * Header
 *
 */









/* eslint-disable no-unused-vars */

var Header_debug = Object(utils["G" /* makeDebugger */])('C:Header');
/* eslint-enable no-unused-vars */

var Header_MiniMap = function MiniMap(_ref) {
  var _ref$activeInfo = _ref.activeInfo,
      community = _ref$activeInfo.community,
      activeThread = _ref$activeInfo.activeThread;
  return external__react__default.a.createElement(MiniMapWrapper, null, external__react__default.a.createElement(CommunityLogo, {
    src: community.logo
  }), external__react__default.a.createElement(external__react__default.a.Fragment, null, community.threads.map(function (t) {
    return external__react__default.a.createElement(MiniTab, {
      key: external__shortid__default.a.generate(),
      active: t.raw === activeThread,
      onClick: onThreadChange.bind(_this, t)
    }, Object(utils["l" /* Trans */])(t.title));
  })));
};

var Header_Header = function Header(_ref2) {
  var activeInfo = _ref2.activeInfo,
      curRoute = _ref2.curRoute,
      leftOffset = _ref2.leftOffset,
      fixed = _ref2.fixed,
      isLogin = _ref2.isLogin,
      accountInfo = _ref2.accountInfo;
  return external__react__default.a.createElement(HeaderWrapper, {
    id: "whereCallShowDoraemon",
    leftOffset: leftOffset,
    fixed: fixed
  }, external__react__default.a.createElement(RouterWrapper, null, fixed ? external__react__default.a.createElement(Header_MiniMap, {
    activeInfo: activeInfo,
    curRoute: curRoute
  }) : external__react__default.a.createElement(components["p" /* Navigator */], null)), external__react__default.a.createElement(Admin, null, external__react__default.a.createElement("div", {
    style: {
      display: 'flex'
    }
  }, external__react__default.a.createElement(StateButton, {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: previewState.bind(_this, 'mst-state')
  }, external__react__default.a.createElement(StateIcon, {
    src: "".concat(assets["c" /* ICON_ASSETS */], "/cmd/header_state.svg")
  }), external__react__default.a.createElement("div", null, "STATE")), external__react__default.a.createElement(DividerIcon, {
    src: "".concat(assets["c" /* ICON_ASSETS */], "/cmd/more.svg")
  }))), external__react__default.a.createElement(Operations, null, external__react__default.a.createElement(Search, {
    onClick: logic_openDoraemon
  }, external__react__default.a.createElement(HeaderIcon, {
    src: "".concat(assets["c" /* ICON_ASSETS */], "/cmd/search2.svg")
  })), external__react__default.a.createElement(Notification, {
    onClick: openPreview.bind(_this, 'post')
  }, external__react__default.a.createElement(HeaderIcon, {
    src: "".concat(assets["c" /* ICON_ASSETS */], "/cmd/notification_none.svg")
  })), isLogin ? external__react__default.a.createElement(User, {
    onClick: previewAccount.bind(_this, 'account')
  }, external__react__default.a.createElement(UserAvatar, {
    src: accountInfo.avatar
  })) : external__react__default.a.createElement(User, {
    onClick: login
  }, external__react__default.a.createElement(HeaderIcon, {
    src: "".concat(assets["c" /* ICON_ASSETS */], "/cmd/header_user.svg")
  }))));
};

var Header_HeaderContainer = (_dec = external__react_keydown__default()(['ctrl+p']), (_class =
/*#__PURE__*/
function (_React$Component) {
  _inherits(HeaderContainer, _React$Component);

  function HeaderContainer() {
    _classCallCheck(this, HeaderContainer);

    return _possibleConstructorReturn(this, (HeaderContainer.__proto__ || Object.getPrototypeOf(HeaderContainer)).apply(this, arguments));
  }

  _createClass(HeaderContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var header = this.props.header;
      init(header);
    }
    /* eslint-disable class-methods-use-this */

  }, {
    key: "openDoraemon",
    value: function openDoraemon() {
      // debug('openDoraemon')
      logic_openDoraemon();
    }
    /* eslint-enable class-methods-use-this */

  }, {
    key: "render",
    value: function render() {
      var header = this.props.header;
      var fixed = header.fixed,
          curRoute = header.curRoute,
          leftOffset = header.leftOffset,
          accountInfo = header.accountInfo,
          isLogin = header.isLogin,
          activeInfo = header.activeInfo;
      return external__react__default.a.createElement("div", {
        id: utils["k" /* TYPE */].APP_HEADER_ID
      }, external__react__default.a.createElement(AffixHeader, {
        fixed: fixed
      }, external__react__default.a.createElement(components["b" /* Affix */], null, external__react__default.a.createElement(Header_Header, {
        fixed: fixed,
        curRoute: curRoute,
        leftOffset: leftOffset,
        accountInfo: accountInfo,
        isLogin: isLogin,
        activeInfo: activeInfo
      }))), external__react__default.a.createElement(RawHeader, {
        fixed: fixed
      }, external__react__default.a.createElement(Header_Header, {
        fixed: fixed,
        curRoute: curRoute,
        leftOffset: leftOffset,
        accountInfo: accountInfo,
        isLogin: isLogin,
        activeInfo: activeInfo
      })));
    }
  }]);

  return HeaderContainer;
}(external__react__default.a.Component), (_applyDecoratedDescriptor(_class.prototype, "openDoraemon", [_dec], Object.getOwnPropertyDescriptor(_class.prototype, "openDoraemon"), _class.prototype)), _class));
/* harmony default export */ var containers_Header = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('header'))(Object(external__mobx_react_["observer"])(Header_HeaderContainer)));

/***/ }),
/* 89 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./containers/Banner/styles/cheatsheet_root_banner.js


var CheatsheetBanner =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "cheatsheet_root_banner__CheatsheetBanner",
  componentId: "s1g3he9z-0"
})(["position:relative;min-height:140px;border-bottom:1px solid tomato;display:flex;flex-direction:column;justify-content:center;background:", ";border-bottom:", ";@media (max-height:800px){min-height:130px;}background-image:linear-gradient(white 2px,transparent 2px),linear-gradient(90deg,white 2px,transparent 2px),linear-gradient(rgba(255,255,255,0.3) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.3) 1px,transparent 1px);background-size:100px 100px,100px 100px,20px 20px,20px 20px;background-position:-2px -2px,-2px -2px,-1px -1px,-1px -1px;"], Object(utils["W" /* theme */])('banner.bg'), Object(utils["W" /* theme */])('banner.spliter'));
var CheatsheetWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "cheatsheet_root_banner__CheatsheetWrapper",
  componentId: "s1g3he9z-1"
})(["display:flex;flex-direction:column;align-items:center;"]);
var CheatsheetTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "cheatsheet_root_banner__CheatsheetTitle",
  componentId: "s1g3he9z-2"
})(["font-size:2em;font-weight:bold;color:", ";"], Object(utils["W" /* theme */])('thread.articleTitle'));
var CheatsheetDesc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "cheatsheet_root_banner__CheatsheetDesc",
  componentId: "s1g3he9z-3"
})(["font-size:1.3em;margin-top:5px;color:", ";"], Object(utils["W" /* theme */])('thread.articleDigest'));
// CONCATENATED MODULE: ./containers/Banner/CheatsheetRootBanner.js



var CheatsheetRootBanner_CheatsheetRootBanner = function CheatsheetRootBanner() {
  return external__react__default.a.createElement(CheatsheetBanner, null, external__react__default.a.createElement(CheatsheetWrapper, null, external__react__default.a.createElement(CheatsheetTitle, null, "cheatsheet"), external__react__default.a.createElement(CheatsheetDesc, null, "TODO: \u8FD9\u91CC\u5E94\u8BE5\u662F\u4E00\u4E2A\u641C\u7D22\u6846")));
};

/* harmony default export */ var Banner_CheatsheetRootBanner = (CheatsheetRootBanner_CheatsheetRootBanner);
// EXTERNAL MODULE: external "ramda/src/range"
var range_ = __webpack_require__(26);
var range__default = /*#__PURE__*/__webpack_require__.n(range_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// CONCATENATED MODULE: ./containers/Banner/styles/index.js


var BaseBanner =
/*#__PURE__*/
external__styled_components__default.a.nav.withConfig({
  displayName: "styles__BaseBanner",
  componentId: "s34mg0d-0"
})(["position:relative;min-height:140px;border-bottom:1px solid tomato;display:flex;flex-direction:column;justify-content:center;background:", ";border-bottom:1px solid;border-bottom-color:", ";@media (max-height:800px){min-height:130px;}"], Object(utils["W" /* theme */])('banner.bg'), Object(utils["W" /* theme */])('banner.spliter'));
var BaseBannerContent =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseBannerContent",
  componentId: "s34mg0d-1"
})(["display:flex;margin-left:8%;margin-right:8%;"]);
var BaseTabber =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseTabber",
  componentId: "s34mg0d-2"
})(["position:absolute;bottom:-16px;width:80vw;display:flex;"]);
var NumbersWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumbersWrapper",
  componentId: "s34mg0d-3"
})(["display:flex;text-align:center;margin-top:-2rem;"]);
var NumberSection =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberSection",
  componentId: "s34mg0d-4"
})(["display:flex;flex-direction:column;justify-content:center;padding:0 5px;border-radius:4px;&:hover{background:", ";cursor:", ";}"], function (_ref) {
  var dead = _ref.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.numberHoverBg');
}, function (_ref2) {
  var dead = _ref2.dead;
  return dead ? '' : 'pointer';
});
var NumberTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberTitle",
  componentId: "s34mg0d-5"
})(["color:", ";&:hover{color:", ";text-decoration:", ";animation:", " 0.4s linear;}"], Object(utils["W" /* theme */])('banner.numberDesc'), function (_ref3) {
  var dead = _ref3.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.active');
}, function (_ref4) {
  var dead = _ref4.dead;
  return dead ? '' : 'underline';
}, utils["b" /* Animate */].pulse);
var NumberItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberItem",
  componentId: "s34mg0d-6"
})(["font-size:1.5rem;color:", ";&:hover{color:", ";text-decoration:", ";animation:", " 0.4s linear;}"], Object(utils["W" /* theme */])('banner.number'), function (_ref5) {
  var dead = _ref5.dead;
  return dead ? '' : Object(utils["W" /* theme */])('banner.active');
}, function (_ref6) {
  var dead = _ref6.dead;
  return dead ? '' : 'underline';
}, utils["b" /* Animate */].pulse);
var NumberDivider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__NumberDivider",
  componentId: "s34mg0d-7"
})(["border:1px solid;border-color:", ";height:70%;align-self:center;margin-left:10px;margin-right:10px;"], Object(utils["W" /* theme */])('banner.numberDivider'));
// CONCATENATED MODULE: ./containers/Banner/styles/activities_root_banner.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral([""]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }





var activities_root_banner_BannerContainer = BaseBanner.extend(_templateObject);
var BannerContentWrapper = BaseBannerContent.extend(_templateObject);
var MonthWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "activities_root_banner__MonthWrapper",
  componentId: "s2m2y5a-0"
})(["", ";color:#56868a;"], utils["q" /* columnCenter */]);
var MonthNumber =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "activities_root_banner__MonthNumber",
  componentId: "s2m2y5a-1"
})(["font-size:1.8em;"]);
var UpIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "activities_root_banner__UpIcon",
  componentId: "s2m2y5a-2"
})(["fill:#6b8688;width:30px;height:30px;", ";"], utils["S" /* smokey */]);
var DaysWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "activities_root_banner__DaysWrapper",
  componentId: "s2m2y5a-3"
})(["display:flex;align-self:center;margin-left:20px;"]);
var DayBlock =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "activities_root_banner__DayBlock",
  componentId: "s2m2y5a-4"
})(["margin-right:", ";background:", ";font-size:", ";position:relative;align-self:center;border:1px solid lightgrey;padding:0 5px;border-radius:100%;&:hover{background:white;cursor:pointer;}"], function (_ref) {
  var day = _ref.day;
  return day % 5 === 0 ? '10px' : '5px';
}, function (_ref2) {
  var day = _ref2.day;
  return day % 5 === 0 ? 'white' : '';
}, function (_ref3) {
  var day = _ref3.day;
  return day % 5 === 0 ? '1.6em' : '0.9em';
});
var DayWeek =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "activities_root_banner__DayWeek",
  componentId: "s2m2y5a-5"
})(["position:absolute;width:50px;top:-30px;left:-5px;font-size:0.8em;color:#95acad;display:", ";", ":hover &{display:block;}"], function (_ref4) {
  var day = _ref4.day;
  return day % 5 === 0 ? 'block' : 'none';
}, DayBlock);
var DayNumber =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "activities_root_banner__DayNumber",
  componentId: "s2m2y5a-6"
})(["color:#95acad;"]);
// CONCATENATED MODULE: ./containers/Banner/ActivitiesRootBanner.js






var ActivitiesRootBanner_MonthSelector = function MonthSelector() {
  return external__react__default.a.createElement(MonthWrapper, null, external__react__default.a.createElement(UpIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/up.svg")
  }), external__react__default.a.createElement(MonthNumber, null, "7\u6708"), external__react__default.a.createElement(UpIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/up.svg"),
    reverse: true
  }));
};

var days = range__default()(1, 32);

var ActivitiesRootBanner_DaysSelector = function DaysSelector() {
  return external__react__default.a.createElement(DaysWrapper, null, days.map(function (day) {
    return external__react__default.a.createElement(DayBlock, {
      key: external__shortid__default.a.generate(),
      day: day
    }, external__react__default.a.createElement(DayWeek, {
      day: day
    }, "\u5468\u51E0"), external__react__default.a.createElement(DayNumber, null, day));
  }));
};

var ActivitiesRootBanner_ActivitiesRootBanner = function ActivitiesRootBanner() {
  return external__react__default.a.createElement(activities_root_banner_BannerContainer, null, external__react__default.a.createElement(BannerContentWrapper, null, external__react__default.a.createElement(ActivitiesRootBanner_MonthSelector, null), external__react__default.a.createElement(ActivitiesRootBanner_DaysSelector, null)));
};

/* harmony default export */ var Banner_ActivitiesRootBanner = (ActivitiesRootBanner_ActivitiesRootBanner);
// EXTERNAL MODULE: ./containers/index.js + 91 modules
var containers = __webpack_require__(28);

// CONCATENATED MODULE: ./containers/Banner/logic.js
var store = null;

var init = function init(_store) {
  if (store) return false;
  store = _store;
};

/* harmony default export */ var logic = (init);
// CONCATENATED MODULE: ./containers/Banner/index.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * Banner
 *
 */




/* import CommunityBanner from './CommunityBanner' */




/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('C:Banner');
/* eslint-enable no-unused-vars */

var Banner_BannerContent = function BannerContent(_ref) {
  var curRoute = _ref.curRoute;
  var mainPath = curRoute.mainPath;

  switch (mainPath) {
    case utils["i" /* ROUTE */].CHEATSHEETS:
      {
        return external__react__default.a.createElement(Banner_CheatsheetRootBanner, null);
      }

    case utils["i" /* ROUTE */].COMMUNITIES:
      {
        return external__react__default.a.createElement(containers["g" /* CommunitiesBanner */], null);
      }

    case utils["i" /* ROUTE */].ACTIVITIES:
      {
        return external__react__default.a.createElement(Banner_ActivitiesRootBanner, null);
      }

    case utils["i" /* ROUTE */].POST:
      {
        return external__react__default.a.createElement(containers["p" /* PostBanner */], null);
      }

    case utils["i" /* ROUTE */].USER:
      {
        return external__react__default.a.createElement(containers["x" /* UserBanner */], null);
      }

    default:
      return external__react__default.a.createElement(containers["i" /* CommunityBanner */], null);
  }
};

var Banner_BannerContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(BannerContainer, _React$Component);

  function BannerContainer() {
    _classCallCheck(this, BannerContainer);

    return _possibleConstructorReturn(this, (BannerContainer.__proto__ || Object.getPrototypeOf(BannerContainer)).apply(this, arguments));
  }

  _createClass(BannerContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var banner = this.props.banner;
      logic(banner);
    }
  }, {
    key: "render",
    value: function render() {
      var banner = this.props.banner;
      var curRoute = banner.curRoute; // const { mainPath } = curRoute
      // debug('detail ---> ', detail)

      return external__react__default.a.createElement(Banner_BannerContent, {
        curRoute: curRoute,
        banner: banner
      });
    }
  }]);

  return BannerContainer;
}(external__react__default.a.Component);

/* harmony default export */ var Banner = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('banner'))(Object(external__mobx_react_["observer"])(Banner_BannerContainer)));

/***/ }),
/* 90 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "antd/lib/divider"
var divider_ = __webpack_require__(133);
var divider__default = /*#__PURE__*/__webpack_require__.n(divider_);

// EXTERNAL MODULE: external "antd/lib/row"
var row_ = __webpack_require__(62);
var row__default = /*#__PURE__*/__webpack_require__.n(row_);

// EXTERNAL MODULE: external "antd/lib/col"
var col_ = __webpack_require__(63);
var col__default = /*#__PURE__*/__webpack_require__.n(col_);

// EXTERNAL MODULE: external "randomcolor"
var external__randomcolor_ = __webpack_require__(134);
var external__randomcolor__default = /*#__PURE__*/__webpack_require__.n(external__randomcolor_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: external "polished"
var external__polished_ = __webpack_require__(14);
var external__polished__default = /*#__PURE__*/__webpack_require__.n(external__polished_);

// CONCATENATED MODULE: ./containers/CheatSheetContent/styles/index.js


/* import { theme } from '../../../utils' */
// visibility: ${props => (props.active === props.name ? 'visible' : 'hidden')};

var CategoryWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CategoryWrapper",
  componentId: "it6kuv-0"
})(["display:flex;width:100%;"]);
var Category =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Category",
  componentId: "it6kuv-1"
})(["width:100px;height:50px;border-radius:5px;margin-right:3em;margin-bottom:3em;background:", ";"], function (_ref) {
  var bg = _ref.bg;
  return bg;
});
var CheatsheetItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CheatsheetItem",
  componentId: "it6kuv-2"
})(["width:100px;margin:10px 20px;display:flex;flex-direction:column;height:30px;justify-content:center;border-radius:4px;background-color:", ";"], function (_ref2) {
  var fg = _ref2.fg;
  return Object(external__polished_["opacify"])(0.01, Object(external__polished_["setSaturation"])(0.1, fg));
});
var Entry =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Entry",
  componentId: "it6kuv-3"
})(["font-size:1.2em;text-align:center;color:", ";&:hover{cursor:pointer;color:", ";}"], function (_ref3) {
  var fg = _ref3.fg;
  return Object(external__polished_["setLightness"])(0.52, Object(external__polished_["setSaturation"])(0.2, fg));
}, function (_ref4) {
  var fg = _ref4.fg;
  return Object(external__polished_["setLightness"])(0.6, Object(external__polished_["setSaturation"])(0.3, fg));
});
var Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Divider",
  componentId: "it6kuv-4"
})(["border-bottom:1px solid grey;margin:2em 0;"]);
// EXTERNAL MODULE: ./utils/network/sr71.js + 3 modules
var sr71 = __webpack_require__(8);

// CONCATENATED MODULE: ./containers/CheatSheetContent/logic.js
/* import R from 'ramda' */


var sr71$ = new sr71["a" /* default */]();
/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:CheatSheetContent');
/* eslint-enable no-unused-vars */

var store = null;
var sub$ = null;
function someMethod() {}
var DataSolver = [];
var ErrSolver = [];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(utils["a" /* $solver */])(DataSolver, ErrSolver));
}
// CONCATENATED MODULE: ./containers/CheatSheetContent/index.js




function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * CheatSheetContent
 *
 */



 // TODO: remove Row, Col, Divider

// import Link from 'next/link'



var cheatsheetData = {
  langs: [{
    title: 'javascript',
    link: 'link'
  }, {
    title: 'ruby',
    link: 'link'
  }, {
    title: 'elixir',
    link: 'link'
  }, {
    title: 'javascript',
    link: 'link'
  }, {
    title: 'ruby',
    link: 'link'
  }, {
    title: 'elixir',
    link: 'link'
  }, {
    title: 'javascript',
    link: 'link'
  }, {
    title: 'ruby',
    link: 'link'
  }, {
    title: 'elixir',
    link: 'link'
  }, {
    title: 'django',
    link: 'link'
  }, {
    title: 'react',
    link: 'link'
  }, {
    title: 'angular',
    link: 'link'
  }, {
    title: 'javascript',
    link: 'link'
  }, {
    title: 'ruby',
    link: 'link'
  }, {
    title: 'django',
    link: 'link'
  }, {
    title: 'react',
    link: 'link'
  }, {
    title: 'angular',
    link: 'link'
  }, {
    title: 'elixir',
    link: 'link'
  }, {
    title: 'javascript',
    link: 'link'
  }, {
    title: 'ruby',
    link: 'link'
  }, {
    title: 'elixir',
    link: 'link'
  }, {
    title: 'javascript',
    link: 'link'
  }, {
    title: 'ruby',
    link: 'link'
  }, {
    title: 'elixir',
    link: 'link'
  }],
  framework: [{
    title: 'django',
    link: 'link'
  }, {
    title: 'react',
    link: 'link'
  }, {
    title: 'angular',
    link: 'link'
  }, {
    title: 'vue',
    link: 'link'
  }]
  /* eslint-disable no-unused-vars */

};
var CheatSheetContent_debug = Object(utils["G" /* makeDebugger */])('C:CheatSheetContent');
/* eslint-enable no-unused-vars */

var CheatSheetContent_Langs = function Langs(_ref) {
  var base = _ref.base;
  //   const base = 'orange' // '#8363B4' //'#68808D'
  var langs = cheatsheetData.langs;
  var colors = external__randomcolor__default()({
    hue: base,
    luminosity: 'light',
    count: langs.length
  });
  return external__react__default.a.createElement(row__default.a, null, external__react__default.a.createElement(col__default.a, {
    span: 1
  }), external__react__default.a.createElement(col__default.a, {
    span: 22
  }, external__react__default.a.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap'
    }
  }, langs.map(function (item, i) {
    return external__react__default.a.createElement(CheatsheetItem, {
      key: external__shortid__default.a.generate(),
      fg: colors[i]
    }, external__react__default.a.createElement(Entry, {
      fg: colors[i]
    }, item.title));
  }))));
};

var CheatSheetContent_CheatSheetContentContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(CheatSheetContentContainer, _React$Component);

  function CheatSheetContentContainer() {
    _classCallCheck(this, CheatSheetContentContainer);

    return _possibleConstructorReturn(this, (CheatSheetContentContainer.__proto__ || Object.getPrototypeOf(CheatSheetContentContainer)).apply(this, arguments));
  }

  _createClass(CheatSheetContentContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var cheatSheetContent = this.props.cheatSheetContent;
      init(cheatSheetContent);
    }
  }, {
    key: "render",
    value: function render() {
      return external__react__default.a.createElement("div", null, external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "green"
      }), external__react__default.a.createElement(divider__default.a, null, "\u524D\u7AEF"), external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "yellow"
      }), external__react__default.a.createElement(divider__default.a, null, "\u540E\u7AEF"), external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "orange"
      }), external__react__default.a.createElement(divider__default.a, null, "\u540E\u7AEF"), external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "red"
      }), external__react__default.a.createElement(divider__default.a, null, "\u540E\u7AEF"), external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "pink"
      }), external__react__default.a.createElement(divider__default.a, null, "\u540E\u7AEF"), external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "blue"
      }), external__react__default.a.createElement(divider__default.a, null, "\u540E\u7AEF"), external__react__default.a.createElement(CheatSheetContent_Langs, {
        base: "purple"
      }));
    }
  }]);

  return CheatSheetContentContainer;
}(external__react__default.a.Component);

/* harmony default export */ var CheatSheetContent = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('cheatSheetContent'))(Object(external__mobx_react_["observer"])(CheatSheetContent_CheatSheetContentContainer)));
// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: ./containers/index.js + 91 modules
var containers = __webpack_require__(28);

// CONCATENATED MODULE: ./components/CommunityContent/styles/index.js


var Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s7p7byu-0"
})(["width:94%;margin:40px;margin-top:25px;margin-bottom:10px;height:70%;min-height:70vh;color:", ";background:", ";border-radius:6px;padding:1em 6em;@media (max-width:1400px){padding:1em 2em;padding-bottom:0;}@media (max-width:1200px){padding:1em 1em;padding-bottom:0;}"], Object(utils["W" /* theme */])('font'), Object(utils["W" /* theme */])('content.bg'));
var holder = 1;
// CONCATENATED MODULE: ./components/CommunityContent/index.js
/*
 *
 * CommunityContent
 *
 */





/* eslint-disable no-unused-vars */

var CommunityContent_debug = Object(utils["G" /* makeDebugger */])('c:CommunityContent:index');
/* eslint-enable no-unused-vars */

var CommunityContent_ComunityContent = function ComunityContent(_ref) {
  var curRoute = _ref.curRoute;
  var subPath = curRoute.subPath;

  switch (subPath) {
    case utils["i" /* ROUTE */].POSTS:
      {
        return external__react__default.a.createElement(containers["r" /* PostsThread */], null);
      }

    case utils["i" /* ROUTE */].REPOS:
      {
        return external__react__default.a.createElement(containers["t" /* ReposThread */], null);
      }

    case 'news':
      {
        return external__react__default.a.createElement("h2", null, "NesPaper");
      }

    case 'tuts':
      {
        return external__react__default.a.createElement("h2", null, "TutsPaper");
      }

    case 'meetups':
      {
        return external__react__default.a.createElement("h2", null, "MeetupPaper");
      }

    case 'users':
      {
        return external__react__default.a.createElement("h2", null, "UsersPaper");
      }

    case utils["i" /* ROUTE */].VIDEOS:
      {
        return external__react__default.a.createElement(containers["z" /* VideosThread */], null);
      }

    case utils["i" /* ROUTE */].JOBS:
      {
        return external__react__default.a.createElement(containers["n" /* JobsThread */], null);
      }

    case 'cheatsheet':
      {
        return external__react__default.a.createElement(containers["f" /* CheatSheetPaper */], null);
      }

    default:
      {
        return external__react__default.a.createElement("div", null, "default");
      }
  }
};

var CommunityContent_CommunityContent = function CommunityContent(_ref2) {
  var curRoute = _ref2.curRoute;
  return external__react__default.a.createElement(Wrapper, null, external__react__default.a.createElement(CommunityContent_ComunityContent, {
    curRoute: curRoute
  }));
};

CommunityContent_CommunityContent.defaultProps = {};
/* harmony default export */ var components_CommunityContent = (CommunityContent_CommunityContent);
// CONCATENATED MODULE: ./containers/Content/logic.js
// import R from 'ramda'

/* eslint-disable no-unused-vars */

var logic_debug = Object(utils["G" /* makeDebugger */])('L:Content');
/* eslint-enable no-unused-vars */

var logic_store = null;
var logic_holder = false;
function logic_init(_store) {
  if (logic_store) return false;
  logic_store = _store;
  /* debug('content', content) */
}
// CONCATENATED MODULE: ./containers/Content/styles/index.js
 // import { theme } from '../../../utils'
// visibility: ${props => (props.active === props.name ? 'visible' : 'hidden')};

var Hidder =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Hidder",
  componentId: "s1gkz01m-0"
})(["display:", ";"], function (_ref) {
  var active = _ref.active,
      name = _ref.name;
  return active === name ? 'block' : 'none';
});
var styles_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1gkz01m-1"
})([""]);
var styles_CategoryWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CategoryWrapper",
  componentId: "s1gkz01m-2"
})(["display:flex;width:100%;"]);
var styles_Category =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Category",
  componentId: "s1gkz01m-3"
})(["width:100px;height:50px;border-radius:5px;margin-right:3em;margin-bottom:3em;background:", ";"], function (_ref2) {
  var bg = _ref2.bg;
  return bg;
});
var styles_Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Divider",
  componentId: "s1gkz01m-4"
})(["border-bottom:1px solid grey;margin:2em 0;"]);
// CONCATENATED MODULE: ./containers/Content/index.js
function Content__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { Content__typeof = function _typeof(obj) { return typeof obj; }; } else { Content__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return Content__typeof(obj); }

function Content__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function Content__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function Content__createClass(Constructor, protoProps, staticProps) { if (protoProps) Content__defineProperties(Constructor.prototype, protoProps); if (staticProps) Content__defineProperties(Constructor, staticProps); return Constructor; }

function Content__possibleConstructorReturn(self, call) { if (call && (Content__typeof(call) === "object" || typeof call === "function")) { return call; } return Content__assertThisInitialized(self); }

function Content__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function Content__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * Content
 *
 */








/* eslint-disable no-unused-vars */

var Content_debug = Object(utils["G" /* makeDebugger */])('C:Content');
/* eslint-enable no-unused-vars */

var Content_renderContent = function renderContent(curRoute) {
  var mainPath = curRoute.mainPath;

  switch (mainPath) {
    case utils["i" /* ROUTE */].CHEATSHEETS:
      {
        return external__react__default.a.createElement(CheatSheetContent, null);
      }

    case utils["i" /* ROUTE */].COMMUNITIES:
      {
        return external__react__default.a.createElement(containers["h" /* CommunitiesContent */], null);
      }

    case utils["i" /* ROUTE */].POST:
      {
        return external__react__default.a.createElement(containers["q" /* PostContent */], null);
      }

    case utils["i" /* ROUTE */].USER:
      {
        return external__react__default.a.createElement(containers["y" /* UserContent */], null);
      }

    default:
      {
        return external__react__default.a.createElement(components_CommunityContent, {
          curRoute: curRoute
        });
      }
  }
};

var Content_ContentContainer =
/*#__PURE__*/
function (_React$Component) {
  Content__inherits(ContentContainer, _React$Component);

  function ContentContainer() {
    Content__classCallCheck(this, ContentContainer);

    return Content__possibleConstructorReturn(this, (ContentContainer.__proto__ || Object.getPrototypeOf(ContentContainer)).apply(this, arguments));
  }

  Content__createClass(ContentContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var content = this.props.content;
      logic_init(content);
    }
  }, {
    key: "render",
    value: function render() {
      var curRoute = this.props.content.curRoute; //    debug('curRoute: ', curRoute)

      return external__react__default.a.createElement(styles_Wrapper, null, Content_renderContent(curRoute));
    }
  }]);

  return ContentContainer;
}(external__react__default.a.Component);

/* harmony default export */ var Content = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('content'))(Object(external__mobx_react_["observer"])(Content_ContentContainer)));

/***/ }),
/* 91 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "next/dynamic"
var dynamic_ = __webpack_require__(38);
var dynamic__default = /*#__PURE__*/__webpack_require__.n(dynamic_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: ./utils/network/sr71.js + 3 modules
var sr71 = __webpack_require__(8);

// CONCATENATED MODULE: ./containers/Preview/logic.js


var sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].NAV_EDIT, utils["e" /* EVENT */].PREVIEW, utils["e" /* EVENT */].NAV_CREATE_POST, utils["e" /* EVENT */].PREVIEW_CLOSE]
});
var debug = Object(utils["G" /* makeDebugger */])('L:Preview');
var store = null;
var sub$ = null;
function closePreview() {
  debug('closePreview');
  store.close(); // force call Typewriter's componentWillUnmount to store the draft
  // wait until preview move out of the screean

  setTimeout(function () {
    store.markState({
      type: null
    });
    Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW_CLOSED);
  }, 200);
}

function loadDataForPreview(info) {
  debug('loadDataForPreview --> : ', info);

  if (info.type === utils["k" /* TYPE */].POST_PREVIEW_VIEW) {
    // debug('load fucking post: ', info.data)
    Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].PREVIEW_POST, {
      type: utils["k" /* TYPE */].POST,
      data: info.data
    }); // loadPost(info.data)
  }
}

var DataResolver = [{
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW),
  action: function action(res) {
    var event = res[utils["e" /* EVENT */].PREVIEW];
    Object(utils["C" /* holdPage */])();
    store.open(event.type);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW_CLOSE),
  action: function action() {
    return closePreview();
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].NAV_EDIT),
  action: function action(res) {
    var event = res[utils["e" /* EVENT */].NAV_EDIT];
    Object(utils["C" /* holdPage */])();
    debug('--> EVENT.NAV_EDIT: ', res);
    store.open(event.type);
    loadDataForPreview(res[utils["e" /* EVENT */].NAV_EDIT]);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].NAV_CREATE_POST),
  action: function action(res) {
    var event = res[utils["e" /* EVENT */].NAV_CREATE_POST];
    Object(utils["C" /* holdPage */])();
    store.open(event.type);
  }
}];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(utils["a" /* $solver */])(DataResolver, []));
}
// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// EXTERNAL MODULE: external "ramda/src/range"
var range_ = __webpack_require__(26);
var range__default = /*#__PURE__*/__webpack_require__.n(range_);

// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: external "react-content-loader"
var external__react_content_loader_ = __webpack_require__(27);
var external__react_content_loader__default = /*#__PURE__*/__webpack_require__.n(external__react_content_loader_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// CONCATENATED MODULE: ./components/LoadingEffects/TypeWriterLoading.js





 // Config-page: http://danilowoz.com/create-react-content-loader/

var LoadingWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "TypeWriterLoading__LoadingWrapper",
  componentId: "tzomq5-0"
})(["width:100%;overflow:hidden;margin-left:7%;margin-top:2%;"]);

var TypeWriterLoading_Loading = function Loading(_ref) {
  var theme = _ref.theme;
  return external__react__default.a.createElement(external__react_content_loader__default.a, {
    height: 500,
    width: 500,
    speed: 2,
    primaryColor: theme.loading.basic,
    secondaryColor: theme.loading.animate
  }, external__react__default.a.createElement("rect", {
    x: "7.39",
    y: "18",
    rx: "4",
    ry: "4",
    width: "76",
    height: "9.88"
  }), external__react__default.a.createElement("rect", {
    x: "3",
    y: "49",
    rx: "5",
    ry: "5",
    width: "396",
    height: "372"
  }), external__react__default.a.createElement("rect", {
    x: "309.92",
    y: "20.05",
    rx: "0",
    ry: "0",
    width: "81",
    height: "7.98"
  }), external__react__default.a.createElement("rect", {
    x: "303.52",
    y: "433.05",
    rx: "0",
    ry: "0",
    width: "85.2",
    height: "26"
  }), external__react__default.a.createElement("rect", {
    x: "11.72",
    y: "440.05",
    rx: "0",
    ry: "0",
    width: "136.2",
    height: "8"
  }));
};

var TypeWriterLoading_TypeWriterLoading = function TypeWriterLoading(_ref2) {
  var num = _ref2.num,
      theme = _ref2.theme;

  // const ukey = shortid.generate()
  var range = range__default()(0, num);

  return range.map(function () {
    return external__react__default.a.createElement(LoadingWrapper, {
      key: external__shortid__default.a.generate()
    }, external__react__default.a.createElement(TypeWriterLoading_Loading, {
      uniquekey: external__shortid__default.a.generate(),
      theme: theme
    }));
  });
};

TypeWriterLoading_TypeWriterLoading.defaultProps = {
  num: 1
};
/* harmony default export */ var LoadingEffects_TypeWriterLoading = (Object(external__styled_components_["withTheme"])(TypeWriterLoading_TypeWriterLoading));
// EXTERNAL MODULE: ./containers/index.js + 91 modules
var containers = __webpack_require__(28);

// EXTERNAL MODULE: external "ramda/src/contains"
var contains_ = __webpack_require__(17);
var contains__default = /*#__PURE__*/__webpack_require__.n(contains_);

// CONCATENATED MODULE: ./containers/Preview/styles/index.js



var WIDE_CASE = [utils["k" /* TYPE */].POST_PREVIEW_VIEW, utils["k" /* TYPE */].PREVIEW_CREATE_POST, utils["k" /* TYPE */].PREVIEW_COMMUNITY_EDITORS];
var WIDE_WIDTH = '70%';
var NARROW_WIDTH = '40%';

function doTransform(visible) {
  return visible ? 'translate(0px, 0px)' : 'translate(105%, 0px)';
}

var PreviewOverlay =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewOverlay",
  componentId: "j67gir-0"
})(["bottom:0;left:0;overflow:auto;position:fixed;height:100%;right:0;z-index:998;top:0;visibility:", ";"], function (_ref) {
  var visible = _ref.visible;
  return visible ? 'visible' : 'hidden';
}); // z-index: 1001;
// z-index: ${props => (props.visible ? 1001 : -1)};
// display: ${props => (props.visible ? 'block' : 'none')};
// visibility: ${props => (props.visible ? 'visible' : 'hidden')};

var PreviewWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewWrapper",
  componentId: "j67gir-1"
})(["color:", ";box-sizing:border-box;transition:transform 450ms cubic-bezier(0.23,1,0.32,1) 0ms;font-family:Roboto,sans-serif;-webkit-tap-highlight-color:rgba(0,0,0,0);border-radius:0px;height:100%;width:", ";max-width:1000px;right:0;position:fixed;transform:", ";top:0px;overflow:auto;z-index:1000;display:flex;justify-content:flex-end;"], Object(utils["W" /* theme */])('preview.font'), function (_ref2) {
  var type = _ref2.type;
  return contains__default()(type, WIDE_CASE) ? WIDE_WIDTH : NARROW_WIDTH;
}, function (_ref3) {
  var visible = _ref3.visible;
  return doTransform(visible);
});
var PreviewContent =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewContent",
  componentId: "j67gir-2"
})(["width:90%;background-color:", ";height:100%;overflow-y:scroll;box-shadow:", ";"], Object(utils["W" /* theme */])('preview.bg'), Object(utils["W" /* theme */])('preview.shadow'));
var PreviewHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewHeader",
  componentId: "j67gir-3"
})(["border-bottom:1px solid grey;line-height:30px;display:flex;"]);
var PreviewCloser =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewCloser",
  componentId: "j67gir-4"
})(["width:10%;"]);
var closeWith = '40px';
var CloserInner =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CloserInner",
  componentId: "j67gir-5"
})(["width:", ";height:45px;background-color:", ";border-right:1px solid ", ";transform-origin:right center 0;transform:rotate3d(0,1,0,-30deg);box-shadow:", ";"], closeWith, Object(utils["W" /* theme */])('preview.bg'), Object(utils["W" /* theme */])('preview.bg'), Object(utils["W" /* theme */])('preview.closerShadow')); // box-shadow: -5px 0px 14px 0px rgba(189, 189, 189, 0.37);

var Closer =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Closer",
  componentId: "j67gir-6"
})(["float:right;width:", ";height:", ";perspective:", ";cursor:pointer;display:", ";&:hover:after{animation:", " 2s cubic-bezier(0,0.56,0.24,0.72);font-weight:bold;}&:after{content:'\u2715';position:absolute;top:9px;right:6px;font-size:large;color:", ";font-weight:lighter;}"], closeWith, closeWith, closeWith, function (_ref4) {
  var type = _ref4.type;
  return type === utils["k" /* TYPE */].PREVIEW_ACCOUNT_VIEW || type === utils["k" /* TYPE */].PREVIEW_ACCOUNT_EDIT ? 'none' : 'block';
}, utils["b" /* Animate */].rotate360, Object(utils["W" /* theme */])('preview.font'));
// CONCATENATED MODULE: ./containers/Preview/index.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * Preview
 *
 */


 // import Link from 'next/link'


 // TODO: move it to component





/* eslint-disable no-unused-vars */

var Preview_debug = Object(utils["G" /* makeDebugger */])('C:Preview');
/* eslint-enable no-unused-vars */

var DynamicTypeWriter = dynamic__default()( false ? new (require('next/dynamic').SameLoopPromise)(function (resolve, reject) {
  eval('require.ensure = function (deps, callback) { callback(require) }');

  require.ensure([], function (require) {
    var m = require('../TypeWriter');

    m.__webpackChunkName = 'containers_TypeWriter_31f1ffd146dca69bcb7a302edb951907.js';
    resolve(m);
  }, 'chunks/containers_TypeWriter_31f1ffd146dca69bcb7a302edb951907.js');
}) : new (__webpack_require__(38).SameLoopPromise)(function (resolve, reject) {
  var weakId = /*require.resolve*/(163);

  try {
    var weakModule = __webpack_require__(weakId);

    return resolve(weakModule);
  } catch (err) {}

  __webpack_require__.e/* require.ensure */(0).then((function (require) {
    try {
      var m = __webpack_require__(163);

      m.__webpackChunkName = 'containers_TypeWriter_31f1ffd146dca69bcb7a302edb951907';
      resolve(m);
    } catch (error) {
      reject(error);
    }
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
}), {
  /* eslint-disable */
  loading: function loading() {
    return external__react__default.a.createElement(LoadingEffects_TypeWriterLoading, null);
  }
  /* eslint-enable */

});

var Preview_CloseBtn = function CloseBtn(_ref) {
  var type = _ref.type;
  return external__react__default.a.createElement(PreviewCloser, {
    onClick: closePreview
  }, external__react__default.a.createElement(Closer, {
    type: type
  }, external__react__default.a.createElement(CloserInner, null)));
}; // const Viewer = ({ type, root, themeKeys, curTheme }) => {
// <AccountViewer2 themeKeys={themeKeys} curTheme={curTheme} />
// TODO: post edit viewer


var Preview_Viewer = function Viewer(_ref2) {
  var type = _ref2.type,
      root = _ref2.root;

  switch (type) {
    case utils["k" /* TYPE */].PREVIEW_ACCOUNT_VIEW:
      {
        return external__react__default.a.createElement(containers["b" /* AccountViewer */], null);
      }

    case utils["k" /* TYPE */].PREVIEW_ACCOUNT_EDIT:
      {
        return external__react__default.a.createElement(containers["a" /* AccountEditor */], null);
      }

    case utils["k" /* TYPE */].POST_PREVIEW_VIEW:
      {
        return external__react__default.a.createElement(containers["c" /* ArticleViwer */], null);
      }

    case utils["k" /* TYPE */].PREVIEW_CREATE_POST:
      {
        return external__react__default.a.createElement(DynamicTypeWriter, {
          onClose: closePreview
        });
      }

    case utils["k" /* TYPE */].PREVIEW_COMMUNITY_EDITORS:
      {
        return external__react__default.a.createElement(containers["j" /* CommunityEditors */], null);
      }

    default:
      {
        return external__react__default.a.createElement(components["x" /* StateTree */], {
          json: root.toJSON()
        });
      }
  }
};

var Preview_PreviewContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(PreviewContainer, _React$Component);

  function PreviewContainer() {
    _classCallCheck(this, PreviewContainer);

    return _possibleConstructorReturn(this, (PreviewContainer.__proto__ || Object.getPrototypeOf(PreviewContainer)).apply(this, arguments));
  }

  _createClass(PreviewContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var preview = this.props.preview;
      init(preview);
    }
  }, {
    key: "render",
    value: function render() {
      var _props$preview = this.props.preview,
          visible = _props$preview.visible,
          type = _props$preview.type,
          themeKeys = _props$preview.themeKeys,
          curTheme = _props$preview.curTheme,
          root = _props$preview.root;
      return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(PreviewOverlay, {
        visible: visible,
        onClick: closePreview
      }), external__react__default.a.createElement(PreviewWrapper, {
        visible: visible,
        type: type
      }, external__react__default.a.createElement(Preview_CloseBtn, {
        type: type
      }), external__react__default.a.createElement(PreviewContent, null, external__react__default.a.createElement(Preview_Viewer, {
        type: type,
        root: root,
        themeKeys: themeKeys,
        curTheme: curTheme
      }))));
    }
  }]);

  return PreviewContainer;
}(external__react__default.a.Component);

/* harmony default export */ var Preview = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('preview'))(Object(external__mobx_react_["observer"])(Preview_PreviewContainer)));

/***/ }),
/* 92 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "ramda/src/toLower"
var toLower_ = __webpack_require__(16);
var toLower__default = /*#__PURE__*/__webpack_require__.n(toLower_);

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: external "react-beautiful-dnd"
var external__react_beautiful_dnd_ = __webpack_require__(137);
var external__react_beautiful_dnd__default = /*#__PURE__*/__webpack_require__.n(external__react_beautiful_dnd_);

// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "react-icons/lib/ti/pin-outline"
var pin_outline_ = __webpack_require__(138);
var pin_outline__default = /*#__PURE__*/__webpack_require__.n(pin_outline_);

// EXTERNAL MODULE: external "react-icons/lib/md/fiber-pin"
var fiber_pin_ = __webpack_require__(139);
var fiber_pin__default = /*#__PURE__*/__webpack_require__.n(fiber_pin_);

// CONCATENATED MODULE: ./components/Icons/index.js
// import styled from 'styled-components'
// TODO: remove react-icon


var PinIcon = fiber_pin__default.a; // styled(Pin)`font-size: 25px;`

var PinIcon2 = pin_outline__default.a;
// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./containers/Sidebar/styles/index.js


 // 纯css，div隐藏滚动条，保留鼠标滚动效果。
// http://blog.csdn.net/liusaint1992/article/details/51277751

var Container =
/*#__PURE__*/
external__styled_components__default.a.aside.withConfig({
  displayName: "styles__Container",
  componentId: "a6oifj-0"
})(["border-right:1px solid;position:fixed;height:100vh;top:0;width:", ";box-shadow:", ";background:", ";border-color:", ";z-index:1000;overflow:hidden;transition:width 0.2s,opacity 0.8s,box-shadow 0.1s linear 0.1s,background-color 0.3s;&:hover{width:250px;box-shadow:3px 0 20px rgba(0,0,0,0.2);}"], function (_ref) {
  var pin = _ref.pin;
  return pin ? '250px' : '56px';
}, function (_ref2) {
  var pin = _ref2.pin;
  return pin ? '3px 0 20px rgba(0, 0, 0, 0.2); ' : '';
}, Object(utils["W" /* theme */])('sidebar.bg'), Object(utils["W" /* theme */])('sidebar.borderColor'));
var StyledPin =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__StyledPin",
  componentId: "a6oifj-1"
})(["color:", ";visibility:", ";opacity:", ";position:absolute;font-size:25px;right:10px;top:5px;transition:visibility 0s,opacity 0.3s linear;cursor:pointer;", ":hover &{visibility:visible;opacity:1;}"], function (_ref3) {
  var pin = _ref3.pin;
  return pin ? Object(utils["W" /* theme */])('sidebar.pinActive') : 'grey';
}, function (_ref4) {
  var pin = _ref4.pin;
  return pin ? 'visible' : 'hidden';
}, function (_ref5) {
  var pin = _ref5.pin;
  return pin ? 1 : 0;
}, Container);
var MenuItem =
/*#__PURE__*/
external__styled_components__default.a.ul.withConfig({
  displayName: "styles__MenuItem",
  componentId: "a6oifj-2"
})(["margin-top:0px;left:0;position:relative;width:260px;height:95vh;overflow-y:scroll;transition:left 0.2s;"]);
var MenuItemWrapper =
/*#__PURE__*/
external__styled_components__default.a.li.withConfig({
  displayName: "styles__MenuItemWrapper",
  componentId: "a6oifj-3"
})(["display:block;&:hover{background:", ";}"], Object(utils["W" /* theme */])('sidebar.menuHover'));
var MenuItemEach =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MenuItemEach",
  componentId: "a6oifj-4"
})(["cursor:pointer;opacity:1;transition:color 0.2s;padding-left:15px;font-size:15px;line-height:50px;height:50px;width:100%;box-sizing:border-box;color:", ";"], Object(utils["W" /* theme */])('sidebar.menuLink'));
var MenuRow =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MenuRow",
  componentId: "a6oifj-5"
})(["display:flex;justify-content:left;font-size:1em;> a{display:", ";color:", ";opacity:", ";flex-grow:1;max-width:50%;}", ":hover &{a{display:block;flex-grow:1;max-width:50%;}}"], function (_ref6) {
  var pin = _ref6.pin;
  return pin ? 'block' : 'none';
}, Object(utils["W" /* theme */])('sidebar.menuLink'), function (_ref7) {
  var active = _ref7.active;
  return active ? 1 : 0.7;
}, Container); // TODO: hover

var MiniChartWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MiniChartWrapper",
  componentId: "a6oifj-6"
})(["width:12vh;justify-content:flex-end;align-items:center;position:relative;margin-top:-2px;display:", ";", ":hover &{display:flex;}"], function (_ref8) {
  var pin = _ref8.pin;
  return pin ? 'flex' : 'none';
}, Container);
var MiniChartBar =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MiniChartBar",
  componentId: "a6oifj-7"
})(["height:8px;width:60px;background-color:#285763;border-radius:2px;"]);
var MiniChartText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MiniChartText",
  componentId: "a6oifj-8"
})(["position:absolute;font-size:1.1em;top:-2px;color:#5396a7;right:2px;", ":hover &{font-weight:bold;}"], MenuRow);
var SVGIconWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SVGIconWrapper",
  componentId: "a6oifj-9"
})(["margin-top:5px;opacity:", ";> svg{width:22px;height:22px;}"], function (_ref9) {
  var active = _ref9.active;
  return active ? 1 : 0.5;
});
var MenuItemIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__MenuItemIcon",
  componentId: "a6oifj-10"
})(["opacity:", ";margin-top:1em;width:22px;height:22px;"], function (_ref10) {
  var active = _ref10.active;
  return active ? 1 : 0.5;
});
// CONCATENATED MODULE: ./containers/Sidebar/PinButton.js




var PinButton_PinButton = function PinButton(props) {
  return external__react__default.a.createElement(StyledPin, props, external__react__default.a.createElement(PinIcon, null));
};

/* harmony default export */ var Sidebar_PinButton = (PinButton_PinButton);
// EXTERNAL MODULE: external "graphql-tag"
var external__graphql_tag_ = __webpack_require__(11);
var external__graphql_tag__default = /*#__PURE__*/__webpack_require__.n(external__graphql_tag_);

// CONCATENATED MODULE: ./containers/Sidebar/schema.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  query subscribedCommunities($userId: ID, $filter: PagedFilter!) {\n    subscribedCommunities(userId: $userId, filter: $filter) {\n      entries {\n        id\n        title\n        desc\n        raw\n        logo\n        contributesDigest\n        threads {\n          title\n          raw\n        }\n      }\n      pageNumber\n      pageSize\n      totalCount\n      totalPages\n    }\n  }\n"]),
    _templateObject2 = /*#__PURE__*/ _taggedTemplateLiteral(["\n  query communities($filter: PagedFilter!) {\n    communities(filter: $filter) {\n      entries {\n        id\n        title\n        desc\n        raw\n        logo\n        contributesDigest\n      }\n      pageNumber\n      pageSize\n      totalCount\n      totalPages\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var schema_subscribedCommunities = external__graphql_tag__default()(_templateObject); // TODO remove

var communities = external__graphql_tag__default()(_templateObject2);
var schema = {
  communities: communities,
  subscribedCommunities: schema_subscribedCommunities
};
/* harmony default export */ var Sidebar_schema = (schema);
// EXTERNAL MODULE: ./utils/network/sr71.js + 3 modules
var sr71 = __webpack_require__(8);

// CONCATENATED MODULE: ./containers/Sidebar/logic.js
// import R from 'ramda'
// const debug = makeDebugger('L:sidebar')



var sr71$ = new sr71["a" /* default */]({
  resv_event: [utils["e" /* EVENT */].LOGOUT, utils["e" /* EVENT */].LOGIN]
});
var store = null;
var sub$ = null;
/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:Sidebar');
/* eslint-enable no-unused-vars */

function logic_pin() {
  store.markState({
    pin: !store.pin
  });
}
function onCommunitySelect(community) {
  debug('onCommunitySelect --> ', community);
  store.markRoute({
    mainPath: community.raw,
    subPath: Object(utils["_1" /* thread2Subpath */])(utils["j" /* THREAD */].POST)
  });
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].COMMUNITY_CHANGE);
}
function loadSubscribedCommunities() {
  var user = utils["c" /* BStore */].get('user');
  var args = {
    filter: {
      page: 1,
      size: 30
    }
  };

  if (user) {
    args.userId = user.id;
    args.filter.size = 20;
  }

  sr71$.query(Sidebar_schema.subscribedCommunities, args);
}
var DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('subscribedCommunities'),
  action: function action(_ref) {
    var subscribedCommunities = _ref.subscribedCommunities;
    return store.loadSubscribedCommunities(subscribedCommunities);
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].LOGOUT),
  action: function action() {
    return loadSubscribedCommunities();
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].LOGIN),
  action: function action() {
    return loadSubscribedCommunities();
  }
}];
var ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref2) {
    var details = _ref2.details;
    debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref3) {
    var details = _ref3.details;
    debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref4) {
    var details = _ref4.details;
    debug('ERR.NETWORK -->', details);
  }
}];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(utils["a" /* $solver */])(DataSolver, ErrSolver));
  loadSubscribedCommunities();
}
// CONCATENATED MODULE: ./containers/Sidebar/index.js


var _this = this;

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 *
 * Sidebar
 *
 */








var Sidebar_debug = Object(utils["G" /* makeDebugger */])('C:Sidebar:index');

var getItemStyle = function getItemStyle(isDragging, draggableStyle) {
  return _objectSpread({}, draggableStyle);
};

var Sidebar_MenuList = function MenuList(_ref) {
  var items = _ref.items,
      pin = _ref.pin,
      activeRaw = _ref.activeRaw;

  /* const sparkData = [0, 2, 5, 9, 5, 10, 3, 5, 0, 0, 1, 8, 2, 9, 0] */
  // const sparkData = [0, 0, 0, 1, 0, 0, 1]
  var listItems = external__react__default.a.createElement(external__react_beautiful_dnd_["DragDropContext"], {
    onDragEnd: Sidebar_debug
  }, external__react__default.a.createElement(external__react_beautiful_dnd_["Droppable"], {
    droppableId: "droppable"
  }, function (provided) {
    return external__react__default.a.createElement("div", {
      ref: provided.innerRef
    }, items.map(function (item, index) {
      return external__react__default.a.createElement(external__react_beautiful_dnd_["Draggable"], {
        key: item.raw,
        draggableId: item.raw,
        index: index
      }, function (provided, snapshot) {
        return external__react__default.a.createElement(MenuItemWrapper, null, external__react__default.a.createElement("div", _extends({
          ref: provided.innerRef
        }, provided.draggableProps, provided.dragHandleProps, {
          style: getItemStyle(snapshot.isDragging, provided.draggableProps.style)
        }), external__react__default.a.createElement(MenuItemEach, null, external__react__default.a.createElement("div", {
          onClick: onCommunitySelect.bind(_this, item)
        }, external__react__default.a.createElement(MenuRow, {
          pin: pin,
          active: activeRaw === toLower__default()(item.raw)
        }, external__react__default.a.createElement(MenuItemIcon, {
          active: activeRaw === toLower__default()(item.raw),
          src: item.logo
        }), external__react__default.a.createElement("div", {
          style: {
            marginRight: 10
          }
        }), external__react__default.a.createElement("a", {
          style: {
            textDecoration: 'none'
          }
        }, item.title), external__react__default.a.createElement(MiniChartWrapper, {
          pin: pin
        }, external__react__default.a.createElement(components["E" /* TrendLine */], {
          data: item.contributesDigest,
          duration: 300,
          radius: 15,
          width: 7
        })))))), provided.placeholder);
      });
    }), provided.placeholder);
  }));
  return external__react__default.a.createElement(MenuItem, null, listItems);
};

var reorder = function reorder(list, startIndex, endIndex) {
  var result = Array.from(list);

  var _result$splice = result.splice(startIndex, 1),
      _result$splice2 = _slicedToArray(_result$splice, 1),
      removed = _result$splice2[0];

  result.splice(endIndex, 0, removed);
  return result;
};

var Sidebar_SidebarContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SidebarContainer, _React$Component);

  function SidebarContainer() {
    _classCallCheck(this, SidebarContainer);

    return _possibleConstructorReturn(this, (SidebarContainer.__proto__ || Object.getPrototypeOf(SidebarContainer)).apply(this, arguments));
  }

  _createClass(SidebarContainer, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var sidebar = this.props.sidebar;
      init(sidebar);
    }
  }, {
    key: "onDragEnd",
    value: function onDragEnd(result) {
      // dropped outside the list
      if (!result.destination) {
        return;
      }
      /*
      const items = reorder(
        this.state.items,
        result.source.index,
        result.destination.index
      )
      this.setState({
        items,
      })
      */


      this.setState(function (prevState) {
        return {
          items: reorder(prevState.items, result.source.index, result.destination.index)
        };
      });
    }
  }, {
    key: "render",
    value: function render() {
      var sidebar = this.props.sidebar;
      var curCommunity = sidebar.curCommunity,
          pin = sidebar.pin,
          subscribedCommunities = sidebar.subscribedCommunities; //    onMouseLeave={logic.leaveSidebar}
      // onMouseLeave is not unreliable in chrome: https://github.com/facebook/react/issues/4492

      var activeRaw = curCommunity.raw;
      return external__react__default.a.createElement(Container, {
        pin: pin
      }, external__react__default.a.createElement(Sidebar_PinButton, {
        pin: pin,
        onClick: logic_pin
      }), external__react__default.a.createElement("br", null), external__react__default.a.createElement("br", null), external__react__default.a.createElement(Sidebar_MenuList, {
        items: subscribedCommunities,
        pin: pin,
        activeRaw: activeRaw
      }));
    }
  }]);

  return SidebarContainer;
}(external__react__default.a.Component);

/* harmony default export */ var Sidebar = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('sidebar'))(Object(external__mobx_react_["observer"])(Sidebar_SidebarContainer)));

/***/ }),
/* 93 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "react-keydown"
var external__react_keydown_ = __webpack_require__(45);
var external__react_keydown__default = /*#__PURE__*/__webpack_require__.n(external__react_keydown_);

// EXTERNAL MODULE: external "ramda/src/findIndex"
var findIndex_ = __webpack_require__(25);
var findIndex__default = /*#__PURE__*/__webpack_require__.n(findIndex_);

// EXTERNAL MODULE: external "ramda/src/allPass"
var allPass_ = __webpack_require__(140);
var allPass__default = /*#__PURE__*/__webpack_require__.n(allPass_);

// EXTERNAL MODULE: external "ramda/src/last"
var last_ = __webpack_require__(46);
var last__default = /*#__PURE__*/__webpack_require__.n(last_);

// EXTERNAL MODULE: external "ramda/src/not"
var not_ = __webpack_require__(15);
var not__default = /*#__PURE__*/__webpack_require__.n(not_);

// EXTERNAL MODULE: external "ramda/src/prop"
var prop_ = __webpack_require__(58);
var prop__default = /*#__PURE__*/__webpack_require__.n(prop_);

// EXTERNAL MODULE: external "ramda/src/isEmpty"
var isEmpty_ = __webpack_require__(9);
var isEmpty__default = /*#__PURE__*/__webpack_require__.n(isEmpty_);

// EXTERNAL MODULE: external "ramda/src/compose"
var compose_ = __webpack_require__(12);
var compose__default = /*#__PURE__*/__webpack_require__.n(compose_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(36);
var router__default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: ./config/assets.js
var assets = __webpack_require__(32);

// EXTERNAL MODULE: external "rxjs/Observable"
var Observable_ = __webpack_require__(39);
var Observable__default = /*#__PURE__*/__webpack_require__.n(Observable_);

// EXTERNAL MODULE: external "rxjs/Subject"
var Subject_ = __webpack_require__(66);
var Subject__default = /*#__PURE__*/__webpack_require__.n(Subject_);

// EXTERNAL MODULE: external "pubsub-js"
var external__pubsub_js_ = __webpack_require__(31);
var external__pubsub_js__default = /*#__PURE__*/__webpack_require__.n(external__pubsub_js_);

// EXTERNAL MODULE: external "rxjs/add/operator/do"
var do_ = __webpack_require__(68);
var do__default = /*#__PURE__*/__webpack_require__.n(do_);

// EXTERNAL MODULE: external "rxjs/add/operator/catch"
var catch_ = __webpack_require__(141);
var catch__default = /*#__PURE__*/__webpack_require__.n(catch_);

// EXTERNAL MODULE: external "rxjs/add/operator/switchMap"
var switchMap_ = __webpack_require__(69);
var switchMap__default = /*#__PURE__*/__webpack_require__.n(switchMap_);

// EXTERNAL MODULE: external "rxjs/add/operator/debounceTime"
var debounceTime_ = __webpack_require__(67);
var debounceTime__default = /*#__PURE__*/__webpack_require__.n(debounceTime_);

// EXTERNAL MODULE: external "rxjs/add/operator/takeUntil"
var takeUntil_ = __webpack_require__(142);
var takeUntil__default = /*#__PURE__*/__webpack_require__.n(takeUntil_);

// EXTERNAL MODULE: external "rxjs/add/operator/map"
var map_ = __webpack_require__(143);
var map__default = /*#__PURE__*/__webpack_require__.n(map_);

// EXTERNAL MODULE: external "rxjs/add/operator/filter"
var filter_ = __webpack_require__(144);
var filter__default = /*#__PURE__*/__webpack_require__.n(filter_);

// EXTERNAL MODULE: external "rxjs/add/operator/merge"
var merge_ = __webpack_require__(70);
var merge__default = /*#__PURE__*/__webpack_require__.n(merge_);

// EXTERNAL MODULE: external "ramda/src/identity"
var identity_ = __webpack_require__(145);
var identity__default = /*#__PURE__*/__webpack_require__.n(identity_);

// EXTERNAL MODULE: external "ramda/src/tail"
var tail_ = __webpack_require__(146);
var tail__default = /*#__PURE__*/__webpack_require__.n(tail_);

// EXTERNAL MODULE: external "ramda/src/pick"
var pick_ = __webpack_require__(74);
var pick__default = /*#__PURE__*/__webpack_require__.n(pick_);

// EXTERNAL MODULE: external "ramda/src/map"
var src_map_ = __webpack_require__(18);
var src_map__default = /*#__PURE__*/__webpack_require__.n(src_map_);

// EXTERNAL MODULE: external "ramda/src/values"
var values_ = __webpack_require__(42);
var values__default = /*#__PURE__*/__webpack_require__.n(values_);

// EXTERNAL MODULE: external "ramda/src/endsWith"
var endsWith_ = __webpack_require__(57);
var endsWith__default = /*#__PURE__*/__webpack_require__.n(endsWith_);

// EXTERNAL MODULE: external "ramda/src/ifElse"
var ifElse_ = __webpack_require__(147);
var ifElse__default = /*#__PURE__*/__webpack_require__.n(ifElse_);

// EXTERNAL MODULE: external "ramda/src/pickBy"
var pickBy_ = __webpack_require__(19);
var pickBy__default = /*#__PURE__*/__webpack_require__.n(pickBy_);

// EXTERNAL MODULE: external "ramda/src/path"
var path_ = __webpack_require__(35);
var path__default = /*#__PURE__*/__webpack_require__.n(path_);

// EXTERNAL MODULE: external "ramda/src/insert"
var insert_ = __webpack_require__(60);
var insert__default = /*#__PURE__*/__webpack_require__.n(insert_);

// EXTERNAL MODULE: external "ramda/src/append"
var append_ = __webpack_require__(61);
var append__default = /*#__PURE__*/__webpack_require__.n(append_);

// EXTERNAL MODULE: external "ramda/src/anyPass"
var anyPass_ = __webpack_require__(148);
var anyPass__default = /*#__PURE__*/__webpack_require__.n(anyPass_);

// EXTERNAL MODULE: external "ramda/src/startsWith"
var startsWith_ = __webpack_require__(149);
var startsWith__default = /*#__PURE__*/__webpack_require__.n(startsWith_);

// EXTERNAL MODULE: external "ramda/src/init"
var init_ = __webpack_require__(150);
var init__default = /*#__PURE__*/__webpack_require__.n(init_);

// EXTERNAL MODULE: external "ramda/src/head"
var head_ = __webpack_require__(34);
var head__default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "ramda/src/filter"
var src_filter_ = __webpack_require__(30);
var src_filter__default = /*#__PURE__*/__webpack_require__.n(src_filter_);

// EXTERNAL MODULE: external "ramda/src/slice"
var slice_ = __webpack_require__(29);
var slice__default = /*#__PURE__*/__webpack_require__.n(slice_);

// EXTERNAL MODULE: external "ramda/src/split"
var split_ = __webpack_require__(33);
var split__default = /*#__PURE__*/__webpack_require__.n(split_);

// EXTERNAL MODULE: external "rxjs/add/observable/fromPromise"
var fromPromise_ = __webpack_require__(72);
var fromPromise__default = /*#__PURE__*/__webpack_require__.n(fromPromise_);

// CONCATENATED MODULE: ./containers/Doraemon/helper/advisor.js






















function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }





var cmdSplit = compose__default()(split__default()('/'), slice__default()(1, Infinity));

var cmdFull = compose__default()(src_filter__default()(utils["L" /* notEmpty */]), cmdSplit);

var cmdHead = compose__default()(head__default.a, cmdSplit);

var cmdLast = compose__default()(last__default.a, cmdFull);

var cmdInit = compose__default()(init__default.a, cmdFull);

var startWithSlash = startsWith__default()('/');
var startWithSpecialPrefix = anyPass__default()([startsWith__default()('?'), startsWith__default()('>'), startsWith__default()('<')]); // TODO need refactor

var advisor_insertBetweenPath = function insertBetweenPath(path) {
  var word = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'threads';

  switch (path.length) {
    case 2:
      return append__default()(word, insert__default()(1, word, path));
    // case 3:
    //  return R.append(word, R.insert(1, word, path))

    default:
      return append__default()(word, path);
  }
};
var advisor_Advisor = function Advisor(store) {
  var _this = this;

  _classCallCheck(this, Advisor);

  Object.defineProperty(this, "getSuggestionPath", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(p) {
      if (isEmpty__default()(p)) {
        return path__default()(p, _this.curSuggestions);
      }

      var cmdChain = advisor_insertBetweenPath(p);

      _this.store.markState({
        cmdChain: cmdChain
      });

      return path__default()(cmdChain, _this.curSuggestions) || {};
    }
  });
  Object.defineProperty(this, "suggestionPathInit", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: compose__default()(this.getSuggestionPath, cmdInit)
  });
  Object.defineProperty(this, "suggestionPath", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: compose__default()(this.getSuggestionPath, cmdFull)
  });
  Object.defineProperty(this, "suggestionPathThenStartsWith", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(val) {
      var init = _this.suggestionPathInit(val);

      return pickBy__default()(function (_, k) {
        return startsWith__default()(cmdLast(val), k);
      }, init);
    }
  });
  Object.defineProperty(this, "walkSuggestion", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: ifElse__default()(endsWith__default()('/'), this.suggestionPath, this.suggestionPathThenStartsWith)
  });
  Object.defineProperty(this, "suggestionBreif", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: compose__default()(values__default.a, src_map__default()(pick__default()(['title', 'desc', 'raw', 'logo', 'cmd'])), this.walkSuggestion)
  });
  Object.defineProperty(this, "getSuggestion", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: ifElse__default()(compose__default()(startsWith__default()('/'), tail__default.a), // avoid multi /, like /////
    function () {
      return identity__default()([]);
    }, this.suggestionBreif)
  });
  Object.defineProperty(this, "relateSuggestions", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(val) {
      // sync with store allSuggestions
      _this.curSuggestions = _this.store.allSuggestions;
      return {
        prefix: cmdSplit(val).length > 1 ? cmdHead(val) : '/',
        data: _this.getSuggestion(val)
      };
    }
  });
  Object.defineProperty(this, "relateSuggestions$", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(q) {
      return Observable_["Observable"].fromPromise(new Promise(function (resolve) {
        return resolve(_this.relateSuggestions(q));
      }));
    }
  });
  Object.defineProperty(this, "specialSuggestions", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(val) {
      return {
        prefix: '/',
        data: [_this.getSuggestionPath(val)]
      };
    }
  });
  this.store = store;
  this.curSuggestions = store.allSuggestions;
};
// CONCATENATED MODULE: ./containers/Doraemon/Pockect.js
function Pockect__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }



 // import 'rxjs/add/observable/of'





 // import 'rxjs/add/operator/distinctUntilChanged'






/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('L:Doraemon:pocket');
/* eslint-enable no-unused-vars */

var Pockect_Pockect =
/*#__PURE__*/
function () {
  function Pockect(store) {
    var _this = this;

    Pockect__classCallCheck(this, Pockect);

    this.store = store; // if only pass down the store.allSuggestions, it will not reactive
    // because store.allSuggestions is only json, has no mobx magic
    // this.advisor = new Advisor(store.allSuggestions)

    this.advisor = new advisor_Advisor(store);
    this.input$ = new Subject_["Subject"]();
    this.stop$ = new Subject_["Subject"](); // esc, pageClick  ...
    // TODO: netfix search use throttle
    // see: https://www.youtube.com/watch?v=XRYN2xt11Ek

    this.cmdInput$ = this.input$.debounceTime(200); // .distinctUntilChanged()

    external__pubsub_js__default.a.subscribe(utils["e" /* EVENT */].LOGIN_PANEL, function () {
      _this.store.handleLogin();

      _this.input$.next('/login/');
    });
    this.cmdSuggestionCommon = this.cmdInput$.filter(startWithSlash).switchMap(function (q) {
      return _this.advisor.relateSuggestions$(q).takeUntil(_this.stop$);
    }).catch(function () {
      return Observable_["Observable"].of([]);
    });
    this.cmdSuggestionSpecial = this.cmdInput$.filter(startWithSpecialPrefix) // > < ?
    .map(this.advisor.specialSuggestions);
    this.cmdSuggesttion$ = this.cmdSuggestionCommon.merge(this.cmdSuggestionSpecial);
  }

  _createClass(Pockect, [{
    key: "query",
    value: function query(term) {
      // debug('inputForOtherUse: ', this.store.inputForOtherUse)
      if (!this.store.inputForOtherUse) {
        this.input$.next(term);
      }
    }
  }, {
    key: "stop",
    value: function stop() {
      //    debug('stop ...')
      this.stop$.next();
    }
  }, {
    key: "cmdSuggesttion",
    value: function cmdSuggesttion() {
      return this.cmdSuggesttion$;
    }
  }, {
    key: "emptyInput",
    value: function emptyInput() {
      return this.input$.filter(utils["D" /* isEmptyValue */]);
    }
  }]);

  return Pockect;
}();


// EXTERNAL MODULE: external "ramda/src/keys"
var keys_ = __webpack_require__(21);
var keys__default = /*#__PURE__*/__webpack_require__.n(keys_);

// EXTERNAL MODULE: external "ramda/src/curry"
var curry_ = __webpack_require__(23);
var curry__default = /*#__PURE__*/__webpack_require__.n(curry_);

// EXTERNAL MODULE: external "ramda/src/contains"
var contains_ = __webpack_require__(17);
var contains__default = /*#__PURE__*/__webpack_require__.n(contains_);

// EXTERNAL MODULE: external "ramda/src/and"
var and_ = __webpack_require__(54);
var and__default = /*#__PURE__*/__webpack_require__.n(and_);

// EXTERNAL MODULE: external "ramda/src/toLower"
var toLower_ = __webpack_require__(16);
var toLower__default = /*#__PURE__*/__webpack_require__.n(toLower_);

// EXTERNAL MODULE: external "ramda/src/isNil"
var isNil_ = __webpack_require__(22);
var isNil__default = /*#__PURE__*/__webpack_require__.n(isNil_);

// EXTERNAL MODULE: external "ramda/src/any"
var any_ = __webpack_require__(151);
var any__default = /*#__PURE__*/__webpack_require__.n(any_);

// EXTERNAL MODULE: external "ramda/src/length"
var length_ = __webpack_require__(152);
var length__default = /*#__PURE__*/__webpack_require__.n(length_);

// EXTERNAL MODULE: external "ramda/src/equals"
var equals_ = __webpack_require__(75);
var equals__default = /*#__PURE__*/__webpack_require__.n(equals_);

// EXTERNAL MODULE: external "scroll-into-view-if-needed"
var external__scroll_into_view_if_needed_ = __webpack_require__(153);
var external__scroll_into_view_if_needed__default = /*#__PURE__*/__webpack_require__.n(external__scroll_into_view_if_needed_);

// CONCATENATED MODULE: ./containers/Doraemon/helper/swissArmyKnife.js














function swissArmyKnife__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }


var lengthE1 = compose__default()(equals__default()(1), length__default.a);
var lengthE2 = compose__default()(equals__default()(2), length__default.a);
var anyNil = any__default()(isNil__default.a);
var swissArmyKnife_SwissArmyKnife = function SwissArmyKnife(store) {
  var _this = this;

  swissArmyKnife__classCallCheck(this, SwissArmyKnife);

  Object.defineProperty(this, "completeInput", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value() {
      var into = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      if (anyNil([_this.store.prefix, _this.store.activeRaw])) return;

      var prefix = toLower__default()(_this.store.prefix);

      var activeRawLast = last__default()(_this.store.curCmdChain);

      var inputValue = ''; // TODO: support ? opt

      if (_this.store.prefix === '/') {
        inputValue = "".concat(prefix).concat(activeRawLast);
      } else {
        inputValue = "/".concat(prefix, "/").concat(activeRawLast);
      }

      if (into) inputValue = "".concat(inputValue, "/"); // debug('new input: ', newInput)

      _this.store.markState({
        inputValue: inputValue
      });
    }
  });
  Object.defineProperty(this, "scrollIfNeeded", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value() {
      try {
        /* eslint-disable no-undef */
        var activeRaw = _this.store.activeRaw;
        external__scroll_into_view_if_needed__default()(document.querySelector("#".concat(activeRaw)), true, {
          duration: 120
        });
        /* eslint-enable no-undef */
      } catch (e) {
        /* eslint-disable no-console */
        console.error('bad selector in scrollIntoViewIfNeeded', e);
        /* eslint-enable no-console */
      }
    }
  });
  Object.defineProperty(this, "navSuggestion", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(direction) {
      var _this$store = _this.store,
          prefix = _this$store.prefix,
          activeRaw = _this$store.activeRaw;
      if (anyNil([prefix, activeRaw]) || isEmpty__default()(activeRaw)) return false;

      if (direction === 'up') {
        _this.store.activeUp();
      } else {
        _this.store.activeDown();
      }

      _this.scrollIfNeeded();
    }
  });
  Object.defineProperty(this, "navToSuggestion", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(suggestion) {
      var activeSuggestion = suggestion.toJSON();

      _this.store.activeTo(activeSuggestion.raw);
    }
  });
  Object.defineProperty(this, "communityLinker", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(cmdpath) {
      return and__default()(contains__default()(head__default()(cmdpath), _this.communities), lengthE1(cmdpath));
    }
  });
  Object.defineProperty(this, "communityInsideLinker", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function value(cmdpath) {
      return and__default()(contains__default()(head__default()(cmdpath), _this.communities), lengthE2(cmdpath));
    }
  });
  Object.defineProperty(this, "stepTwoCmd", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: curry__default()(function (name, cmdpath) {
      return and__default()(equals__default()(name, head__default()(cmdpath)), lengthE2(cmdpath));
    })
  });
  Object.defineProperty(this, "stepOneCmd", {
    configurable: true,
    enumerable: true,
    writable: true,
    value: curry__default()(function (name, cmdpath) {
      return and__default()(equals__default()(name, head__default()(cmdpath)), lengthE1(cmdpath));
    })
  });
  this.store = store;
  this.communities = keys__default()(store.communities);
};
// CONCATENATED MODULE: ./containers/Doraemon/oauth_window.js
// From https://gist.github.com/gauravtiwari/2ae9f44aee281c759fe5a66d5c2721a2
// By https://gist.github.com/gauravtiwari

/* global window */

/* eslint-disable */
var popup = function popup(authUrl) {
  var windowArea = {
    width: Math.floor(window.outerWidth * 0.6),
    height: Math.floor(window.outerHeight * 0.5)
  };

  if (windowArea.width < 1000) {
    windowArea.width = 600;
  }

  if (windowArea.height < 630) {
    windowArea.height = 550;
  }

  windowArea.left = Math.floor(window.screenX + (window.outerWidth - windowArea.width) / 2);
  windowArea.top = Math.floor(window.screenY + (window.outerHeight - windowArea.height) / 3);
  var sep = authUrl.indexOf('?') !== -1 ? '&' : '?';
  var url = "".concat(authUrl).concat(sep);
  var windowOpts = "toolbar=0,scrollbars=1,status=1,resizable=1,location=1,menuBar=0,\n    width=".concat(windowArea.width, ",height=").concat(windowArea.height, ",\n    left=").concat(windowArea.left, ",top=").concat(windowArea.top);
  var authWindow = window.open(url, '_blank', windowOpts); // Create IE + others compatible event handler

  var eventMethod = window.addEventListener ? 'addEventListener' : 'attachEvent';
  var eventer = window[eventMethod];
  var messageEvent = eventMethod === 'attachEvent' ? 'onmessage' : 'message';
  /* const Timer = setInterval(() => { */
  // detect code here

  var scanTimer = setInterval(function () {
    /* const scanTimer = setTimeout(() => { */
    // console.log('authWindow.location.search: ', authWindow.location.search)
    // console.log('authWindow.location.location href: ', authWindow.location.href)
    if (authWindow.location.search === undefined && authWindow.location.href === undefined) {
      console.log('close for user close');
      clearInterval(scanTimer);
    }

    window.postMessage({
      from_child: authWindow.location.search
    }, window.location.href);
  }, 1000); // beforeunload not work here casue there is a redirect

  /*
  window[eventMethod]('beforeunload', () => {
    console.log('user close authWindow 2 ??')
     clearInterval(scanTimer)
  })
  */
  // Listen to message from child window

  var authPromise = new Promise(function (resolve, reject) {
    eventer(messageEvent, function (msg) {
      // This doesn't work in Chrome 59
      // if (e.origin !== window.SITE_DOMAIN) {
      // https://stackoverflow.com/questions/25098021/securityerror-blocked-a-frame-with-origin-from-accessing-a-cross-origin-frame
      if (
      /* eslint-disable */
      !~msg.origin.indexOf("".concat(window.location.protocol, "//").concat(window.location.host))
      /* eslint-enable */
      ) {
          clearInterval(scanTimer);
          authWindow.close();
          reject(new Error('Not allowed'));
        }

      if (msg.data.from_parent) {
        clearInterval(scanTimer);
        authWindow.close();
      } else {// clearInterval(Timer)
        // clearInterval(Timer)
        // authWindow.close()
        // reject('Unauthorised')
      }
    }, false);
  });
  return authPromise;
};
/* eslint-enable */


/* harmony default export */ var oauth_window = (popup);
// CONCATENATED MODULE: ./containers/Doraemon/logic.js













var logic_debug = Object(utils["G" /* makeDebugger */])('L:Doraemon');
var logic_store = null;
var pockect$ = null;
var SAK = null;
var cmdResolver = [];

var reposIsEmpty = compose__default()(isEmpty__default.a, prop__default()('reposData'));

var inputValueIsNotEmpty = compose__default()(not__default.a, isEmpty__default.a, prop__default()('inputValue'));

var isNotSearching = compose__default()(not__default.a, prop__default()('searching'));

function queryPocket() {
  pockect$.query(logic_store.inputValue);
}

function simuUserLogin() {
  var data = {
    id: '112',
    token: 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJtYXN0YW5pX3NlcnZlciIsImV4cCI6MTUyNTI2Nzc3NCwiaWF0IjoxNTI0MDU4MTc0LCJpc3MiOiJtYXN0YW5pX3NlcnZlciIsImp0aSI6IjdiNjdhYzJmLTIwMjYtNDMzNy04MjcyLTVmYjY0ZDMxMGVjNyIsIm5iZiI6MTUyNDA1ODE3Mywic3ViIjoiMTEyIiwidHlwIjoiYWNjZXNzIn0.mm0GuOhzs8UYikPZGnIKQpnGYJQiwzEtCx2xeRn1qcT3sOT6Yg3GvM303OxDoGHnrNf72HSjwVxiCO6mXkq8mg',
    nickname: 'mydearxym',
    avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
    bio: "everyday is the opportunity you can't get back,so live life to the fullest",
    fromGithub: true
  };
  utils["c" /* BStore */].set('user', data);
  logic_store.updateAccount(data);
}

function githubLoginHandler() {
  // header.openPreview(type)
  logic_debug('just previewAccount ..');
  var clientId = '3b4281c5e54ffd801f85';
  var info = 'from_github';
  var cb = 'http://www.coderplanets.com';
  var github = 'https://github.com/login/oauth/authorize';
  var url = "".concat(github, "?client_id=").concat(clientId, "&state=").concat(info, "&redirect_uri=").concat(cb); // debug(url)
  // sr71$.data().subscribe($solver(DataSolver, ErrSolver))
  // checkUserAccount()
  // return false
  // signinGithub('71b0c5169ebbb7a124b9')

  /* reference */

  /* http://www.graphql.college/implementing-github-oauth-flow-in-react */

  /* Global.location.href = url */

  /* console.log('getParameterByName:', getParameterByName('recoe')) */
  // popup('http://localhost:3000?code=djfiekdjfie')

  oauth_window(url);
  simuUserLogin();
  setTimeout(function () {
    // use normal-http to signinGithub
    // sync userinfo to store
    // finally:
    Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].LOGIN);
  }, 5000);
  /*
      Global.addEventListener('message', e => {
     if (e.origin === Global.location.origin) {
     if (e.data.from_child) {
     debug('收到合法消息: ', e.data)
     Global.postMessage({ from_parent: true }, Global.location.href)
     }
     }
     })
   */
}

var logic_initCmdResolver = function initCmdResolver() {
  cmdResolver = [{
    match: SAK.stepOneCmd('theme'),
    action: function action() {
      SAK.completeInput(true);
      queryPocket();
    }
  }, {
    match: SAK.stepOneCmd('login'),
    action: function action() {
      SAK.completeInput(true);
      queryPocket();
    }
  }, {
    match: SAK.stepOneCmd('debug'),
    action: function action() {
      SAK.completeInput(true);
      queryPocket();
      logic_store.markState({
        inputForOtherUse: true,
        inputValue: utils["h" /* Global */].localStorage.getItem('debug')
      });
    }
  }, {
    match: SAK.stepOneCmd('hforward'),
    action: function action() {
      logic_debug('SAK.stepOneCmd hforward');
    }
  }, {
    match: SAK.stepOneCmd('hbackward'),
    action: function action() {
      logic_debug('SAK.stepOneCmd hbackward');
    }
  }, {
    match: SAK.stepOneCmd('cheatsheet'),
    action: function action() {
      logic_debug('SAK.stepOneCmd cheatsheet');
      router__default.a.push({
        pathname: '/',
        query: {
          main: 'cheatsheet'
        }
      }, '/cheatsheet');
      logic_hidePanel();
    }
  }, {
    match: SAK.stepOneCmd('communities'),
    action: function action() {
      logic_debug('SAK.stepOneCmd communities');
      router__default.a.push({
        pathname: '/',
        query: {
          main: 'communities',
          sub: 'all'
        }
      }, '/communities/all');
      logic_hidePanel();
    }
  }, {
    match: SAK.stepTwoCmd('theme'),
    action: function action(cmdpath) {
      var theme = last__default()(cmdpath);

      logic_store.changeTheme(theme);
    }
  }, {
    match: SAK.stepTwoCmd('login'),
    action: function action(cmdpath) {
      logic_debug('stepTwoCmd login->: ', cmdpath);
      githubLoginHandler();
      logic_hidePanel();
      /* reference */

      /* http://www.graphql.college/implementing-github-oauth-flow-in-react */

      /* SAK.completeInput(true) */

      /* queryPocket() */
    }
  }, {
    match: SAK.stepTwoCmd('debug'),
    action: function action(cmdpath) {
      var cmd = last__default()(cmdpath);

      if (cmd === 'github') {
        utils["h" /* Global */].window.open('https://github.com/visionmedia/debug', '_blank');
      } else if (cmd === 'write') {
        utils["h" /* Global */].localStorage.setItem('debug', logic_store.inputValue);
        logic_hidePanel();
      }
    }
  }, {
    match: SAK.communityLinker,
    action: function action(cmdpath) {
      logic_debug('communityLinker: ', cmdpath); // Router.push(url, as)
      // TODO: use route store  method

      router__default.a.push({
        pathname: '/',
        query: {
          main: cmdpath[0]
        }
      }, cmdpath[0]);
      logic_hidePanel();
    }
  }, {
    match: SAK.communityInsideLinker,
    action: function action(cmdpath) {
      logic_debug('communityInsideLinker: ', cmdpath);
    }
  }];
};

var doCmd = function doCmd() {
  var cmd = logic_store.curCmdChain;
  if (!cmd) return;
  /* Do not use forEach, cause forEach will not break */

  for (var i = 0; i < cmdResolver.length; i += 1) {
    if (cmdResolver[i].match(cmd)) {
      return cmdResolver[i].action(cmd);
    }
  }

  return false;
};

function handleShortCuts(e) {
  //  debug('onKeyPress ..', e.key)
  switch (e.key) {
    case 'Tab':
      {
        SAK.completeInput();
        queryPocket();
        e.preventDefault();
        break;
      }

    case 'Enter':
      {
        doCmd(); // Cmder.doCmd()
        // pockect$.doCmd()

        e.preventDefault();
        break;
      }
    // Prevent default behavior in text input while pressing arrow up
    // https://stackoverflow.com/questions/1080532/prevent-default-behavior-in-text-input-while-pressing-arrow-up

    case 'ArrowUp':
      {
        navSuggestion('up');
        e.preventDefault();
        break;
      }

    case 'ArrowDown':
      {
        navSuggestion('down');
        e.preventDefault();
        break;
      }

    default:
      {
        //  debug('onKeyPress: ', e.key)
        break;
      }
  }
} // TODO: not found hinter logic ..

var repoNotFound = allPass__default()([reposIsEmpty, inputValueIsNotEmpty, isNotSearching]);
function navSuggestion(direction) {
  SAK.navSuggestion(direction);
} // mounseEnter

function navToSuggestion(suggestion) {
  SAK.navToSuggestion(suggestion);
}
function getPrefixLogo(prefix) {
  var _store2 = logic_store,
      subscribedCommunities = _store2.subscribedCommunities;

  if (isEmpty__default()(subscribedCommunities) || isEmpty__default()(prefix)) {
    return assets["b" /* DEFAULT_ICON */];
  }

  var index = findIndex__default()(function (e) {
    return e.raw === prefix;
  }, subscribedCommunities);

  if (index === -1) return assets["b" /* DEFAULT_ICON */];
  var logo = subscribedCommunities[index].logo;
  return logo;
}
function logic_hidePanel() {
  logic_store.hideDoraemon();
  pockect$.stop();
}
function inputOnChange(e) {
  var inputValue = e.target.value;
  logic_store.markState({
    inputValue: inputValue,
    cmdChain: null // searching: true,

  });
  queryPocket();
}
function logic_init(_store) {
  if (logic_store) return false;
  logic_store = _store;
  pockect$ = new Pockect_Pockect(logic_store);
  SAK = new swissArmyKnife_SwissArmyKnife(logic_store);
  logic_initCmdResolver();
  pockect$.cmdSuggesttion().subscribe(function (res) {
    // debug('--> loadSuggestions res: ', res)
    logic_store.loadSuggestions(res);
  });
  pockect$.emptyInput().subscribe(function () {
    logic_store.clearSuggestions();
  });
}
// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// CONCATENATED MODULE: ./containers/Doraemon/styles/index.js



var rotate360 =
/*#__PURE__*/
Object(external__styled_components_["keyframes"])(["from{transform:rotate(0deg);}to{transform:rotate(360deg);}"]);
var LoadingIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__LoadingIcon",
  componentId: "s1hpyqsp-0"
})(["fill:", ";width:30px;height:30px;margin-top:20px;animation:", " 2s linear infinite;"], Object(utils["W" /* theme */])('shell.searchIcon'), rotate360);
var AddOn =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__AddOn",
  componentId: "s1hpyqsp-1"
})(["margin-left:15px;width:25px;"]);
var PageOverlay =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PageOverlay",
  componentId: "s1hpyqsp-2"
})(["bottom:0;cursor:pointer;left:0;overflow:auto;position:fixed;right:0;top:0;z-index:1001;display:", ";"], function (_ref) {
  var visible = _ref.visible;
  return visible ? 'block' : 'none';
}); // flex-grow example: http://zhoon.github.io/css3/2014/08/23/flex.html

var PanelContainer =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PanelContainer",
  componentId: "s1hpyqsp-3"
})(["box-shadow:0 2px 4px 0 rgba(0,0,0,0.2),0 25px 50px 0 rgba(0,0,0,0.1);width:45vw;max-width:550px;position:fixed;top:12vh;z-index:1002;display:", ";left:50%;margin-left:-19vw;"], function (_ref2) {
  var visible = _ref2.visible;
  return visible ? 'block' : 'none';
});
var Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s1hpyqsp-4"
})(["width:100%;overflow:hidden;"]);
var SuggestionWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SuggestionWrapper",
  componentId: "s1hpyqsp-5"
})(["position:relative;display:", ";flex-direction:column;max-height:60vh;overflow-y:scroll;overflow-x:hidden;width:102%;"], function (_ref3) {
  var empty = _ref3.empty;
  return empty ? 'none' : 'flex';
}); // #001b21;

var BaseBar =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseBar",
  componentId: "s1hpyqsp-6"
})(["border:1px solid ", ";width:100%;height:70px;background:", ";color:white;display:flex;flex-direction:row;"], Object(utils["W" /* theme */])('shell.border'), Object(utils["W" /* theme */])('shell.barBg'));
var EditorBar =
/*#__PURE__*/
external__styled_components__default()(BaseBar).withConfig({
  displayName: "styles__EditorBar",
  componentId: "s1hpyqsp-7"
})(["position:relative;"]);
var AlertBar =
/*#__PURE__*/
external__styled_components__default()(BaseBar).withConfig({
  displayName: "styles__AlertBar",
  componentId: "s1hpyqsp-8"
})(["position:relative;padding:18px;color:#365760;&:before{content:'\u26A0 ';margin-right:10px;color:tomato;}"]);
var InfoBar =
/*#__PURE__*/
external__styled_components__default()(BaseBar).withConfig({
  displayName: "styles__InfoBar",
  componentId: "s1hpyqsp-9"
})(["padding:10px;min-height:70px;background:", ";"], function (_ref4) {
  var active = _ref4.active;
  return active ? Object(utils["W" /* theme */])('shell.activeBg') : '';
});
var InputBar =
/*#__PURE__*/
external__styled_components__default.a.input.withConfig({
  displayName: "styles__InputBar",
  componentId: "s1hpyqsp-10"
})(["caret-color:", ";flex-grow:1;font-family:'.SFNSText-Light','SF UI Text','Helvetica Neue','Arial','Lucida Grande','Segoe UI',Noto Sans,sans-serif;height:100%;width:auto;outline:none;font-weight:200;color:", ";font-size:1.6rem;max-height:none;background-color:transparent;padding:0 20px 0px 20px;border:0;border-radius:0;transition:all 400ms ease;"], Object(utils["W" /* theme */])('shell.searchInput'), Object(utils["W" /* theme */])('shell.searchInput'));
var AvatarWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__AvatarWrapper",
  componentId: "s1hpyqsp-11"
})(["width:10%;margin-right:10px;"]);
var AvatarImg =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__AvatarImg",
  componentId: "s1hpyqsp-12"
})(["width:100%;border-radius:50%;"]);
var ContentWraper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ContentWraper",
  componentId: "s1hpyqsp-13"
})(["color:tomato;text-align:left;flex-grow:1;"]);
var Title =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Title",
  componentId: "s1hpyqsp-14"
})(["display:block;font-size:1.5em;color:", ";> a{color:", ";}"], Object(utils["W" /* theme */])('shell.title'), Object(utils["W" /* theme */])('shell.link'));
var Desc =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Desc",
  componentId: "s1hpyqsp-15"
})(["color:", ";text-overflow:ellipsis;font-size:1.1em;width:90%;white-space:nowrap;overflow:hidden;margin-bottom:7px;"], Object(utils["W" /* theme */])('shell.desc'));
var Hint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Hint",
  componentId: "s1hpyqsp-16"
})(["color:", ";margin-top:10px;margin-right:15px;width:30px;font-size:1.1rem;"], Object(utils["W" /* theme */])('shell.desc'));
var HintEnter =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__HintEnter",
  componentId: "s1hpyqsp-17"
})(["color:", ";margin-top:10px;margin-right:1.5em;width:30px;height:30px;transform:rotateX(180deg);fill:", ";"], Object(utils["W" /* theme */])('shell.desc'), Object(utils["W" /* theme */])('shell.desc'));
var SubInfoWraper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SubInfoWraper",
  componentId: "s1hpyqsp-18"
})(["display:flex;justify-content:space-between;"]);
var RepoLang =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RepoLang",
  componentId: "s1hpyqsp-19"
})(["color:", ";font-style:italic;"], Object(utils["W" /* theme */])('shell.desc'));
var RepoStar =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__RepoStar",
  componentId: "s1hpyqsp-20"
})(["color:", ";font-style:italic;margin-right:10px;"], Object(utils["W" /* theme */])('shell.desc'));
var NodeSVGIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__NodeSVGIcon",
  componentId: "s1hpyqsp-21"
})(["width:40px;height:40px;margin-top:3px;transform:", ";"], function (_ref5) {
  var reverse = _ref5.reverse;
  return reverse ? 'rotate(180deg)' : '';
});
var ThemeDot =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ThemeDot",
  componentId: "s1hpyqsp-22"
})(["width:35px;height:35px;margin-top:5px;background:", ";border-radius:50%;"], function (_ref6) {
  var bg = _ref6.bg;
  return bg;
}); // TODO: rename -> PrefixIcon

var PrefixSVGIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__PrefixSVGIcon",
  componentId: "s1hpyqsp-23"
})(["width:30px;height:30px;margin-top:20px;"]);
var PrefixSearchIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__PrefixSearchIcon",
  componentId: "s1hpyqsp-24"
})(["width:30px;height:30px;margin-top:20px;fill:", ";"], Object(utils["W" /* theme */])('shell.searchIcon'));
var PrefixMagicIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__PrefixMagicIcon",
  componentId: "s1hpyqsp-25"
})(["width:30px;height:25px;margin-top:20px;transform:rotate(-30deg);"]);
// CONCATENATED MODULE: ./containers/Doraemon/InputEditor.js
var _dec, _dec2, _dec3, _desc, _value, _class;

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function InputEditor__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function InputEditor__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function InputEditor__createClass(Constructor, protoProps, staticProps) { if (protoProps) InputEditor__defineProperties(Constructor.prototype, protoProps); if (staticProps) InputEditor__defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
  var desc = {};
  Object['ke' + 'ys'](descriptor).forEach(function (key) {
    desc[key] = descriptor[key];
  });
  desc.enumerable = !!desc.enumerable;
  desc.configurable = !!desc.configurable;

  if ('value' in desc || desc.initializer) {
    desc.writable = true;
  }

  desc = decorators.slice().reverse().reduce(function (desc, decorator) {
    return decorator(target, property, desc) || desc;
  }, desc);

  if (context && desc.initializer !== void 0) {
    desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
    desc.initializer = undefined;
  }

  if (desc.initializer === void 0) {
    Object['define' + 'Property'](target, property, desc);
    desc = null;
  }

  return desc;
}

/*
 *
 * Doraemon:InputEditor
 *
 */




 // const debug = makeDebugger('C:Doraemon:InputEditor')

var InputEditor_PrefixIcon = function PrefixIcon(_ref) {
  var prefix = _ref.prefix;

  switch (prefix) {
    case '':
      {
        return external__react__default.a.createElement(PrefixSearchIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/search.svg")
        });
      }

    case '/':
      {
        return external__react__default.a.createElement(PrefixMagicIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/magic.svg")
        });
      }

    default:
      {
        return external__react__default.a.createElement(PrefixSVGIcon, {
          src: getPrefixLogo(prefix)
        });
      }
  }
};

var InputEditor_InputEditor = (_dec = external__react_keydown__default()(['ctrl+g', 'ctrl+c']), _dec2 = external__react_keydown__default()(['ctrl+p']), _dec3 = external__react_keydown__default()(['ctrl+n']), (_class =
/*#__PURE__*/
function (_React$Component) {
  _inherits(InputEditor, _React$Component);

  function InputEditor() {
    InputEditor__classCallCheck(this, InputEditor);

    return _possibleConstructorReturn(this, (InputEditor.__proto__ || Object.getPrototypeOf(InputEditor)).apply(this, arguments));
  }

  InputEditor__createClass(InputEditor, [{
    key: "hidePanel",

    /* eslint-disable class-methods-use-this */
    value: function hidePanel() {
      //     debug('this bitch? ')
      logic_hidePanel();
    } // Prevent default behavior in text input while pressing arrow up
    // https://stackoverflow.com/questions/1080532/prevent-default-behavior-in-text-input-while-pressing-arrow-up

  }, {
    key: "up",
    value: function up(e) {
      // console.log('keydown ctrl+p')
      navSuggestion('up');
      e.preventDefault();
    }
  }, {
    key: "down",
    value: function down(e) {
      navSuggestion('down');
      e.preventDefault();
    }
    /* eslint-enable class-methods-use-this */

  }, {
    key: "render",
    value: function render() {
      var _props = this.props,
          searching = _props.searching,
          value = _props.value,
          prefix = _props.prefix; // if you want to use innerRef
      // see https://github.com/styled-components/styled-components/issues/102
      // innerRef={input => (this.doraemonInput = input)}

      return external__react__default.a.createElement(EditorBar, null, external__react__default.a.createElement(AddOn, null, searching ? external__react__default.a.createElement(LoadingIcon, {
        src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/search_loading.svg")
      }) : external__react__default.a.createElement(InputEditor_PrefixIcon, {
        prefix: prefix
      })), external__react__default.a.createElement(InputBar, {
        id: "doraemonInputbar",
        spellCheck: false,
        autoCapitalize: "off",
        autoCorrect: "off",
        autoComplete: "off",
        onKeyDown: handleShortCuts,
        onBlur: logic_hidePanel,
        onChange: inputOnChange,
        value: value
      }));
    }
  }]);

  return InputEditor;
}(external__react__default.a.Component), (_applyDecoratedDescriptor(_class.prototype, "hidePanel", [_dec], Object.getOwnPropertyDescriptor(_class.prototype, "hidePanel"), _class.prototype), _applyDecoratedDescriptor(_class.prototype, "up", [_dec2], Object.getOwnPropertyDescriptor(_class.prototype, "up"), _class.prototype), _applyDecoratedDescriptor(_class.prototype, "down", [_dec3], Object.getOwnPropertyDescriptor(_class.prototype, "down"), _class.prototype)), _class));

// CONCATENATED MODULE: ./containers/Doraemon/NodeIcon.js
/*
 * render the icon based on suggestion type
 *
 */



 // const debug = makeDebugger('C:Doraemon:NodeIcon')

var NodeIcon_NodeIcon = function NodeIcon(_ref) {
  var _ref$suggestion = _ref.suggestion,
      raw = _ref$suggestion.raw,
      logo = _ref$suggestion.logo,
      cmd = _ref$suggestion.cmd;

  /* const lowerRaw = R.toLower(raw) */
  if (cmd === 'theme') {
    return external__react__default.a.createElement(ThemeDot, {
      bg: utils["Y" /* themeCoverMap */][raw]
    });
  }

  return external__react__default.a.createElement(NodeSVGIcon, {
    src: logo || assets["b" /* DEFAULT_ICON */]
  });
};

/* harmony default export */ var Doraemon_NodeIcon = (NodeIcon_NodeIcon);
// CONCATENATED MODULE: ./containers/Doraemon/index.js
function Doraemon__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { Doraemon__typeof = function _typeof(obj) { return typeof obj; }; } else { Doraemon__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return Doraemon__typeof(obj); }

function Doraemon__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function Doraemon__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function Doraemon__createClass(Constructor, protoProps, staticProps) { if (protoProps) Doraemon__defineProperties(Constructor.prototype, protoProps); if (staticProps) Doraemon__defineProperties(Constructor, staticProps); return Constructor; }

function Doraemon__possibleConstructorReturn(self, call) { if (call && (Doraemon__typeof(call) === "object" || typeof call === "function")) { return call; } return Doraemon__assertThisInitialized(self); }

function Doraemon__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function Doraemon__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * Magic Doraemon
 *
 */

 // import Link from 'next/link'
// import styled from 'styled-components'







/* eslint-disable no-unused-vars */

var Doraemon_debug = Object(utils["G" /* makeDebugger */])('C:Doraemon');
/* eslint-enable no-unused-vars */

var Doraemon_HintIcon = function HintIcon(_ref) {
  var index = _ref.index,
      active = _ref.active,
      cur = _ref.cur,
      length = _ref.length;

  if (active === cur) {
    return external__react__default.a.createElement(HintEnter, {
      src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/enter.svg")
    });
  }

  if (length <= 9) {
    return external__react__default.a.createElement(Hint, null, "^ ", index);
  }

  return external__react__default.a.createElement("span", null);
};

var Doraemon_DoraemonContainer =
/*#__PURE__*/
function (_React$Component) {
  Doraemon__inherits(DoraemonContainer, _React$Component);

  function DoraemonContainer() {
    Doraemon__classCallCheck(this, DoraemonContainer);

    return Doraemon__possibleConstructorReturn(this, (DoraemonContainer.__proto__ || Object.getPrototypeOf(DoraemonContainer)).apply(this, arguments));
  }

  Doraemon__createClass(DoraemonContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var doraemon = this.props.doraemon;
      logic_init(doraemon);
    } // ref={infobar => (this[`infobar${suggestion.title}`] = infobar)}
    // ref={wraper => (this.wraper = wraper)}

  }, {
    key: "render",
    value: function render() {
      var _this = this;

      var doraemon = this.props.doraemon;
      var inputValue = doraemon.inputValue,
          suggestions = doraemon.suggestions,
          activeRaw = doraemon.activeRaw,
          prefix = doraemon.prefix,
          visible = doraemon.visible,
          subscribedCommunities = doraemon.subscribedCommunities; // debug('activeRaw: ', activeRaw)
      // debug('suggestion.raw: ', suggestions.toJSON())

      return external__react__default.a.createElement("div", null, external__react__default.a.createElement(PageOverlay, {
        visible: visible,
        onClick: logic_hidePanel
      }), external__react__default.a.createElement(PanelContainer, {
        visible: visible
      }, external__react__default.a.createElement(InputEditor_InputEditor, {
        value: inputValue,
        searching: false,
        prefix: prefix,
        subscribedCommunities: subscribedCommunities
      }), repoNotFound(doraemon) && external__react__default.a.createElement(AlertBar, null, "Repo not found"), external__react__default.a.createElement(Wrapper, null, external__react__default.a.createElement(SuggestionWrapper, {
        empty: suggestions.length === 0
      }, suggestions.map(function (suggestion, i) {
        return external__react__default.a.createElement(InfoBar, {
          active: activeRaw === suggestion.raw,
          key: suggestion.raw,
          id: suggestion.raw,
          onMouseEnter: navToSuggestion.bind(_this, suggestion)
        }, external__react__default.a.createElement(AvatarWrapper, null, external__react__default.a.createElement(Doraemon_NodeIcon, {
          raw: suggestion.raw,
          suggestion: suggestion
        })), external__react__default.a.createElement(ContentWraper, null, external__react__default.a.createElement(Title, null, suggestion.title), external__react__default.a.createElement(Desc, null, suggestion.desc)), external__react__default.a.createElement(Doraemon_HintIcon, {
          index: i,
          active: activeRaw,
          cur: suggestion.raw,
          length: suggestions.length
        }));
      })))));
    }
  }]);

  return DoraemonContainer;
}(external__react__default.a.Component);

/* harmony default export */ var Doraemon = __webpack_exports__["a"] = (Object(external__mobx_react_["inject"])(Object(utils["T" /* storePlug */])('doraemon'))(Object(external__mobx_react_["observer"])(Doraemon_DoraemonContainer)));

/***/ }),
/* 94 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]),
    _templateObject2 = /*#__PURE__*/ _taggedTemplateLiteral(["\n  query account {\n    account {\n      company\n      education\n      location\n      qq\n      weibo\n      weichat\n      sex\n      githubProfile {\n        htmlUrl\n        login\n      }\n      contributes {\n        records {\n          count\n          date\n        }\n        startDate\n        endDate\n        totalCount\n      }\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var userRaw = "\n  query user($id: ID!) {\n    user(id: $id) {\n      id\n      nickname\n      avatar\n      bio\n      fromGithub\n      company\n      education\n      location\n      qq\n      weibo\n      weichat\n      sex\n      githubProfile {\n        htmlUrl\n        login\n      }\n      contributes {\n        records {\n          count\n          date\n        }\n        startDate\n        endDate\n        totalCount\n      }\n    }\n  }\n";
var user = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, userRaw); // TODO: use user schema

var account = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject2);
var schema = {
  account: account,
  user: user,
  userRaw: userRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 95 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  ", "\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var postRaw = "\n  query post($id: ID!) {\n    post(id: $id) {\n      id\n      title\n      body\n      insertedAt\n      updatedAt\n      views\n      length\n      author {\n        id\n        avatar\n        nickname\n      }\n      favoritedCount\n      starredCount\n      communities {\n        id\n        title\n        logo\n      }\n      tags {\n        id\n        title\n        color\n      }\n    }\n  }\n";
var post = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject, postRaw);
var schema = {
  post: post,
  postRaw: postRaw
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 96 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  query($filter: CommunitiesFilter!, $userHasLogin: Boolean!) {\n    pagedCommunities(filter: $filter) {\n      entries {\n        id\n        title\n        desc\n        raw\n        logo\n        contributesDigest\n        subscribersCount\n        viewerHasSubscribed @include(if: $userHasLogin)\n      }\n      pageNumber\n      pageSize\n      totalCount\n      totalPages\n    }\n  }\n"]),
    _templateObject2 = /*#__PURE__*/ _taggedTemplateLiteral(["\n  mutation($communityId: ID!) {\n    subscribeCommunity(communityId: $communityId) {\n      id\n      title\n      raw\n      logo\n      contributesDigest\n      threads {\n        title\n        raw\n      }\n    }\n  }\n"]),
    _templateObject3 = /*#__PURE__*/ _taggedTemplateLiteral(["\n  mutation($communityId: ID!) {\n    unsubscribeCommunity(communityId: $communityId) {\n      id\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var pagedCommunities = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject);
var pagedCommunitiesRaw = "\n  query($filter: CommunitiesFilter!, $userHasLogin: Boolean!) {\n    pagedCommunities(filter: $filter) {\n      entries {\n        id\n        title\n        desc\n        raw\n        logo\n        contributesDigest\n        subscribersCount\n        viewerHasSubscribed @include(if: $userHasLogin)\n      }\n      pageNumber\n      pageSize\n      totalCount\n      totalPages\n    }\n  }\n";
var subscribeCommunity = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject2);
var unsubscribeCommunity = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject3);
var schema = {
  pagedCommunities: pagedCommunities,
  pagedCommunitiesRaw: pagedCommunitiesRaw,
  subscribeCommunity: subscribeCommunity,
  unsubscribeCommunity: unsubscribeCommunity
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),
/* 97 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__(0);


var MarkDownStyle =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components___default.a.div.withConfig({
  displayName: "MarkDownStyle",
  componentId: "dybdnr-0"
})(["@font-face{font-family:octicons-link;src:url(data:font/woff;charset=utf-8;base64,d09GRgABAAAAAAZwABAAAAAACFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEU0lHAAAGaAAAAAgAAAAIAAAAAUdTVUIAAAZcAAAACgAAAAoAAQAAT1MvMgAAAyQAAABJAAAAYFYEU3RjbWFwAAADcAAAAEUAAACAAJThvmN2dCAAAATkAAAABAAAAAQAAAAAZnBnbQAAA7gAAACyAAABCUM+8ihnyxnwaaagtaaaabaaaaaqaboai2dsewyaaafsaaabpaaaazwceq9tagvhzaaaasgaaaa0aaaangh4a91oagvhaaadcaaaaboaaaakca8drghtdhgaaal8aaaadaaaaawgaacfbg9jyqaaasaaaaaiaaaacabiatbtyxhwaaacqaaaabgaaaagaa8asm5hbwuaaatoaaabqgaaalxu73socg9zdaaabiwaaaaeaaaame3qpobwcmvwaaaebaaaahyaaab/aFGpk3jaTY6xa8JAGMW/O62BDi0tJLYQincXEypYIiGJjSgHniQ6umTsUEyLm5BV6NDBP8Tpts6F0v+k/0an2i+itHDw3v2+9+DBKTzsJNnWJNTgHEy4BgG3EMI9DCEDOGEXzDADU5hBKMIgNPZqoD3SilVaXZCER3/I7AtxEJLtzzuZfI+VVkprxTlXShWKb3TBecG11rwoNlmmn1P2WYcJczl32etSpKnziC7lQyWe1smVPy/Lt7Kc+0vwy/gAgIIEqAN9we0pwKXreiMasxvabDQMM4riO+qxM2ogwDGOZTXxwxDiycQIcoYFBLj5K3EIaSctAq2kTYiw+ymhce7vwM9jSqO8JyVd5RH9gyTt2+J/yUmYlIR0s04n6+7vm1ozezueleaujhadsuxhwvrgvljn1tq7xiuvv/ocTRF42mNgZGBgYGbwZOBiAAFGJBIMAAizAFoAAABiAGIAznjaY2BkYGAA4in8zwXi+W2+MjCzMIDApSwvXzC97Z4Ig8N/BxYGZgcgl52BCSQKAA3jCV8CAABfAAAAAAQAAEB42mNgZGBg4f3vACQZQABIMjKgAmYAKEgBXgAAeNpjYGY6wTiBgZWBg2kmUxoDA4MPhGZMYzBi1AHygVLYQUCaawqDA4PChxhmh/8ODDEsvAwHgMKMIDnGL0x7gJQCAwMAJd4MFwAAAHjaY2BgYGaA4DAGRgYQkAHyGMF8NgYrIM3JIAGVYYDT+AEjAwuDFpBmA9KMDEwMCh9i/v8H8sH0/4dQc1iAmAkALaUKLgAAAHjaTY9LDsIgEIbtgqHUPpDi3gPoBVyRTmTddOmqTXThEXqrob2gQ1FjwpDvfwCBdmdXC5AVKFu3e5MfNFJ29KTQT48Ob9/lqYwOGZxeUelN2U2R6+cArgtCJpauW7UQBqnFkUsjAY/kOU1cP+DAgvxwn1chZDwUbd6CFimGXwzwF6tPbFIcjEl+vvmM/byA48e6tWrKArm4ZJlCbdsrxksL1AwWn/yBSJKpYbq8AXaaTb8AAHja28jAwOC00ZrBeQNDQOWO//sdBBgYGRiYWYAEELEwMTE4uzo5Zzo5b2BxdnFOcALxNjA6b2ByTswC8jYwg0VlNuoCTWAMqNzMzsoK1rEhNqByEyerg5PMJlYuVueETKcd/89uBpnpvIEVomeHLoMsAAe1Id4AAAAAAAB42oWQT07CQBTGv0JBhagk7HQzKxca2sJCE1hDt4QF+9jos0nbaaydcqfwcj7au3ahj+LO13FMmm6cl7785vven0kBjHCBhfpYuNa5Ph1c0e2Xu3jEvWG7UdPDLZ4N92nOm+EBXuAbHmIMSRMs+4aued4nd3chd8ndvoltsa2gl8m9podbcl+hD7C1xoaHeLJSEao0FEW14ckxC+TU8TxvsY6X0eLPmRhry2WVioLpkrbp84LLQPGI7c6sOiUzpWIWS5GzlSgUzzLBSikOPFTOXqly7rqx0Z1Q5BAIoZBSFihQYQOOBEdkCOgXTOHA07HAGjGWiIjaPZNW13/+lm6S9FT7rLHFJ6fQbkATOG1j2OFMucKJJsxIVfQORl+9jyda6sl1duyhscm1dyclfoedve4qmydlebfqhf3o/AdDumsjAAB42mNgYoAAZQYjBmyAGYQZmdhL8zLdDEydARfoAqIAAAABAAMABwAKABMAB///AA8AAQAAAAAAAAAAAAAAAAABAAAAAA==);}.markdown-body{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;line-height:1.5;color:", ";font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol';font-size:16px;line-height:1.5;word-wrap:break-word;}.markdown-body .pl-c{color:#6a737d;}.markdown-body .pl-c1,.markdown-body .pl-s .pl-v{color:#005cc5;}.markdown-body .pl-e,.markdown-body .pl-en{color:#6f42c1;}.markdown-body .pl-smi,.markdown-body .pl-s .pl-s1{color:#24292e;}.markdown-body .pl-ent{color:#22863a;}.markdown-body .pl-k{color:#d73a49;}.markdown-body .pl-s,.markdown-body .pl-pds,.markdown-body .pl-s .pl-pse .pl-s1,.markdown-body .pl-sr,.markdown-body .pl-sr .pl-cce,.markdown-body .pl-sr .pl-sre,.markdown-body .pl-sr .pl-sra{color:#032f62;}.markdown-body .pl-v,.markdown-body .pl-smw{color:#e36209;}.markdown-body .pl-bu{color:#b31d28;}.markdown-body .pl-ii{color:#fafbfc;background-color:#b31d28;}.markdown-body .pl-c2{color:#fafbfc;background-color:#d73a49;}.markdown-body .pl-c2::before{content:'^M';}.markdown-body .pl-sr .pl-cce{font-weight:bold;color:#22863a;}.markdown-body .pl-ml{color:#735c0f;}.markdown-body .pl-mh,.markdown-body .pl-mh .pl-en,.markdown-body .pl-ms{font-weight:bold;color:#005cc5;}.markdown-body .pl-mi{font-style:italic;color:#24292e;}.markdown-body .pl-mb{font-weight:bold;color:#24292e;}.markdown-body .pl-md{color:#b31d28;background-color:#ffeef0;}.markdown-body .pl-mi1{color:#22863a;background-color:#f0fff4;}.markdown-body .pl-mc{color:#e36209;background-color:#ffebda;}.markdown-body .pl-mi2{color:#f6f8fa;background-color:#005cc5;}.markdown-body .pl-mdr{font-weight:bold;color:#6f42c1;}.markdown-body .pl-ba{color:#586069;}.markdown-body .pl-sg{color:#959da5;}.markdown-body .pl-corl{text-decoration:underline;color:#032f62;}.markdown-body .octicon{display:inline-block;vertical-align:text-top;fill:currentColor;}.markdown-body a{background-color:transparent;-webkit-text-decoration-skip:objects;}.markdown-body a:active,.markdown-body a:hover{outline-width:0;}.markdown-body strong{font-weight:inherit;}.markdown-body strong{font-weight:normal !important;color:", ";background-color:", ";}.markdown-body h1{font-size:2em;margin:0.67em 0;}.markdown-body img{border-style:none;}.markdown-body svg:not(:root){overflow:hidden;}.markdown-body code,.markdown-body kbd,.markdown-body pre{font-family:monospace,monospace;font-size:1em;}.markdown-body hr{box-sizing:content-box;height:0;overflow:visible;}.markdown-body input{font:inherit;margin:0;}.markdown-body input{overflow:visible;}.markdown-body [type='checkbox']{box-sizing:border-box;padding:0;}.markdown-body *{box-sizing:border-box;}.markdown-body input{font-family:inherit;font-size:inherit;line-height:inherit;}.markdown-body a{color:", ";text-decoration:none;}.markdown-body a:hover{text-decoration:underline;}.markdown-body strong{font-weight:600;}.markdown-body hr{height:0;margin:15px 0;overflow:hidden;background:transparent;border:0;border-bottom:1px solid #dfe2e5;}.markdown-body hr::before{display:table;content:'';}.markdown-body hr::after{display:table;clear:both;content:'';}.markdown-body table{border-spacing:0;border-collapse:collapse;}.markdown-body td,.markdown-body th{padding:0;}.markdown-body h1,.markdown-body h2,.markdown-body h3,.markdown-body h4,.markdown-body h5,.markdown-body h6{margin-top:0;margin-bottom:0;color:", ";}.markdown-body h1{font-size:32px;font-weight:600;}.markdown-body h2{font-size:24px;font-weight:600;}.markdown-body h3{font-size:20px;font-weight:600;}.markdown-body h4{font-size:16px;font-weight:600;}.markdown-body h5{font-size:14px;font-weight:600;}.markdown-body h6{font-size:12px;font-weight:600;}.markdown-body p{margin-top:0;margin-bottom:10px;}.markdown-body blockquote{margin:0;}.markdown-body ul,.markdown-body ol{padding-left:0;margin-top:0;margin-bottom:0;}.markdown-body ol ol,.markdown-body ul ol{list-style-type:lower-roman;}.markdown-body ul ul ol,.markdown-body ul ol ol,.markdown-body ol ul ol,.markdown-body ol ol ol{list-style-type:lower-alpha;}.markdown-body dd{margin-left:0;}.markdown-body code{font-family:'SFMono-Regular',Consolas,'Liberation Mono',Menlo,Courier,monospace;font-size:12px;}.markdown-body pre{margin-top:0;margin-bottom:0;font-family:'SFMono-Regular',Consolas,'Liberation Mono',Menlo,Courier,monospace;font-size:12px;}.markdown-body .octicon{vertical-align:text-bottom;}.markdown-body .pl-0{padding-left:0 !important;}.markdown-body .pl-1{padding-left:4px !important;}.markdown-body .pl-2{padding-left:8px !important;}.markdown-body .pl-3{padding-left:16px !important;}.markdown-body .pl-4{padding-left:24px !important;}.markdown-body .pl-5{padding-left:32px !important;}.markdown-body .pl-6{padding-left:40px !important;}.markdown-body::before{display:table;content:'';}.markdown-body::after{display:table;clear:both;content:'';}.markdown-body > *:first-child{margin-top:0 !important;}.markdown-body > *:last-child{margin-bottom:0 !important;}.markdown-body a:not([href]){color:inherit;text-decoration:none;}.markdown-body .anchor{float:left;padding-right:4px;margin-left:-20px;line-height:1;}.markdown-body .anchor:focus{outline:none;}.markdown-body p,.markdown-body blockquote,.markdown-body ul,.markdown-body ol,.markdown-body dl,.markdown-body table,.markdown-body pre{margin-top:0;margin-bottom:16px;}.markdown-body hr{height:0.25em;padding:0;margin:24px 0;background-color:#e1e4e8;border:0;}.markdown-body blockquote{padding:0 1em;color:", ";border-left:", ";font-style:italic;}.markdown-body blockquote >:first-child{margin-top:0;}.markdown-body blockquote >:last-child{margin-bottom:0;}.markdown-body kbd{display:inline-block;padding:3px 5px;font-size:11px;line-height:10px;color:#444d56;vertical-align:middle;background-color:#fafbfc;border:solid 1px #c6cbd1;border-bottom-color:#959da5;border-radius:3px;box-shadow:inset 0 -1px 0 #959da5;}.markdown-body h1,.markdown-body h2,.markdown-body h3,.markdown-body h4,.markdown-body h5,.markdown-body h6{margin-top:24px;margin-bottom:16px;font-weight:600;line-height:1.25;}.markdown-body h1 .octicon-link,.markdown-body h2 .octicon-link,.markdown-body h3 .octicon-link,.markdown-body h4 .octicon-link,.markdown-body h5 .octicon-link,.markdown-body h6 .octicon-link{color:#1b1f23;vertical-align:middle;visibility:hidden;}.markdown-body h1:hover .anchor,.markdown-body h2:hover .anchor,.markdown-body h3:hover .anchor,.markdown-body h4:hover .anchor,.markdown-body h5:hover .anchor,.markdown-body h6:hover .anchor{text-decoration:none;}.markdown-body h1:hover .anchor .octicon-link,.markdown-body h2:hover .anchor .octicon-link,.markdown-body h3:hover .anchor .octicon-link,.markdown-body h4:hover .anchor .octicon-link,.markdown-body h5:hover .anchor .octicon-link,.markdown-body h6:hover .anchor .octicon-link{visibility:visible;}.markdown-body h1{padding-bottom:0.3em;font-size:2em;border-bottom:1px solid;border-bottom-color:", ";}.markdown-body h2{padding-bottom:0.3em;font-size:1.5em;border-bottom:1px solid;border-bottom-color:", ";}.markdown-body h3{font-size:1.25em;}.markdown-body h4{font-size:1em;}.markdown-body h5{font-size:0.875em;}.markdown-body h6{font-size:0.85em;color:", ";}.markdown-body ul,.markdown-body ol{padding-left:1.2em !important;}.markdown-body ol{display:block;list-style-type:decimal;-webkit-margin-before:1em;-webkit-margin-after:1em;-webkit-margin-start:0px;-webkit-margin-end:0px;-webkit-padding-start:40px;}.markdown-body ul{display:block;list-style-type:disc;-webkit-margin-before:1em;-webkit-margin-after:1em;-webkit-margin-start:0px;-webkit-margin-end:0px;-webkit-padding-start:40px;}.markdown-body ul ul,.markdown-body ul ol,.markdown-body ol ol,.markdown-body ol ul{margin-top:0;margin-bottom:0;}.markdown-body li > p{margin-top:16px;}.markdown-body li + li{margin-top:0.25em;}.markdown-body dl{padding:0;}.markdown-body dl dt{padding:0;margin-top:16px;font-size:1em;font-style:italic;font-weight:600;}.markdown-body dl dd{padding:0 16px;margin-bottom:16px;}.markdown-body table{display:block;width:100%;overflow:auto;}.markdown-body table th{font-weight:600;}.markdown-body table th,.markdown-body table td{padding:6px 13px;border:", ";}.markdown-body table tr{background-color:", ";border-top:", ";}.markdown-body table tr:nth-child(2n){background-color:", ";}.markdown-body img{max-width:50%;box-sizing:content-box;display:block;margin-left:auto;margin-right:auto;}.markdown-body img[align='right']{padding-left:20px;}.markdown-body img[align='left']{padding-right:20px;}.markdown-body code{padding:0;padding-top:0.2em;padding-bottom:0.2em;margin:0;font-size:85%;background-color:", ";border-radius:3px;}.markdown-body code::before,.markdown-body code::after{letter-spacing:-0.2em;content:'\0a0';}.markdown-body pre{word-wrap:normal;}.markdown-body pre > code{padding:0;margin:0;font-size:100%;word-break:normal;white-space:pre;background:transparent;border:0;}.markdown-body .highlight{margin-bottom:16px;}.markdown-body .highlight pre{margin-bottom:0;word-break:normal;}.markdown-body pre{padding:16px;overflow:auto;font-size:85%;line-height:1.45;background-color:", ";border-radius:3px;}.markdown-body pre code{display:inline;max-width:auto;padding:0;margin:0;overflow:visible;line-height:inherit;word-wrap:normal;background-color:transparent;border:0;}.markdown-body pre code::before,.markdown-body pre code::after{content:normal;}.markdown-body .full-commit .btn-outline:not(:disabled):hover{color:#005cc5;border-color:#005cc5;}.markdown-body kbd{display:inline-block;padding:3px 5px;font:11px 'SFMono-Regular',Consolas,'Liberation Mono',Menlo,Courier,monospace;line-height:10px;color:#444d56;vertical-align:middle;background-color:#fafbfc;border:solid 1px #d1d5da;border-bottom-color:#c6cbd1;border-radius:3px;box-shadow:inset 0 -1px 0 #c6cbd1;}.markdown-body:checked + .radio-label{position:relative;z-index:1;border-color:#0366d6;}.markdown-body .task-list-item{list-style-type:none;}.markdown-body .task-list-item + .task-list-item{margin-top:3px;}.markdown-body .task-list-item input{margin:0 0.2em 0.25em -1.6em;vertical-align:middle;}.markdown-body hr{border-bottom-color:", ";}.markdown-body .task-done{margin-left:-1.2em;list-style-type:none;&:before{content:'[o]';color:", ";margin-right:0.5em;}}.markdown-body .task-pending{margin-left:-1.2em;list-style-type:none;&:before{content:'[-]';color:", ";margin-right:0.5em;}}"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.fg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.strongFg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.strongBg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.link'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.title'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.blockquoteFg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.blockquoteBorder'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.titleBottom'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.titleBottom'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.title'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.tableborder'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.tableBg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.tableborder'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.tableBg2n'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('code.bg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('code.bg'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.hrColor'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.taskDone'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["W" /* theme */])('markdown.taskPeding'));
/* harmony default export */ __webpack_exports__["a"] = (MarkDownStyle);
/*
   background: #0A2A35;
   margin-top: 0;
   margin-bottom: 0;
   padding-top: 10px;
   padding-bottom: 10px;
   padding-left: 0.6em;
   color: #3B6E9D;
 */

/***/ }),
/* 98 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "mobx-state-tree"
var external__mobx_state_tree_ = __webpack_require__(5);
var external__mobx_state_tree__default = /*#__PURE__*/__webpack_require__.n(external__mobx_state_tree_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "ramda/src/omit"
var omit_ = __webpack_require__(109);
var omit__default = /*#__PURE__*/__webpack_require__.n(omit_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(36);
var router__default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// CONCATENATED MODULE: ./containers/Route/store.js


/*
 * RouteStore store
 *
 */




/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('S:RouteStore');
/* eslint-enable no-unused-vars */

var Query = external__mobx_state_tree_["types"].model('Query', {
  page: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '1'),
  size: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, String(config["h" /* PAGE_SIZE */].COMMON)) // sort .... [when, ...]
  // view ... [chart, list ...]

});
var RouteStore = external__mobx_state_tree_["types"].model('RouteStore', {
  mainPath: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  subPath: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  query: external__mobx_state_tree_["types"].optional(Query, {})
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      var mainPath = self.mainPath,
          subPath = self.subPath;
      return {
        mainPath: mainPath,
        subPath: subPath
      };
    }

  };
}).actions(function (self) {
  return {
    markRoute: function markRoute(query) {
      if (!utils["N" /* onClient */]) return false;
      var _query = query,
          mainPath = _query.mainPath,
          subPath = _query.subPath,
          page = _query.page;

      if (mainPath) {
        self.mainPath = mainPath;
      }

      if (subPath) {
        self.subPath = subPath;
      }

      if (page && String(page) === '1') {
        query = omit__default()(['page'], query);
      }

      var allQueryString = Object(utils["R" /* serializeQuery */])(query);
      var queryString = Object(utils["R" /* serializeQuery */])(omit__default()(['mainPath', 'subPath'], query));
      var url = "/".concat(allQueryString);
      var asPath = "/".concat(self.mainPath, "/").concat(self.subPath).concat(queryString); // NOTE: shallow option only works for same page url
      // if page is diffrent, it will cause page reload

      /* console.log('push url: ', url) */

      router__default.a.push(url, asPath, {
        shallow: true
      }); // see: https://stackoverflow.com/questions/824349/modify-the-url-without-reloading-the-page

      /* return Global.history.pushState({}, null, url) */
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var store = (RouteStore);
// EXTERNAL MODULE: external "ramda/src/remove"
var remove_ = __webpack_require__(110);
var remove__default = /*#__PURE__*/__webpack_require__.n(remove_);

// EXTERNAL MODULE: external "ramda/src/propEq"
var propEq_ = __webpack_require__(37);
var propEq__default = /*#__PURE__*/__webpack_require__.n(propEq_);

// EXTERNAL MODULE: external "ramda/src/findIndex"
var findIndex_ = __webpack_require__(25);
var findIndex__default = /*#__PURE__*/__webpack_require__.n(findIndex_);

// EXTERNAL MODULE: external "ramda/src/insert"
var insert_ = __webpack_require__(60);
var insert__default = /*#__PURE__*/__webpack_require__.n(insert_);

// EXTERNAL MODULE: external "ramda/src/merge"
var merge_ = __webpack_require__(13);
var merge__default = /*#__PURE__*/__webpack_require__.n(merge_);

// EXTERNAL MODULE: external "store"
var external__store_ = __webpack_require__(59);
var external__store__default = /*#__PURE__*/__webpack_require__.n(external__store_);

// CONCATENATED MODULE: ./stores/SharedModel/Community.js

 // NOTE: the SimpleXXX version is to avoid circle import issue which cause MST error

var Thread = external__mobx_state_tree_["types"].model('Thread', {
  title: external__mobx_state_tree_["types"].string,
  raw: external__mobx_state_tree_["types"].string
});
var SimpleCategory = external__mobx_state_tree_["types"].model('Category', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string)
});
var Community = external__mobx_state_tree_["types"].model('Community', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  desc: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  raw: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  logo: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  categories: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(SimpleCategory), []),
  contributesDigest: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(external__mobx_state_tree_["types"].number), []),
  subscribersCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  editorsCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  postsCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  viewerHasSubscribed: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].boolean),
  threads: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Thread), []),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedCommunities = external__mobx_state_tree_["types"].model('PagedCommunities', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Community), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Article.js

var Article = external__mobx_state_tree_["types"].model('Article', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  desc: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
/* harmony default export */ var SharedModel_Article = (Article);
// CONCATENATED MODULE: ./stores/SharedModel/User.js



var SubscribedCommunities = external__mobx_state_tree_["types"].model('SubscribedCommunities', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Community), []),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
var ContributeRecord = external__mobx_state_tree_["types"].model('ContributeRecord', {
  date: external__mobx_state_tree_["types"].string,
  count: external__mobx_state_tree_["types"].number
});
var Contributes = external__mobx_state_tree_["types"].model('Contributes', {
  records: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(ContributeRecord), []),
  startDate: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  endDate: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  totalCount: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].number)
});
var GithubProfile = external__mobx_state_tree_["types"].model('GithubProfile', {
  login: external__mobx_state_tree_["types"].string,
  htmlUrl: external__mobx_state_tree_["types"].string
});
var User = external__mobx_state_tree_["types"].model('User', {
  // identifier is desiged to be immutable, this id would be updated when login

  /* id: t.optional(t.string, ''), */
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),

  /* nickname: t.optional(t.string, ''), */
  nickname: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),

  /* bio: t.optional(t.string, ''), */
  bio: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),

  /* avatar: t.optional(t.string, ''), */
  avatar: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  email: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  location: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  company: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  education: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  sex: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  qq: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  weichat: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  weibo: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  fromGithub: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),

  /* fromWeixin: t.optional(t.boolean, false), */

  /* subscribedCommunities: t.optional(SubscribedCommunities, {}), */
  subscribedCommunities: external__mobx_state_tree_["types"].maybe(SubscribedCommunities),
  subscribedCommunitiesCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  contributes: external__mobx_state_tree_["types"].optional(Contributes, {}),
  githubProfile: external__mobx_state_tree_["types"].maybe(GithubProfile),
  cmsPassportString: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var SimpleUser = external__mobx_state_tree_["types"].model('SimpleUser2', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  nickname: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  bio: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  avatar: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string)
});
var EmptyUser = {
  id: '',
  nickname: '',
  bio: '',
  avatar: '',
  fromGithub: false,
  fromWeixin: false,
  subscribedCommunities: {},
  contributes: {},
  githubProfile: null
};
var PagedUsers = external__mobx_state_tree_["types"].model('PagedUsers', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(User), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Comment.js



var CommentBrief = external__mobx_state_tree_["types"].model('CommentBrief', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  body: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  floor: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].number),
  author: external__mobx_state_tree_["types"].optional(User, {})
});
var Comment = external__mobx_state_tree_["types"].model('Comment', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  body: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  author: external__mobx_state_tree_["types"].optional(User, {}),
  floor: external__mobx_state_tree_["types"].number,
  replyTo: external__mobx_state_tree_["types"].maybe(CommentBrief),
  replies: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(CommentBrief), []),
  contributesDigest: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(external__mobx_state_tree_["types"].number), []),
  repliesCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  likesCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  dislikesCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  viewerHasLiked: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].boolean),
  viewerHasDisliked: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].boolean),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedComments = external__mobx_state_tree_["types"].model('PagedComments', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Comment), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Tag.js



var Tag = external__mobx_state_tree_["types"].model('Tag', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  color: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('color', config["i" /* TAG_COLORS */]), config["i" /* TAG_COLORS */][0]),
  thread: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('thread', config["b" /* CMS_THREADS */]), config["b" /* CMS_THREADS */][0]),
  community: external__mobx_state_tree_["types"].maybe(Community),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedTags = external__mobx_state_tree_["types"].model('PagedTags', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Post.js






var Post = external__mobx_state_tree_["types"].model('Post', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  body: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  digest: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  // author: t.optional(User, {}),
  author: external__mobx_state_tree_["types"].maybe(User),
  communities: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Community), []),
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  comments: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Comment), []),
  commentsCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  commentsParticipatorsCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  commentsParticipators: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(User), []),
  views: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  length: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  favoritedCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  starredCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  viewerHasFavorited: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  viewerHasStarred: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedPosts = external__mobx_state_tree_["types"].model('PagedPosts', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Post), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Video.js




/* import { Comment } from './Comment' */


var Video = external__mobx_state_tree_["types"].model('Video', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  desc: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  duration: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),

  /* durationDec: t.maybe(t.number), */
  author: external__mobx_state_tree_["types"].maybe(User),
  source: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  link: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  originalAuthor: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  originalAuthorLink: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  views: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  communities: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Community), []),
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),

  /* comments: t.optional(t.array(Comment), []), */
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedVideos = external__mobx_state_tree_["types"].model('PagedVideos', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Video), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Repo.js





var Repo = external__mobx_state_tree_["types"].model('Reop', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  repoName: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  desc: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  readme: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  language: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  author: external__mobx_state_tree_["types"].maybe(User),
  repoLink: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  producer: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  producerLink: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  repoStarCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  repoForkCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  repoWatchCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  views: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  communities: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Community), []),
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedRepos = external__mobx_state_tree_["types"].model('PagedRepos', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Repo), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Job.js






var Job = external__mobx_state_tree_["types"].model('Job', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  body: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  digest: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  // author: t.optional(User, {}),
  author: external__mobx_state_tree_["types"].maybe(User),
  communities: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Community), []),
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  comments: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Comment), []),
  commentsCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  commentsParticipatorsCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  commentsParticipators: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(User), []),
  views: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  favoritedCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  starredCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedJobs = external__mobx_state_tree_["types"].model('PagedJobs', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Job), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/Category.js

 // NOTE: the SimpleXXX version is to avoid circle import issue which cause MST error

var SimpleCommunity = external__mobx_state_tree_["types"].model('SimpleCommunity', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  desc: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  raw: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  logo: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string)
});
var Category_SimpleUser = external__mobx_state_tree_["types"].model('SimpleUser', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  nickname: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  bio: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  avatar: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string)
});
var Category = external__mobx_state_tree_["types"].model('Category', {
  id: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  title: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  raw: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  communities: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(SimpleCommunity), []),
  author: external__mobx_state_tree_["types"].optional(Category_SimpleUser, {}),
  insertedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  updatedAt: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
});
var PagedCategories = external__mobx_state_tree_["types"].model('PagedCategories', {
  entries: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Category), []),
  pageNumber: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 1),
  pageSize: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, config["h" /* PAGE_SIZE */].COMMON),
  totalCount: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  totalPages: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0)
});
// CONCATENATED MODULE: ./stores/SharedModel/index.js










var emptyPagiData = {
  entries: [],
  pageNumber: 1,
  pageSize: 20,
  totalCount: 0,
  totalPages: 0
};
// CONCATENATED MODULE: ./stores/AccountStore/index.js






function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * AccountStore store
 *
 */




/* eslint-disable no-unused-vars */

var AccountStore_debug = Object(utils["G" /* makeDebugger */])('S:AccountStore');
/* eslint-enable no-unused-vars */

var AccountStore = external__mobx_state_tree_["types"].model('AccountStore', {
  user: external__mobx_state_tree_["types"].optional(User, {}) // subscribedCommunites: ...

}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get accountInfo() {
      return _objectSpread({}, Object(utils["U" /* stripMobx */])(self.user));
    },

    get subscribedCommunities() {
      var subscribedCommunities = self.user.subscribedCommunities;
      return _objectSpread({}, Object(utils["U" /* stripMobx */])(subscribedCommunities));
    },

    get isLogin() {
      return self.user.nickname !== '';
    }

  };
}).actions(function (self) {
  return {
    logout: function logout() {
      self.user = EmptyUser;
      self.root.preview.close();
      external__store__default.a.remove('user');
    },
    updateAccount: function updateAccount(sobj) {
      var user = merge__default()(self.user, _objectSpread({}, sobj));

      self.markState({
        user: user
      });
    },
    loadSubscribedCommunities: function loadSubscribedCommunities(data) {
      self.user.subscribedCommunities = data;
    },
    addSubscribedCommunity: function addSubscribedCommunity(community) {
      var entries = self.user.subscribedCommunities.entries;
      self.user.subscribedCommunities.entries = insert__default()(0, community, entries);
      self.user.subscribedCommunities.totalCount += 1;
      self.root.communitiesContent.toggleSubscribe(community);
    },
    removeSubscribedCommunity: function removeSubscribedCommunity(community) {
      var entries = self.user.subscribedCommunities.entries;

      var index = findIndex__default()(propEq__default()('id', community.id), entries);

      self.user.subscribedCommunities.entries = remove__default()(index, 1, entries);
      self.user.subscribedCommunities.totalCount -= 1;
      self.root.communitiesContent.toggleSubscribe(community);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var stores_AccountStore = (AccountStore);
// CONCATENATED MODULE: ./stores/UsersStore/index.js
/*
 * UsersStore store
 *
 */
 // import R from 'ramda'



/* eslint-disable no-unused-vars */

var UsersStore_debug = Object(utils["G" /* makeDebugger */])('S:UsersStore');
/* eslint-enable no-unused-vars */

var UsersStore = external__mobx_state_tree_["types"].model('UsersStore', {
  all: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].array(User)),
  visiting: User // filter: ...
  // account: ..
  // curVisit: ...
  // all: ...

}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    }

  };
}).actions(function (self) {
  return {
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var stores_UsersStore = (UsersStore);
// CONCATENATED MODULE: ./stores/ViewingStore/index.js
/*
 * ViewingStore store
 *
 */

/* import R from 'ramda' */



/* eslint-disable no-unused-vars */

var ViewingStore_debug = Object(utils["G" /* makeDebugger */])('S:ViewingStore');
/* eslint-enable no-unused-vars */

var ViewingStore = external__mobx_state_tree_["types"].model('ViewingStore', {
  community: external__mobx_state_tree_["types"].optional(Community, {}),
  post: external__mobx_state_tree_["types"].optional(Post, {}),
  video: external__mobx_state_tree_["types"].optional(Video, {}),
  repo: external__mobx_state_tree_["types"].optional(Repo, {}),
  activeThread: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('activeThread', utils["j" /* THREAD */].__TYPES), utils["j" /* THREAD */].POST)
  /*
     activeTag: t.optional(Tag, {}),
     activeThread: t.optional(
     t.enumeration('activeThread', THREAD.__TYPES),
     THREAD.POST
     ),
   */

}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    }

  };
}).actions(function (self) {
  return {
    setViewing: function setViewing(sobj) {
      self.markState(sobj);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var stores_ViewingStore = (ViewingStore);
// EXTERNAL MODULE: external "ramda/src/keys"
var keys_ = __webpack_require__(21);
var keys__default = /*#__PURE__*/__webpack_require__.n(keys_);

// CONCATENATED MODULE: ./stores/ThemeStore/index.js


/*
 * ThemeStore store
 *
 */


/* eslint-disable no-unused-vars */

var ThemeStore_debug = Object(utils["G" /* makeDebugger */])('S:ThemeStore');
/* eslint-enable no-unused-vars */

var ThemeDefaults = {
  curTheme: 'default'
};
var ThemeStore = external__mobx_state_tree_["types"].model('ThemeStore', {
  curTheme: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('theme', keys__default()(utils["Z" /* themeDict */])), 'default')
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get themeData() {
      return utils["Z" /* themeDict */][self.curTheme];
    },

    get themeKeys() {
      return keys__default()(utils["Z" /* themeDict */]);
    }

  };
}).actions(function (self) {
  return {
    changeTheme: function changeTheme(name) {
      self.curTheme = name;
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
// CONCATENATED MODULE: ./containers/BodyLayout/store.js
/*
 * BodylayoutStore store
 *
 */


/* eslint-disable no-unused-vars */

var store_debug = Object(utils["G" /* makeDebugger */])('S:BodylayoutStore');
/* eslint-enable no-unused-vars */

var BodylayoutStore = external__mobx_state_tree_["types"].model('BodylayoutStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get sidebarPin() {
      return self.root.sidebar.pin;
    }

  };
}).actions(function (self) {
  return {
    openDoraemon: function openDoraemon() {
      self.root.openDoraemon();
    }
  };
});
/* harmony default export */ var BodyLayout_store = (BodylayoutStore);
// EXTERNAL MODULE: external "ramda/src/values"
var values_ = __webpack_require__(42);
var values__default = /*#__PURE__*/__webpack_require__.n(values_);

// EXTERNAL MODULE: external "ramda/src/toLower"
var toLower_ = __webpack_require__(16);
var toLower__default = /*#__PURE__*/__webpack_require__.n(toLower_);

// EXTERNAL MODULE: external "ramda/src/map"
var map_ = __webpack_require__(18);
var map__default = /*#__PURE__*/__webpack_require__.n(map_);

// EXTERNAL MODULE: external "ramda/src/compose"
var compose_ = __webpack_require__(12);
var compose__default = /*#__PURE__*/__webpack_require__.n(compose_);

// CONCATENATED MODULE: ./containers/Sidebar/store.js





/*
 * SidebarStore store
 *
 */


/* import MenuItem from './MenuItemStore' */
// TODO: remove

var menuItemConveter = compose__default()(map__default()(function (item) {
  return {
    id: item.id,
    title: item.title,
    raw: item.raw,
    logo: item.logo,
    contributesDigest: item.contributesDigest,
    target: {
      href: {
        pathname: '/',
        query: {
          main: toLower__default()(item.raw),
          sub: 'posts' // default to posts

        }
      },
      as: {
        // pathname: `/${R.toLower(item.raw)}/posts`,
        pathname: "/".concat(toLower__default()(item.raw))
      }
    }
  };
}), values__default.a);
/* eslint-disable no-unused-vars */


var Sidebar_store_debug = Object(utils["G" /* makeDebugger */])('S:SidebarStore');
/* eslint-enable no-unused-vars */

var SidebarStore = external__mobx_state_tree_["types"].model('SidebarStore', {
  // open: t.optional(t.boolean, false),
  pin: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false) // theme: t.string, // view staff
  // curSelectItem: t.string, // view staff
  // searchBox: t.string, // complex data
  // loading: t.optional(t.boolean, false),

}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curCommunity() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.community);
    },

    get accountInfo() {
      return self.root.accountInfo;
    },

    get isLogin() {
      return self.root.account.isLogin;
    },

    get theme() {
      return self.root.theme;
    },

    get langs() {
      return self.root.langs;
    },

    get getLoading() {
      return self.loading;
    },

    get langMessages() {
      return self.root.langMessages;
    },

    get subscribedCommunities() {
      var entries = self.root.account.subscribedCommunities.entries;
      return menuItemConveter(entries);
    }

  };
}).actions(function (self) {
  return {
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    loadSubscribedCommunities: function loadSubscribedCommunities(data) {
      self.root.account.loadSubscribedCommunities(data);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    },
    changeTheme: function changeTheme(name) {
      self.root.changeTheme(name);
    }
  };
});
/* harmony default export */ var Sidebar_store = (SidebarStore);
// CONCATENATED MODULE: ./containers/Preview/store.js
/*
 * PreviewStore store
 *
 */

 // const debug = makeDebugger('S:PreviewStore')

var PreviewStore = external__mobx_state_tree_["types"].model('PreviewStore', {
  visible: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  type: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].enumeration('previewType', [utils["k" /* TYPE */].POST_PREVIEW_VIEW, utils["k" /* TYPE */].PREVIEW_ACCOUNT_VIEW, utils["k" /* TYPE */].PREVIEW_ACCOUNT_EDIT, utils["k" /* TYPE */].PREVIEW_ROOT_STORE, utils["k" /* TYPE */].PREVIEW_CREATE_POST, utils["k" /* TYPE */].PREVIEW_COMMUNITY_EDITORS])) // header:
  // body:

}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get themeKeys() {
      return self.root.theme.themeKeys;
    },

    get curTheme() {
      return self.root.theme.curTheme;
    }

  };
}).actions(function (self) {
  return {
    open: function open() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : utils["k" /* TYPE */].POST_PREVIEW_VIEW;
      self.visible = true;
      self.type = type;
    },
    close: function close() {
      self.visible = false; // self.type = TYPE.PREVIEW_ROOT_STORE

      Object(utils["_2" /* unholdPage */])();
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var Preview_store = (PreviewStore);
// EXTERNAL MODULE: external "ramda/src/isEmpty"
var isEmpty_ = __webpack_require__(9);
var isEmpty__default = /*#__PURE__*/__webpack_require__.n(isEmpty_);

// EXTERNAL MODULE: external "ramda/src/filter"
var filter_ = __webpack_require__(30);
var filter__default = /*#__PURE__*/__webpack_require__.n(filter_);

// EXTERNAL MODULE: external "ramda/src/append"
var append_ = __webpack_require__(61);
var append__default = /*#__PURE__*/__webpack_require__.n(append_);

// EXTERNAL MODULE: external "ramda/src/forEach"
var forEach_ = __webpack_require__(43);
var forEach__default = /*#__PURE__*/__webpack_require__.n(forEach_);

// CONCATENATED MODULE: ./containers/Doraemon/helper/defaultSuggestion.js
/*
   those are the default cmd
   theme --
   user --
   cheatsheet -- TODO
   login --
 */

var cmds = {
  theme: {
    title: 'theme',
    desc: 'theme desc..',
    raw: 'theme',
    logo: "".concat(config["e" /* ICON_ASSETS */], "/cmd/themes.svg"),
    threads: {
      cyan: {
        title: 'cyan theme',
        desc: "cyan desc",
        raw: "cyan",
        cmd: 'theme'
      },
      solarized: {
        title: 'solarizedDark theme',
        desc: "solarizedDark desc",
        raw: "solarized",
        cmd: 'theme'
      }
    }
  },
  user: {
    title: 'user',
    desc: 'user desc..',
    raw: 'user',
    logo: "".concat(config["e" /* ICON_ASSETS */], "/cmd/users.svg")
  },
  cheatsheet: {
    title: 'cheatsheet',
    desc: 'Cheatsheet desc',
    raw: 'cheatsheet',
    logo: "".concat(config["e" /* ICON_ASSETS */], "/cmd/cheatsheet.svg"),
    threads: {
      react: {
        title: 'javascript',
        desc: 'javascript cheatsheet',
        raw: 'javascript',
        logo: "".concat(config["e" /* ICON_ASSETS */], "/pl/javascript.svg"),
        threads: {
          react2: {
            title: 'javascript2',
            desc: 'javascript2 cheatsheet',
            raw: 'javascript2',
            logo: "".concat(config["e" /* ICON_ASSETS */], "/pl/javascript.svg")
          }
        }
      }
    }
  },
  login: {
    title: '登陆',
    desc: '登陆 desc',
    raw: 'login',
    logo: "".concat(config["e" /* ICON_ASSETS */], "/cmd/login.svg"),
    threads: {
      github: {
        title: 'github 登陆',
        desc: '使用 github open id 登陆',
        raw: 'github',
        logo: "".concat(config["e" /* ICON_ASSETS */], "/cmd/github.svg")
      }
    }
  }
};
/* harmony default export */ var defaultSuggestion = (cmds);
// CONCATENATED MODULE: ./containers/Doraemon/store.js










function store__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { store__defineProperty(target, key, source[key]); }); } return target; }

function store__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * DoraemonStore store
 *
 */


 // const debug = makeDebugger('S:DoraemonStore')

var store_convertThreadsToMaps = function convertThreadsToMaps(com) {
  var title = com.title,
      desc = com.desc,
      logo = com.logo,
      raw = com.raw;
  var threads = {};

  forEach__default()(function (t) {
    threads[t.title] = {
      title: t.title,
      raw: t.raw
    };
  }, com.threads);

  return {
    title: title,
    desc: desc,
    logo: logo,
    raw: raw,
    threads: threads
  };
};

var Suggestion = external__mobx_state_tree_["types"].model('Suggestion', {
  title: external__mobx_state_tree_["types"].string,
  desc: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  raw: external__mobx_state_tree_["types"].string,
  logo: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  cmd: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].enumeration('cmd', ['theme', 'debug'])),
  descType: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('descType', ['text', 'component']), 'text')
});
var DoraemonStore = external__mobx_state_tree_["types"].model('DoraemonStore', {
  visible: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  inputValue: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  suggestions: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Suggestion), []),
  activeRaw: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  // TODO: prefix -> cmdPrefix, and prefix be a getter
  prefix: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  // for debug config, input login/password ... etc
  inputForOtherUse: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  cmdChain: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].array(external__mobx_state_tree_["types"].string))
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curCmdChain() {
      if (!self.cmdChain && self.activeRaw) {
        return [self.activeRaw];
      }

      if (self.cmdChain && self.activeRaw) {
        return append__default()(self.activeRaw, filter__default()(function (el) {
          return el !== 'threads';
        }, map__default()(toLower__default.a, self.cmdChain)));
      }

      return null;
    },

    get subscribedCommunities() {
      var entries = self.root.account.subscribedCommunities.entries;
      return entries;
    },

    get allSuggestions() {
      var entries = self.root.account.subscribedCommunities.entries;
      if (!entries) return [];
      var subscribedCommunitiesMaps = {};

      forEach__default()(function (com) {
        subscribedCommunitiesMaps[com.title] = store__objectSpread({}, com);
      }, map__default()(store_convertThreadsToMaps, entries));

      return merge__default()(subscribedCommunitiesMaps, defaultSuggestion);
    },

    get suggestionCount() {
      return self.suggestions.length;
    },

    get activeSuggestionIndex() {
      return findIndex__default()(propEq__default()('raw', self.activeRaw))(self.suggestions);
    },

    get activeTitle() {
      if (self.activeSuggestionIndex === -1) {
        return undefined;
      }

      return self.suggestions[self.activeSuggestionIndex].title;
    }

  };
}).actions(function (self) {
  return {
    updateAccount: function updateAccount(data) {
      self.root.account.updateAccount(data);
    },
    changeTheme: function changeTheme(name) {
      self.root.changeTheme(name);
    },
    loadSuggestions: function loadSuggestions(suggestion) {
      self.suggestions = suggestion.data;
      self.prefix = suggestion.prefix; // if (data)R.isEmpty()

      if (!isEmpty__default()(suggestion.data)) {
        self.activeRaw = suggestion.data[0].raw;
      }

      if (self.suggestionCount === 0) {
        self.activeRaw = null;
      }
    },
    clearSuggestions: function clearSuggestions() {
      self.suggestions = [];
      self.prefix = '';
      self.activeRaw = null;
    },
    activeUp: function activeUp() {
      if (self.suggestionCount === 0) return false;
      var nextActiveRaw = '';
      var curIndex = self.activeSuggestionIndex;

      if (curIndex > 0 && curIndex <= self.suggestionCount) {
        nextActiveRaw = self.suggestions[curIndex - 1].raw;
      } else {
        nextActiveRaw = self.suggestions[self.suggestionCount - 1].raw;
      }

      self.markState({
        activeRaw: nextActiveRaw
      });
    },
    activeDown: function activeDown() {
      if (self.suggestionCount === 0) return false;
      var nextActiveRaw = '';
      var curIndex = self.activeSuggestionIndex;

      if (curIndex >= 0 && curIndex < self.suggestionCount - 1) {
        nextActiveRaw = self.suggestions[curIndex + 1].raw;
      } else {
        nextActiveRaw = self.suggestions[0].raw;
      }

      self.markState({
        activeRaw: nextActiveRaw
      });
    },
    activeTo: function activeTo(raw) {
      self.markState({
        activeRaw: raw
      });
    },
    open: function open() {
      self.visible = true;
      Object(utils["y" /* focusDoraemonBar */])();
    },
    handleLogin: function handleLogin() {
      self.open();
      self.inputValue = '/login/';
    },
    hideDoraemon: function hideDoraemon() {
      self.visible = false;
      self.inputValue = '';
      self.inputForOtherUse = false;
      self.cmdChain = null;
      self.clearSuggestions();
      Object(utils["B" /* hideDoraemonBarRecover */])();
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var Doraemon_store = (DoraemonStore);
// CONCATENATED MODULE: ./containers/Header/store.js
/*
 * HeaderStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var Header_store_debug = Object(utils["G" /* makeDebugger */])('S:HeaderStore');
/* eslint-enable no-unused-vars */

var HeaderStore = external__mobx_state_tree_["types"].model('HeaderStore', {
  fixed: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  preSidebarPin: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get activeInfo() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing);
    },

    get accountInfo() {
      return self.root.account.accountInfo;
    },

    get isLogin() {
      return self.root.account.isLogin;
    },

    get leftOffset() {
      var curSidebarPin = self.root.sidebar.pin;

      if (!curSidebarPin && !self.preSidebarPin && !self.fixed || !curSidebarPin && !self.preSidebarPin || curSidebarPin && !self.preSidebarPin && !self.fixed || curSidebarPin && self.preSidebarPin && self.fixed || curSidebarPin && self.preSidebarPin && !self.fixed || !curSidebarPin && self.preSidebarPin && !self.fixed) {
        return 0;
      } // 特殊情况： 当 sidebar 打开时下滑页面， 需要一个 preSidebarPin 的中间状态


      if (!curSidebarPin && self.preSidebarPin && self.fixed) {
        return '-180px';
      } // isPin && !self.preSidebarPin && self.fixed


      return '180px';
    }

  };
}).actions(function (self) {
  return {
    setFix: function setFix() {
      var fixed = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      self.preSidebarPin = self.root.sidebar.pin;
      self.fixed = fixed;
    },
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    handleLogin: function handleLogin() {
      self.root.doraemon.handleLogin();
    },
    updateAccount: function updateAccount(sobj) {
      self.root.account.updateAccount(sobj);
    },
    openDoraemon: function openDoraemon() {
      self.root.openDoraemon();
    },
    openPreview: function openPreview(type) {
      self.root.openPreview(type);
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var Header_store = (HeaderStore);
// CONCATENATED MODULE: ./containers/Content/store.js
/*
 * ContentStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var Content_store_debug = Object(utils["G" /* makeDebugger */])('S:ContentStore');
/* eslint-enable no-unused-vars */

var ContentStore = external__mobx_state_tree_["types"].model('ContentStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    }

  };
}).actions(function (self) {
  return {
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var Content_store = (ContentStore);
// CONCATENATED MODULE: ./containers/Banner/store.js
/*
 * BannerStore store
 *
 */
 // import R from 'ramda'


/* import { Post } from '../SharedModel' */

/* eslint-disable no-unused-vars */

var Banner_store_debug = Object(utils["G" /* makeDebugger */])('S:BannerStore');
/* eslint-enable no-unused-vars */

var BannerStore = external__mobx_state_tree_["types"].model('BannerStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    }

  };
}).actions(function (self) {
  return {
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var Banner_store = (BannerStore);
// CONCATENATED MODULE: ./containers/PostBanner/store.js
/*
 * PostBannerStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var PostBanner_store_debug = Object(utils["G" /* makeDebugger */])('S:PostBannerStore');
/* eslint-enable no-unused-vars */

var PostBannerStore = external__mobx_state_tree_["types"].model('PostBannerStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get postData() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
    }

  };
}).actions(function (self) {
  return {
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var PostBanner_store = (PostBannerStore);
// CONCATENATED MODULE: ./containers/CommunityBanner/store.js
/*
 * CommunityBanner store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var CommunityBanner_store_debug = Object(utils["G" /* makeDebugger */])('S:CommunityBanner');
/* eslint-enable no-unused-vars */

var CommunityBanner = external__mobx_state_tree_["types"].model('CommunityBanner', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get viewing() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing);
    }

  };
}).actions(function (self) {
  return {
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var CommunityBanner_store = (CommunityBanner);
// EXTERNAL MODULE: external "ramda/src/concat"
var concat_ = __webpack_require__(111);
var concat__default = /*#__PURE__*/__webpack_require__.n(concat_);

// CONCATENATED MODULE: ./containers/CommunitiesBanner/store.js


/*
 * CommunitiesBannerStore store
 *
 */



/* eslint-disable no-unused-vars */

var CommunitiesBanner_store_debug = Object(utils["G" /* makeDebugger */])('S:CommunitiesBannerStore');
/* eslint-enable no-unused-vars */

var CommunitiesBannerStore = external__mobx_state_tree_["types"].model('CommunitiesBannerStore', {
  pagedCategories: external__mobx_state_tree_["types"].maybe(PagedCategories),
  activeRaw: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, 'all')
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get pagedCategoriesData() {
      var data = Object(utils["U" /* stripMobx */])(self.pagedCategories);

      if (data) {
        data.entries = concat__default()([{
          title: '全部',
          raw: 'all'
        }], data.entries);
      }

      return data;
    }

  };
}).actions(function (self) {
  return {
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var CommunitiesBanner_store = (CommunitiesBannerStore);
// CONCATENATED MODULE: ./containers/CommunitiesContent/store.js



/*
 * CommunitiesContentStore store
 *
 */



/* eslint-disable no-unused-vars */

var CommunitiesContent_store_debug = Object(utils["G" /* makeDebugger */])('S:CommunitiesContentStore');
/* eslint-enable no-unused-vars */

var CommunitiesContentStore = external__mobx_state_tree_["types"].model('CommunitiesContentStore', {
  pagedCommunities: external__mobx_state_tree_["types"].maybe(PagedCommunities),
  // cur active category

  /* category: t.optional(t.string, ''), */
  // for UI loading state
  subscribing: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  subscribingId: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get isLogin() {
      return self.root.account.isLogin;
    },

    get pagedCommunitiesData() {
      return Object(utils["U" /* stripMobx */])(self.pagedCommunities);
    }

  };
}).actions(function (self) {
  return {
    toggleSubscribe: function toggleSubscribe(community) {
      var index = findIndex__default()(propEq__default()('id', community.id), self.pagedCommunities.entries);

      if (index === -1) return false;

      if (self.pagedCommunities.entries[index].viewerHasSubscribed) {
        self.pagedCommunities.entries[index].viewerHasSubscribed = false;
        self.pagedCommunities.entries[index].subscribersCount -= 1;
      } else {
        self.pagedCommunities.entries[index].viewerHasSubscribed = true;
        self.pagedCommunities.entries[index].subscribersCount += 1;
      }
    },
    addSubscribedCommunity: function addSubscribedCommunity(community) {
      self.root.account.addSubscribedCommunity(community);
    },
    removeSubscribedCommunity: function removeSubscribedCommunity(community) {
      self.root.account.removeSubscribedCommunity(community);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var CommunitiesContent_store = (CommunitiesContentStore);
// CONCATENATED MODULE: ./containers/CheatSheetContent/store.js
/*
 * CheatSheetContentStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var CheatSheetContent_store_debug = Object(utils["G" /* makeDebugger */])('S:CheatSheetContentStore');
/* eslint-enable no-unused-vars */

var CheatSheetContentStore = external__mobx_state_tree_["types"].model('CheatSheetContentStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    }

  };
}).actions(function (self) {
  return {
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var CheatSheetContent_store = (CheatSheetContentStore);
// CONCATENATED MODULE: ./containers/PostContent/store.js
/*
 * PostContentStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var PostContent_store_debug = Object(utils["G" /* makeDebugger */])('S:PostContentStore');
/* eslint-enable no-unused-vars */

var PostContentStore = external__mobx_state_tree_["types"].model('PostContentStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get postData() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
    }

  };
}).actions(function (self) {
  return {
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var PostContent_store = (PostContentStore);
// CONCATENATED MODULE: ./containers/PostsThread/store.js


/*
 * PostsThreadStore store
 *
 */



/* eslint-disable no-unused-vars */

var PostsThread_store_debug = Object(utils["G" /* makeDebugger */])('S:PostsThreadStore');
/* eslint-enable no-unused-vars */

/* const filters = { */

/* js: { */

/* time: 'today', */

/* sort: 'most_views', */

/* length: 'most_words', */

/* }, */

/* } */

/* const tags = { */

/* js: 'react', */

/* } */
// TODO: move to SharedModel

var FilterModel = external__mobx_state_tree_["types"].model('FilterModel', {
  when: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('when', ['', utils["f" /* FILTER */].TODAY, utils["f" /* FILTER */].THIS_WEEK, utils["f" /* FILTER */].THIS_MONTH, utils["f" /* FILTER */].THIS_YEAR]), ''),
  sort: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('sort', ['', utils["f" /* FILTER */].MOST_VIEWS, utils["f" /* FILTER */].MOST_FAVORITES, utils["f" /* FILTER */].MOST_STARS, utils["f" /* FILTER */].MOST_COMMENTS]), ''),
  wordLength: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('length', ['', utils["f" /* FILTER */].MOST_WORDS, utils["f" /* FILTER */].LEAST_WORDS]), '')
});
var PostsThreadStore = external__mobx_state_tree_["types"].model('PostsThreadStore', {
  pagedPosts: external__mobx_state_tree_["types"].optional(PagedPosts, emptyPagiData),
  filters: external__mobx_state_tree_["types"].optional(FilterModel, {}),

  /* tags: t.optional(t.map(Tag), {}), */
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  activeTag: external__mobx_state_tree_["types"].maybe(Tag),
  curView: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('curView', [utils["k" /* TYPE */].RESULT, utils["k" /* TYPE */].LOADING, utils["k" /* TYPE */].NOT_FOUND, utils["k" /* TYPE */].RESULT_EMPTY]), utils["k" /* TYPE */].RESULT)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get curCommunity() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.community);
    },

    get pagedPostsData() {
      return Object(utils["U" /* stripMobx */])(self.pagedPosts);
    },

    get accountInfo() {
      return self.root.account.accountInfo;
    },

    get tagsData() {
      return Object(utils["U" /* stripMobx */])(self.tags);
    },

    get filtersData() {
      return Object(utils["U" /* stripMobx */])(self.filters);
    },

    get activeTagData() {
      return Object(utils["U" /* stripMobx */])(self.activeTag) || {
        title: '',
        color: ''
      };
    },

    get activePost() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
    }

  };
}).actions(function (self) {
  return {
    selectFilter: function selectFilter(option) {
      var curfilter = self.filtersData;
      self.filters = merge__default()(curfilter, option);
    },
    selectTag: function selectTag(tag) {
      var cur = tag.title === '' ? null : tag;
      self.activeTag = cur;
    },
    setHeaderFix: function setHeaderFix(fix) {
      self.root.setHeaderFix(fix);
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var PostsThread_store = (PostsThreadStore);
// CONCATENATED MODULE: ./containers/VideosThread/store.js


/*
 * VideosThread store
 *
 */



/* eslint-disable no-unused-vars */

var VideosThread_store_debug = Object(utils["G" /* makeDebugger */])('S:VideosThread');
/* eslint-enable no-unused-vars */

var store_FilterModel = external__mobx_state_tree_["types"].model('FilterModel', {
  when: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('when', ['', utils["f" /* FILTER */].TODAY, utils["f" /* FILTER */].THIS_WEEK, utils["f" /* FILTER */].THIS_MONTH, utils["f" /* FILTER */].THIS_YEAR]), ''),
  sort: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('sort', ['', utils["f" /* FILTER */].MOST_VIEWS, utils["f" /* FILTER */].MOST_FAVORITES, utils["f" /* FILTER */].MOST_STARS, utils["f" /* FILTER */].MOST_COMMENTS]), ''),
  wordLength: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('length', ['', utils["f" /* FILTER */].MOST_WORDS, utils["f" /* FILTER */].LEAST_WORDS]), '')
});
var VideosThread = external__mobx_state_tree_["types"].model('VideosThread', {
  pagedVideos: external__mobx_state_tree_["types"].optional(PagedVideos, emptyPagiData),
  filters: external__mobx_state_tree_["types"].optional(store_FilterModel, {}),
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  activeTag: external__mobx_state_tree_["types"].maybe(Tag),
  curView: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('curView', [utils["k" /* TYPE */].RESULT, utils["k" /* TYPE */].LOADING, utils["k" /* TYPE */].NOT_FOUND, utils["k" /* TYPE */].RESULT_EMPTY]), utils["k" /* TYPE */].RESULT)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get curCommunity() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.community);
    },

    get tagsData() {
      return Object(utils["U" /* stripMobx */])(self.tags);
    },

    get filtersData() {
      return Object(utils["U" /* stripMobx */])(self.filters);
    },

    get activeTagData() {
      return Object(utils["U" /* stripMobx */])(self.activeTag) || {
        title: '',
        color: ''
      };
    },

    get pagedVideosData() {
      return Object(utils["U" /* stripMobx */])(self.pagedVideos);
    },

    get activeVideo() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.video);
    }

  };
}).actions(function (self) {
  return {
    selectFilter: function selectFilter(option) {
      var curfilter = self.filtersData;
      self.filters = merge__default()(curfilter, option);
    },
    selectTag: function selectTag(tag) {
      var cur = tag.title === '' ? null : tag;
      self.activeTag = cur;
    },
    setHeaderFix: function setHeaderFix(fix) {
      self.root.setHeaderFix(fix);
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var VideosThread_store = (VideosThread);
// CONCATENATED MODULE: ./containers/ReposThread/store.js


/*
 * ReposThread store
 *
 */



/* eslint-disable no-unused-vars */

var ReposThread_store_debug = Object(utils["G" /* makeDebugger */])('S:ReposThread');
/* eslint-enable no-unused-vars */

var ReposThread_store_FilterModel = external__mobx_state_tree_["types"].model('FilterModel', {
  when: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('when', ['', utils["f" /* FILTER */].TODAY, utils["f" /* FILTER */].THIS_WEEK, utils["f" /* FILTER */].THIS_MONTH, utils["f" /* FILTER */].THIS_YEAR]), ''),
  sort: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('sort', ['', utils["f" /* FILTER */].MOST_VIEWS, utils["f" /* FILTER */].MOST_FAVORITES, utils["f" /* FILTER */].MOST_STARS, utils["f" /* FILTER */].MOST_COMMENTS]), ''),
  wordLength: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('length', ['', utils["f" /* FILTER */].MOST_WORDS, utils["f" /* FILTER */].LEAST_WORDS]), '')
});
var ReposThread = external__mobx_state_tree_["types"].model('ReposThread', {
  pagedRepos: external__mobx_state_tree_["types"].optional(PagedRepos, emptyPagiData),
  filters: external__mobx_state_tree_["types"].optional(ReposThread_store_FilterModel, {}),

  /* tags: t.optional(t.map(Tag), {}), */
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  activeTag: external__mobx_state_tree_["types"].maybe(Tag),
  curView: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('curView', [utils["k" /* TYPE */].RESULT, utils["k" /* TYPE */].LOADING, utils["k" /* TYPE */].NOT_FOUND, utils["k" /* TYPE */].RESULT_EMPTY]), utils["k" /* TYPE */].RESULT)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get curCommunity() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.community);
    },

    get pagedReposData() {
      return Object(utils["U" /* stripMobx */])(self.pagedRepos);
    },

    get accountInfo() {
      return self.root.account.accountInfo;
    },

    get tagsData() {
      return Object(utils["U" /* stripMobx */])(self.tags);
    },

    get filtersData() {
      return Object(utils["U" /* stripMobx */])(self.filters);
    },

    get activeTagData() {
      return Object(utils["U" /* stripMobx */])(self.activeTag) || {
        title: '',
        color: ''
      };
    },

    get activeRepo() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.repo);
    }

  };
}).actions(function (self) {
  return {
    selectFilter: function selectFilter(option) {
      var curfilter = self.filtersData;
      self.filters = merge__default()(curfilter, option);
    },
    selectTag: function selectTag(tag) {
      var cur = tag.title === '' ? null : tag;
      self.activeTag = cur;
    },
    setHeaderFix: function setHeaderFix(fix) {
      self.root.setHeaderFix(fix);
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var ReposThread_store = (ReposThread);
// CONCATENATED MODULE: ./containers/JobsThread/store.js


/*
 * JobsThreadStore store
 *
 */



/* eslint-disable no-unused-vars */

var JobsThread_store_debug = Object(utils["G" /* makeDebugger */])('S:JobsThreadStore');
/* eslint-enable no-unused-vars */

/* const filters = { */

/* js: { */

/* time: 'today', */

/* sort: 'most_views', */

/* length: 'most_words', */

/* }, */

/* } */

/* const tags = { */

/* js: 'react', */

/* } */

var JobsThread_store_FilterModel = external__mobx_state_tree_["types"].model('FilterModel', {
  when: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('when', ['', utils["f" /* FILTER */].TODAY, utils["f" /* FILTER */].THIS_WEEK, utils["f" /* FILTER */].THIS_MONTH, utils["f" /* FILTER */].THIS_YEAR]), ''),
  sort: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('sort', ['', utils["f" /* FILTER */].MOST_VIEWS, utils["f" /* FILTER */].MOST_FAVORITES, utils["f" /* FILTER */].MOST_STARS, utils["f" /* FILTER */].MOST_COMMENTS]), ''),
  wordLength: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('length', ['', utils["f" /* FILTER */].MOST_WORDS, utils["f" /* FILTER */].LEAST_WORDS]), '')
});
var JobsThreadStore = external__mobx_state_tree_["types"].model('JobsThreadStore', {
  pagedJobs: external__mobx_state_tree_["types"].maybe(PagedJobs),
  filters: external__mobx_state_tree_["types"].optional(JobsThread_store_FilterModel, {}),
  tags: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Tag), []),
  activeTag: external__mobx_state_tree_["types"].maybe(Tag),
  curView: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('curView', [utils["k" /* TYPE */].RESULT, utils["k" /* TYPE */].LOADING, utils["k" /* TYPE */].NOT_FOUND, utils["k" /* TYPE */].RESULT_EMPTY]), utils["k" /* TYPE */].RESULT),
  // runtime: ..
  // data: ...
  // TODO: rename to activeArticle
  activeJob: external__mobx_state_tree_["types"].optional(SharedModel_Article, {})
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get curCommunity() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing.community);
    },

    get pagedJobsData() {
      return Object(utils["U" /* stripMobx */])(self.pagedJobs);
    },

    get tagsData() {
      return Object(utils["U" /* stripMobx */])(self.tags);
    },

    get accountInfo() {
      return self.root.account.accountInfo;
    },

    get filtersData() {
      return Object(utils["U" /* stripMobx */])(self.filters);
    },

    get activeTagData() {
      return Object(utils["U" /* stripMobx */])(self.activeTag) || {
        title: '',
        color: ''
      };
    },

    get active() {
      return Object(utils["U" /* stripMobx */])(self.activeJob);
    }

  };
}).actions(function (self) {
  return {
    selectFilter: function selectFilter(option) {
      var curfilter = self.filtersData;
      self.filters = merge__default()(curfilter, option);
    },
    selectTag: function selectTag(tag) {
      var cur = tag.title === '' ? null : tag;
      self.activeTag = cur;
    },
    setHeaderFix: function setHeaderFix(fix) {
      self.root.setHeaderFix(fix);
    },
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var JobsThread_store = (JobsThreadStore);
// CONCATENATED MODULE: ./containers/CheatSheetPaper/store.js
/*
 * CheatSheetPaperStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var CheatSheetPaper_store_debug = Object(utils["G" /* makeDebugger */])('S:CheatSheetPaperStore');
/* eslint-enable no-unused-vars */

var MarkDownBlock = external__mobx_state_tree_["types"].model('Suggestion', {
  header: external__mobx_state_tree_["types"].string,
  cards: external__mobx_state_tree_["types"].array(external__mobx_state_tree_["types"].string)
});
var CheatSheetPaperStore = external__mobx_state_tree_["types"].model('CheatSheetPaperStore', {
  current: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  source: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(MarkDownBlock), []),
  errMsg: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  state: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('state', ['init', 'loading', 'empty', 'net_error', 'parse_error', '404', 'loaded']), 'init')
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    }

  };
}).actions(function (self) {
  return {
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var CheatSheetPaper_store = (CheatSheetPaperStore);
// CONCATENATED MODULE: ./containers/TypeWriter/store.js
/*
 * TypeWriterStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var TypeWriter_store_debug = Object(utils["G" /* makeDebugger */])('S:TypeWriterStore');
/* eslint-enable no-unused-vars */

var TypeWriterStore = external__mobx_state_tree_["types"].model('TypeWriterStore', {
  title: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  linkAddr: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  body: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  publishing: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  isOriginal: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, true),
  articleType: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('articleType', ['original', 'reprint', 'translate']), 'original'),
  curView: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('curView', ['MARKDOWN_HELP_VIEW', 'EDIT_VIEW', 'CREATE_VIEW', 'PREVIEW_VIEW']), 'CREATE_VIEW'),

  /* for StatusBox */
  success: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  error: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  warn: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  statusMsg: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get statusClean() {
      var success = self.success,
          error = self.error,
          warn = self.warn;
      return !success && !error && !warn;
    },

    get viewing() {
      return Object(utils["U" /* stripMobx */])(self.root.viewing);
    }

  };
}).actions(function (self) {
  return {
    closePreview: function closePreview() {
      self.root.closePreview();
    },
    reset: function reset() {
      self.markState({
        title: '',
        linkAddr: '',
        body: '',
        isOriginal: true,
        articleType: 'original' // curView:

      });
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var TypeWriter_store = (TypeWriterStore);
// EXTERNAL MODULE: external "ramda/src/contains"
var contains_ = __webpack_require__(17);
var contains__default = /*#__PURE__*/__webpack_require__.n(contains_);

// CONCATENATED MODULE: ./containers/Comments/store.js






/*
 * CommentsStore store
 *
 */



/* eslint-disable no-unused-vars */

var Comments_store_debug = Object(utils["G" /* makeDebugger */])('S:CommentsStore');
/* eslint-enable no-unused-vars */

var Mention = external__mobx_state_tree_["types"].model('Mention', {
  id: external__mobx_state_tree_["types"].string,
  nickname: external__mobx_state_tree_["types"].string,
  avatar: external__mobx_state_tree_["types"].string
});
var CommentsStore = external__mobx_state_tree_["types"].model('CommentsStore', {
  // toggle main comment box
  showInputBox: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // toggle editor inside the comment box
  showInputEditor: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // toggle markdown preview inside the comment box
  showInputPreview: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // toggle modal editor for reply
  showReplyBox: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  showReplyEditor: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  showReplyPreview: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // current to be delete comment id, use to target the confirm mask
  tobeDeleteId: external__mobx_state_tree_["types"].maybe(external__mobx_state_tree_["types"].string),
  // words count for current comment (include reply comment)
  countCurrent: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].number, 0),
  // cur filter type of comment list
  filterType: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('filterType', [utils["k" /* TYPE */].DESC_INSERTED, utils["k" /* TYPE */].ASC_INSERTED, utils["k" /* TYPE */].MOST_LIKES, utils["k" /* TYPE */].MOST_DISLIKES]), utils["k" /* TYPE */].ASC_INSERTED),
  // content input of current comment editor
  editContent: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  // content input of current reply comment editor
  replyContent: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, ''),
  // comments pagination data of current COMMUNITY / PART
  pagedComments: external__mobx_state_tree_["types"].optional(PagedComments, emptyPagiData),
  // current "@user" in valid array format
  referUsers: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(Mention), []),
  // current "@user" in string list
  extractMentions: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].array(external__mobx_state_tree_["types"].string), []),
  // parrent comment of current reply
  replyToComment: external__mobx_state_tree_["types"].maybe(Comment),
  // toggle loading for creating comment
  creating: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // toggle loading for creating reply comment
  replying: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // toggle loading for comments list
  loading: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  // toggle loading for first item of commetns list
  loadingFresh: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get isLogin() {
      return self.root.account.isLogin;
    },

    get referUsersData() {
      var referUsers = Object(utils["U" /* stripMobx */])(self.referUsers);
      var extractMentions = Object(utils["U" /* stripMobx */])(self.extractMentions);
      return filter__default()(function (user) {
        return contains__default()(user.nickname, extractMentions);
      }, referUsers);
    },

    get pagedCommentsData() {
      return Object(utils["U" /* stripMobx */])(self.pagedComments);
    },

    get accountInfo() {
      return self.root.account.accountInfo;
    },

    get viewingArticle() {
      var subPath = self.curRoute.subPath;

      switch (Object(utils["V" /* subPath2Thread */])(subPath)) {
        case utils["j" /* THREAD */].POST:
          {
            return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
          }

        case utils["j" /* THREAD */].JOB:
          {
            return Object(utils["U" /* stripMobx */])(self.root.viewing.job);
          }

        default:
          {
            return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
          }
      }
    }

  };
}).actions(function (self) {
  return {
    addReferUser: function addReferUser(user) {
      var index = findIndex__default()(function (u) {
        return u.id === String(user.id);
      }, self.referUsers);

      if (index === -1) {
        self.referUsers.push({
          id: String(user.id),
          nickname: user.name,
          avatar: user.avatar
        });
      }
    },
    updateOneComment: function updateOneComment(id) {
      var comment = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var index = findIndex__default()(propEq__default()('id', id), self.entriesData);

      self.entries[index] = merge__default()(self.entriesData[index], comment);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var Comments_store = (CommentsStore);
// CONCATENATED MODULE: ./containers/AccountEditor/store.js


function AccountEditor_store__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { AccountEditor_store__defineProperty(target, key, source[key]); }); } return target; }

function AccountEditor_store__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * AccountEditorStore store
 *
 */



/* eslint-disable no-unused-vars */

var AccountEditor_store_debug = Object(utils["G" /* makeDebugger */])('S:AccountEditorStore');
/* eslint-enable no-unused-vars */

var AccountEditorStore = external__mobx_state_tree_["types"].model('AccountEditorStore', {
  user: external__mobx_state_tree_["types"].optional(User, {}),
  updating: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  success: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  error: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  warn: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false),
  statusMsg: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].string, '')
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get statusClean() {
      var success = self.success,
          error = self.error,
          warn = self.warn;
      return !success && !error && !warn;
    },

    get accountInfo() {
      return AccountEditor_store__objectSpread({}, Object(utils["U" /* stripMobx */])(self.user));
    },

    get accountOrigin() {
      return self.root.account.accountInfo;
    }

  };
}).actions(function (self) {
  return {
    copyAccountInfo: function copyAccountInfo() {
      var accountInfo = self.root.account.accountInfo;

      if (accountInfo !== {}) {
        self.user = accountInfo;
      }
    },
    updateOrign: function updateOrign(user) {
      self.root.account.updateAccount(user);
    },
    updateUser: function updateUser(sobj) {
      var user = merge__default()(self.user, AccountEditor_store__objectSpread({}, sobj));

      self.markState({
        user: user
      });
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var AccountEditor_store = (AccountEditorStore);
// CONCATENATED MODULE: ./containers/ArticleViwer/store.js



function ArticleViwer_store__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * ArticleViwerStore store
 *
 */


/* eslint-disable no-unused-vars */

var ArticleViwer_store_debug = Object(utils["G" /* makeDebugger */])('S:ArticleViwerStore');
/* eslint-enable no-unused-vars */

var ArticleViwerStore = external__mobx_state_tree_["types"].model('ArticleViwerStore', {
  type: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('type', [utils["k" /* TYPE */].POST, utils["k" /* TYPE */].JOB] // ...
  ), utils["k" /* TYPE */].POST),
  postLoading: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].boolean, false)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get curRoute() {
      return self.root.curRoute;
    },

    get isLogin() {
      return self.root.account.isLogin;
    },

    get viewingPost() {
      var subPath = self.curRoute.subPath;

      switch (Object(utils["V" /* subPath2Thread */])(subPath)) {
        case utils["j" /* THREAD */].POST:
          {
            return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
          }

        case utils["j" /* THREAD */].JOB:
          {
            return Object(utils["U" /* stripMobx */])(self.root.viewing.job);
          }

        default:
          {
            return Object(utils["U" /* stripMobx */])(self.root.viewing.post);
          }
      }
    }

  };
}).actions(function (self) {
  return {
    load: function load(upperType, data) {
      var type = toLower__default()(upperType);

      self.markState(ArticleViwer_store__defineProperty({
        type: upperType
      }, type, merge__default()(self[type], data)));
    },
    setViewing: function setViewing(sobj) {
      self.root.setViewing(sobj);
    },
    markRoute: function markRoute(query) {
      self.root.markRoute(query);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var ArticleViwer_store = (ArticleViwerStore);
// CONCATENATED MODULE: ./containers/AccountViewer/store.js
/*
 * AccountViewerStore store
 *
 */
 // import R from 'ramda'


/* eslint-disable no-unused-vars */

var AccountViewer_store_debug = Object(utils["G" /* makeDebugger */])('S:AccountViewerStore');
/* eslint-enable no-unused-vars */

var AccountViewerStore = external__mobx_state_tree_["types"].model('AccountViewerStore', {}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get subscribedCommunities() {
      return self.root.account.subscribedCommunities;
    },

    get accountInfo() {
      return self.root.account.accountInfo;
    },

    get curTheme() {
      return self.root.theme.curTheme;
    }

  };
}).actions(function (self) {
  return {
    logout: function logout() {
      self.root.account.logout();
    },
    changeTheme: function changeTheme(name) {
      self.root.changeTheme(name);
    },
    updateAccount: function updateAccount(data) {
      self.root.account.updateAccount(data);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var AccountViewer_store = (AccountViewerStore);
// CONCATENATED MODULE: ./containers/CommunityEditors/store.js
/*
 * CommunityEditors store
 *
 */
 // import R from 'ramda'



/* eslint-disable no-unused-vars */

var CommunityEditors_store_debug = Object(utils["G" /* makeDebugger */])('S:CommunityEditors');
/* eslint-enable no-unused-vars */

var CommunityEditors = external__mobx_state_tree_["types"].model('CommunityEditors', {
  pagedEditors: external__mobx_state_tree_["types"].optional(PagedUsers, emptyPagiData)
}).views(function (self) {
  return {
    get root() {
      return Object(external__mobx_state_tree_["getParent"])(self);
    },

    get pagedEditorsData() {
      return Object(utils["U" /* stripMobx */])(self.pagedEditors);
    }

  };
}).actions(function (self) {
  return {
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var CommunityEditors_store = (CommunityEditors);
// CONCATENATED MODULE: ./stores/index.js
// domain store

/* export { default as RouteStore } from './RouteStore' */




 // utils store






 // banners store




 // contents store



 // threads store





 // toolbox



 // viewers store




// CONCATENATED MODULE: ./stores/RootStore/index.js
/*
 * rootStore store
 *
 */



/* eslint-disable no-unused-vars */

var RootStore_debug = Object(utils["G" /* makeDebugger */])('S:rootStore');
/* eslint-enable no-unused-vars */

var rootStore = external__mobx_state_tree_["types"].model({
  // domain stores
  account: external__mobx_state_tree_["types"].optional(stores_AccountStore, {}),
  users: external__mobx_state_tree_["types"].maybe(stores_UsersStore),
  route: external__mobx_state_tree_["types"].optional(store, {}),
  viewing: external__mobx_state_tree_["types"].optional(stores_ViewingStore, {}),
  comments: external__mobx_state_tree_["types"].optional(Comments_store, {}),
  theme: external__mobx_state_tree_["types"].optional(ThemeStore, ThemeDefaults),
  appLocale: external__mobx_state_tree_["types"].optional(external__mobx_state_tree_["types"].enumeration('locale', ['zh', 'en']), 'zh'),
  appLangs: external__mobx_state_tree_["types"].map(external__mobx_state_tree_["types"].frozen),
  // domain end
  // toolbox
  sidebar: external__mobx_state_tree_["types"].optional(Sidebar_store, {
    menuItems: []
  }),
  preview: external__mobx_state_tree_["types"].optional(Preview_store, {
    visible: false
  }),
  doraemon: external__mobx_state_tree_["types"].optional(Doraemon_store, {}),
  typeWriter: external__mobx_state_tree_["types"].optional(TypeWriter_store, {}),
  accountEditor: external__mobx_state_tree_["types"].optional(AccountEditor_store, {}),
  // toolbox end
  // layouts > xxx > papers
  // layouts
  bodylayout: external__mobx_state_tree_["types"].optional(BodyLayout_store, {}),
  header: external__mobx_state_tree_["types"].optional(Header_store, {}),
  content: external__mobx_state_tree_["types"].optional(Content_store, {}),
  // layouts end
  // banners
  banner: external__mobx_state_tree_["types"].optional(Banner_store, {}),
  postBanner: external__mobx_state_tree_["types"].optional(PostBanner_store, {}),
  communityBanner: external__mobx_state_tree_["types"].optional(CommunityBanner_store, {}),
  communitiesBanner: external__mobx_state_tree_["types"].optional(CommunitiesBanner_store, {}),
  // content
  communitiesContent: external__mobx_state_tree_["types"].optional(CommunitiesContent_store, {}),
  cheatSheatContent: external__mobx_state_tree_["types"].optional(CheatSheetContent_store, {}),
  postContent: external__mobx_state_tree_["types"].optional(PostContent_store, {}),
  // content end
  // threads
  postsThread: external__mobx_state_tree_["types"].optional(PostsThread_store, {}),
  videosThread: external__mobx_state_tree_["types"].optional(VideosThread_store, {}),
  reposThread: external__mobx_state_tree_["types"].optional(ReposThread_store, {}),
  jobsThread: external__mobx_state_tree_["types"].optional(JobsThread_store, {}),
  cheatSheetPaper: external__mobx_state_tree_["types"].optional(CheatSheetPaper_store, {}),
  // viewers (for preview usage)
  articleViwer: external__mobx_state_tree_["types"].optional(ArticleViwer_store, {}),
  accountViewer: external__mobx_state_tree_["types"].optional(AccountViewer_store, {}),
  communityEditors: external__mobx_state_tree_["types"].optional(CommunityEditors_store, {})
}).views(function (self) {
  return {
    get locale() {
      return self.appLocale;
    },

    get langs() {
      return self.appLangs;
    },

    get langMessages() {
      // TODO: try - catch
      // return self.langs.toJSON()[self.appLocale]
      return self.langs.get(self.locale);
    },

    get doraemonVisible() {
      // TODO self.doraemon.visible
      return self.doraemon.visible;
    },

    get curRoute() {
      return self.route.curRoute;
    },

    get accountInfo() {
      return self.account.accountInfo;
    }

  };
}).actions(function (self) {
  return {
    afterCreate: function afterCreate() {// self.communities.load()
    },
    markRoute: function markRoute(query) {
      self.route.markRoute(query);
    },
    setHeaderFix: function setHeaderFix(fix) {
      self.header.setFix(fix);
    },
    openDoraemon: function openDoraemon() {
      self.doraemon.open();
    },
    openPreview: function openPreview(type) {
      self.preview.open(type);
    },
    closePreview: function closePreview() {
      self.preview.close();
    },
    changeTheme: function changeTheme(name) {
      self.theme.changeTheme(name);
    },
    changeLocale: function changeLocale(locale) {
      self.appLocale = locale;
    },
    setLangMessages: function setLangMessages(key, val) {
      // self.appLangs.set({ en: { fic: 2 } })
      self.appLangs.set(key, val);
    },
    isLocaleExist: function isLocaleExist(locale) {
      return !!self.langs.get(locale);
    },
    setViewing: function setViewing(sobj) {
      self.viewing.setViewing(sobj);
    },
    markState: function markState(sobj) {
      Object(utils["I" /* markStates */])(sobj, self);
    }
  };
});
/* harmony default export */ var RootStore = (rootStore);
// CONCATENATED MODULE: ./stores/init.js
function init__objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { init__defineProperty(target, key, source[key]); }); } return target; }

function init__defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

/*
 * the entry of the App store
 *
 */
// import { onAction } from 'mobx-state-tree'

var init_rootStore = null;

var init_createRootStore = function createRootStore(_ref) {
  var langSetup = _ref.langSetup,
      restData = _objectWithoutProperties(_ref, ["langSetup"]);

  return RootStore.create(init__objectSpread({
    appLangs: langSetup || {}
  }, restData), {});
};

function initRootStore(_ref2) {
  var langSetup = _ref2.langSetup,
      restData = _objectWithoutProperties(_ref2, ["langSetup"]);

  if (init_rootStore === null) {
    init_rootStore = init_createRootStore(init__objectSpread({
      langSetup: langSetup
    }, restData));
  }

  init_rootStore.markState(init__objectSpread({}, restData));
  return init_rootStore;
}

/* harmony default export */ var init = __webpack_exports__["a"] = (initRootStore); // not work, TODO

/*
if (module.hot) {
  if (module.hot.data && module.hot.data.rootStore) {
    // applySnapshot(module.hot.data.old, module.hot.data.rootStore)
  }
  module.hot.dispose(data => {
   // getSnapshot ...
  })
}
*/

/***/ }),
/* 99 */
/***/ (function(module, exports) {

module.exports = require("debug");

/***/ }),
/* 100 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/uniq");

/***/ }),
/* 101 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/tap");

/***/ }),
/* 102 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/either");

/***/ }),
/* 103 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/reduce");

/***/ }),
/* 104 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/pathEq");

/***/ }),
/* 105 */
/***/ (function(module, exports) {

module.exports = require("graphql-request");

/***/ }),
/* 106 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/reject");

/***/ }),
/* 107 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/forEachObjIndexed");

/***/ }),
/* 108 */
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),
/* 109 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/omit");

/***/ }),
/* 110 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/remove");

/***/ }),
/* 111 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/concat");

/***/ }),
/* 112 */
/***/ (function(module, exports) {

module.exports = require("react-svg");

/***/ }),
/* 113 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/popover");

/***/ }),
/* 114 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/button");

/***/ }),
/* 115 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/tag");

/***/ }),
/* 116 */
/***/ (function(module, exports) {

module.exports = require("react-trend");

/***/ }),
/* 117 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/reverse");

/***/ }),
/* 118 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/pagination");

/***/ }),
/* 119 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/tabs");

/***/ }),
/* 120 */
/***/ (function(module, exports) {

module.exports = require("antd");

/***/ }),
/* 121 */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ }),
/* 122 */
/***/ (function(module, exports) {

module.exports = require("react-intl");

/***/ }),
/* 123 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/observable/of");

/***/ }),
/* 124 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/observable/fromEventPattern");

/***/ }),
/* 125 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/timeoutWith");

/***/ }),
/* 126 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/join");

/***/ }),
/* 127 */
/***/ (function(module, exports) {

module.exports = require("apollo-link");

/***/ }),
/* 128 */
/***/ (function(module, exports) {

module.exports = require("apollo-link-retry");

/***/ }),
/* 129 */
/***/ (function(module, exports) {

module.exports = require("apollo-link-http");

/***/ }),
/* 130 */
/***/ (function(module, exports) {

module.exports = require("apollo-link-error");

/***/ }),
/* 131 */
/***/ (function(module, exports) {

module.exports = require("apollo-client");

/***/ }),
/* 132 */
/***/ (function(module, exports) {

module.exports = require("apollo-cache-inmemory");

/***/ }),
/* 133 */
/***/ (function(module, exports) {

module.exports = require("antd/lib/divider");

/***/ }),
/* 134 */
/***/ (function(module, exports) {

module.exports = require("randomcolor");

/***/ }),
/* 135 */
/***/ (function(module, exports) {

module.exports = require("draft-js-plugins-editor");

/***/ }),
/* 136 */
/***/ (function(module, exports) {

module.exports = require("draft-js-mention-plugin");

/***/ }),
/* 137 */
/***/ (function(module, exports) {

module.exports = require("react-beautiful-dnd");

/***/ }),
/* 138 */
/***/ (function(module, exports) {

module.exports = require("react-icons/lib/ti/pin-outline");

/***/ }),
/* 139 */
/***/ (function(module, exports) {

module.exports = require("react-icons/lib/md/fiber-pin");

/***/ }),
/* 140 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/allPass");

/***/ }),
/* 141 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/catch");

/***/ }),
/* 142 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/takeUntil");

/***/ }),
/* 143 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/map");

/***/ }),
/* 144 */
/***/ (function(module, exports) {

module.exports = require("rxjs/add/operator/filter");

/***/ }),
/* 145 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/identity");

/***/ }),
/* 146 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/tail");

/***/ }),
/* 147 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/ifElse");

/***/ }),
/* 148 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/anyPass");

/***/ }),
/* 149 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/startsWith");

/***/ }),
/* 150 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/init");

/***/ }),
/* 151 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/any");

/***/ }),
/* 152 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/length");

/***/ }),
/* 153 */
/***/ (function(module, exports) {

module.exports = require("scroll-into-view-if-needed");

/***/ }),
/* 154 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/mergeDeepRight");

/***/ }),
/* 155 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/pluck");

/***/ }),
/* 156 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/replace");

/***/ }),
/* 157 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/nth");

/***/ }),
/* 158 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./components/Footer/styles/index.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral([""]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }



var Container =
/*#__PURE__*/
external__styled_components__default.a.footer.withConfig({
  displayName: "styles__Container",
  componentId: "cknon7-0"
})(["display:flex;flex-direction:column;align-items:center;margin-left:-5%;margin-bottom:20px;"]);
var styles_link =
/*#__PURE__*/
external__styled_components__default.a.a.withConfig({
  displayName: "styles__link",
  componentId: "cknon7-1"
})(["text-decoration:none;font-weight:bolder;color:", ";transition:color 0.3s;&:hover{text-decoration:underline;color:", ";}"], Object(utils["W" /* theme */])('footer.text'), Object(utils["W" /* theme */])('footer.hover'));
var Support =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Support",
  componentId: "cknon7-2"
})(["font-weight:bolder;color:", ";transition:color 0.3s;&:hover{cursor:pointer;color:", ";}"], Object(utils["W" /* theme */])('footer.text'), Object(utils["W" /* theme */])('footer.hover'));
var BaseInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BaseInfo",
  componentId: "cknon7-3"
})(["display:flex;margin-top:20px;"]);
var BeianInfo =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BeianInfo",
  componentId: "cknon7-4"
})(["margin-bottom:20px;"]);
var Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Divider",
  componentId: "cknon7-5"
})(["margin-left:12px;margin-right:12px;color:", ";"], Object(utils["W" /* theme */])('footer.text'));
var GitSource =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__GitSource",
  componentId: "cknon7-6"
})(["margin-top:2px;", ";"], utils["S" /* smokey */]);
var Powerby =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Powerby",
  componentId: "cknon7-7"
})(["color:", ";font-style:italic;"], Object(utils["W" /* theme */])('footer.label'));
var PowerbyLink = styles_link.extend(_templateObject);
var About = styles_link.extend(_templateObject);
var Beian = styles_link.extend(_templateObject);
// CONCATENATED MODULE: ./components/Footer/index.js
function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

/*
 *
 * Footer
 *
 */




/* eslint-disable no-unused-vars */

var debug = Object(utils["G" /* makeDebugger */])('c:Footer:index');
/* eslint-enable no-unused-vars */

var Footer_Footer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Footer, _React$Component);

  function Footer() {
    var _ref;

    var _temp, _this;

    _classCallCheck(this, Footer);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(_this, (_temp = _this = _possibleConstructorReturn(this, (_ref = Footer.__proto__ || Object.getPrototypeOf(Footer)).call.apply(_ref, [this].concat(args))), Object.defineProperty(_assertThisInitialized(_this), "state", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: {
        showSupport: false
      }
    }), _temp));
  }

  _createClass(Footer, [{
    key: "componentDidMount",
    value: function componentDidMount() {}
  }, {
    key: "toggleSupport",
    value: function toggleSupport() {
      this.setState(function (prevState) {
        return {
          showSupport: !prevState.showSupport
        };
      });
    }
  }, {
    key: "render",
    value: function render() {
      var showSupport = this.state.showSupport;
      return external__react__default.a.createElement(Container, null, external__react__default.a.createElement(components["e" /* BuyMeChuanChuan */], {
        show: showSupport,
        onClose: this.toggleSupport.bind(this)
      }), external__react__default.a.createElement(BaseInfo, null, external__react__default.a.createElement(Beian, {
        href: "http://www.miitbeian.gov.cn",
        rel: "noopener noreferrer",
        target: "_blank"
      }, "\u8700ICP\u590717043722\u53F7-4"), external__react__default.a.createElement(Divider, null, "|"), external__react__default.a.createElement(About, {
        href: "http://www.miitbeian.gov.cn",
        rel: "noopener noreferrer",
        target: "_blank"
      }, "\u5173\u4E8E CPS"), external__react__default.a.createElement(Divider, null, "|"), external__react__default.a.createElement(About, {
        href: "http://api.coderplanets.com/graphiql",
        rel: "noopener noreferrer",
        target: "_blank"
      }, "Developer API"), external__react__default.a.createElement(Divider, null, "|"), external__react__default.a.createElement(About, {
        href: "http://www.miitbeian.gov.cn",
        rel: "noopener noreferrer",
        target: "_blank"
      }, "\u8054\u7CFB\u6211\u4EEC"), external__react__default.a.createElement(Divider, null, "|"), external__react__default.a.createElement(Powerby, null, "Powered by", ' ', external__react__default.a.createElement(PowerbyLink, {
        href: "https://github.com/mastani-stack",
        rel: "noopener noreferrer",
        target: "_blank"
      }, "Mastani-Stack")), external__react__default.a.createElement(Divider, null, "|"), external__react__default.a.createElement(Support, {
        onClick: this.toggleSupport.bind(this)
      }, "\u8D44\u52A9"), external__react__default.a.createElement(Divider, null, "|"), external__react__default.a.createElement(GitSource, null, external__react__default.a.createElement("iframe", {
        title: "souce_attr",
        src: "https://ghbtns.com/github-btn.html?user=mydearxym&repo=mastani_web&type=star&count=true",
        frameBorder: "0",
        scrolling: "0",
        width: "80px",
        height: "20px"
      }))));
    }
  }]);

  return Footer;
}(external__react__default.a.Component);

/* harmony default export */ var components_Footer = __webpack_exports__["a"] = (Footer_Footer);

/***/ }),
/* 159 */
/***/ (function(module, exports) {

module.exports = require("intl");

/***/ }),
/* 160 */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),
/* 161 */,
/* 162 */
/***/ (function(module, exports) {

module.exports = require("react-json-view");

/***/ }),
/* 163 */,
/* 164 */
/***/ (function(module, exports) {

module.exports = require("ramda/src/repeat");

/***/ }),
/* 165 */,
/* 166 */,
/* 167 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Posts; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__ = __webpack_require__(160);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_mobx_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__stores_init__ = __webpack_require__(98);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__utils__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__containers__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__containers_CommunityBanner_schema__ = __webpack_require__(78);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__containers_PostsThread_schema__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_Footer__ = __webpack_require__(158);


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } } function _next(value) { step("next", value); } function _throw(err) { step("throw", err); } _next(); }); }; }









 // try to fix safari bug
// see https://github.com/yahoo/react-intl/issues/422

global.Intl = __webpack_require__(159);

function fetchData(_x) {
  return _fetchData.apply(this, arguments);
}

function _fetchData() {
  _fetchData = _asyncToGenerator(
  /*#__PURE__*/
  __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee2(props) {
    var _makeGQClient, request, asPath, communityRaw, pagedPostsRaw, partialTagsRaw, community, thread, filter, curCommunity, pagedPosts, partialTags;

    return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _makeGQClient = Object(__WEBPACK_IMPORTED_MODULE_5__utils__["H" /* makeGQClient */])(), request = _makeGQClient.request;
            asPath = props.asPath; // schema

            communityRaw = __WEBPACK_IMPORTED_MODULE_7__containers_CommunityBanner_schema__["a" /* default */].communityRaw;
            pagedPostsRaw = __WEBPACK_IMPORTED_MODULE_8__containers_PostsThread_schema__["a" /* default */].pagedPostsRaw, partialTagsRaw = __WEBPACK_IMPORTED_MODULE_8__containers_PostsThread_schema__["a" /* default */].partialTagsRaw; // utils

            community = Object(__WEBPACK_IMPORTED_MODULE_5__utils__["z" /* getMainPath */])(props);
            thread = Object(__WEBPACK_IMPORTED_MODULE_5__utils__["x" /* extractThreadFromPath */])(props);
            filter = _objectSpread({}, Object(__WEBPACK_IMPORTED_MODULE_5__utils__["P" /* queryStringToJSON */])(asPath), {
              community: community // data

            });
            curCommunity = request(communityRaw, {
              raw: community
            });
            pagedPosts = request(pagedPostsRaw, {
              filter: filter
            });
            partialTags = request(partialTagsRaw, {
              thread: thread,
              community: community
            });
            _context2.t0 = _objectSpread;
            _context2.t1 = {};
            _context2.next = 14;
            return pagedPosts;

          case 14:
            _context2.t2 = _context2.sent;
            _context2.next = 17;
            return partialTags;

          case 17:
            _context2.t3 = _context2.sent;
            _context2.next = 20;
            return curCommunity;

          case 20:
            _context2.t4 = _context2.sent;
            return _context2.abrupt("return", (0, _context2.t0)(_context2.t1, _context2.t2, _context2.t3, _context2.t4));

          case 22:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));
  return _fetchData.apply(this, arguments);
}

var Posts =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Posts, _React$Component);

  _createClass(Posts, null, [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.mark(function _callee(props) {
        var req, asPath, isServer, thread, _ref, pagedPosts, partialTags, community, curView;

        return __WEBPACK_IMPORTED_MODULE_0__babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                req = props.req, asPath = props.asPath;
                isServer = !!req;

                if (isServer) {
                  _context.next = 4;
                  break;
                }

                return _context.abrupt("return", {});

              case 4:
                console.log('SSR ## community (in javascript) post ##: ', asPath);
                console.log('SSR queryStringToJSON: ', Object(__WEBPACK_IMPORTED_MODULE_5__utils__["P" /* queryStringToJSON */])(asPath));
                thread = Object(__WEBPACK_IMPORTED_MODULE_5__utils__["A" /* getSubPath */])(props);
                _context.next = 9;
                return fetchData(props);

              case 9:
                _ref = _context.sent;
                pagedPosts = _ref.pagedPosts;
                partialTags = _ref.partialTags;
                community = _ref.community;
                curView = pagedPosts.entries.length === 0 ? __WEBPACK_IMPORTED_MODULE_5__utils__["k" /* TYPE */].RESULT_EMPTY : __WEBPACK_IMPORTED_MODULE_5__utils__["k" /* TYPE */].RESULT;
                /* const { locale, messages } = req || Global.__NEXT_DATA__.props */

                /* const langSetup = {} */

                /* langSetup[locale] = messages */

                /* eslint-enable no-undef */

                return _context.abrupt("return", {
                  langSetup: {},

                  /* curCommunity: { community, activeThread: subPath2Thread(thread) }, */
                  viewing: {
                    community: community,
                    activeThread: Object(__WEBPACK_IMPORTED_MODULE_5__utils__["V" /* subPath2Thread */])(thread)
                  },
                  route: {
                    mainPath: community.raw,
                    subPath: thread
                  },
                  postsThread: {
                    pagedPosts: pagedPosts,
                    curView: curView,
                    tags: partialTags
                  }
                });

              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x2) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  function Posts(props) {
    var _this;

    _classCallCheck(this, Posts);

    _this = _possibleConstructorReturn(this, (Posts.__proto__ || Object.getPrototypeOf(Posts)).call(this, props));
    _this.store = Object(__WEBPACK_IMPORTED_MODULE_3__stores_init__["a" /* default */])(_objectSpread({}, props));
    return _this;
  }

  _createClass(Posts, [{
    key: "render",
    value: function render() {
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["Provider"], {
        store: this.store
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components__["j" /* GAWraper */], null, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["w" /* ThemeWrapper */], null, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["u" /* Route */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["o" /* MultiLanguage */], null, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["v" /* Sidebar */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["s" /* Preview */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["l" /* Doraemon */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["e" /* BodyLayout */], null, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["m" /* Header */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["d" /* Banner */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__containers__["k" /* Content */], null), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__components_Footer__["a" /* default */], null))))));
    }
  }]);

  return Posts;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);



/***/ }),
/* 168 */,
/* 169 */,
/* 170 */,
/* 171 */,
/* 172 */,
/* 173 */,
/* 174 */,
/* 175 */,
/* 176 */,
/* 177 */,
/* 178 */,
/* 179 */,
/* 180 */,
/* 181 */,
/* 182 */,
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(167);


/***/ })
/******/ ]);