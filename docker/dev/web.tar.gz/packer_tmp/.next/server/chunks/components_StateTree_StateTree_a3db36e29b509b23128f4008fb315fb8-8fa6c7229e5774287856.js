exports.ids = [1];
exports.modules = {

/***/ 161:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_json_view__ = __webpack_require__(162);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_json_view___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_json_view__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils__ = __webpack_require__(0);
/*
 *
 * StateTree
 *
 */



/* import PropTypes from 'prop-types' */


/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_3__utils__["G" /* makeDebugger */])('c:StateTree:index');
/* eslint-enable no-unused-vars */

/* apathy flat ocean tube */

var StateTree = function StateTree(_ref) {
  var json = _ref.json;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", null, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_json_view___default.a, {
    src: json,
    theme: "rjv-default",
    name: "rootStore",
    collapsed: 1,
    iconStyle: "circle",
    displayDataTypes: false,
    enableClipboard: false
  }));
};

StateTree.defaultProps = {};
/* harmony default export */ __webpack_exports__["default"] = (StateTree);

/***/ })

};;