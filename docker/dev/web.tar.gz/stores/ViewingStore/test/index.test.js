/*
* ViewingStore store test
*
*/

// import R from 'ramda'

// import ViewingStore from '../index'

it('TODO: test ViewingStore', () => {
  expect(1 + 1).toBe(2)
})
