/*
* UsersStore store test
*
*/

// import R from 'ramda'

// import UsersStore from '../index'

it('TODO: test UsersStore', () => {
  expect(1 + 1).toBe(2)
})
