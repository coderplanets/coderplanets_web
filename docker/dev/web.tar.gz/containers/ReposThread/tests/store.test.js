/*
* ReposThread store test
*
*/

// import R from 'ramda'

// import ReposThread from '../index'

it('TODO: store test ReposThread', () => {
  expect(1 + 1).toBe(2)
})
