// import React from 'react'
// import { shallow } from 'enzyme'

// import UserContent from '../index'

describe('TODO <UserContent />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
