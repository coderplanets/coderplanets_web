/*
 * Doraemon Langs
 *
 * This contains all the text for the Doraemon component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.Doraemon.header',
    defaultMessage: 'This is the Doraemon component !',
  },
})
