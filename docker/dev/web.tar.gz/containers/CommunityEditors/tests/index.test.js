// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunityEditors from '../index'

describe('TODO <CommunityEditors />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
