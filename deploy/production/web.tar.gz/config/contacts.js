export const EMAIL_CLUB = 'club@group.coderplanets.com'
export const EMAIL_SUPPORT = 'support@group.coderplanets.com'
export const EMAIL_HELLO = 'hello@group.coderplanets.com'
export const EMAIL_BUSINESS = 'business@group.coderplanets.com'
