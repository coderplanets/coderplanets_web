/*
 * UserBanner store test
 *
 */

// import R from 'ramda'

// import UserBanner from '../index'

it('TODO: store test UserBanner', () => {
  expect(1 + 1).toBe(2)
})
