// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleBanner from '../index'

describe('TODO <ArticleBanner />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
