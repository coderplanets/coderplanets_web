/*
 * ArticleBanner store test
 *
 */

// import R from 'ramda'

// import ArticleBanner from '../index'

it('TODO: store test ArticleBanner', () => {
  expect(1 + 1).toBe(2)
})
