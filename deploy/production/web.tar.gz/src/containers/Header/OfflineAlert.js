import React from 'react'

// import { ICON_CMD } from 'config'
import { Wrapper } from './styles/offline_alert'

const OfflineAlert = () => <Wrapper>您已离线，请检查网络设置</Wrapper>

export default OfflineAlert
