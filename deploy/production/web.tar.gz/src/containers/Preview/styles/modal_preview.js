import styled from 'styled-components'

// import Img from '../../../components/Img'
// import { theme } from '@utils'

export const Wrapper = styled.div`
  display: flex;
  justify-content: center;
`
export const Holder = 1
