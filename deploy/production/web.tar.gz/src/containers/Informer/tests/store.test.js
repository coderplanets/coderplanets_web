/*
 * Informer store test
 *
 */

// import R from 'ramda'

// import Informer from '../index'

it('TODO: store test Informer', () => {
  expect(1 + 1).toBe(2)
})
