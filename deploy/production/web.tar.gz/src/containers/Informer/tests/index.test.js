// import React from 'react'
// import { shallow } from 'enzyme'

// import Informer from '../index'

describe('TODO <Informer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
