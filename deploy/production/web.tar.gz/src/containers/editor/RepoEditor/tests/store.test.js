/*
 * RepoEditor store test
 *
 */

// import R from 'ramda'

// import RepoEditor from '../index'

it('TODO: store test RepoEditor', () => {
  expect(1 + 1).toBe(2)
})
