// import React from 'react'
// import { shallow } from 'enzyme'

// import JobEditor from '../index'

describe('TODO <JobEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
