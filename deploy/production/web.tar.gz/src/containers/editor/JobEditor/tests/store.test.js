/*
 * JobEditor store test
 *
 */

// import R from 'ramda'

// import JobEditor from '../index'

it('TODO: store test JobEditor', () => {
  expect(1 + 1).toBe(2)
})
