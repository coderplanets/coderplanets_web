// import React from 'react'
// import { shallow } from 'enzyme'

// import VideoEditor from '../index'

describe('TODO <VideoEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
