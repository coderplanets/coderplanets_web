import styled from 'styled-components'

// import Img from '@components/Img'
// import { theme } from '@utils'

export const Wrapper = styled.div`
  background: white;
`
export const Title = styled.div``
