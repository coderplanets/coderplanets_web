// import React from 'react'
// import { shallow } from 'enzyme'

// import RichEditor from '../index'

describe('TODO <RichEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
