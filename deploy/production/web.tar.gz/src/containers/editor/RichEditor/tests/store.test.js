/*
 * RichEditor store test
 *
 */

// import R from 'ramda'

// import RichEditor from '../index'

it('TODO: store test RichEditor', () => {
  expect(1 + 1).toBe(2)
})
