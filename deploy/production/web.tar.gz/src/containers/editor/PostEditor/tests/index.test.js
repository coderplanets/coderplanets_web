// import React from 'react'
// import { shallow } from 'enzyme'

// import PostEditor from '../index'

describe('TODO <PostEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
