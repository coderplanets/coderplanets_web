/*
 * PostEditor store test
 *
 */

// import R from 'ramda'

// import PostEditor from '../index'

it('TODO: store test PostEditor', () => {
  expect(1 + 1).toBe(2)
})
