import styled from 'styled-components'

// import Img from '@components/Img'
import { cs } from '@utils'

export const Wrapper = styled.div``
export const MsgWrapper = styled.div`
  ${cs.flex('justify-center')};
  width: 90%;
`
