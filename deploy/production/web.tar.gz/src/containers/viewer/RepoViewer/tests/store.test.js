/*
 * RepoViewer store test
 *
 */

// import R from 'ramda'

// import RepoViewer from '../index'

it('TODO: store test RepoViewer', () => {
  expect(1 + 1).toBe(2)
})
