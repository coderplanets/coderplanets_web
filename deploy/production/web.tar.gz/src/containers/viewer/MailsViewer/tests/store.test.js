/*
 * MailsViewer store test
 *
 */

// import R from 'ramda'

// import MailsViewer from '../index'

it('TODO: store test MailsViewer', () => {
  expect(1 + 1).toBe(2)
})
