// import React from 'react'
// import { shallow } from 'enzyme'

// import MailsViewer from '../index'

describe('TODO <MailsViewer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
