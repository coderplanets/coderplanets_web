// import React from 'react'
// import { shallow } from 'enzyme'

// import PostViewer from '../index'

describe('TODO <PostViewer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
