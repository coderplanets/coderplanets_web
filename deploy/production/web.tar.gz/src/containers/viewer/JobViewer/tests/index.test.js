// import React from 'react'
// import { shallow } from 'enzyme'

// import JobViewer from '../index'

describe('TODO <JobViewer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
