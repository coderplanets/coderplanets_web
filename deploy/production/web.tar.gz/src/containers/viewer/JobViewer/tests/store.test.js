/*
 * JobViewer store test
 *
 */

// import R from 'ramda'

// import JobViewer from '../index'

it('TODO: store test JobViewer', () => {
  expect(1 + 1).toBe(2)
})
