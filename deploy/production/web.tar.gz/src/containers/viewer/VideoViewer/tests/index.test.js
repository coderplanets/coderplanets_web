// import React from 'react'
// import { shallow } from 'enzyme'

// import VideoViewer from '../index'

describe('TODO <VideoViewer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
