/*
 * VideoViewer store test
 *
 */

// import R from 'ramda'

// import VideoViewer from '../index'

it('TODO: store test VideoViewer', () => {
  expect(1 + 1).toBe(2)
})
