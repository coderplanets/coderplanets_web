import styled from 'styled-components'

// import Img from '@components/Img'
// import { theme } from '@utils'

export const Wrapper = styled.div``
export const ContentWrapper = styled.div`
  padding: 0 20px;
`
export const Divider = styled.div`
  margin-top: 18px;
`
