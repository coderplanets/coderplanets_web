/*
 * CommunitySetter store test
 *
 */

// import R from 'ramda'

// import CommunitySetter from '../index'

it('TODO: store test CommunitySetter', () => {
  expect(1 + 1).toBe(2)
})
