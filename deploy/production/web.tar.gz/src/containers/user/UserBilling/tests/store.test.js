/*
 * UserBilling store test
 *
 */

// import R from 'ramda'

// import UserBilling from '../index'

it('TODO: store test UserBilling', () => {
  expect(1 + 1).toBe(2)
})
