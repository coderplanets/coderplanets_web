/*
 * UserStared store test
 *
 */

// import R from 'ramda'

// import UserStared from '../index'

it('TODO: store test UserStared', () => {
  expect(1 + 1).toBe(2)
})
