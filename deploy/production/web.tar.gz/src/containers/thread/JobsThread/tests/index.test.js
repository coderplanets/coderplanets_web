// import React from 'react'
// import { shallow } from 'enzyme'

// import JobsThread from '../index'

describe('TODO <JobsThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
