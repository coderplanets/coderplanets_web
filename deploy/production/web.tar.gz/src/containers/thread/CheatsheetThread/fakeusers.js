const fakeusers = [
  {
    avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
    nickname: 'nickname',
    bio: 'bio',
    company: 'company',
    location: 'location',
    htmlUrl: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
  },
  {
    avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
    nickname: 'nickname',
    bio: 'bio',
    company: 'company',
    location: 'location',
    htmlUrl: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
  },
  {
    avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
    nickname: 'nickname',
    bio: 'bio',
    company: 'company',
    location: 'location',
    htmlUrl: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
  },
]

export default fakeusers
