// import React from 'react'
// import { shallow } from 'enzyme'

// import CheatsheetThread from '../index'

describe('TODO <CheatsheetThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
