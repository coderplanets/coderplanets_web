/*
 * CheatsheetThread store test
 *
 */

// import R from 'ramda'

// import CheatsheetThread from '../index'

it('TODO: store test CheatsheetThread', () => {
  expect(1 + 1).toBe(2)
})
