/*
 * UsersThread store test
 *
 */

// import R from 'ramda'

// import UsersThread from '../index'

it('TODO: store test UsersThread', () => {
  expect(1 + 1).toBe(2)
})
