/*
 * TagsBar store test
 *
 */

// import R from 'ramda'

// import TagsBar from '../index'

it('TODO: store test TagsBar', () => {
  expect(1 + 1).toBe(2)
})
