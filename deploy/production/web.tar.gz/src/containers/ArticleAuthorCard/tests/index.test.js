// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleAuthorCard from '../index'

describe('TODO <ArticleAuthorCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
