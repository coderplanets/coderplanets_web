/*
 * ArticleAuthorCard store test
 *
 */

// import R from 'ramda'

// import ArticleAuthorCard from '../index'

it('TODO: store test ArticleAuthorCard', () => {
  expect(1 + 1).toBe(2)
})
