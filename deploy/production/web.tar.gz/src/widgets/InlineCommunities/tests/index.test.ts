// import React from 'react'
// import { shallow } from 'enzyme'

// import InlineCommunities from '../index'

describe('TODO <InlineCommunities />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
