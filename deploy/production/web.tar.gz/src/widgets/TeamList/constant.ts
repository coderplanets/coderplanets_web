import type { TLayout } from './spec'

export const LAYOUT = {
  EDIT_WORKS: 'edit-works' as TLayout,
  WORKS: 'works' as TLayout,
  GUIDE_CONTRIBUTE: 'guide-contribute' as TLayout,
}

export const holder = 1
