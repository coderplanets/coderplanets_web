// import React from 'react'
// import { shallow } from 'enzyme'

// import TeamList from '../index'

describe('TODO <TeamList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
