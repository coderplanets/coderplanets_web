// import React from 'react'
// import { shallow } from 'enzyme'

// import DigestSentence from '../index'

describe('TODO <DigestSentence />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
