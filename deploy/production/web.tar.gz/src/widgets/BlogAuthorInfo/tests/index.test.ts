// import React from 'react'
// import { shallow } from 'enzyme'

// import BlogAuthorInfo from '../index'

describe('TODO <BlogAuthorInfo />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
