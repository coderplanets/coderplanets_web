// import React from 'react'
// import { shallow } from 'enzyme'

// import BlogFeedsList from '../index'

describe('TODO <BlogFeedsList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
