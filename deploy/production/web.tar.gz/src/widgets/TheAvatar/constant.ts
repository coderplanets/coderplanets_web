export const TYPE = {
  POST_ITEM: 'post-item',
  ARTICLE_AUTHOR: 'article-author',
}

export const holder = 1
