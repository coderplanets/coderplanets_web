export type TItem = {
  id: string
  title: string
  link: string
  desc: string
  cover?: string
}
