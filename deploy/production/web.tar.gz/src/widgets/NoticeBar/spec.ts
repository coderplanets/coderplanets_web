export type TType = 'lock' | 'archived' | 'notice' | 'bot' | 'info'
