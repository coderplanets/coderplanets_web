// import React from 'react'
// import { shallow } from 'enzyme'

// import BannerNotify from '../index'

describe('TODO <BannerNotify />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
