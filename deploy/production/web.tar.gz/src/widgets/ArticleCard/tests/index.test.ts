// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleCard from '../index'

describe('TODO <ArticleCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
