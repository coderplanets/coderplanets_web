// import React from 'react'
// import { shallow } from 'enzyme'

// import SubTitle from '../index'

describe('TODO <SubTitle />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
