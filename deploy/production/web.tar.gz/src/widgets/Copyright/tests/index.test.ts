// import React from 'react'
// import { shallow } from 'enzyme'

// import Copyright from '../index'

describe('TODO <Copyright />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
