// import React from 'react'
// import { shallow } from 'enzyme'

// import Modal from '../index'

describe('TODO <Modal />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
