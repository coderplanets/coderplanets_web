// import React from 'react'
// import { shallow } from 'enzyme'

// import DotDivider from '../index'

describe('TODO <DotDivider />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
