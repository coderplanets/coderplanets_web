export const WIDTH = '150px'
export const holder = 1
