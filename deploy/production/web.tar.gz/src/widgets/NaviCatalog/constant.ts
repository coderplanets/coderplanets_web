export const ROOT_MENU = 'root'
export const CHILD_MENU = 'child'
