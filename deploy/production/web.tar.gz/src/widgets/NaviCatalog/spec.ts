export type TMenuMode = 'root' | 'child'
