export type TSelectProps = {
  menuIsOpen?: boolean
  value?: {
    value: string
  }
}
