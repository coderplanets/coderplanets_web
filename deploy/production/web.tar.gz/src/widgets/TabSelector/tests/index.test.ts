// import React from 'react'
// import { shallow } from 'enzyme'

// import TabSelector from '../index'

describe('TODO <TabSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
