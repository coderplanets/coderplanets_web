// import React from 'react'
// import { shallow } from 'enzyme'

// import ContributorList from '../index'

describe('TODO <ContributorList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
