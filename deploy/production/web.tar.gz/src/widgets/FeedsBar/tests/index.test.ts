// import React from 'react'
// import { shallow } from 'enzyme'

// import FeedsBar from '../index'

describe('TODO <FeedsBar />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
