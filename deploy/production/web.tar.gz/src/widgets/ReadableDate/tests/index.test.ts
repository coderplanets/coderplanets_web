// import React from 'react'
// import { shallow } from 'enzyme'

// import ReadableDate from '../index'

describe('TODO <ReadableDate />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
