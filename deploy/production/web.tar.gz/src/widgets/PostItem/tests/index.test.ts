// import React from 'react'
// import { shallow } from 'enzyme'

// import PostItem from '../index'

describe('TODO <PostItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
