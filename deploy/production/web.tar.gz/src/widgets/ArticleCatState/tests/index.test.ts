// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleCatState from '../index'

describe('TODO <ArticleCatState />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
