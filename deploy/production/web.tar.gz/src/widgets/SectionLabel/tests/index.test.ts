// import React from 'react'
// import { shallow } from 'enzyme'

// import SectionLabel from '../index'

describe('TODO <SectionLabel />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
