// import React from 'react'
// import { shallow } from 'enzyme'

// import EnterHint from '../index'

describe('TODO <EnterHint />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
