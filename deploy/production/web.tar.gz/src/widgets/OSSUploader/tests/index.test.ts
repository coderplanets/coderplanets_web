// import React from 'react'
// import { shallow } from 'enzyme'

// import OssUploader from '../index'

describe('TODO <OssUploader />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
