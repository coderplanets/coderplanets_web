// import React from 'react'
// import { shallow } from 'enzyme'

// import NaviIntro from '../index'

describe('TODO <NaviIntro />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
