// import React from 'react'
// import { shallow } from 'enzyme'

// import EmojiSelector from '../index'

describe('TODO <EmojiSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
