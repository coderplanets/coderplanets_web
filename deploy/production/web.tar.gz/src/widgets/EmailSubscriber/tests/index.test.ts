// import React from 'react'
// import { shallow } from 'enzyme'

// import EmailSubscriber from '../index'

describe('TODO <EmailSubscriber />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
