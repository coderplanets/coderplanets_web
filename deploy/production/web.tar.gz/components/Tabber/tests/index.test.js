// import React from 'react'
// import { shallow } from 'enzyme'

// import Tabber from '../index'

describe('<Tabber />', () => {
  it('TODO: Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
