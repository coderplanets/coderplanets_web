// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleEditToolbar from '../index'

describe('TODO <ArticleEditToolbar />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
