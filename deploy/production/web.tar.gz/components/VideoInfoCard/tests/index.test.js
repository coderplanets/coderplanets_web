// import React from 'react'
// import { shallow } from 'enzyme'

// import VideoInfoCard from '../index'

describe('TODO <VideoInfoCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
