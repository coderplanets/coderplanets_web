// import React from 'react'
// import { shallow } from 'enzyme'

// import SearchingLabel from '../index'

describe('TODO <SearchingLabel />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
