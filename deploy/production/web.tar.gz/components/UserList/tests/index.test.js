// import React from 'react'
// import { shallow } from 'enzyme'

// import UserList from '../index'

describe('TODO <UserList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
