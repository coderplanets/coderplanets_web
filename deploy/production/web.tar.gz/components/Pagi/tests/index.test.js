// import React from 'react'
// import { shallow } from 'enzyme'

// import Pagi from '../index'

describe('TODO <Pagi />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
