// import React from 'react'
// import { shallow } from 'enzyme'

// import Popconfirm from '../index'

describe('TODO <Popconfirm />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
