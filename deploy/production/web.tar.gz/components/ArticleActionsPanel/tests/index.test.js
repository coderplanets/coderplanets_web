// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleActionsPanel from '../index'

describe('TODO <ArticleActionsPanel />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
