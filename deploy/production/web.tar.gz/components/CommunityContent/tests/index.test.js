// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunityContent from '../index'

describe('TODO <CommunityContent />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
