import styled from 'styled-components'
// bbst

export const PreviewerContainer = styled.div``

export const holder = 1
