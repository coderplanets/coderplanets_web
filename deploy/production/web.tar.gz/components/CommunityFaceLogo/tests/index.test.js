// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunityFaceLogo from '../index'

describe('TODO <CommunityFaceLogo />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
