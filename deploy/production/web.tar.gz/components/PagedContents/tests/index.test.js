// import React from 'react'
// import { shallow } from 'enzyme'

// import PagedContents from '../index'

describe('TODO <PagedContents />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
