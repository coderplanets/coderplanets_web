// import React from 'react'
// import { shallow } from 'enzyme'

// import ThemeSelector from '../index'

describe('<ThemeSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
