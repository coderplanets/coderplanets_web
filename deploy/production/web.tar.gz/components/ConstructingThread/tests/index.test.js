// import React from 'react'
// import { shallow } from 'enzyme'

// import ConstructingThread from '../index'

describe('TODO <ConstructingThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
