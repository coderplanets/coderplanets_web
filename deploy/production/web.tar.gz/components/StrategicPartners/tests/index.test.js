// import React from 'react'
// import { shallow } from 'enzyme'

// import StrategicPartners from '../index'

describe('TODO <StrategicPartners />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
