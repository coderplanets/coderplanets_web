// import React from 'react'
// import { shallow } from 'enzyme'

// import JobItem from '../index'

describe('TODO <JobItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
