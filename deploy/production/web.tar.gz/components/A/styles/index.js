import styled from 'styled-components'

// import Img from '../../../components/Img'
// import { theme } from '../../../utils'

export const Wrapper = styled.a`
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
  transition: color 0.2s;
`
export const Holder = 1
