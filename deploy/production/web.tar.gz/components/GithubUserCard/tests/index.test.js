// import React from 'react'
// import { shallow } from 'enzyme'

// import GithubUserCard from '../index'

describe('TODO <GithubUserCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
