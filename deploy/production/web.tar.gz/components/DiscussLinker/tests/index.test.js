// import React from 'react'
// import { shallow } from 'enzyme'

// import DiscussLinker from '../index'

describe('TODO <DiscussLinker />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
