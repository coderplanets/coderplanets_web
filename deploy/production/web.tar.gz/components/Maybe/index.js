/*
 *
 * Maybe
 *
 */

import React from 'react'
/* import PropTypes from 'prop-types' */

import { makeDebugger } from '../../utils'
/* eslint-disable no-unused-vars */
const debug = makeDebugger('c:Maybe:index')
/* eslint-enable no-unused-vars */

const Maybe = () => {
  return <div>Maybe</div>
}

Maybe.propTypes = {
  // https://www.npmjs.com/package/prop-types
}

Maybe.defaultProps = {}

export default Maybe
