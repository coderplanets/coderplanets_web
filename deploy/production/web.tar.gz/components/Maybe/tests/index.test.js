// import React from 'react'
// import { shallow } from 'enzyme'

// import Maybe from '../index'

describe('TODO <Maybe />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
