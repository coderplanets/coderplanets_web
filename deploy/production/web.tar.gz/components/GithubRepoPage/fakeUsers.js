const fakeBuilders = [
  {
    avatar: 'http://robohash.org/set_set2/bgset_bg1/ivxebJQeJz',
    link: 'xxx',
    nickname: 'user1',
  },
  {
    avatar: 'http://robohash.org/set_set1/bgset_bg2/K9q2gg',
    link: 'xxx',
    nickname: 'user1',
  },
  {
    avatar: 'http://robohash.org/set_set3/bgset_bg1/bURifG',
    link: 'xxx',
    nickname: 'user1',
  },
  {
    avatar: 'http://robohash.org/set_set1/bgset_bg1/poWVpD',
    link: 'xxx',
    nickname: 'user1',
  },
  {
    avatar: 'https://avatars2.githubusercontent.com/u/6184465?v=4',
    link: 'xxx',
    nickname: 'user1',
  },
]

export default fakeBuilders
