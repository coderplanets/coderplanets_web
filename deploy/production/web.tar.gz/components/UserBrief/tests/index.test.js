// import React from 'react'
// import { shallow } from 'enzyme'

// import UserBrief from '../index'

describe('TODO <UserBrief />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
