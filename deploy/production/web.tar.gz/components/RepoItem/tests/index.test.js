// import React from 'react'
// import { shallow } from 'enzyme'

// import RepoItem from '../index'

describe('TODO <RepoItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
