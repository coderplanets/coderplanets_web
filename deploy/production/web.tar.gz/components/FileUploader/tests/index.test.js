// import React from 'react'
// import { shallow } from 'enzyme'

// import FileUploader from '../index'

describe('TODO <FileUploader />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
