// import React from 'react'
// import { shallow } from 'enzyme'

// import VideoSourceInfo from '../index'

describe('TODO <VideoSourceInfo />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
