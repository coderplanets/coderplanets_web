// import React from 'react'
// import { shallow } from 'enzyme'

// import ThreadSelector from '../index'

describe('TODO <ThreadSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
