// import React from 'react'
// import { shallow } from 'enzyme'

// import ContentSourceCard from '../index'

describe('TODO <ContentSourceCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
