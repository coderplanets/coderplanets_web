// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleHeader from '../index'

describe('TODO <ArticleHeader />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
