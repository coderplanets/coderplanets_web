// import React from 'react'
// import { shallow } from 'enzyme'

// import VideoItem from '../index'

describe('TODO <VideoItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
