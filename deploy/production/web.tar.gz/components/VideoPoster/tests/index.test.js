// import React from 'react'
// import { shallow } from 'enzyme'

// import VideoPoster from '../index'

describe('TODO <VideoPoster />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
