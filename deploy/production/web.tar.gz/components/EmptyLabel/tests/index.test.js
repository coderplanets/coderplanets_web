// import React from 'react'
// import { shallow } from 'enzyme'

// import EmptyLabel from '../index'

describe('TODO <EmptyLabel />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
