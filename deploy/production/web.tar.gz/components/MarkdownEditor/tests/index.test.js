// import React from 'react'
// import { shallow } from 'enzyme'

// import MarkdownEditor from '../index'

describe('TODO <MarkdownEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
