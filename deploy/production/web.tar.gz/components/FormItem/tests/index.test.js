// import React from 'react'
// import { shallow } from 'enzyme'

// import FormItem from '../index'

describe('TODO <FormItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
