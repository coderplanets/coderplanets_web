/*
* AccountStore store test
*
*/

// import R from 'ramda'

// import AccountStore from '../index'

it('TODO: test AccountStore', () => {
  expect(1 + 1).toBe(2)
})
