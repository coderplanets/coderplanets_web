/*
* RootStore store test
*
*/

/* import RootStore from '../index' */
/*  */
/* const langSetup = { */
/* testid: 'test', */
/* } */

it('TODO mini test', () => {
  /* const app = RootStore.create({ menuItems: [], appLangs: langSetup }) */
  expect(1 + 1).toBe(2)
})
