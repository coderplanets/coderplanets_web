/*
* UserSettingsStore store test
*
*/

// import R from 'ramda'

// import UserSettingsStore from '../index'

it('TODO: test UserSettingsStore', () => {
  expect(1 + 1).toBe(2)
})
