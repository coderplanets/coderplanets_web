/*
* UserFavoritesStore store test
*
*/

// import R from 'ramda'

// import UserFavoritesStore from '../index'

it('TODO: test UserFavoritesStore', () => {
  expect(1 + 1).toBe(2)
})
