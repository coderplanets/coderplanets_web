// import React from 'react'
// import { shallow } from 'enzyme'

// import AvatarAdder from '../index'

describe('TODO <AvatarAdder />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
