/*
* JobsThreadStore store test
*
*/

// import R from 'ramda'

// import JobsThreadStore from '../index'

it('TODO: test JobsThreadStore', () => {
  expect(1 + 1).toBe(2)
})
