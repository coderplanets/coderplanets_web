// import React from 'react'
// import { shallow } from 'enzyme'

// import Labeler from '../index'

describe('TODO <Labeler />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
