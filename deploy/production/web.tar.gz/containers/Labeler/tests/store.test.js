/*
* Labeler store test
*
*/

// import R from 'ramda'

// import Labeler from '../index'

it('TODO: store test Labeler', () => {
  expect(1 + 1).toBe(2)
})
