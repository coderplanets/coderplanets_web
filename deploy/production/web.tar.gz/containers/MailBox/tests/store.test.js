/*
* MailBox store test
*
*/

// import R from 'ramda'

// import MailBox from '../index'

it('TODO: store test MailBox', () => {
  expect(1 + 1).toBe(2)
})
