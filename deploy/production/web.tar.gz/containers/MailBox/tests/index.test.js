// import React from 'react'
// import { shallow } from 'enzyme'

// import MailBox from '../index'

describe('TODO <MailBox />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
