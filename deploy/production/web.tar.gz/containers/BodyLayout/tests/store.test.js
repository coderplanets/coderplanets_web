/*
 * BodylayoutStore store test
 *
 */

// import R from 'ramda'
// import BodylayoutStore from '../index'

it('BodylayoutStore 1 + 1 = 2', () => {
  expect(1 + 1).toBe(2)
})
