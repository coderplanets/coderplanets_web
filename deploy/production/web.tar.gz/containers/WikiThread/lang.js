/*
 * WikiThread Langs
 *
 * This contains all the text for the WikiThread component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.WikiThread.header',
    defaultMessage: 'This is the WikiThread component !',
  },
})
