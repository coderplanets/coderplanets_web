// import React from 'react'
// import { shallow } from 'enzyme'

// import WikiThread from '../index'

describe('TODO <WikiThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
