/*
 * PostsThreadStore store test
 *
 */

// import R from 'ramda'

// import PostsThreadStore from '../index'

it('TODO: test PostsThreadStore', () => {
  expect(1 + 1).toBe(2)
})
