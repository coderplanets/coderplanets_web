/*
* UpgradePackges store test
*
*/

// import R from 'ramda'

// import UpgradePackges from '../index'

it('TODO: store test UpgradePackges', () => {
  expect(1 + 1).toBe(2)
})
