// import React from 'react'
// import { shallow } from 'enzyme'

// import UpgradePackges from '../index'

describe('TODO <UpgradePackges />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
