/*
 * UpgradePackges Langs
 *
 * This contains all the text for the UpgradePackges component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.UpgradePackges.header',
    defaultMessage: 'This is the UpgradePackges component !',
  },
})
