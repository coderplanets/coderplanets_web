// import React from 'react'
// import { shallow } from 'enzyme'

// import ReposThread from '../index'

describe('TODO <ReposThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
