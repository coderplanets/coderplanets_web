/*
 * ReposThread Langs
 *
 * This contains all the text for the ReposThread component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.ReposThread.header',
    defaultMessage: 'This is the ReposThread component !',
  },
})
