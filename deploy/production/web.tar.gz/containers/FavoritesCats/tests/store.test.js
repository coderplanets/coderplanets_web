/*
* FavoritesCats store test
*
*/

// import R from 'ramda'

// import FavoritesCats from '../index'

it('TODO: store test FavoritesCats', () => {
  expect(1 + 1).toBe(2)
})
