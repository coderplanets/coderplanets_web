// import gql from 'graphql-tag'
import { P } from '../schemas'

const schema = {
  user: P.user,
}

export default schema
