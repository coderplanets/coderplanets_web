// import React from 'react'
// import { shallow } from 'enzyme'

// import UserBanner from '../index'

describe('TODO <UserBanner />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
