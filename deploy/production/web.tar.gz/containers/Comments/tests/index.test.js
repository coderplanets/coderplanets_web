// import React from 'react'
// import { shallow } from 'enzyme'

// import Comments from '../index'

describe('TODO <Comments />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
