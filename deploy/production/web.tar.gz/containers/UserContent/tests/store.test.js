/*
* UserContent store test
*
*/

// import R from 'ramda'

// import UserContent from '../index'

it('TODO: store test UserContent', () => {
  expect(1 + 1).toBe(2)
})
