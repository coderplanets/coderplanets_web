/*
* JobContent store test
*
*/

// import R from 'ramda'

// import JobContent from '../index'

it('TODO: store test JobContent', () => {
  expect(1 + 1).toBe(2)
})
