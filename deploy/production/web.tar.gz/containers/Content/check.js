const md = `
- [ ] djfiefe
- [ ] djfiefe
- [ ] djfiefe
- [ ] djfiefe
- [x] djfiefe
`

export default md
