// import React from 'react'
// import { shallow } from 'enzyme'

// import UsersThread from '../index'

describe('TODO <UsersThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
