/*
* CommunityContent store test
*
*/

// import R from 'ramda'

// import CommunityContent from '../index'

it('TODO: store test CommunityContent', () => {
  expect(1 + 1).toBe(2)
})
