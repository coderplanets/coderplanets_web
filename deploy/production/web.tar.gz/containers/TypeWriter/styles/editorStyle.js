import styled from 'styled-components'

export const Wrapper = styled.div`
  margin-left: 10px;
  margin-right: 10px;
`
export const holder = false
