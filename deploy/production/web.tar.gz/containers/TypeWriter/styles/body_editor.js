import styled from 'styled-components'

export const Wrapper = styled.div`
  margin-left: 10px;
  margin-right: 10px;
  font-size: 0.8rem;
`
export const holder = false
