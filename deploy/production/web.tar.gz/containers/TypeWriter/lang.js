/*
 * TypeWriter Langs
 *
 * This contains all the text for the TypeWriter component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.TypeWriter.header',
    defaultMessage: 'This is the TypeWriter component !',
  },
})
