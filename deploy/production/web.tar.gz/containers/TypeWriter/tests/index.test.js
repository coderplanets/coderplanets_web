// import React from 'react'
// import { shallow } from 'enzyme'

// import TypeWriter from '../index'

describe('<TypeWriter />', () => {
  it('TODO Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
