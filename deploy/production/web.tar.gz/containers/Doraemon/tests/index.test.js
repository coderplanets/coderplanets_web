// import React from 'react'
// import { shallow } from 'enzyme'

// import Doraemon from '../index'

describe('<Doraemon />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
