// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunitiesBanner from '../index'

describe('TODO <CommunitiesBanner />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
