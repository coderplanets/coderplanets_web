/*
 * CommunitiesContentStore store test
 *
 */

// import R from 'ramda'

// import CommunitiesContentStore from '../index'

it('TODO: test CommunitiesContentStore', () => {
  expect(1 + 1).toBe(2)
})
