export const updateFields = [
  'nickname',
  'email',
  'location',
  'bio',
  'sex',
  // social
  'qq',
  'weibo',
  'weichat',
  'github',
  'zhihu',
  'douban',
  'twitter',
  'facebook',
  'dribble',
  'instagram',
  'pinterest',
  'huaban',
  // backgrounds
  'workBackgrounds',
  'educationBackgrounds',
]

export const holder = 1
