/*
 * VideosThread Langs
 *
 * This contains all the text for the VideosThread component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.VideosThread.header',
    defaultMessage: 'This is the VideosThread component !',
  },
})
