/*
 * RouteStore store test
 *
 */

// import RouteStore from '../index'

it('RouteStore todo: 1 + 1 = 2', () => {
  expect(1 + 1).toBe(2)
})
