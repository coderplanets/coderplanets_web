/*
 * PostBannerStore store test
 *
 */

// import R from 'ramda'

// import PostBannerStore from '../index'

it('TODO: test PostBannerStore', () => {
  expect(1 + 1).toBe(2)
})
