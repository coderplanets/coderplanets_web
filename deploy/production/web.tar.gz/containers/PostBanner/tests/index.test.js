// import React from 'react'
// import { shallow } from 'enzyme'

// import PostBanner from '../index'

describe('TODO <PostBanner />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
