/*
 * PostContentStore store test
 *
 */

// import R from 'ramda'

// import PostContentStore from '../index'

it('TODO: test PostContentStore', () => {
  expect(1 + 1).toBe(2)
})
