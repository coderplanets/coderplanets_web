// import React from 'react'
// import { shallow } from 'enzyme'

// import PostContent from '../index'

describe('TODO <PostContent />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
