/*
 * ArticleViwerStore store test
 *
 */

// import R from 'ramda'

// import ArticleViwerStore from '../index'

it('TODO: test ArticleViwerStore', () => {
  expect(1 + 1).toBe(2)
})
