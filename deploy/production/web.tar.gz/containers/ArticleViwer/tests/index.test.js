// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleViwer from '../index'

describe('<ArticleViwer />', () => {
  it('TODO Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
