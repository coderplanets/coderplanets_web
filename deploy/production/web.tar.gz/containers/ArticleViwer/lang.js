/*
 * ArticleViwer Langs
 *
 * This contains all the text for the ArticleViwer component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.ArticleViwer.header',
    defaultMessage: 'This is the ArticleViwer component !',
  },
})
