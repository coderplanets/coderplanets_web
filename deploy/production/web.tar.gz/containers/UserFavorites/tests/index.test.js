// import React from 'react'
// import { shallow } from 'enzyme'

// import UserFavorites from '../index'

describe('TODO <UserFavorites />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
