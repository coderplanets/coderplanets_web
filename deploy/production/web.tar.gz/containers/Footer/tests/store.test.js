/*
* Footer2 store test
*
*/

// import R from 'ramda'

// import Footer2 from '../index'

it('TODO: store test Footer2', () => {
  expect(1 + 1).toBe(2)
})
