// import React from 'react'
// import { shallow } from 'enzyme'

// import Footer2 from '../index'

describe('TODO <Footer2 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
