/*
 * Footer2 Langs
 *
 * This contains all the text for the Footer2 component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  header: {
    id: 'containers.Footer2.header',
    defaultMessage: 'This is the Footer2 component !',
  },
})
