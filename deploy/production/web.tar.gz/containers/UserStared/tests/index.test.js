// import React from 'react'
// import { shallow } from 'enzyme'

// import UserStared from '../index'

describe('TODO <UserStared />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
