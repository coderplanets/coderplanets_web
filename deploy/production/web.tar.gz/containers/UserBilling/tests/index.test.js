// import React from 'react'
// import { shallow } from 'enzyme'

// import UserBilling from '../index'

describe('TODO <UserBilling />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
