import styled from 'styled-components'

// import Img from '../../../components/Img'
import { cs } from '../../../utils'

export const Wrapper = styled.div`
  ${cs.flexColumn()};
`

export const holder = 1
