/*
* VideoEditor store test
*
*/

// import R from 'ramda'

// import VideoEditor from '../index'

it('TODO: store test VideoEditor', () => {
  expect(1 + 1).toBe(2)
})
