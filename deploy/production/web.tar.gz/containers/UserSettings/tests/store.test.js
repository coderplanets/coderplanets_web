/*
* UserSettings store test
*
*/

// import R from 'ramda'

// import UserSettings from '../index'

it('TODO: store test UserSettings', () => {
  expect(1 + 1).toBe(2)
})
