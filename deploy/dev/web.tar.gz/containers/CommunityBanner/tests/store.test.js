/*
* CommunityBanner store test
*
*/

// import R from 'ramda'

// import CommunityBanner from '../index'

it('TODO: store test CommunityBanner', () => {
  expect(1 + 1).toBe(2)
})
