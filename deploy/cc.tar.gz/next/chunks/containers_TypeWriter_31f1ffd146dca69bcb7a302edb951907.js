
        __NEXT_REGISTER_CHUNK('containers_TypeWriter_31f1ffd146dca69bcb7a302edb951907', function() {
      webpackJsonp([5],{

/***/ "./containers/TypeWriter/Editor.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__("./node_modules/next/node_modules/prop-types/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__BodyEditor__ = __webpack_require__("./containers/TypeWriter/BodyEditor.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__logic__ = __webpack_require__("./containers/TypeWriter/logic.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__styles__ = __webpack_require__("./containers/TypeWriter/styles/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__styles_editor__ = __webpack_require__("./containers/TypeWriter/styles/editor.js");
var _this = this,
    _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/TypeWriter/Editor.js";

/*
 * Editor based on Draft
 */








var articleTypeDic = {
  original: '原创',
  reprint: '转载',
  translate: '翻译'
};

var OriginalSelector = function OriginalSelector(_ref) {
  var active = _ref.active,
      onSelect = _ref.onSelect;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["s" /* Selector */], {
    onClick: onSelect.bind(_this, 'original'),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["d" /* CheckIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/check2.svg"),
    active: active,
    value: "original",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["e" /* CheckText */], {
    active: active,
    value: "original",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }, "\u539F\u521B")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["s" /* Selector */], {
    onClick: onSelect.bind(_this, 'reprint'),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["d" /* CheckIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/check2.svg"),
    active: active,
    value: "reprint",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["e" /* CheckText */], {
    active: active,
    value: "reprint",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }, "\u8F6C\u8F7D")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["s" /* Selector */], {
    onClick: onSelect.bind(_this, 'translate'),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 68
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["d" /* CheckIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/check2.svg"),
    active: active,
    value: "translate",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["e" /* CheckText */], {
    active: active,
    value: "translate",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 74
    }
  }, "\u7FFB\u8BD1")));
};

var Editor = function Editor(_ref2) {
  var articleType = _ref2.articleType,
      copyrightChange = _ref2.copyrightChange,
      title = _ref2.title,
      titleOnChange = _ref2.titleOnChange,
      body = _ref2.body,
      bodyOnChange = _ref2.bodyOnChange,
      linkAddr = _ref2.linkAddr,
      linkSourceOnChange = _ref2.linkSourceOnChange,
      onPreview = _ref2.onPreview;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["c" /* BodyWrapper */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 92
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["b" /* BodyHeader */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 93
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["f" /* CopyRightCheck */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 94
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__components__["s" /* Popover */], {
    content: __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(OriginalSelector, {
      active: articleType,
      onSelect: copyrightChange,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 97
      }
    }),
    placement: "right",
    trigger: "hover",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["r" /* ReprintWrapper */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 102
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["q" /* ReprintIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/").concat(articleType, ".svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["g" /* CopyRightText */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 104
    }
  }, articleTypeDic[articleType]), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["n" /* MoreIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/more.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 105
    }
  })))), articleType !== 'original' ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["t" /* SourceLink */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 110
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["k" /* LinkLabel */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111
    }
  }, "\u539F\u5730\u5740:"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["j" /* LinkInput */], {
    placeholder: "\u8BF7\u586B\u5199url\u5730\u5740, \u6BD4\u5982: https://coderplanets/js/posts/...",
    value: linkAddr,
    onChange: linkSourceOnChange,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 112
    }
  })) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["p" /* PreviewBtn */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 121
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__components__["d" /* Button */], {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: onPreview,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    }
  }, "\u9884\u89C8"))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__styles__["u" /* TitleInput */], {
    placeholder: "\u6587\u7AE0\u6807\u9898.",
    defaultValue: "",
    value: title,
    onChange: titleOnChange,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 127
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("br", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__BodyEditor__["a" /* default */], {
    onChange: bodyOnChange,
    body: body,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 134
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["e" /* ExtraWrapper */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["b" /* ExtraItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["c" /* ExtraItemIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/extra_tag.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 137
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["d" /* ExtraItemTitle */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 138
    }
  }, "\u6807\u7B7E")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["a" /* ExtraDivider */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/more.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 140
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["b" /* ExtraItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 141
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["c" /* ExtraItemIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/extra_vote.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 142
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["d" /* ExtraItemTitle */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    }
  }, "\u6295\u7968")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["a" /* ExtraDivider */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/more.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 145
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["b" /* ExtraItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 146
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["c" /* ExtraItemIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/extra_code.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 147
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["d" /* ExtraItemTitle */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 148
    }
  }, "\u4EE3\u7801")), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["a" /* ExtraDivider */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/more.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 150
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__components__["i" /* FileUploader */], {
    onUploadDone: __WEBPACK_IMPORTED_MODULE_5__logic__["h" /* onUploadImageDone */],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 151
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["b" /* ExtraItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 152
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["c" /* ExtraItemIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/extra_image.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 153
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["d" /* ExtraItemTitle */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 154
    }
  }, "\u56FE\u7247"))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["a" /* ExtraDivider */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/more.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 158
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["b" /* ExtraItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 159
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["c" /* ExtraItemIcon */], {
    src: "".concat(__WEBPACK_IMPORTED_MODULE_3__config__["e" /* ICON_ASSETS */], "/cmd/extra_setting.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 160
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_editor__["d" /* ExtraItemTitle */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 161
    }
  }, "\u8BBE\u7F6E"))));
};

Editor.propTypes = {
  // https://www.npmjs.com/package/prop-types
  articleType: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string.isRequired,
  copyrightChange: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,
  bodyOnChange: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,
  titleOnChange: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,
  onPreview: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired,
  body: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,
  title: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,
  linkAddr: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.string,
  linkSourceOnChange: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.func.isRequired
};
Editor.defaultProps = {
  body: '',
  title: '',
  linkAddr: ''
};
/* harmony default export */ __webpack_exports__["a"] = (Editor);

/***/ }),

/***/ "./containers/TypeWriter/Footer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__logic__ = __webpack_require__("./containers/TypeWriter/logic.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__styles_footer__ = __webpack_require__("./containers/TypeWriter/styles/footer.js");
var _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/TypeWriter/Footer.js";
//





var Footer = function Footer(_ref) {
  var onPublish = _ref.onPublish,
      publishing = _ref.publishing,
      success = _ref.success,
      error = _ref.error,
      warn = _ref.warn,
      statusMsg = _ref.statusMsg;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__styles_footer__["b" /* FooterWrapper */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["y" /* StatusBox */], {
    success: success,
    error: error,
    warn: warn,
    msg: statusMsg,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__styles_footer__["d" /* RespectText */], {
    show: !success && !warn && !error && !publishing,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    }
  }, "\u8BF7\u5C0A\u91CD\u81EA\u5DF1\u548C\u4ED6\u4EBA\u7684\u65F6\u95F4\uFF0C\u4E0D\u8981\u53D1\u5E03\u65E0\u610F\u4E49\u7684\u5185\u5BB9\u3002"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__styles_footer__["a" /* Divider */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__styles_footer__["c" /* PublishBtns */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    }
  }, publishing ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["d" /* Button */], {
    size: "default",
    type: "primary",
    ghost: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, "\u53D6\u6D88"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["v" /* Space */], {
    right: "15px",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["d" /* Button */], {
    size: "default",
    type: "primary",
    disabled: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["k" /* Icon */], {
    type: "loading",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }), "\u6B63\u5728\u53D1\u5E03...")) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["d" /* Button */], {
    size: "default",
    type: "primary",
    ghost: true,
    onClick: __WEBPACK_IMPORTED_MODULE_2__logic__["b" /* canclePublish */],
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, "\u53D6\u6D88"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["v" /* Space */], {
    right: "15px",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["d" /* Button */], {
    size: "default",
    type: "primary",
    onClick: onPublish,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, "\u53D1", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__components__["v" /* Space */], {
    right: "10px",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }), "\u5E03"))));
};

/* harmony default export */ __webpack_exports__["a"] = (Footer);

/***/ }),

/***/ "./containers/TypeWriter/MarkDownHelper.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_keys__ = __webpack_require__("./node_modules/ramda/src/keys.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_keys___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ramda_src_keys__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_ramda_src_filter__ = __webpack_require__("./node_modules/ramda/src/filter.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_ramda_src_filter___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_ramda_src_filter__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_remarkable__ = __webpack_require__("./node_modules/remarkable/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_remarkable___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_remarkable__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_remarkable_emoji__ = __webpack_require__("./node_modules/remarkable-emoji/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_remarkable_emoji___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_remarkable_emoji__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_remarkable_mentions__ = __webpack_require__("./node_modules/remarkable-mentions/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_remarkable_mentions___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_remarkable_mentions__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_mastani_codehighlight__ = __webpack_require__("./node_modules/mastani-codehighlight/prism.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_mastani_codehighlight___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_mastani_codehighlight__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_shortid__ = __webpack_require__("./node_modules/shortid/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_shortid___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_shortid__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__ThemeWrapper_MarkDownStyle__ = __webpack_require__("./containers/ThemeWrapper/MarkDownStyle.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__emojis__ = __webpack_require__("./containers/TypeWriter/emojis.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__emojis___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__emojis__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__styles_markdown_helper__ = __webpack_require__("./containers/TypeWriter/styles/markdown_helper.js");


var _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/TypeWriter/MarkDownHelper.js";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }











var md = new __WEBPACK_IMPORTED_MODULE_3_remarkable___default.a();
md.use(__WEBPACK_IMPORTED_MODULE_5_remarkable_mentions___default()({
  url: __WEBPACK_IMPORTED_MODULE_8__config__["g" /* MENTION_USER_ADDR */]
}));
md.use(__WEBPACK_IMPORTED_MODULE_4_remarkable_emoji___default.a);

var notTooLong = function notTooLong(l) {
  return l.length < 20;
};
/* eslint-disable react/no-danger */


var Emojis = function Emojis() {
  var source = __WEBPACK_IMPORTED_MODULE_1_ramda_src_filter___default()(notTooLong, __WEBPACK_IMPORTED_MODULE_0_ramda_src_keys___default()(__WEBPACK_IMPORTED_MODULE_10__emojis___default.a));

  return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__styles_markdown_helper__["b" /* EmojiWraper */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    }
  }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__ThemeWrapper_MarkDownStyle__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement("div", {
    className: "markdown-body",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, source.map(function (item) {
    return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__styles_markdown_helper__["a" /* EmojiItem */], {
      key: __WEBPACK_IMPORTED_MODULE_7_shortid___default.a.generate(),
      dangerouslySetInnerHTML: {
        __html: md.render("".concat(item, " `").concat(item, "`"))
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 37
      }
    });
  }))));
};

var MarkDownInfo = function MarkDownInfo() {
  var IntroMD = "`\u8BF4\u660E`: \u663E\u793A\u6548\u679C\u4E0E\u4E0B\u65B9\u5B9E\u73B0\u4EE3\u7801\u4E00\u4E00\u5BF9\u5E94\n# \u8FD9\u662F\u4E00\u7EA7\u6807\u9898\n```text\n# \u8FD9\u662F\u4E00\u7EA7\u6807\u9898\n```\n## \u8FD9\u662F\u4E8C\u7EA7\u6807\u9898\n```text\n## \u8FD9\u662F\u4E8C\u7EA7\u6807\u9898\n```\n\n### \u8FD9\u662F\u4E09\u7EA7\u6807\u9898\n```text\n### \u8FD9\u662F\u4E09\u7EA7\u6807\u9898\n```\n\n#### \u8FD9\u662F\u56DB\u7EA7\u6807\u9898\n```text\n#### \u8FD9\u662F\u56DB\u7EA7\u6807\u9898\n```\n\n##### \u8FD9\u662F\u4E94\u7EA7\u6807\u9898\n```text\n##### \u8FD9\u662F\u4E94\u7EA7\u6807\u9898\n```\n\n###### \u8FD9\u662F\u516D\u7EA7\u6807\u9898\n```text\n###### \u8FD9\u662F\u516D\u7EA7\u6807\u9898\n```\n\n\u7F16\u7A0B\u8BED\u8A00\u4EE3\u7801\u9AD8\u4EAE:\n ```js\nconsole.log('hello mastani')\n ```\n\n```text\n'''js\nconsole.log('hello mastani')\n'''\n\u6CE8\u610F\u8FD9\u91CC\u662F\u53CD\u659C\u6760(`), \u5982\u679C\u662F\u5176\u4ED6\u7F16\u7A0B\u8BED\u8A00\u5C06'js'\u66FF\u6362\u5373\u53EF\u3002\n```\n\n> \u8FD9\u662F\u5F15\u7528\n```text\n> \u8FD9\u662F\u5F15\u7528\n```\n\nAt \u67D0\u4E2A\u7528\u6237: @mydearxym\n\n```text\nAt \u67D0\u4E2A\u7528\u6237: @mydearxym\n```\n\n\u63D2\u5165\u94FE\u63A5: [coderplanets.com](https://coderplanets.com)\n\n```text\n\u63D2\u5165\u94FE\u63A5: [coderplanets.com](https://coderplanets.com)\n```\n\n## Emoji \u53C2\u8003\n";
  return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement("div", {
    className: "markdown-body",
    dangerouslySetInnerHTML: {
      __html: md.render(IntroMD)
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113
    }
  });
};
/* eslint-enable react/no-danger */


var MarkDownHelper =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MarkDownHelper, _React$Component);

  function MarkDownHelper() {
    _classCallCheck(this, MarkDownHelper);

    return _possibleConstructorReturn(this, (MarkDownHelper.__proto__ || Object.getPrototypeOf(MarkDownHelper)).apply(this, arguments));
  }

  _createClass(MarkDownHelper, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      __WEBPACK_IMPORTED_MODULE_6_mastani_codehighlight___default.a.highlightAll();
    }
  }, {
    key: "render",
    value: function render() {
      return __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__styles_markdown_helper__["c" /* Wrapper */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 130
        }
      }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__ThemeWrapper_MarkDownStyle__["a" /* default */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 131
        }
      }, __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(MarkDownInfo, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 132
        }
      }), __WEBPACK_IMPORTED_MODULE_2_react___default.a.createElement(Emojis, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 133
        }
      })));
    }
  }]);

  return MarkDownHelper;
}(__WEBPACK_IMPORTED_MODULE_2_react___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (MarkDownHelper);

/***/ }),

/***/ "./containers/TypeWriter/Preview.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_remarkable__ = __webpack_require__("./node_modules/remarkable/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_remarkable___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_remarkable__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_remarkable_emoji__ = __webpack_require__("./node_modules/remarkable-emoji/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_remarkable_emoji___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_remarkable_emoji__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_remarkable_mentions__ = __webpack_require__("./node_modules/remarkable-mentions/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_remarkable_mentions___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_remarkable_mentions__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ThemeWrapper_MarkDownStyle__ = __webpack_require__("./containers/ThemeWrapper/MarkDownStyle.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__styles_preview__ = __webpack_require__("./containers/TypeWriter/styles/preview.js");
var _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/TypeWriter/Preview.js";

/*
 * Editor based on Draft
 */



 // import Prism from 'mastani-codehighlight'





var md = new __WEBPACK_IMPORTED_MODULE_1_remarkable___default.a();
md.use(__WEBPACK_IMPORTED_MODULE_3_remarkable_mentions___default()({
  url: __WEBPACK_IMPORTED_MODULE_4__config__["g" /* MENTION_USER_ADDR */]
}));
md.use(__WEBPACK_IMPORTED_MODULE_2_remarkable_emoji___default.a);
/* eslint-disable react/no-danger */

var Preview = function Preview(_ref) {
  var onBack = _ref.onBack,
      title = _ref.title,
      body = _ref.body;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_preview__["c" /* BodyWrapper */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_preview__["b" /* BodyHeader */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }, "\xA0", __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_preview__["a" /* BackToEditBtn */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__components__["d" /* Button */], {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: onBack,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }, "\u8FD4\u56DE\u7F16\u8F91"))), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles_preview__["d" /* PreviewHeader */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, title), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__ThemeWrapper_MarkDownStyle__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    className: "markdown-body",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    id: "typewriter-preview-container",
    dangerouslySetInnerHTML: {
      __html: md.render(body)
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }))));
};
/* eslint-enable react/no-danger */


/* harmony default export */ __webpack_exports__["a"] = (Preview);

/***/ }),

/***/ "./containers/TypeWriter/emojis.js":
/***/ (function(module, exports) {

// prettier-ignore
module.exports = {
  ":alarm_clock:": "\u23F0",
  ":anchor:": "\u2693",
  ":aquarius:": "\u2652",
  ":aries:": "\u2648",
  ":arrow_backward:": "\u25C0",
  ":arrow_double_down:": "\u23EC",
  ":arrow_double_up:": "\u23EB",
  ":arrow_down:": "\u2B07",
  ":arrow_forward:": "\u25B6",
  ":arrow_heading_down:": "\u2935",
  ":arrow_heading_up:": "\u2934",
  ":arrow_left:": "\u2B05",
  ":arrow_lower_left:": "\u2199",
  ":arrow_lower_right:": "\u2198",
  ":arrow_right:": "\u27A1",
  ":arrow_right_hook:": "\u21AA",
  ":arrow_up:": "\u2B06",
  ":arrow_up_down:": "\u2195",
  ":arrow_upper_left:": "\u2196",
  ":arrow_upper_right:": "\u2197",
  ":ballot_box_with_check:": "\u2611",
  ":bangbang:": "\u203C",
  ":cancer:": "\u264B",
  ":baseball:": "\u26BE",
  ":black_large_square:": "\u2B1B",
  ":black_medium_small_square:": "\u25FE",
  ":black_medium_square:": "\u25FC",
  ":black_nib:": "\u2712",
  ":black_small_square:": "\u25AA",
  ":black_circle:": "\u26AB",
  ":boat:": "\u26F5",
  ":capricorn:": "\u2651",
  ":church:": "\u26EA",
  ":cloud:": "\u2601",
  ":clubs:": "\u2663",
  ":coffee:": "\u2615",
  ":congratulations:": "\u3297",
  ":copyright:": "\xA9",
  ":curly_loop:": "\u27B0",
  ":eight_pointed_black_star:": "\u2734",
  ":eight_spoked_asterisk:": "\u2733",
  ":diamonds:": "\u2666",
  ":email:": "\u2709",
  ":envelope:": "\u2709",
  ":exclamation:": "\u2757",
  ":fast_forward:": "\u23E9",
  ":fist:": "\u270A",
  ":fountain:": "\u26F2",
  ":fuelpump:": "\u26FD",
  ":gemini:": "\u264A",
  ":golf:": "\u26F3",
  ":grey_exclamation:": "\u2755",
  ":grey_question:": "\u2754",
  ":hand:": "\u270B",
  ":heart:": "\u2764",
  ":hearts:": "\u2665",
  ":heavy_check_mark:": "\u2714",
  ":heavy_division_sign:": "\u2797",
  ":heavy_exclamation_mark:": "\u2757",
  ":heavy_minus_sign:": "\u2796",
  ":heavy_multiplication_x:": "\u2716",
  ":heavy_plus_sign:": "\u2795",
  ":hotsprings:": "\u2668",
  ":hourglass:": "\u231B",
  ":hourglass_flowing_sand:": "\u23F3",
  ":information_source:": "\u2139",
  ":interrobang:": "\u2049",
  ":left_right_arrow:": "\u2194",
  ":leftwards_arrow_with_hook:": "\u21A9",
  ":leo:": "\u264C",
  ":libra:": "\u264E",
  ":loop:": "\u27BF",
  ":m:": "\u24C2",
  ":negative_squared_cross_mark:": "\u274E",
  ":no_entry:": "\u26D4",
  ":o:": "\u2B55",
  ":ophiuchus:": "\u26CE",
  ":part_alternation_mark:": "\u303D",
  ":partly_sunny:": "\u26C5",
  ":pencil2:": "\u270F",
  ":phone:": "\u260E",
  ":pisces:": "\u2653",
  ":point_up:": "\u261D",
  ":question:": "\u2753",
  ":raised_hand:": "\u270B",
  ":recycle:": "\u267B",
  ":registered:": "\xAE",
  ":relaxed:": "\u263A",
  ":rewind:": "\u23EA",
  ":sagittarius:": "\u2650",
  ":sailboat:": "\u26F5",
  ":scissors:": "\u2702",
  ":scorpius:": "\u264F",
  ":secret:": "\u3299",
  ":snowflake:": "\u2744",
  ":snowman:": "\u26C4",
  ":soccer:": "\u26BD",
  ":spades:": "\u2660",
  ":sparkle:": "\u2747",
  ":sparkles:": "\u2728",
  ":star:": "\u2B50",
  ":sunny:": "\u2600",
  ":taurus:": "\u2649",
  ":telephone:": "\u260E",
  ":tent:": "\u26FA",
  ":tm:": "\u2122",
  ":umbrella:": "\u2614",
  ":v:": "\u270C",
  ":virgo:": "\u264D",
  ":warning:": "\u26A0",
  ":watch:": "\u231A",
  ":wavy_dash:": "\u3030",
  ":wheelchair:": "\u267F",
  ":white_check_mark:": "\u2705",
  ":white_circle:": "\u26AA",
  ":white_large_square:": "\u2B1C",
  ":white_medium_small_square:": "\u25FD",
  ":white_medium_square:": "\u25FB",
  ":white_small_square:": "\u25AB",
  ":x:": "\u274C",
  ":zap:": "\u26A1",
  ":airplane:": "\u2708",
  ":+1:": "👍",
  ":-1:": "👎",
  ":100:": "💯",
  ":1234:": "🔢",
  ":8ball:": "🎱",
  ":a:": "🅰",
  ":ab:": "🆎",
  ":abc:": "🔤",
  ":abcd:": "🔡",
  ":accept:": "🉑",
  ":aerial_tramway:": "🚡",
  ":alien:": "👽",
  ":ambulance:": "🚑",
  ":angel:": "👼",
  ":anger:": "💢",
  ":angry:": "😠",
  ":-||": "😠",
  ":@": "😠",
  ">:(": "😠",
  ":anguished:": "😧",
  ":ant:": "🐜",
  ":apple:": "🍎",
  ":arrow_down_small:": "🔽",
  ":arrow_up_small:": "🔼",
  ":arrows_clockwise:": "🔃",
  ":arrows_counterclockwise:": "🔄",
  ":art:": "🎨",
  ":articulated_lorry:": "🚛",
  ":astonished:": "😲",
  ":athletic_shoe:": "👟",
  ":atm:": "🏧",
  ":b:": "🅱",
  ":baby:": "👶",
  ":baby_bottle:": "🍼",
  ":baby_chick:": "🐤",
  ":baby_symbol:": "🚼",
  ":back:": "🔙",
  ":baggage_claim:": "🛄",
  ":balloon:": "🎈",
  ":bamboo:": "🎍",
  ":banana:": "🍌",
  ":bank:": "🏦",
  ":bar_chart:": "📊",
  ":barber:": "💈",
  ":basketball:": "🏀",
  ":bath:": "🛀",
  ":bathtub:": "🛁",
  ":battery:": "🔋",
  ":bear:": "🐻",
  ":bee:": "🐝",
  ":beer:": "🍺",
  ":beers:": "🍻",
  ":beetle:": "🐞",
  ":beginner:": "🔰",
  ":bell:": "🔔",
  ":bento:": "🍱",
  ":bicyclist:": "🚴",
  ":bike:": "🚲",
  ":bikini:": "👙",
  ":bird:": "🐦",
  ":birthday:": "🎂",
  ":black_joker:": "🃏",
  ":black_square_button:": "🔲",
  ":blossom:": "🌼",
  ":blowfish:": "🐡",
  ":blue_book:": "📘",
  ":blue_car:": "🚙",
  ":blue_heart:": "💙",
  ":blush:": "😊",
  ":$": "😊",
  ":boar:": "🐗",
  ":bomb:": "💣",
  ":book:": "📖",
  ":bookmark:": "🔖",
  ":bookmark_tabs:": "📑",
  ":books:": "📚",
  ":boom:": "💥",
  ":boot:": "👢",
  ":bouquet:": "💐",
  ":bow:": "🙇",
  ":bowling:": "🎳",
  ":boy:": "👦",
  ":bread:": "🍞",
  ":bride_with_veil:": "👰",
  ":bridge_at_night:": "🌉",
  ":briefcase:": "💼",
  ":broken_heart:": "💔",
  ":bug:": "🐛",
  ":bulb:": "💡",
  ":bullettrain_front:": "🚅",
  ":bullettrain_side:": "🚄",
  ":bus:": "🚌",
  ":busstop:": "🚏",
  ":bust_in_silhouette:": "👤",
  ":busts_in_silhouette:": "👥",
  ":cactus:": "🌵",
  ":cake:": "🍰",
  ":calendar:": "📆",
  ":calling:": "📲",
  ":camel:": "🐫",
  ":camera:": "📷",
  ":candy:": "🍬",
  ":capital_abcd:": "🔠",
  ":car:": "🚗",
  ":card_index:": "📇",
  ":carousel_horse:": "🎠",
  ":cat:": "🐱",
  ":cat2:": "🐈",
  ":cd:": "💿",
  ":chart:": "💹",
  ":chart_with_downwards_trend:": "📉",
  ":chart_with_upwards_trend:": "📈",
  ":checkered_flag:": "🏁",
  ":cherries:": "🍒",
  ":cherry_blossom:": "🌸",
  ":chestnut:": "🌰",
  ":chicken:": "🐔",
  ":children_crossing:": "🚸",
  ":chocolate_bar:": "🍫",
  ":christmas_tree:": "🎄",
  ":cinema:": "🎦",
  ":circus_tent:": "🎪",
  ":city_sunrise:": "🌇",
  ":city_sunset:": "🌆",
  ":cl:": "🆑",
  ":clap:": "👏",
  ":clapper:": "🎬",
  ":clipboard:": "📋",
  ":clock1:": "🕐",
  ":clock10:": "🕙",
  ":clock1030:": "🕥",
  ":clock11:": "🕚",
  ":clock1130:": "🕦",
  ":clock12:": "🕛",
  ":clock1230:": "🕧",
  ":clock130:": "🕜",
  ":clock2:": "🕑",
  ":clock230:": "🕝",
  ":clock3:": "🕒",
  ":clock330:": "🕞",
  ":clock4:": "🕓",
  ":clock430:": "🕟",
  ":clock5:": "🕔",
  ":clock530:": "🕠",
  ":clock6:": "🕕",
  ":clock630:": "🕡",
  ":clock7:": "🕖",
  ":clock730:": "🕢",
  ":clock8:": "🕗",
  ":clock830:": "🕣",
  ":clock9:": "🕘",
  ":clock930:": "🕤",
  ":closed_book:": "📕",
  ":closed_lock_with_key:": "🔐",
  ":closed_umbrella:": "🌂",
  ":cocktail:": "🍸",
  ":cold_sweat:": "😰",
  ":collision:": "💥",
  ":computer:": "💻",
  ":confetti_ball:": "🎊",
  ":confounded:": "😖",
  ":confused:": "😕",
  "%-)": "😕",
  "%)": "😕",
  ":construction:": "🚧",
  ":construction_worker:": "👷",
  ":convenience_store:": "🏪",
  ":cookie:": "🍪",
  ":cool:": "🆒",
  ":cop:": "👮",
  ":corn:": "🌽",
  ":couple:": "👫",
  ":couple_with_heart:": "💑",
  ":couplekiss:": "💏",
  ":cow:": "🐮",
  ":cow2:": "🐄",
  ":credit_card:": "💳",
  ":crocodile:": "🐊",
  ":crossed_flags:": "🎌",
  ":crown:": "👑",
  ":cry:": "😢",
  ":'(": "😢",
  ":-'(": "😢",
  ":crying_cat_face:": "😿",
  ":crystal_ball:": "🔮",
  ":cupid:": "💘",
  ":currency_exchange:": "💱",
  ":curry:": "🍛",
  ":custard:": "🍮",
  ":customs:": "🛃",
  ":cyclone:": "🌀",
  ":dancer:": "💃",
  ":dancers:": "👯",
  ":dango:": "🍡",
  ":dart:": "🎯",
  ":dash:": "💨",
  ":date:": "📅",
  ":deciduous_tree:": "🌳",
  ":department_store:": "🏬",
  ":diamond_shape_with_a_dot_inside:": "💠",
  ":disappointed:": "😞",
  ":disappointed_relieved:": "😥",
  ":dizzy:": "💫",
  ":dizzy_face:": "😵",
  ":do_not_litter:": "🚯",
  ":dog:": "🐶",
  ":dog2:": "🐕",
  ":dollar:": "💵",
  ":dolls:": "🎎",
  ":dolphin:": "🐬",
  ":door:": "🚪",
  ":doughnut:": "🍩",
  ":dragon:": "🐉",
  ":dragon_face:": "🐲",
  ":dress:": "👗",
  ":dromedary_camel:": "🐪",
  ":droplet:": "💧",
  ":dvd:": "📀",
  ":e-mail:": "📧",
  ":ear:": "👂",
  ":ear_of_rice:": "🌾",
  ":earth_africa:": "🌍",
  ":earth_americas:": "🌎",
  ":earth_asia:": "🌏",
  ":egg:": "🍳",
  ":eggplant:": "🍆",
  ":electric_plug:": "🔌",
  ":elephant:": "🐘",
  ":end:": "🔚",
  ":envelope_with_arrow:": "📩",
  ":euro:": "💶",
  ":european_castle:": "🏰",
  ":european_post_office:": "🏤",
  ":evergreen_tree:": "🌲",
  ":expressionless:": "😑",
  ":eyeglasses:": "👓",
  ":eyes:": "👀",
  ":facepunch:": "👊",
  ":factory:": "🏭",
  ":fallen_leaf:": "🍂",
  ":family:": "👪",
  ":fax:": "📠",
  ":fearful:": "😨",
  ":feet:": "🐾",
  ":ferris_wheel:": "🎡",
  ":file_folder:": "📁",
  ":fire:": "🔥",
  ":fire_engine:": "🚒",
  ":fireworks:": "🎆",
  ":first_quarter_moon:": "🌓",
  ":first_quarter_moon_with_face:": "🌛",
  ":fish:": "🐟",
  ":fish_cake:": "🍥",
  ":fishing_pole_and_fish:": "🎣",
  ":flags:": "🎏",
  ":flashlight:": "🔦",
  ":floppy_disk:": "💾",
  ":flower_playing_cards:": "🎴",
  ":flushed:": "😳",
  ":foggy:": "🌁",
  ":football:": "🏈",
  ":footprints:": "👣",
  ":fork_and_knife:": "🍴",
  ":four_leaf_clover:": "🍀",
  ":free:": "🆓",
  ":fried_shrimp:": "🍤",
  ":fries:": "🍟",
  ":frog:": "🐸",
  ":frowning:": "😦",
  ":(": "😦",
  ":-(": "😦",
  ":-[": "😦",
  ":[": "😦",
  ":full_moon:": "🌕",
  ":full_moon_with_face:": "🌝",
  ":game_die:": "🎲",
  ":gem:": "💎",
  ":ghost:": "👻",
  ":gift:": "🎁",
  ":gift_heart:": "💝",
  ":girl:": "👧",
  ":globe_with_meridians:": "🌐",
  ":goat:": "🐐",
  ":grapes:": "🍇",
  ":green_apple:": "🍏",
  ":green_book:": "📗",
  ":green_heart:": "💚",
  ":grimacing:": "😬",
  ":grin:": "😁",
  "xD": "😁",
  "x-D": "😁",
  "XD": "😁",
  "X-D": "😁",
  ":grinning:": "😀",
  ":guardsman:": "💂",
  ":guitar:": "🎸",
  ":gun:": "🔫",
  ":haircut:": "💇",
  ":hamburger:": "🍔",
  ":hammer:": "🔨",
  ":hamster:": "🐹",
  ":handbag:": "👜",
  ":hankey:": "💩",
  ":hatched_chick:": "🐥",
  ":hatching_chick:": "🐣",
  ":headphones:": "🎧",
  ":hear_no_evil:": "🙉",
  ":heart_decoration:": "💟",
  ":heart_eyes:": "😍",
  ":heart_eyes_cat:": "😻",
  ":heartbeat:": "💓",
  ":heartpulse:": "💗",
  ":heavy_dollar_sign:": "💲",
  ":helicopter:": "🚁",
  ":herb:": "🌿",
  ":hibiscus:": "🌺",
  ":high_brightness:": "🔆",
  ":high_heel:": "👠",
  ":hocho:": "🔪",
  ":honey_pot:": "🍯",
  ":honeybee:": "🐝",
  ":horse:": "🐴",
  ":horse_racing:": "🏇",
  ":hospital:": "🏥",
  ":hotel:": "🏨",
  ":house:": "🏠",
  ":house_with_garden:": "🏡",
  ":hushed:": "😯",
  ":ice_cream:": "🍨",
  ":icecream:": "🍦",
  ":id:": "🆔",
  ":ideograph_advantage:": "🉐",
  ":imp:": "👿",
  ":inbox_tray:": "📥",
  ":incoming_envelope:": "📨",
  ":information_desk_person:": "💁",
  ":innocent:": "😇",
  ":halo:": "😇",
  "0:-)": "😇",
  "0:)": "😇",
  "0:3": "😇",
  "0:-3": "😇",
  ":iphone:": "📱",
  ":izakaya_lantern:": "🏮",
  ":jack_o_lantern:": "🎃",
  ":japan:": "🗾",
  ":japanese_castle:": "🏯",
  ":japanese_goblin:": "👺",
  ":japanese_ogre:": "👹",
  ":jeans:": "👖",
  ":joy:": "😂",
  ":joy_cat:": "😹",
  ":key:": "🔑",
  ":keycap_ten:": "🔟",
  ":kimono:": "👘",
  ":kiss:": "💋",
  ":kissing:": "😗",
  ":*": "😗",
  ":^*": "😗",
  ":kissing_cat:": "😽",
  ":kissing_closed_eyes:": "😚",
  ":kissing_heart:": "😘",
  ":kissing_smiling_eyes:": "😙",
  ":koala:": "🐨",
  ":koko:": "🈁",
  ":large_blue_circle:": "🔵",
  ":large_blue_diamond:": "🔷",
  ":large_orange_diamond:": "🔶",
  ":last_quarter_moon:": "🌗",
  ":last_quarter_moon_with_face:": "🌜",
  ":laughing:": "😆",
  ":laugh:": "😆",
  ":-D": "😆",
  ":D": "😆",
  ":leaves:": "🍃",
  ":ledger:": "📒",
  ":left_luggage:": "🛅",
  ":lemon:": "🍋",
  ":leopard:": "🐆",
  ":light_rail:": "🚈",
  ":link:": "🔗",
  ":lips:": "👄",
  ":lipstick:": "💄",
  ":lock:": "🔒",
  ":lock_with_ink_pen:": "🔏",
  ":lollipop:": "🍭",
  ":loudspeaker:": "📢",
  ":love_hotel:": "🏩",
  ":love_letter:": "💌",
  ":low_brightness:": "🔅",
  ":mag:": "🔍",
  ":mag_right:": "🔎",
  ":mahjong:": "🀄",
  ":mailbox:": "📫",
  ":mailbox_closed:": "📪",
  ":mailbox_with_mail:": "📬",
  ":mailbox_with_no_mail:": "📭",
  ":man:": "👨",
  ":man_with_gua_pi_mao:": "👲",
  ":man_with_turban:": "👳",
  ":mans_shoe:": "👞",
  ":maple_leaf:": "🍁",
  ":mask:": "😷",
  ":massage:": "💆",
  ":meat_on_bone:": "🍖",
  ":mega:": "📣",
  ":melon:": "🍈",
  ":memo:": "📝",
  ":mens:": "🚹",
  ":metro:": "🚇",
  ":microphone:": "🎤",
  ":microscope:": "🔬",
  ":milky_way:": "🌌",
  ":minibus:": "🚐",
  ":minidisc:": "💽",
  ":mobile_phone_off:": "📴",
  ":money_with_wings:": "💸",
  ":moneybag:": "💰",
  ":monkey:": "🐒",
  ":monkey_face:": "🐵",
  ":monorail:": "🚝",
  ":moon:": "🌙",
  ":mortar_board:": "🎓",
  ":mount_fuji:": "🗻",
  ":mountain_bicyclist:": "🚵",
  ":mountain_cableway:": "🚠",
  ":mountain_railway:": "🚞",
  ":mouse:": "🐭",
  ":mouse2:": "🐁",
  ":movie_camera:": "🎥",
  ":moyai:": "🗿",
  ":muscle:": "💪",
  ":mushroom:": "🍄",
  ":musical_keyboard:": "🎹",
  ":musical_note:": "🎵",
  ":musical_score:": "🎼",
  ":mute:": "🔇",
  ":nail_care:": "💅",
  ":name_badge:": "📛",
  ":necktie:": "👔",
  ":neutral_face:": "😐",
  ":|": "😐",
  ":-|": "😐",
  ":new:": "🆕",
  ":new_moon:": "🌑",
  ":new_moon_with_face:": "🌚",
  ":newspaper:": "📰",
  ":ng:": "🆖",
  ":no_bell:": "🔕",
  ":no_bicycles:": "🚳",
  ":no_entry_sign:": "🚫",
  ":no_good:": "🙅",
  ":no_mobile_phones:": "📵",
  ":no_mouth:": "😶",
  ":no_pedestrians:": "🚷",
  ":no_smoking:": "🚭",
  ":non-potable_water:": "🚱",
  ":nose:": "👃",
  ":notebook:": "📓",
  ":notebook_with_decorative_cover:": "📔",
  ":notes:": "🎶",
  ":nut_and_bolt:": "🔩",
  ":o2:": "🅾",
  ":ocean:": "🌊",
  ":octopus:": "🐙",
  ":oden:": "🍢",
  ":office:": "🏢",
  ":ok:": "🆗",
  ":ok_hand:": "👌",
  ":ok_woman:": "🙆",
  ":older_man:": "👴",
  ":older_woman:": "👵",
  ":on:": "🔛",
  ":oncoming_automobile:": "🚘",
  ":oncoming_bus:": "🚍",
  ":oncoming_police_car:": "🚔",
  ":oncoming_taxi:": "🚖",
  ":open_book:": "📖",
  ":open_file_folder:": "📂",
  ":open_hands:": "👐",
  ":open_mouth:": "😮",
  ":O": "😮",
  ":-O": "😮",
  ":-o": "😮",
  ":o": "😮",
  ":orange_book:": "📙",
  ":outbox_tray:": "📤",
  ":ox:": "🐂",
  ":package:": "📦",
  ":page_facing_up:": "📄",
  ":page_with_curl:": "📃",
  ":pager:": "📟",
  ":palm_tree:": "🌴",
  ":panda_face:": "🐼",
  ":paperclip:": "📎",
  ":parking:": "🅿",
  ":passport_control:": "🛂",
  ":paw_prints:": "🐾",
  ":peach:": "🍑",
  ":pear:": "🍐",
  ":pencil:": "📝",
  ":penguin:": "🐧",
  ":pensive:": "😔",
  ":performing_arts:": "🎭",
  ":persevere:": "😣",
  ":person_frowning:": "🙍",
  ":person_with_blond_hair:": "👱",
  ":person_with_pouting_face:": "🙎",
  ":pig:": "🐷",
  ":pig2:": "🐖",
  ":pig_nose:": "🐽",
  ":pill:": "💊",
  ":pineapple:": "🍍",
  ":pizza:": "🍕",
  ":point_down:": "👇",
  ":point_left:": "👈",
  ":point_right:": "👉",
  ":point_up_2:": "👆",
  ":police_car:": "🚓",
  ":poodle:": "🐩",
  ":poop:": "💩",
  ":post_office:": "🏣",
  ":postal_horn:": "📯",
  ":postbox:": "📮",
  ":potable_water:": "🚰",
  ":pouch:": "👝",
  ":poultry_leg:": "🍗",
  ":pound:": "💷",
  ":pouting_cat:": "😾",
  ":pray:": "🙏",
  ":princess:": "👸",
  ":punch:": "👊",
  ":purple_heart:": "💜",
  ":purse:": "👛",
  ":pushpin:": "📌",
  ":put_litter_in_its_place:": "🚮",
  ":rabbit:": "🐰",
  ":rabbit2:": "🐇",
  ":racehorse:": "🐎",
  ":radio:": "📻",
  ":radio_button:": "🔘",
  ":rage:": "😡",
  ":railway_car:": "🚃",
  ":rainbow:": "🌈",
  ":raised_hands:": "🙌",
  ":raising_hand:": "🙋",
  ":ram:": "🐏",
  ":ramen:": "🍜",
  ":rat:": "🐀",
  ":red_car:": "🚗",
  ":red_circle:": "🔴",
  ":relieved:": "😌",
  ":repeat:": "🔁",
  ":repeat_one:": "🔂",
  ":restroom:": "🚻",
  ":revolving_hearts:": "💞",
  ":ribbon:": "🎀",
  ":rice:": "🍚",
  ":rice_ball:": "🍙",
  ":rice_cracker:": "🍘",
  ":rice_scene:": "🎑",
  ":ring:": "💍",
  ":rocket:": "🚀",
  ":roller_coaster:": "🎢",
  ":rooster:": "🐓",
  ":rose:": "🌹",
  ":rotating_light:": "🚨",
  ":round_pushpin:": "📍",
  ":rowboat:": "🚣",
  ":rugby_football:": "🏉",
  ":runner:": "🏃",
  ":running:": "🏃",
  ":running_shirt_with_sash:": "🎽",
  ":sa:": "🈂",
  ":sake:": "🍶",
  ":sandal:": "👡",
  ":santa:": "🎅",
  ":satellite:": "📡",
  ":satisfied:": "😆",
  ":saxophone:": "🎷",
  ":school:": "🏫",
  ":school_satchel:": "🎒",
  ":scream:": "😱",
  ":scream_cat:": "🙀",
  ":scroll:": "📜",
  ":seat:": "💺",
  ":see_no_evil:": "🙈",
  ":seedling:": "🌱",
  ":shaved_ice:": "🍧",
  ":sheep:": "🐑",
  ":shell:": "🐚",
  ":ship:": "🚢",
  ":shirt:": "👕",
  ":shit:": "💩",
  ":shoe:": "👞",
  ":shower:": "🚿",
  ":signal_strength:": "📶",
  ":six_pointed_star:": "🔯",
  ":ski:": "🎿",
  ":skull:": "💀",
  ":sleeping:": "😴",
  ":sleepy:": "😪",
  ":slot_machine:": "🎰",
  ":small_blue_diamond:": "🔹",
  ":small_orange_diamond:": "🔸",
  ":small_red_triangle:": "🔺",
  ":small_red_triangle_down:": "🔻",
  ":smile:": "😄",
  ":))": "😄",
  ":-))": "😄",
  ":smile_cat:": "😸",
  ":smiley:": "😃",
  ":-)": "😃",
  ":)": "😃",
  ":]": "😃",
  ":o)": "😃",
  ":smiley_cat:": "😺",
  ":smiling_imp:": "😈",
  "}:-)": "😈",
  "3:-)": "😈",
  "}:)": "😈",
  "3:)": "😈",
  ":smirk:": "😏",
  ":smirk_cat:": "😼",
  ":smoking:": "🚬",
  ":snail:": "🐌",
  ":snake:": "🐍",
  ":snowboarder:": "🏂",
  ":sob:": "😭",
  ":soon:": "🔜",
  ":sos:": "🆘",
  ":sound:": "🔉",
  ":space_invader:": "👾",
  ":spaghetti:": "🍝",
  ":sparkler:": "🎇",
  ":sparkling_heart:": "💖",
  ":speak_no_evil:": "🙊",
  ":speaker:": "🔊",
  ":speech_balloon:": "💬",
  ":speedboat:": "🚤",
  ":star2:": "🌟",
  ":stars:": "🌃",
  ":station:": "🚉",
  ":statue_of_liberty:": "🗽",
  ":steam_locomotive:": "🚂",
  ":stew:": "🍲",
  ":straight_ruler:": "📏",
  ":strawberry:": "🍓",
  ":stuck_out_tongue:": "😛",
  ":P": "😛",
  ":-P": "😛",
  ":-p": "😛",
  ":p": "😛",
  ":stuck_out_tongue_closed_eyes:": "😝",
  "XP": "😝",
  "X-P": "😝",
  "xP": "😝",
  "x-P": "😝",
  "Xp": "😝",
  "X-p": "😝",
  ":stuck_out_tongue_winking_eye:": "😜",
  ":sun_with_face:": "🌞",
  ":sunflower:": "🌻",
  ":sunglasses:": "😎",
  "8-)": "😎",
  "8)": "😎",
  ":sunrise:": "🌅",
  ":sunrise_over_mountains:": "🌄",
  ":surfer:": "🏄",
  ":sushi:": "🍣",
  ":suspension_railway:": "🚟",
  ":sweat:": "😓",
  ":sweat_drops:": "💦",
  ":sweat_smile:": "😅",
  ":sweet_potato:": "🍠",
  ":swimmer:": "🏊",
  ":symbols:": "🔣",
  ":syringe:": "💉",
  ":tada:": "🎉",
  ":tanabata_tree:": "🎋",
  ":tangerine:": "🍊",
  ":taxi:": "🚕",
  ":tea:": "🍵",
  ":telephone_receiver:": "📞",
  ":telescope:": "🔭",
  ":tennis:": "🎾",
  ":thought_balloon:": "💭",
  ":thumbsdown:": "👎",
  ":thumbsup:": "👍",
  ":ticket:": "🎫",
  ":tiger:": "🐯",
  ":tiger2:": "🐅",
  ":tired_face:": "😫",
  ":toilet:": "🚽",
  ":tokyo_tower:": "🗼",
  ":tomato:": "🍅",
  ":tongue:": "👅",
  ":top:": "🔝",
  ":tophat:": "🎩",
  ":tractor:": "🚜",
  ":traffic_light:": "🚥",
  ":train:": "🚃",
  ":train2:": "🚆",
  ":tram:": "🚊",
  ":triangular_flag_on_post:": "🚩",
  ":triangular_ruler:": "📐",
  ":trident:": "🔱",
  ":triumph:": "😤",
  ":trolleybus:": "🚎",
  ":trophy:": "🏆",
  ":tropical_drink:": "🍹",
  ":tropical_fish:": "🐠",
  ":truck:": "🚚",
  ":trumpet:": "🎺",
  ":tshirt:": "👕",
  ":tulip:": "🌷",
  ":turtle:": "🐢",
  ":tv:": "📺",
  ":twisted_rightwards_arrows:": "🔀",
  ":two_hearts:": "💕",
  ":two_men_holding_hands:": "👬",
  ":two_women_holding_hands:": "👭",
  ":u5272:": "🈹",
  ":u5408:": "🈴",
  ":u55b6:": "🈺",
  ":u6307:": "🈯",
  ":u6708:": "🈷",
  ":u6709:": "🈶",
  ":u6e80:": "🈵",
  ":u7121:": "🈚",
  ":u7533:": "🈸",
  ":u7981:": "🈲",
  ":u7a7a:": "🈳",
  ":unamused:": "😒",
  ":\\": "😒",
  ":-\\": "😒",
  ":-/": "😒",
  ":/": "😒",
  ":underage:": "🔞",
  ":unlock:": "🔓",
  ":up:": "🆙",
  ":vertical_traffic_light:": "🚦",
  ":vhs:": "📼",
  ":vibration_mode:": "📳",
  ":video_camera:": "📹",
  ":video_game:": "🎮",
  ":violin:": "🎻",
  ":volcano:": "🌋",
  ":vs:": "🆚",
  ":walking:": "🚶",
  ":waning_crescent_moon:": "🌘",
  ":waning_gibbous_moon:": "🌖",
  ":water_buffalo:": "🐃",
  ":watermelon:": "🍉",
  ":wave:": "👋",
  ":waxing_crescent_moon:": "🌒",
  ":waxing_gibbous_moon:": "🌔",
  ":wc:": "🚾",
  ":weary:": "😩",
  ":wedding:": "💒",
  ":whale:": "🐳",
  ":whale2:": "🐋",
  ":white_flower:": "💮",
  ":white_square_button:": "🔳",
  ":wind_chime:": "🎐",
  ":wine_glass:": "🍷",
  ":wink:": "😉",
  ";)": "😉",
  ";-)": "😉",
  ":wolf:": "🐺",
  ":woman:": "👩",
  ":womans_clothes:": "👚",
  ":womans_hat:": "👒",
  ":womens:": "🚺",
  ":worried:": "😟",
  ":wrench:": "🔧",
  ":yellow_heart:": "💛",
  ":yen:": "💴",
  ":yum:": "😋",
  ":zzz:": "💤"
};

/***/ }),

/***/ "./containers/TypeWriter/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_mobx_react__ = __webpack_require__("./node_modules/mobx-react/index.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Editor__ = __webpack_require__("./containers/TypeWriter/Editor.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Preview__ = __webpack_require__("./containers/TypeWriter/Preview.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__MarkDownHelper__ = __webpack_require__("./containers/TypeWriter/MarkDownHelper.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__logic__ = __webpack_require__("./containers/TypeWriter/logic.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__Footer__ = __webpack_require__("./containers/TypeWriter/Footer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__styles__ = __webpack_require__("./containers/TypeWriter/styles/index.js");
var _this = this,
    _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/TypeWriter/index.js";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * TypeWriter
 *
 */
 // import PropTypes from 'prop-types'

 // import ContentInput from './ContentInput'









/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_6__utils__["H" /* makeDebugger */])('C:TypeWriter');
/* eslint-enable no-unused-vars */

var View = function View(_ref) {
  var curView = _ref.curView,
      articleType = _ref.articleType,
      copyrightChange = _ref.copyrightChange,
      title = _ref.title,
      body = _ref.body,
      linkAddr = _ref.linkAddr;

  // const curView = 'create' // markdown_help
  if (curView === 'CREATE_VIEW' || curView === 'PREVIEW_VIEW') {
    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49
      }
    }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["h" /* EditorBlock */], {
      name: "CREATE_VIEW",
      curView: curView,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50
      }
    }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__Editor__["a" /* default */], {
      articleType: articleType,
      copyrightChange: copyrightChange,
      title: title,
      titleOnChange: __WEBPACK_IMPORTED_MODULE_7__logic__["i" /* titleOnChange */],
      linkAddr: linkAddr,
      linkSourceOnChange: __WEBPACK_IMPORTED_MODULE_7__logic__["f" /* linkSourceOnChange */],
      body: body,
      bodyOnChange: __WEBPACK_IMPORTED_MODULE_7__logic__["a" /* bodyOnChange */],
      onPreview: __WEBPACK_IMPORTED_MODULE_7__logic__["c" /* changeView */].bind(_this, 'PREVIEW_VIEW'),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 51
      }
    })), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["o" /* PreviewBlock */], {
      name: "PREVIEW_VIEW",
      curView: curView,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63
      }
    }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__Preview__["a" /* default */], {
      title: title,
      body: body,
      onBack: __WEBPACK_IMPORTED_MODULE_7__logic__["c" /* changeView */].bind(_this, 'CREATE_VIEW'),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      }
    })));
  }

  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__MarkDownHelper__["a" /* default */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 73
    }
  });
};

var TopHeader = function TopHeader(_ref2) {
  var curView = _ref2.curView;

  switch (curView) {
    case 'MARKDOWN_HELP_VIEW':
      {
        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["i" /* Header */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 80
          }
        }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["v" /* UsageText */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 81
          }
        }, "Github Flavor Markdown"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["a" /* BackToEditHint */], {
          onClick: __WEBPACK_IMPORTED_MODULE_7__logic__["c" /* changeView */].bind(_this, 'CREATE_VIEW'),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 82
          }
        }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["m" /* MarkdownIcon */], {
          src: "".concat(__WEBPACK_IMPORTED_MODULE_2__config__["e" /* ICON_ASSETS */], "/cmd/original.svg"),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 83
          }
        }), "\u8FD4\u56DE\u7F16\u8F91"));
      }

    default:
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["i" /* Header */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 91
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["v" /* UsageText */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 92
        }
      }, "\u53D1\u5E03\u5E16\u5B50"), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["l" /* MarkDownHint */], {
        onClick: __WEBPACK_IMPORTED_MODULE_7__logic__["c" /* changeView */].bind(_this, 'MARKDOWN_HELP_VIEW'),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 93
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["m" /* MarkdownIcon */], {
        src: "".concat(__WEBPACK_IMPORTED_MODULE_2__config__["e" /* ICON_ASSETS */], "/cmd/markdown.svg"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 96
        }
      }), "markdown \u8BED\u6CD5 / emojj \u901F\u67E5"));
  }
}; // TODO: use input in old IE


var TypeWriterContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(TypeWriterContainer, _React$Component);

  function TypeWriterContainer() {
    _classCallCheck(this, TypeWriterContainer);

    return _possibleConstructorReturn(this, (TypeWriterContainer.__proto__ || Object.getPrototypeOf(TypeWriterContainer)).apply(this, arguments));
  }

  _createClass(TypeWriterContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var typeWriter = this.props.typeWriter;
      __WEBPACK_IMPORTED_MODULE_7__logic__["e" /* init */](typeWriter);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      debug('TODO: store state to localstarange'); // Message.success('草稿已经保存')
    }
  }, {
    key: "render",
    value: function render() {
      var _props$typeWriter = this.props.typeWriter,
          articleType = _props$typeWriter.articleType,
          curView = _props$typeWriter.curView,
          linkAddr = _props$typeWriter.linkAddr,
          title = _props$typeWriter.title,
          body = _props$typeWriter.body,
          publishing = _props$typeWriter.publishing,
          success = _props$typeWriter.success,
          error = _props$typeWriter.error,
          warn = _props$typeWriter.warn,
          statusMsg = _props$typeWriter.statusMsg;
      return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__styles__["w" /* Wrapper */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 133
        }
      }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(TopHeader, {
        curView: curView,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 134
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(View, {
        curView: curView,
        linkAddr: linkAddr,
        title: title,
        body: body,
        articleType: articleType,
        copyrightChange: __WEBPACK_IMPORTED_MODULE_7__logic__["d" /* copyrightChange */],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 135
        }
      }), __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__Footer__["a" /* default */], {
        onPublish: __WEBPACK_IMPORTED_MODULE_7__logic__["g" /* onPublish */],
        publishing: publishing,
        success: success,
        error: error,
        warn: warn,
        statusMsg: statusMsg,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 143
        }
      }));
    }
  }]);

  return TypeWriterContainer;
}(__WEBPACK_IMPORTED_MODULE_0_react___default.a.Component); // TypeWriterContainer.propTypes = {
// https://www.npmjs.com/package/prop-types
// closePreview: PropTypes.func.isRequired,
// }
// TypeWriterContainer.defaultProps = {}


/* harmony default export */ __webpack_exports__["default"] = (Object(__WEBPACK_IMPORTED_MODULE_1_mobx_react__["b" /* inject */])(Object(__WEBPACK_IMPORTED_MODULE_6__utils__["U" /* storePlug */])('typeWriter'))(Object(__WEBPACK_IMPORTED_MODULE_1_mobx_react__["c" /* observer */])(TypeWriterContainer)));

/***/ }),

/***/ "./containers/TypeWriter/logic.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["d"] = copyrightChange;
/* harmony export (immutable) */ __webpack_exports__["c"] = changeView;
/* harmony export (immutable) */ __webpack_exports__["h"] = onUploadImageDone;
/* harmony export (immutable) */ __webpack_exports__["g"] = onPublish;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return canclePublish; });
/* harmony export (immutable) */ __webpack_exports__["a"] = bodyOnChange;
/* harmony export (immutable) */ __webpack_exports__["i"] = titleOnChange;
/* harmony export (immutable) */ __webpack_exports__["f"] = linkSourceOnChange;
/* harmony export (immutable) */ __webpack_exports__["e"] = init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_isEmpty__ = __webpack_require__("./node_modules/ramda/src/isEmpty.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_isEmpty___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ramda_src_isEmpty__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_ramda_src_repeat__ = __webpack_require__("./node_modules/ramda/src/repeat.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_ramda_src_repeat___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_ramda_src_repeat__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ramda_src_trim__ = __webpack_require__("./node_modules/ramda/src/trim.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ramda_src_trim___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ramda_src_trim__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ramda_src_slice__ = __webpack_require__("./node_modules/ramda/src/slice.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ramda_src_slice___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_ramda_src_slice__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__schema__ = __webpack_require__("./containers/TypeWriter/schema.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utils_network_sr71__ = __webpack_require__("./utils/network/sr71.js");







var sr71$ = new __WEBPACK_IMPORTED_MODULE_6__utils_network_sr71__["a" /* default */]();
/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_4__utils__["H" /* makeDebugger */])('L:TypeWriter');
/* eslint-enable no-unused-vars */

var store = null;
var sub$ = null;
function copyrightChange(articleType) {
  store.markState({
    articleType: articleType
  });
}
function changeView(curView) {
  store.markState({
    curView: curView
  });
}

function checkValid() {
  var _store2 = store,
      body = _store2.body,
      title = _store2.title,
      articleType = _store2.articleType,
      linkAddr = _store2.linkAddr;

  if (Object(__WEBPACK_IMPORTED_MODULE_4__utils__["E" /* isEmptyValue */])(body) || Object(__WEBPACK_IMPORTED_MODULE_4__utils__["E" /* isEmptyValue */])(title)) {
    Object(__WEBPACK_IMPORTED_MODULE_4__utils__["K" /* meteorState */])(store, 'error', 5, '文章标题 或 文章内容 不能为空');
    return false;
  }

  if (articleType !== 'original' && Object(__WEBPACK_IMPORTED_MODULE_4__utils__["E" /* isEmptyValue */])(linkAddr)) {
    Object(__WEBPACK_IMPORTED_MODULE_4__utils__["K" /* meteorState */])(store, 'error', 5, '请填写完整地址以方便跳转, http(s)://...');
    return false;
  }

  return true;
}

function onUploadImageDone(url) {
  debug('onUploadImageDone: ', url);
  Object(__WEBPACK_IMPORTED_MODULE_4__utils__["u" /* dispatchEvent */])(__WEBPACK_IMPORTED_MODULE_4__utils__["e" /* EVENT */].DRAFT_INSERT_SNIPPET, {
    type: 'Image',
    data: "![](".concat(url, ")")
  });
}

var getDigest = function getDigest(body) {
  /* eslint-disable no-undef */
  var digestContainer = document.getElementById('typewriter-preview-container');
  /* eslint-enable no-undef */

  var innerImagesLength = Object(__WEBPACK_IMPORTED_MODULE_4__utils__["v" /* extractAttachments */])(body).length;

  var digest = __WEBPACK_IMPORTED_MODULE_3_ramda_src_slice___default()(0, 65, __WEBPACK_IMPORTED_MODULE_2_ramda_src_trim___default()(digestContainer.innerText));

  if (innerImagesLength > 0 && innerImagesLength <= 2) {
    var imgDigest = "".concat(__WEBPACK_IMPORTED_MODULE_1_ramda_src_repeat___default()('[图片]', innerImagesLength));
    digest = __WEBPACK_IMPORTED_MODULE_0_ramda_src_isEmpty___default()(digest) ? imgDigest : "".concat(digest, "..").concat(imgDigest);
  } else if (innerImagesLength > 2) {
    var _imgDigest = "".concat(__WEBPACK_IMPORTED_MODULE_1_ramda_src_repeat___default()('[图片]', 2), " x ").concat(innerImagesLength);

    digest = __WEBPACK_IMPORTED_MODULE_0_ramda_src_isEmpty___default()(digest) ? _imgDigest : "".concat(digest, "..").concat(_imgDigest);
  }

  return digest;
}; // TODO move specfical logic outof here


function onPublish() {
  // debug('onPublish: ', store.body)
  var _store3 = store,
      body = _store3.body,
      title = _store3.title,
      articleType = _store3.articleType;

  if (checkValid()) {
    publishing();
    var digest = getDigest(body);
    var length = Object(__WEBPACK_IMPORTED_MODULE_4__utils__["r" /* countWords */])(body);
    var variables = {
      title: title,
      body: body,
      digest: digest,
      length: length,
      communityId: store.viewing.community.id
    };
    if (articleType !== 'original') variables.linkAddr = store.linkAddr; // debug('variables-: ', variables)
    // TODO: switch createJob

    sr71$.mutate(__WEBPACK_IMPORTED_MODULE_5__schema__["a" /* default */].createPost, variables);
  }
}
var canclePublish = function canclePublish() {
  debug('canclePublish');
  cancleLoading(); // store.reset()

  store.closePreview();
};
function bodyOnChange(body) {
  // debug('editorOnChange: ', body)
  store.markState({
    body: body
  });
}
function titleOnChange(e) {
  store.markState({
    title: e.target.value
  });
}
function linkSourceOnChange(e) {
  store.markState({
    linkAddr: e.target.value
  });
}

function publishing() {
  var maybe = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  store.markState({
    publishing: maybe
  });
}

var DataSolver = [{
  match: Object(__WEBPACK_IMPORTED_MODULE_4__utils__["n" /* asyncRes */])('createPost'),
  action: function action() {
    cancleLoading();
    store.reset();
    store.closePreview();
    Object(__WEBPACK_IMPORTED_MODULE_4__utils__["u" /* dispatchEvent */])(__WEBPACK_IMPORTED_MODULE_4__utils__["e" /* EVENT */].REFRESH_POSTS); // 1. empty the store
    // 2. close the preview
    // 3. notify the xxxPaper
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_4__utils__["n" /* asyncRes */])(__WEBPACK_IMPORTED_MODULE_4__utils__["e" /* EVENT */].PREVIEW),
  action: function action() {}
}];

var cancleLoading = function cancleLoading() {
  store.markState({
    publishing: false
  });
};

var ErrSolver = [{
  match: Object(__WEBPACK_IMPORTED_MODULE_4__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_4__utils__["d" /* ERR */].CRAPHQL),
  action: function action(_ref) {
    var details = _ref.details;
    var errMsg = details[0].detail;
    debug('ERR.CRAPHQL -->', details);
    Object(__WEBPACK_IMPORTED_MODULE_4__utils__["K" /* meteorState */])(store, 'error', 5, errMsg);
    cancleLoading();
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_4__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_4__utils__["d" /* ERR */].TIMEOUT),
  action: function action(_ref2) {
    var details = _ref2.details;
    debug('ERR.TIMEOUT -->', details);
    cancleLoading();
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_4__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_4__utils__["d" /* ERR */].NETWORK),
  action: function action(_ref3) {
    var details = _ref3.details;
    debug('ERR.NETWORK -->', details);
    cancleLoading();
  }
}];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(__WEBPACK_IMPORTED_MODULE_4__utils__["a" /* $solver */])(DataSolver, ErrSolver));
}

/***/ }),

/***/ "./containers/TypeWriter/schema.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag__ = __webpack_require__("./node_modules/graphql-tag/src/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_graphql_tag__);
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  mutation(\n    $title: String!\n    $body: String!\n    $digest: String!\n    $length: Int!\n    $linkAddr: String\n    $communityId: ID!\n  ) {\n    createPost(\n      title: $title\n      body: $body\n      digest: $digest\n      length: $length\n      linkAddr: $linkAddr\n      communityId: $communityId\n    ) {\n      id\n      title\n      body\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var createPost = __WEBPACK_IMPORTED_MODULE_0_graphql_tag___default()(_templateObject);
var schema = {
  createPost: createPost
};
/* harmony default export */ __webpack_exports__["a"] = (schema);

/***/ }),

/***/ "./containers/TypeWriter/styles/editor.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return ExtraWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return ExtraItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExtraDivider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return ExtraItemTitle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return ExtraItemIcon; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utils__ = __webpack_require__("./utils/index.js");



var ExtraWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "editor__ExtraWrapper",
  componentId: "s11203rz-0"
})(["display:flex;justify-content:center;"]);
var ExtraItem =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "editor__ExtraItem",
  componentId: "s11203rz-1"
})(["display:flex;color:", ";&:hover{color:#51abb2;animation:", " 0.4s linear;}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.footer'), __WEBPACK_IMPORTED_MODULE_2__utils__["b" /* Animate */].pulse);
var ExtraDivider =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "editor__ExtraDivider",
  componentId: "s11203rz-2"
})(["fill:#75898a;width:10px;height:10px;margin-left:4px;margin-right:4px;"]);
var ExtraItemTitle =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "editor__ExtraItemTitle",
  componentId: "s11203rz-3"
})(["cursor:pointer;font-size:1.2em;", ":hover &{color:", ";}"], ExtraItem, Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.footerHover'));
var ExtraItemIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "editor__ExtraItemIcon",
  componentId: "s11203rz-4"
})(["fill:", ";width:17px;height:17px;margin-right:3px;margin-top:2px;", ":hover &{fill:", ";}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content'), ExtraItem, Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.footerHover'));

/***/ }),

/***/ "./containers/TypeWriter/styles/footer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return FooterWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return RespectText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Divider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return PublishBtns; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__("./utils/index.js");


var FooterWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "footer__FooterWrapper",
  componentId: "s1ll3u5v-0"
})(["display:flex;flex-direction:column;align-items:center;margin-top:30px;margin-left:35px;margin-right:40px;margin-bottom:50px;"]);
var RespectText =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "footer__RespectText",
  componentId: "s1ll3u5v-1"
})(["color:", ";display:", ";"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('editor.placeholder'), function (_ref) {
  var show = _ref.show;
  return show ? 'block' : 'none';
});
var Divider =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "footer__Divider",
  componentId: "s1ll3u5v-2"
})(["border-top:1px solid;border-color:", ";margin-top:10px;width:55%;margin-bottom:20px;"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('editor.placeholder'));
var PublishBtns =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "footer__PublishBtns",
  componentId: "s1ll3u5v-3"
})(["width:50%;text-align:center;"]);

/***/ }),

/***/ "./containers/TypeWriter/styles/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return EditorBlock; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return PreviewBlock; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "u", function() { return TitleInput; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "w", function() { return Wrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return Header; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "v", function() { return UsageText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return MarkdownIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return MarkDownHint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BackToEditHint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return BodyWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return BodyHeader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return CopyRightCheck; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return CopyRightText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "r", function() { return ReprintWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "q", function() { return ReprintIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return MoreIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "t", function() { return SourceLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return LinkInput; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return LinkLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "p", function() { return PreviewBtn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "s", function() { return Selector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return CheckIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return CheckText; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utils__ = __webpack_require__("./utils/index.js");



var EditorBlock =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__EditorBlock",
  componentId: "zc119b-0"
})(["display:", ";"], function (_ref) {
  var name = _ref.name,
      curView = _ref.curView;
  return name === curView ? 'block' : 'none';
});
var PreviewBlock =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__PreviewBlock",
  componentId: "zc119b-1"
})(["display:", ";"], function (_ref2) {
  var name = _ref2.name,
      curView = _ref2.curView;
  return name === curView ? 'block' : 'none';
});
var TitleInput =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["m" /* Input */]).withConfig({
  displayName: "styles__TitleInput",
  componentId: "zc119b-2"
})(["border-color:", ";border-bottom:1px solid;border-bottom-color:", ";::placeholder{color:", ";}text-align:center;height:45px;font-size:1.6em;color:", ";background:", ";align-self:center;width:85%;&:hover{border-color:", ";border-bottom:1px solid;border-bottom-color:", ";}&:focus{border-color:", ";box-shadow:none;border-bottom:1px solid;border-bottom-color:", ";}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.border'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.borderNormal'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.placeholder'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.headerBg'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.border'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.borderActive'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.border'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.borderActive'));
var Wrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "zc119b-3"
})([""]);
var Header =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__Header",
  componentId: "zc119b-4"
})(["display:flex;margin-left:35px;margin-right:35px;padding-top:15px;margin-bottom:10px;"]);
var UsageText =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__UsageText",
  componentId: "zc119b-5"
})(["color:", ";font-size:1.3em;flex-grow:1;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content'));
var MarkdownIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "styles__MarkdownIcon",
  componentId: "zc119b-6"
})(["fill:#51abb2;width:20px;height:18px;margin-right:5px;", ":hover &{fill:#618c92;}"], MarkDownHint);
var MarkDownHint =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__MarkDownHint",
  componentId: "zc119b-7"
})(["display:flex;color:", ";&:hover{color:", ";cursor:pointer;}transition:color 0.3s;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.placeholder'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content')); // this is from top

var BackToEditHint =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__BackToEditHint",
  componentId: "zc119b-8"
})(["display:flex;color:", ";cursor:pointer;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'));
var BodyWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__BodyWrapper",
  componentId: "zc119b-9"
})(["padding:20px;background-color:", ";min-height:600px;margin-top:5px;margin-left:4%;margin-right:4%;border-radius:5px;flex-direction:column;display:flex;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.contentBg'));
var BodyHeader =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__BodyHeader",
  componentId: "zc119b-10"
})(["display:flex;justify-content:space-between;"]);
var CopyRightCheck =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__CopyRightCheck",
  componentId: "zc119b-11"
})(["display:flex;"]);
var CopyRightText =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__CopyRightText",
  componentId: "zc119b-12"
})(["font-size:1.1em;"]);
var ReprintWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__ReprintWrapper",
  componentId: "zc119b-13"
})(["color:", ";display:flex;cursor:pointer;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content'));
var ReprintIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "styles__ReprintIcon",
  componentId: "zc119b-14"
})(["fill:", ";width:14px;height:14px;margin-top:3px;margin-right:5px;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content'));
var MoreIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "styles__MoreIcon",
  componentId: "zc119b-15"
})(["width:14px;height:14px;margin-top:3px;fill:", ";&:hover{cursor:pointer;}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.placeholder'));
var SourceLink =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__SourceLink",
  componentId: "zc119b-16"
})(["display:flex;width:60%;justify-content:center;"]);
var LinkInput =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["m" /* Input */]).withConfig({
  displayName: "styles__LinkInput",
  componentId: "zc119b-17"
})(["border:1px solid;border-color:", ";height:20px;line-height:20px;width:50%;font-size:0.9em;margin-top:-1px;background:", ";padding-left:2px;color:", ";::placeholder{color:", ";}text-align:left;&:hover{border-color:", ";border-bottom:1px solid;border-bottom-color:", ";color:", ";}&:focus{border-color:", ";box-shadow:none;border-bottom:1px solid;border-bottom-color:", ";color:", ";text-align:left;}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.border'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.headerBg'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.placeholder'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.headerBg'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.border'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.headerBg'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.placeholder'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'));
var LinkLabel =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__LinkLabel",
  componentId: "zc119b-18"
})(["font-size:0.9em;color:", ";", ":hover &{color:", ";}transition:color 0.3s;"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.placeholder'), SourceLink, Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'));
var PreviewBtn =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__PreviewBtn",
  componentId: "zc119b-19"
})(["margin-top:-3px;"]);
var Selector =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__Selector",
  componentId: "zc119b-20"
})(["display:flex;&:hover{cursor:pointer;color:", ";}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.title'));
var CheckIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "styles__CheckIcon",
  componentId: "zc119b-21"
})(["fill:", ";width:18px;height:18px;margin-top:2px;margin-right:3px;visibility:", ";"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content'), function (_ref3) {
  var active = _ref3.active,
      value = _ref3.value;
  return active === value ? 'visiable' : 'hidden';
});
var CheckText =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__CheckText",
  componentId: "zc119b-22"
})(["color:", ";"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('editor.content'));

/***/ }),

/***/ "./containers/TypeWriter/styles/markdown_helper.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return EmojiWraper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EmojiItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return Wrapper; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__("./utils/index.js");


var EmojiWraper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "markdown_helper__EmojiWraper",
  componentId: "s1bqnfqi-0"
})(["margin-top:18px;"]);
var EmojiItem =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "markdown_helper__EmojiItem",
  componentId: "s1bqnfqi-1"
})(["width:200px;"]);
var Wrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "markdown_helper__Wrapper",
  componentId: "s1bqnfqi-2"
})(["background:", ";padding:20px;margin-left:4%;margin-right:4%;"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('preview.markdownHelperBg'));

/***/ }),

/***/ "./containers/TypeWriter/styles/preview.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return PreviewHeader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BackToEditBtn; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__index__ = __webpack_require__("./containers/TypeWriter/styles/index.js");
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return __WEBPACK_IMPORTED_MODULE_2__index__["b"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return __WEBPACK_IMPORTED_MODULE_2__index__["c"]; });
 // BodyWrapper, BodyHeader, BackToEditBtn, PreviewHeader



var PreviewHeader =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "preview__PreviewHeader",
  componentId: "s1jmfbbs-0"
})(["color:", ";margin-bottom:15px;padding-bottom:10px;text-align:center;font-size:1.5em;align-self:center;border-bottom:1px solid;border-bottom-color:", ";width:80%;min-height:1.5em;"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('preview.title'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('preview.divider'));
var BackToEditBtn =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "preview__BackToEditBtn",
  componentId: "s1jmfbbs-1"
})([""]);

/***/ }),

/***/ "./node_modules/ramda/src/always.js":
/***/ (function(module, exports, __webpack_require__) {

var _curry1 = /*#__PURE__*/__webpack_require__("./node_modules/ramda/src/internal/_curry1.js");

/**
 * Returns a function that always returns the given value. Note that for
 * non-primitives the value returned is a reference to the original value.
 *
 * This function is known as `const`, `constant`, or `K` (for K combinator) in
 * other languages and libraries.
 *
 * @func
 * @memberOf R
 * @since v0.1.0
 * @category Function
 * @sig a -> (* -> a)
 * @param {*} val The value to wrap in a function
 * @return {Function} A Function :: * -> val.
 * @example
 *
 *      var t = R.always('Tee');
 *      t(); //=> 'Tee'
 */


var always = /*#__PURE__*/_curry1(function always(val) {
  return function () {
    return val;
  };
});
module.exports = always;

/***/ }),

/***/ "./node_modules/ramda/src/repeat.js":
/***/ (function(module, exports, __webpack_require__) {

var _curry2 = /*#__PURE__*/__webpack_require__("./node_modules/ramda/src/internal/_curry2.js");

var always = /*#__PURE__*/__webpack_require__("./node_modules/ramda/src/always.js");

var times = /*#__PURE__*/__webpack_require__("./node_modules/ramda/src/times.js");

/**
 * Returns a fixed list of size `n` containing a specified identical value.
 *
 * @func
 * @memberOf R
 * @since v0.1.1
 * @category List
 * @sig a -> n -> [a]
 * @param {*} value The value to repeat.
 * @param {Number} n The desired size of the output list.
 * @return {Array} A new array containing `n` `value`s.
 * @see R.times
 * @example
 *
 *      R.repeat('hi', 5); //=> ['hi', 'hi', 'hi', 'hi', 'hi']
 *
 *      var obj = {};
 *      var repeatedObjs = R.repeat(obj, 5); //=> [{}, {}, {}, {}, {}]
 *      repeatedObjs[0] === repeatedObjs[1]; //=> true
 * @symb R.repeat(a, 0) = []
 * @symb R.repeat(a, 1) = [a]
 * @symb R.repeat(a, 2) = [a, a]
 */


var repeat = /*#__PURE__*/_curry2(function repeat(value, n) {
  return times(always(value), n);
});
module.exports = repeat;

/***/ }),

/***/ "./node_modules/ramda/src/times.js":
/***/ (function(module, exports, __webpack_require__) {

var _curry2 = /*#__PURE__*/__webpack_require__("./node_modules/ramda/src/internal/_curry2.js");

/**
 * Calls an input function `n` times, returning an array containing the results
 * of those function calls.
 *
 * `fn` is passed one argument: The current value of `n`, which begins at `0`
 * and is gradually incremented to `n - 1`.
 *
 * @func
 * @memberOf R
 * @since v0.2.3
 * @category List
 * @sig (Number -> a) -> Number -> [a]
 * @param {Function} fn The function to invoke. Passed one argument, the current value of `n`.
 * @param {Number} n A value between `0` and `n - 1`. Increments after each function call.
 * @return {Array} An array containing the return values of all calls to `fn`.
 * @see R.repeat
 * @example
 *
 *      R.times(R.identity, 5); //=> [0, 1, 2, 3, 4]
 * @symb R.times(f, 0) = []
 * @symb R.times(f, 1) = [f(0)]
 * @symb R.times(f, 2) = [f(0), f(1)]
 */


var times = /*#__PURE__*/_curry2(function times(fn, n) {
  var len = Number(n);
  var idx = 0;
  var list;

  if (len < 0 || isNaN(len)) {
    throw new RangeError('n must be a non-negative number');
  }
  list = new Array(len);
  while (idx < len) {
    list[idx] = fn(idx);
    idx += 1;
  }
  return list;
});
module.exports = times;

/***/ })

})
        })
      ;
//# sourceMappingURL=containers_TypeWriter_31f1ffd146dca69bcb7a302edb951907.js.map