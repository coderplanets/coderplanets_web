exports.ids = [0];
exports.modules = {

/***/ 161:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: external "react"
var external__react_ = __webpack_require__(1);
var external__react__default = /*#__PURE__*/__webpack_require__.n(external__react_);

// EXTERNAL MODULE: external "mobx-react"
var external__mobx_react_ = __webpack_require__(6);
var external__mobx_react__default = /*#__PURE__*/__webpack_require__.n(external__mobx_react_);

// EXTERNAL MODULE: ./config/index.js + 1 modules
var config = __webpack_require__(4);

// EXTERNAL MODULE: external "prop-types"
var external__prop_types_ = __webpack_require__(7);
var external__prop_types__default = /*#__PURE__*/__webpack_require__.n(external__prop_types_);

// EXTERNAL MODULE: ./components/index.js + 38 modules
var components = __webpack_require__(3);

// EXTERNAL MODULE: ./containers/TypeWriter/BodyEditor.js + 2 modules
var BodyEditor = __webpack_require__(52);

// EXTERNAL MODULE: external "ramda/src/isEmpty"
var isEmpty_ = __webpack_require__(9);
var isEmpty__default = /*#__PURE__*/__webpack_require__.n(isEmpty_);

// EXTERNAL MODULE: external "ramda/src/repeat"
var repeat_ = __webpack_require__(162);
var repeat__default = /*#__PURE__*/__webpack_require__.n(repeat_);

// EXTERNAL MODULE: external "ramda/src/trim"
var trim_ = __webpack_require__(51);
var trim__default = /*#__PURE__*/__webpack_require__.n(trim_);

// EXTERNAL MODULE: external "ramda/src/slice"
var slice_ = __webpack_require__(29);
var slice__default = /*#__PURE__*/__webpack_require__.n(slice_);

// EXTERNAL MODULE: ./utils/index.js + 22 modules
var utils = __webpack_require__(0);

// EXTERNAL MODULE: external "graphql-tag"
var external__graphql_tag_ = __webpack_require__(11);
var external__graphql_tag__default = /*#__PURE__*/__webpack_require__.n(external__graphql_tag_);

// CONCATENATED MODULE: ./containers/TypeWriter/schema.js
var _templateObject = /*#__PURE__*/ _taggedTemplateLiteral(["\n  mutation(\n    $title: String!\n    $body: String!\n    $digest: String!\n    $length: Int!\n    $linkAddr: String\n    $communityId: ID!\n  ) {\n    createPost(\n      title: $title\n      body: $body\n      digest: $digest\n      length: $length\n      linkAddr: $linkAddr\n      communityId: $communityId\n    ) {\n      id\n      title\n      body\n    }\n  }\n"]);

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var createPost = external__graphql_tag__default()(_templateObject);
var schema = {
  createPost: createPost
};
/* harmony default export */ var TypeWriter_schema = (schema);
// EXTERNAL MODULE: ./utils/network/sr71.js + 3 modules
var sr71 = __webpack_require__(8);

// CONCATENATED MODULE: ./containers/TypeWriter/logic.js







var sr71$ = new sr71["a" /* default */]();
/* eslint-disable no-unused-vars */

var debug = Object(utils["H" /* makeDebugger */])('L:TypeWriter');
/* eslint-enable no-unused-vars */

var store = null;
var sub$ = null;
function logic_copyrightChange(articleType) {
  store.markState({
    articleType: articleType
  });
}
function changeView(curView) {
  store.markState({
    curView: curView
  });
}

function checkValid() {
  var _store2 = store,
      body = _store2.body,
      title = _store2.title,
      articleType = _store2.articleType,
      linkAddr = _store2.linkAddr;

  if (Object(utils["E" /* isEmptyValue */])(body) || Object(utils["E" /* isEmptyValue */])(title)) {
    Object(utils["K" /* meteorState */])(store, 'error', 5, '文章标题 或 文章内容 不能为空');
    return false;
  }

  if (articleType !== 'original' && Object(utils["E" /* isEmptyValue */])(linkAddr)) {
    Object(utils["K" /* meteorState */])(store, 'error', 5, '请填写完整地址以方便跳转, http(s)://...');
    return false;
  }

  return true;
}

function onUploadImageDone(url) {
  debug('onUploadImageDone: ', url);
  Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].DRAFT_INSERT_SNIPPET, {
    type: 'Image',
    data: "![](".concat(url, ")")
  });
}

var logic_getDigest = function getDigest(body) {
  /* eslint-disable no-undef */
  var digestContainer = document.getElementById('typewriter-preview-container');
  /* eslint-enable no-undef */

  var innerImagesLength = Object(utils["v" /* extractAttachments */])(body).length;

  var digest = slice__default()(0, 65, trim__default()(digestContainer.innerText));

  if (innerImagesLength > 0 && innerImagesLength <= 2) {
    var imgDigest = "".concat(repeat__default()('[图片]', innerImagesLength));
    digest = isEmpty__default()(digest) ? imgDigest : "".concat(digest, "..").concat(imgDigest);
  } else if (innerImagesLength > 2) {
    var _imgDigest = "".concat(repeat__default()('[图片]', 2), " x ").concat(innerImagesLength);

    digest = isEmpty__default()(digest) ? _imgDigest : "".concat(digest, "..").concat(_imgDigest);
  }

  return digest;
}; // TODO move specfical logic outof here


function logic_onPublish() {
  // debug('onPublish: ', store.body)
  var _store3 = store,
      body = _store3.body,
      title = _store3.title,
      articleType = _store3.articleType;

  if (checkValid()) {
    logic_publishing();
    var digest = logic_getDigest(body);
    var length = Object(utils["r" /* countWords */])(body);
    var variables = {
      title: title,
      body: body,
      digest: digest,
      length: length,
      communityId: store.viewing.community.id
    };
    if (articleType !== 'original') variables.linkAddr = store.linkAddr; // debug('variables-: ', variables)
    // TODO: switch createJob

    sr71$.mutate(TypeWriter_schema.createPost, variables);
  }
}
var canclePublish = function canclePublish() {
  debug('canclePublish');
  cancleLoading(); // store.reset()

  store.closePreview();
};
function logic_bodyOnChange(body) {
  // debug('editorOnChange: ', body)
  store.markState({
    body: body
  });
}
function logic_titleOnChange(e) {
  store.markState({
    title: e.target.value
  });
}
function logic_linkSourceOnChange(e) {
  store.markState({
    linkAddr: e.target.value
  });
}

function logic_publishing() {
  var maybe = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
  store.markState({
    publishing: maybe
  });
}

var DataSolver = [{
  match: Object(utils["n" /* asyncRes */])('createPost'),
  action: function action() {
    cancleLoading();
    store.reset();
    store.closePreview();
    Object(utils["u" /* dispatchEvent */])(utils["e" /* EVENT */].REFRESH_POSTS); // 1. empty the store
    // 2. close the preview
    // 3. notify the xxxPaper
  }
}, {
  match: Object(utils["n" /* asyncRes */])(utils["e" /* EVENT */].PREVIEW),
  action: function action() {}
}];

var cancleLoading = function cancleLoading() {
  store.markState({
    publishing: false
  });
};

var ErrSolver = [{
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].CRAPHQL),
  action: function action(_ref) {
    var details = _ref.details;
    var errMsg = details[0].detail;
    debug('ERR.CRAPHQL -->', details);
    Object(utils["K" /* meteorState */])(store, 'error', 5, errMsg);
    cancleLoading();
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].TIMEOUT),
  action: function action(_ref2) {
    var details = _ref2.details;
    debug('ERR.TIMEOUT -->', details);
    cancleLoading();
  }
}, {
  match: Object(utils["m" /* asyncErr */])(utils["d" /* ERR */].NETWORK),
  action: function action(_ref3) {
    var details = _ref3.details;
    debug('ERR.NETWORK -->', details);
    cancleLoading();
  }
}];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(utils["a" /* $solver */])(DataSolver, ErrSolver));
}
// EXTERNAL MODULE: external "styled-components"
var external__styled_components_ = __webpack_require__(2);
var external__styled_components__default = /*#__PURE__*/__webpack_require__.n(external__styled_components_);

// CONCATENATED MODULE: ./containers/TypeWriter/styles/index.js



var EditorBlock =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__EditorBlock",
  componentId: "zc119b-0"
})(["display:", ";"], function (_ref) {
  var name = _ref.name,
      curView = _ref.curView;
  return name === curView ? 'block' : 'none';
});
var PreviewBlock =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewBlock",
  componentId: "zc119b-1"
})(["display:", ";"], function (_ref2) {
  var name = _ref2.name,
      curView = _ref2.curView;
  return name === curView ? 'block' : 'none';
});
var TitleInput =
/*#__PURE__*/
external__styled_components__default()(components["m" /* Input */]).withConfig({
  displayName: "styles__TitleInput",
  componentId: "zc119b-2"
})(["border-color:", ";border-bottom:1px solid;border-bottom-color:", ";::placeholder{color:", ";}text-align:center;height:45px;font-size:1.6em;color:", ";background:", ";align-self:center;width:85%;&:hover{border-color:", ";border-bottom:1px solid;border-bottom-color:", ";}&:focus{border-color:", ";box-shadow:none;border-bottom:1px solid;border-bottom-color:", ";}"], Object(utils["X" /* theme */])('editor.border'), Object(utils["X" /* theme */])('editor.borderNormal'), Object(utils["X" /* theme */])('editor.placeholder'), Object(utils["X" /* theme */])('editor.title'), Object(utils["X" /* theme */])('editor.headerBg'), Object(utils["X" /* theme */])('editor.border'), Object(utils["X" /* theme */])('editor.borderActive'), Object(utils["X" /* theme */])('editor.border'), Object(utils["X" /* theme */])('editor.borderActive'));
var Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "zc119b-3"
})([""]);
var Header =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Header",
  componentId: "zc119b-4"
})(["display:flex;margin-left:35px;margin-right:35px;padding-top:15px;margin-bottom:10px;"]);
var UsageText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__UsageText",
  componentId: "zc119b-5"
})(["color:", ";font-size:1.3em;flex-grow:1;"], Object(utils["X" /* theme */])('editor.content'));
var MarkdownIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__MarkdownIcon",
  componentId: "zc119b-6"
})(["fill:#51abb2;width:20px;height:18px;margin-right:5px;", ":hover &{fill:#618c92;}"], MarkDownHint);
var MarkDownHint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__MarkDownHint",
  componentId: "zc119b-7"
})(["display:flex;color:", ";&:hover{color:", ";cursor:pointer;}transition:color 0.3s;"], Object(utils["X" /* theme */])('editor.placeholder'), Object(utils["X" /* theme */])('editor.content')); // this is from top

var BackToEditHint =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BackToEditHint",
  componentId: "zc119b-8"
})(["display:flex;color:", ";cursor:pointer;"], Object(utils["X" /* theme */])('editor.title'));
var BodyWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BodyWrapper",
  componentId: "zc119b-9"
})(["padding:20px;background-color:", ";min-height:600px;margin-top:5px;margin-left:4%;margin-right:4%;border-radius:5px;flex-direction:column;display:flex;"], Object(utils["X" /* theme */])('editor.contentBg'));
var BodyHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__BodyHeader",
  componentId: "zc119b-10"
})(["display:flex;justify-content:space-between;"]);
var CopyRightCheck =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CopyRightCheck",
  componentId: "zc119b-11"
})(["display:flex;"]);
var CopyRightText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CopyRightText",
  componentId: "zc119b-12"
})(["font-size:1.1em;"]);
var ReprintWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__ReprintWrapper",
  componentId: "zc119b-13"
})(["color:", ";display:flex;cursor:pointer;"], Object(utils["X" /* theme */])('editor.content'));
var ReprintIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__ReprintIcon",
  componentId: "zc119b-14"
})(["fill:", ";width:14px;height:14px;margin-top:3px;margin-right:5px;"], Object(utils["X" /* theme */])('editor.content'));
var MoreIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__MoreIcon",
  componentId: "zc119b-15"
})(["width:14px;height:14px;margin-top:3px;fill:", ";&:hover{cursor:pointer;}"], Object(utils["X" /* theme */])('editor.placeholder'));
var SourceLink =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__SourceLink",
  componentId: "zc119b-16"
})(["display:flex;width:60%;justify-content:center;"]);
var LinkInput =
/*#__PURE__*/
external__styled_components__default()(components["m" /* Input */]).withConfig({
  displayName: "styles__LinkInput",
  componentId: "zc119b-17"
})(["border:1px solid;border-color:", ";height:20px;line-height:20px;width:50%;font-size:0.9em;margin-top:-1px;background:", ";padding-left:2px;color:", ";::placeholder{color:", ";}text-align:left;&:hover{border-color:", ";border-bottom:1px solid;border-bottom-color:", ";color:", ";}&:focus{border-color:", ";box-shadow:none;border-bottom:1px solid;border-bottom-color:", ";color:", ";text-align:left;}"], Object(utils["X" /* theme */])('editor.border'), Object(utils["X" /* theme */])('editor.headerBg'), Object(utils["X" /* theme */])('editor.title'), Object(utils["X" /* theme */])('editor.placeholder'), Object(utils["X" /* theme */])('editor.headerBg'), Object(utils["X" /* theme */])('editor.border'), Object(utils["X" /* theme */])('editor.title'), Object(utils["X" /* theme */])('editor.headerBg'), Object(utils["X" /* theme */])('editor.placeholder'), Object(utils["X" /* theme */])('editor.title'));
var LinkLabel =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__LinkLabel",
  componentId: "zc119b-18"
})(["font-size:0.9em;color:", ";", ":hover &{color:", ";}transition:color 0.3s;"], Object(utils["X" /* theme */])('editor.placeholder'), SourceLink, Object(utils["X" /* theme */])('editor.title'));
var PreviewBtn =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__PreviewBtn",
  componentId: "zc119b-19"
})(["margin-top:-3px;"]);
var Selector =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__Selector",
  componentId: "zc119b-20"
})(["display:flex;&:hover{cursor:pointer;color:", ";}"], Object(utils["X" /* theme */])('editor.title'));
var CheckIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "styles__CheckIcon",
  componentId: "zc119b-21"
})(["fill:", ";width:18px;height:18px;margin-top:2px;margin-right:3px;visibility:", ";"], Object(utils["X" /* theme */])('editor.content'), function (_ref3) {
  var active = _ref3.active,
      value = _ref3.value;
  return active === value ? 'visiable' : 'hidden';
});
var CheckText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "styles__CheckText",
  componentId: "zc119b-22"
})(["color:", ";"], Object(utils["X" /* theme */])('editor.content'));
// CONCATENATED MODULE: ./containers/TypeWriter/styles/editor.js



var ExtraWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editor__ExtraWrapper",
  componentId: "s11203rz-0"
})(["display:flex;justify-content:center;"]);
var ExtraItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editor__ExtraItem",
  componentId: "s11203rz-1"
})(["display:flex;color:", ";&:hover{color:#51abb2;animation:", " 0.4s linear;}"], Object(utils["X" /* theme */])('editor.footer'), utils["b" /* Animate */].pulse);
var ExtraDivider =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "editor__ExtraDivider",
  componentId: "s11203rz-2"
})(["fill:#75898a;width:10px;height:10px;margin-left:4px;margin-right:4px;"]);
var ExtraItemTitle =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "editor__ExtraItemTitle",
  componentId: "s11203rz-3"
})(["cursor:pointer;font-size:1.2em;", ":hover &{color:", ";}"], ExtraItem, Object(utils["X" /* theme */])('editor.footerHover'));
var ExtraItemIcon =
/*#__PURE__*/
external__styled_components__default()(components["l" /* Img */]).withConfig({
  displayName: "editor__ExtraItemIcon",
  componentId: "s11203rz-4"
})(["fill:", ";width:17px;height:17px;margin-right:3px;margin-top:2px;", ":hover &{fill:", ";}"], Object(utils["X" /* theme */])('editor.content'), ExtraItem, Object(utils["X" /* theme */])('editor.footerHover'));
// CONCATENATED MODULE: ./containers/TypeWriter/Editor.js
var _this = this;

/*
 * Editor based on Draft
 */








var articleTypeDic = {
  original: '原创',
  reprint: '转载',
  translate: '翻译'
};

var Editor_OriginalSelector = function OriginalSelector(_ref) {
  var active = _ref.active,
      onSelect = _ref.onSelect;
  return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(Selector, {
    onClick: onSelect.bind(_this, 'original')
  }, external__react__default.a.createElement(CheckIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/check2.svg"),
    active: active,
    value: "original"
  }), external__react__default.a.createElement(CheckText, {
    active: active,
    value: "original"
  }, "\u539F\u521B")), external__react__default.a.createElement(Selector, {
    onClick: onSelect.bind(_this, 'reprint')
  }, external__react__default.a.createElement(CheckIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/check2.svg"),
    active: active,
    value: "reprint"
  }), external__react__default.a.createElement(CheckText, {
    active: active,
    value: "reprint"
  }, "\u8F6C\u8F7D")), external__react__default.a.createElement(Selector, {
    onClick: onSelect.bind(_this, 'translate')
  }, external__react__default.a.createElement(CheckIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/check2.svg"),
    active: active,
    value: "translate"
  }), external__react__default.a.createElement(CheckText, {
    active: active,
    value: "translate"
  }, "\u7FFB\u8BD1")));
};

var Editor_Editor = function Editor(_ref2) {
  var articleType = _ref2.articleType,
      copyrightChange = _ref2.copyrightChange,
      title = _ref2.title,
      titleOnChange = _ref2.titleOnChange,
      body = _ref2.body,
      bodyOnChange = _ref2.bodyOnChange,
      linkAddr = _ref2.linkAddr,
      linkSourceOnChange = _ref2.linkSourceOnChange,
      onPreview = _ref2.onPreview;
  return external__react__default.a.createElement(BodyWrapper, null, external__react__default.a.createElement(BodyHeader, null, external__react__default.a.createElement(CopyRightCheck, null, external__react__default.a.createElement(components["s" /* Popover */], {
    content: external__react__default.a.createElement(Editor_OriginalSelector, {
      active: articleType,
      onSelect: copyrightChange
    }),
    placement: "right",
    trigger: "hover"
  }, external__react__default.a.createElement(ReprintWrapper, null, external__react__default.a.createElement(ReprintIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/").concat(articleType, ".svg")
  }), external__react__default.a.createElement(CopyRightText, null, articleTypeDic[articleType]), external__react__default.a.createElement(MoreIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/more.svg")
  })))), articleType !== 'original' ? external__react__default.a.createElement(SourceLink, null, external__react__default.a.createElement(LinkLabel, null, "\u539F\u5730\u5740:"), external__react__default.a.createElement(LinkInput, {
    placeholder: "\u8BF7\u586B\u5199url\u5730\u5740, \u6BD4\u5982: https://coderplanets/js/posts/...",
    value: linkAddr,
    onChange: linkSourceOnChange
  })) : external__react__default.a.createElement("div", null), external__react__default.a.createElement(PreviewBtn, null, external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: onPreview
  }, "\u9884\u89C8"))), external__react__default.a.createElement(TitleInput, {
    placeholder: "\u6587\u7AE0\u6807\u9898.",
    defaultValue: "",
    value: title,
    onChange: titleOnChange
  }), external__react__default.a.createElement("br", null), external__react__default.a.createElement(BodyEditor["a" /* default */], {
    onChange: bodyOnChange,
    body: body
  }), external__react__default.a.createElement(ExtraWrapper, null, external__react__default.a.createElement(ExtraItem, null, external__react__default.a.createElement(ExtraItemIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_tag.svg")
  }), external__react__default.a.createElement(ExtraItemTitle, null, "\u6807\u7B7E")), external__react__default.a.createElement(ExtraDivider, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/more.svg")
  }), external__react__default.a.createElement(ExtraItem, null, external__react__default.a.createElement(ExtraItemIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_vote.svg")
  }), external__react__default.a.createElement(ExtraItemTitle, null, "\u6295\u7968")), external__react__default.a.createElement(ExtraDivider, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/more.svg")
  }), external__react__default.a.createElement(ExtraItem, null, external__react__default.a.createElement(ExtraItemIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_code.svg")
  }), external__react__default.a.createElement(ExtraItemTitle, null, "\u4EE3\u7801")), external__react__default.a.createElement(ExtraDivider, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/more.svg")
  }), external__react__default.a.createElement(components["i" /* FileUploader */], {
    onUploadDone: onUploadImageDone
  }, external__react__default.a.createElement(ExtraItem, null, external__react__default.a.createElement(ExtraItemIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_image.svg")
  }), external__react__default.a.createElement(ExtraItemTitle, null, "\u56FE\u7247"))), external__react__default.a.createElement(ExtraDivider, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/more.svg")
  }), external__react__default.a.createElement(ExtraItem, null, external__react__default.a.createElement(ExtraItemIcon, {
    src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/extra_setting.svg")
  }), external__react__default.a.createElement(ExtraItemTitle, null, "\u8BBE\u7F6E"))));
};

Editor_Editor.defaultProps = {
  body: '',
  title: '',
  linkAddr: ''
};
/* harmony default export */ var TypeWriter_Editor = (Editor_Editor);
// EXTERNAL MODULE: external "remarkable"
var external__remarkable_ = __webpack_require__(48);
var external__remarkable__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_);

// EXTERNAL MODULE: external "remarkable-emoji"
var external__remarkable_emoji_ = __webpack_require__(49);
var external__remarkable_emoji__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_emoji_);

// EXTERNAL MODULE: external "remarkable-mentions"
var external__remarkable_mentions_ = __webpack_require__(50);
var external__remarkable_mentions__default = /*#__PURE__*/__webpack_require__.n(external__remarkable_mentions_);

// EXTERNAL MODULE: ./containers/ThemeWrapper/MarkDownStyle.js
var MarkDownStyle = __webpack_require__(97);

// CONCATENATED MODULE: ./containers/TypeWriter/styles/preview.js
 // BodyWrapper, BodyHeader, BackToEditBtn, PreviewHeader



var PreviewHeader =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "preview__PreviewHeader",
  componentId: "s1jmfbbs-0"
})(["color:", ";margin-bottom:15px;padding-bottom:10px;text-align:center;font-size:1.5em;align-self:center;border-bottom:1px solid;border-bottom-color:", ";width:80%;min-height:1.5em;"], Object(utils["X" /* theme */])('preview.title'), Object(utils["X" /* theme */])('preview.divider'));
var BackToEditBtn =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "preview__BackToEditBtn",
  componentId: "s1jmfbbs-1"
})([""]);
// CONCATENATED MODULE: ./containers/TypeWriter/Preview.js
/*
 * Editor based on Draft
 */



 // import Prism from 'mastani-codehighlight'





var md = new external__remarkable__default.a();
md.use(external__remarkable_mentions__default()({
  url: config["g" /* MENTION_USER_ADDR */]
}));
md.use(external__remarkable_emoji__default.a);
/* eslint-disable react/no-danger */

var Preview_Preview = function Preview(_ref) {
  var onBack = _ref.onBack,
      title = _ref.title,
      body = _ref.body;
  return external__react__default.a.createElement(BodyWrapper, null, external__react__default.a.createElement(BodyHeader, null, "\xA0", external__react__default.a.createElement(BackToEditBtn, null, external__react__default.a.createElement(components["d" /* Button */], {
    size: "small",
    type: "primary",
    ghost: true,
    onClick: onBack
  }, "\u8FD4\u56DE\u7F16\u8F91"))), external__react__default.a.createElement(PreviewHeader, null, title), external__react__default.a.createElement(MarkDownStyle["a" /* default */], null, external__react__default.a.createElement("div", {
    className: "markdown-body"
  }, external__react__default.a.createElement("div", {
    id: "typewriter-preview-container",
    dangerouslySetInnerHTML: {
      __html: md.render(body)
    }
  }))));
};
/* eslint-enable react/no-danger */


/* harmony default export */ var TypeWriter_Preview = (Preview_Preview);
// EXTERNAL MODULE: external "ramda/src/keys"
var keys_ = __webpack_require__(21);
var keys__default = /*#__PURE__*/__webpack_require__.n(keys_);

// EXTERNAL MODULE: external "ramda/src/filter"
var filter_ = __webpack_require__(30);
var filter__default = /*#__PURE__*/__webpack_require__.n(filter_);

// EXTERNAL MODULE: external "mastani-codehighlight"
var external__mastani_codehighlight_ = __webpack_require__(41);
var external__mastani_codehighlight__default = /*#__PURE__*/__webpack_require__.n(external__mastani_codehighlight_);

// EXTERNAL MODULE: external "shortid"
var external__shortid_ = __webpack_require__(10);
var external__shortid__default = /*#__PURE__*/__webpack_require__.n(external__shortid_);

// EXTERNAL MODULE: ./containers/TypeWriter/emojis.js
var emojis = __webpack_require__(200);
var emojis_default = /*#__PURE__*/__webpack_require__.n(emojis);

// CONCATENATED MODULE: ./containers/TypeWriter/styles/markdown_helper.js


var EmojiWraper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "markdown_helper__EmojiWraper",
  componentId: "s1bqnfqi-0"
})(["margin-top:18px;"]);
var EmojiItem =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "markdown_helper__EmojiItem",
  componentId: "s1bqnfqi-1"
})(["width:200px;"]);
var markdown_helper_Wrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "markdown_helper__Wrapper",
  componentId: "s1bqnfqi-2"
})(["background:", ";padding:20px;margin-left:4%;margin-right:4%;"], Object(utils["X" /* theme */])('preview.markdownHelperBg'));
// CONCATENATED MODULE: ./containers/TypeWriter/MarkDownHelper.js



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }











var MarkDownHelper_md = new external__remarkable__default.a();
MarkDownHelper_md.use(external__remarkable_mentions__default()({
  url: config["g" /* MENTION_USER_ADDR */]
}));
MarkDownHelper_md.use(external__remarkable_emoji__default.a);

var notTooLong = function notTooLong(l) {
  return l.length < 20;
};
/* eslint-disable react/no-danger */


var MarkDownHelper_Emojis = function Emojis() {
  var source = filter__default()(notTooLong, keys__default()(emojis_default.a));

  return external__react__default.a.createElement(EmojiWraper, null, external__react__default.a.createElement(MarkDownStyle["a" /* default */], null, external__react__default.a.createElement("div", {
    className: "markdown-body",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center'
    }
  }, source.map(function (item) {
    return external__react__default.a.createElement(EmojiItem, {
      key: external__shortid__default.a.generate(),
      dangerouslySetInnerHTML: {
        __html: MarkDownHelper_md.render("".concat(item, " `").concat(item, "`"))
      }
    });
  }))));
};

var MarkDownHelper_MarkDownInfo = function MarkDownInfo() {
  var IntroMD = "`\u8BF4\u660E`: \u663E\u793A\u6548\u679C\u4E0E\u4E0B\u65B9\u5B9E\u73B0\u4EE3\u7801\u4E00\u4E00\u5BF9\u5E94\n# \u8FD9\u662F\u4E00\u7EA7\u6807\u9898\n```text\n# \u8FD9\u662F\u4E00\u7EA7\u6807\u9898\n```\n## \u8FD9\u662F\u4E8C\u7EA7\u6807\u9898\n```text\n## \u8FD9\u662F\u4E8C\u7EA7\u6807\u9898\n```\n\n### \u8FD9\u662F\u4E09\u7EA7\u6807\u9898\n```text\n### \u8FD9\u662F\u4E09\u7EA7\u6807\u9898\n```\n\n#### \u8FD9\u662F\u56DB\u7EA7\u6807\u9898\n```text\n#### \u8FD9\u662F\u56DB\u7EA7\u6807\u9898\n```\n\n##### \u8FD9\u662F\u4E94\u7EA7\u6807\u9898\n```text\n##### \u8FD9\u662F\u4E94\u7EA7\u6807\u9898\n```\n\n###### \u8FD9\u662F\u516D\u7EA7\u6807\u9898\n```text\n###### \u8FD9\u662F\u516D\u7EA7\u6807\u9898\n```\n\n\u7F16\u7A0B\u8BED\u8A00\u4EE3\u7801\u9AD8\u4EAE:\n ```js\nconsole.log('hello mastani')\n ```\n\n```text\n'''js\nconsole.log('hello mastani')\n'''\n\u6CE8\u610F\u8FD9\u91CC\u662F\u53CD\u659C\u6760(`), \u5982\u679C\u662F\u5176\u4ED6\u7F16\u7A0B\u8BED\u8A00\u5C06'js'\u66FF\u6362\u5373\u53EF\u3002\n```\n\n> \u8FD9\u662F\u5F15\u7528\n```text\n> \u8FD9\u662F\u5F15\u7528\n```\n\nAt \u67D0\u4E2A\u7528\u6237: @mydearxym\n\n```text\nAt \u67D0\u4E2A\u7528\u6237: @mydearxym\n```\n\n\u63D2\u5165\u94FE\u63A5: [coderplanets.com](https://coderplanets.com)\n\n```text\n\u63D2\u5165\u94FE\u63A5: [coderplanets.com](https://coderplanets.com)\n```\n\n## Emoji \u53C2\u8003\n";
  return external__react__default.a.createElement("div", {
    className: "markdown-body",
    dangerouslySetInnerHTML: {
      __html: MarkDownHelper_md.render(IntroMD)
    }
  });
};
/* eslint-enable react/no-danger */


var MarkDownHelper_MarkDownHelper =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MarkDownHelper, _React$Component);

  function MarkDownHelper() {
    _classCallCheck(this, MarkDownHelper);

    return _possibleConstructorReturn(this, (MarkDownHelper.__proto__ || Object.getPrototypeOf(MarkDownHelper)).apply(this, arguments));
  }

  _createClass(MarkDownHelper, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      external__mastani_codehighlight__default.a.highlightAll();
    }
  }, {
    key: "render",
    value: function render() {
      return external__react__default.a.createElement(markdown_helper_Wrapper, null, external__react__default.a.createElement(MarkDownStyle["a" /* default */], null, external__react__default.a.createElement(MarkDownHelper_MarkDownInfo, null), external__react__default.a.createElement(MarkDownHelper_Emojis, null)));
    }
  }]);

  return MarkDownHelper;
}(external__react__default.a.Component);

/* harmony default export */ var TypeWriter_MarkDownHelper = (MarkDownHelper_MarkDownHelper);
// CONCATENATED MODULE: ./containers/TypeWriter/styles/footer.js


var FooterWrapper =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "footer__FooterWrapper",
  componentId: "s1ll3u5v-0"
})(["display:flex;flex-direction:column;align-items:center;margin-top:30px;margin-left:35px;margin-right:40px;margin-bottom:50px;"]);
var RespectText =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "footer__RespectText",
  componentId: "s1ll3u5v-1"
})(["color:", ";display:", ";"], Object(utils["X" /* theme */])('editor.placeholder'), function (_ref) {
  var show = _ref.show;
  return show ? 'block' : 'none';
});
var Divider =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "footer__Divider",
  componentId: "s1ll3u5v-2"
})(["border-top:1px solid;border-color:", ";margin-top:10px;width:55%;margin-bottom:20px;"], Object(utils["X" /* theme */])('editor.placeholder'));
var PublishBtns =
/*#__PURE__*/
external__styled_components__default.a.div.withConfig({
  displayName: "footer__PublishBtns",
  componentId: "s1ll3u5v-3"
})(["width:50%;text-align:center;"]);
// CONCATENATED MODULE: ./containers/TypeWriter/Footer.js
//





var Footer_Footer = function Footer(_ref) {
  var onPublish = _ref.onPublish,
      publishing = _ref.publishing,
      success = _ref.success,
      error = _ref.error,
      warn = _ref.warn,
      statusMsg = _ref.statusMsg;
  return external__react__default.a.createElement(FooterWrapper, null, external__react__default.a.createElement(components["y" /* StatusBox */], {
    success: success,
    error: error,
    warn: warn,
    msg: statusMsg
  }), external__react__default.a.createElement(RespectText, {
    show: !success && !warn && !error && !publishing
  }, "\u8BF7\u5C0A\u91CD\u81EA\u5DF1\u548C\u4ED6\u4EBA\u7684\u65F6\u95F4\uFF0C\u4E0D\u8981\u53D1\u5E03\u65E0\u610F\u4E49\u7684\u5185\u5BB9\u3002"), external__react__default.a.createElement(Divider, null), external__react__default.a.createElement(PublishBtns, null, publishing ? external__react__default.a.createElement("div", null, external__react__default.a.createElement(components["d" /* Button */], {
    size: "default",
    type: "primary",
    ghost: true
  }, "\u53D6\u6D88"), external__react__default.a.createElement(components["v" /* Space */], {
    right: "15px"
  }), external__react__default.a.createElement(components["d" /* Button */], {
    size: "default",
    type: "primary",
    disabled: true
  }, external__react__default.a.createElement(components["k" /* Icon */], {
    type: "loading"
  }), "\u6B63\u5728\u53D1\u5E03...")) : external__react__default.a.createElement("div", null, external__react__default.a.createElement(components["d" /* Button */], {
    size: "default",
    type: "primary",
    ghost: true,
    onClick: canclePublish
  }, "\u53D6\u6D88"), external__react__default.a.createElement(components["v" /* Space */], {
    right: "15px"
  }), external__react__default.a.createElement(components["d" /* Button */], {
    size: "default",
    type: "primary",
    onClick: onPublish
  }, "\u53D1", external__react__default.a.createElement(components["v" /* Space */], {
    right: "10px"
  }), "\u5E03"))));
};

/* harmony default export */ var TypeWriter_Footer = (Footer_Footer);
// CONCATENATED MODULE: ./containers/TypeWriter/index.js
var TypeWriter__this = this;

function TypeWriter__typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { TypeWriter__typeof = function _typeof(obj) { return typeof obj; }; } else { TypeWriter__typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return TypeWriter__typeof(obj); }

function TypeWriter__classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function TypeWriter__defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function TypeWriter__createClass(Constructor, protoProps, staticProps) { if (protoProps) TypeWriter__defineProperties(Constructor.prototype, protoProps); if (staticProps) TypeWriter__defineProperties(Constructor, staticProps); return Constructor; }

function TypeWriter__possibleConstructorReturn(self, call) { if (call && (TypeWriter__typeof(call) === "object" || typeof call === "function")) { return call; } return TypeWriter__assertThisInitialized(self); }

function TypeWriter__assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function TypeWriter__inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 *
 * TypeWriter
 *
 */
 // import PropTypes from 'prop-types'

 // import ContentInput from './ContentInput'









/* eslint-disable no-unused-vars */

var TypeWriter_debug = Object(utils["H" /* makeDebugger */])('C:TypeWriter');
/* eslint-enable no-unused-vars */

var TypeWriter_View = function View(_ref) {
  var curView = _ref.curView,
      articleType = _ref.articleType,
      copyrightChange = _ref.copyrightChange,
      title = _ref.title,
      body = _ref.body,
      linkAddr = _ref.linkAddr;

  // const curView = 'create' // markdown_help
  if (curView === 'CREATE_VIEW' || curView === 'PREVIEW_VIEW') {
    return external__react__default.a.createElement(external__react__default.a.Fragment, null, external__react__default.a.createElement(EditorBlock, {
      name: "CREATE_VIEW",
      curView: curView
    }, external__react__default.a.createElement(TypeWriter_Editor, {
      articleType: articleType,
      copyrightChange: copyrightChange,
      title: title,
      titleOnChange: logic_titleOnChange,
      linkAddr: linkAddr,
      linkSourceOnChange: logic_linkSourceOnChange,
      body: body,
      bodyOnChange: logic_bodyOnChange,
      onPreview: changeView.bind(TypeWriter__this, 'PREVIEW_VIEW')
    })), external__react__default.a.createElement(PreviewBlock, {
      name: "PREVIEW_VIEW",
      curView: curView
    }, external__react__default.a.createElement(TypeWriter_Preview, {
      title: title,
      body: body,
      onBack: changeView.bind(TypeWriter__this, 'CREATE_VIEW')
    })));
  }

  return external__react__default.a.createElement(TypeWriter_MarkDownHelper, null);
};

var TypeWriter_TopHeader = function TopHeader(_ref2) {
  var curView = _ref2.curView;

  switch (curView) {
    case 'MARKDOWN_HELP_VIEW':
      {
        return external__react__default.a.createElement(Header, null, external__react__default.a.createElement(UsageText, null, "Github Flavor Markdown"), external__react__default.a.createElement(BackToEditHint, {
          onClick: changeView.bind(TypeWriter__this, 'CREATE_VIEW')
        }, external__react__default.a.createElement(MarkdownIcon, {
          src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/original.svg")
        }), "\u8FD4\u56DE\u7F16\u8F91"));
      }

    default:
      return external__react__default.a.createElement(Header, null, external__react__default.a.createElement(UsageText, null, "\u53D1\u5E03\u5E16\u5B50"), external__react__default.a.createElement(MarkDownHint, {
        onClick: changeView.bind(TypeWriter__this, 'MARKDOWN_HELP_VIEW')
      }, external__react__default.a.createElement(MarkdownIcon, {
        src: "".concat(config["e" /* ICON_ASSETS */], "/cmd/markdown.svg")
      }), "markdown \u8BED\u6CD5 / emojj \u901F\u67E5"));
  }
}; // TODO: use input in old IE


var TypeWriter_TypeWriterContainer =
/*#__PURE__*/
function (_React$Component) {
  TypeWriter__inherits(TypeWriterContainer, _React$Component);

  function TypeWriterContainer() {
    TypeWriter__classCallCheck(this, TypeWriterContainer);

    return TypeWriter__possibleConstructorReturn(this, (TypeWriterContainer.__proto__ || Object.getPrototypeOf(TypeWriterContainer)).apply(this, arguments));
  }

  TypeWriter__createClass(TypeWriterContainer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var typeWriter = this.props.typeWriter;
      init(typeWriter);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      TypeWriter_debug('TODO: store state to localstarange'); // Message.success('草稿已经保存')
    }
  }, {
    key: "render",
    value: function render() {
      var _props$typeWriter = this.props.typeWriter,
          articleType = _props$typeWriter.articleType,
          curView = _props$typeWriter.curView,
          linkAddr = _props$typeWriter.linkAddr,
          title = _props$typeWriter.title,
          body = _props$typeWriter.body,
          publishing = _props$typeWriter.publishing,
          success = _props$typeWriter.success,
          error = _props$typeWriter.error,
          warn = _props$typeWriter.warn,
          statusMsg = _props$typeWriter.statusMsg;
      return external__react__default.a.createElement(Wrapper, null, external__react__default.a.createElement(TypeWriter_TopHeader, {
        curView: curView
      }), external__react__default.a.createElement(TypeWriter_View, {
        curView: curView,
        linkAddr: linkAddr,
        title: title,
        body: body,
        articleType: articleType,
        copyrightChange: logic_copyrightChange
      }), external__react__default.a.createElement(TypeWriter_Footer, {
        onPublish: logic_onPublish,
        publishing: publishing,
        success: success,
        error: error,
        warn: warn,
        statusMsg: statusMsg
      }));
    }
  }]);

  return TypeWriterContainer;
}(external__react__default.a.Component); // TypeWriterContainer.propTypes = {
// https://www.npmjs.com/package/prop-types
// closePreview: PropTypes.func.isRequired,
// }
// TypeWriterContainer.defaultProps = {}


/* harmony default export */ var TypeWriter = __webpack_exports__["default"] = (Object(external__mobx_react_["inject"])(Object(utils["U" /* storePlug */])('typeWriter'))(Object(external__mobx_react_["observer"])(TypeWriter_TypeWriterContainer)));

/***/ }),

/***/ 200:
/***/ (function(module, exports) {

// prettier-ignore
module.exports = {
  ":alarm_clock:": "\u23F0",
  ":anchor:": "\u2693",
  ":aquarius:": "\u2652",
  ":aries:": "\u2648",
  ":arrow_backward:": "\u25C0",
  ":arrow_double_down:": "\u23EC",
  ":arrow_double_up:": "\u23EB",
  ":arrow_down:": "\u2B07",
  ":arrow_forward:": "\u25B6",
  ":arrow_heading_down:": "\u2935",
  ":arrow_heading_up:": "\u2934",
  ":arrow_left:": "\u2B05",
  ":arrow_lower_left:": "\u2199",
  ":arrow_lower_right:": "\u2198",
  ":arrow_right:": "\u27A1",
  ":arrow_right_hook:": "\u21AA",
  ":arrow_up:": "\u2B06",
  ":arrow_up_down:": "\u2195",
  ":arrow_upper_left:": "\u2196",
  ":arrow_upper_right:": "\u2197",
  ":ballot_box_with_check:": "\u2611",
  ":bangbang:": "\u203C",
  ":cancer:": "\u264B",
  ":baseball:": "\u26BE",
  ":black_large_square:": "\u2B1B",
  ":black_medium_small_square:": "\u25FE",
  ":black_medium_square:": "\u25FC",
  ":black_nib:": "\u2712",
  ":black_small_square:": "\u25AA",
  ":black_circle:": "\u26AB",
  ":boat:": "\u26F5",
  ":capricorn:": "\u2651",
  ":church:": "\u26EA",
  ":cloud:": "\u2601",
  ":clubs:": "\u2663",
  ":coffee:": "\u2615",
  ":congratulations:": "\u3297",
  ":copyright:": "\xA9",
  ":curly_loop:": "\u27B0",
  ":eight_pointed_black_star:": "\u2734",
  ":eight_spoked_asterisk:": "\u2733",
  ":diamonds:": "\u2666",
  ":email:": "\u2709",
  ":envelope:": "\u2709",
  ":exclamation:": "\u2757",
  ":fast_forward:": "\u23E9",
  ":fist:": "\u270A",
  ":fountain:": "\u26F2",
  ":fuelpump:": "\u26FD",
  ":gemini:": "\u264A",
  ":golf:": "\u26F3",
  ":grey_exclamation:": "\u2755",
  ":grey_question:": "\u2754",
  ":hand:": "\u270B",
  ":heart:": "\u2764",
  ":hearts:": "\u2665",
  ":heavy_check_mark:": "\u2714",
  ":heavy_division_sign:": "\u2797",
  ":heavy_exclamation_mark:": "\u2757",
  ":heavy_minus_sign:": "\u2796",
  ":heavy_multiplication_x:": "\u2716",
  ":heavy_plus_sign:": "\u2795",
  ":hotsprings:": "\u2668",
  ":hourglass:": "\u231B",
  ":hourglass_flowing_sand:": "\u23F3",
  ":information_source:": "\u2139",
  ":interrobang:": "\u2049",
  ":left_right_arrow:": "\u2194",
  ":leftwards_arrow_with_hook:": "\u21A9",
  ":leo:": "\u264C",
  ":libra:": "\u264E",
  ":loop:": "\u27BF",
  ":m:": "\u24C2",
  ":negative_squared_cross_mark:": "\u274E",
  ":no_entry:": "\u26D4",
  ":o:": "\u2B55",
  ":ophiuchus:": "\u26CE",
  ":part_alternation_mark:": "\u303D",
  ":partly_sunny:": "\u26C5",
  ":pencil2:": "\u270F",
  ":phone:": "\u260E",
  ":pisces:": "\u2653",
  ":point_up:": "\u261D",
  ":question:": "\u2753",
  ":raised_hand:": "\u270B",
  ":recycle:": "\u267B",
  ":registered:": "\xAE",
  ":relaxed:": "\u263A",
  ":rewind:": "\u23EA",
  ":sagittarius:": "\u2650",
  ":sailboat:": "\u26F5",
  ":scissors:": "\u2702",
  ":scorpius:": "\u264F",
  ":secret:": "\u3299",
  ":snowflake:": "\u2744",
  ":snowman:": "\u26C4",
  ":soccer:": "\u26BD",
  ":spades:": "\u2660",
  ":sparkle:": "\u2747",
  ":sparkles:": "\u2728",
  ":star:": "\u2B50",
  ":sunny:": "\u2600",
  ":taurus:": "\u2649",
  ":telephone:": "\u260E",
  ":tent:": "\u26FA",
  ":tm:": "\u2122",
  ":umbrella:": "\u2614",
  ":v:": "\u270C",
  ":virgo:": "\u264D",
  ":warning:": "\u26A0",
  ":watch:": "\u231A",
  ":wavy_dash:": "\u3030",
  ":wheelchair:": "\u267F",
  ":white_check_mark:": "\u2705",
  ":white_circle:": "\u26AA",
  ":white_large_square:": "\u2B1C",
  ":white_medium_small_square:": "\u25FD",
  ":white_medium_square:": "\u25FB",
  ":white_small_square:": "\u25AB",
  ":x:": "\u274C",
  ":zap:": "\u26A1",
  ":airplane:": "\u2708",
  ":+1:": "👍",
  ":-1:": "👎",
  ":100:": "💯",
  ":1234:": "🔢",
  ":8ball:": "🎱",
  ":a:": "🅰",
  ":ab:": "🆎",
  ":abc:": "🔤",
  ":abcd:": "🔡",
  ":accept:": "🉑",
  ":aerial_tramway:": "🚡",
  ":alien:": "👽",
  ":ambulance:": "🚑",
  ":angel:": "👼",
  ":anger:": "💢",
  ":angry:": "😠",
  ":-||": "😠",
  ":@": "😠",
  ">:(": "😠",
  ":anguished:": "😧",
  ":ant:": "🐜",
  ":apple:": "🍎",
  ":arrow_down_small:": "🔽",
  ":arrow_up_small:": "🔼",
  ":arrows_clockwise:": "🔃",
  ":arrows_counterclockwise:": "🔄",
  ":art:": "🎨",
  ":articulated_lorry:": "🚛",
  ":astonished:": "😲",
  ":athletic_shoe:": "👟",
  ":atm:": "🏧",
  ":b:": "🅱",
  ":baby:": "👶",
  ":baby_bottle:": "🍼",
  ":baby_chick:": "🐤",
  ":baby_symbol:": "🚼",
  ":back:": "🔙",
  ":baggage_claim:": "🛄",
  ":balloon:": "🎈",
  ":bamboo:": "🎍",
  ":banana:": "🍌",
  ":bank:": "🏦",
  ":bar_chart:": "📊",
  ":barber:": "💈",
  ":basketball:": "🏀",
  ":bath:": "🛀",
  ":bathtub:": "🛁",
  ":battery:": "🔋",
  ":bear:": "🐻",
  ":bee:": "🐝",
  ":beer:": "🍺",
  ":beers:": "🍻",
  ":beetle:": "🐞",
  ":beginner:": "🔰",
  ":bell:": "🔔",
  ":bento:": "🍱",
  ":bicyclist:": "🚴",
  ":bike:": "🚲",
  ":bikini:": "👙",
  ":bird:": "🐦",
  ":birthday:": "🎂",
  ":black_joker:": "🃏",
  ":black_square_button:": "🔲",
  ":blossom:": "🌼",
  ":blowfish:": "🐡",
  ":blue_book:": "📘",
  ":blue_car:": "🚙",
  ":blue_heart:": "💙",
  ":blush:": "😊",
  ":$": "😊",
  ":boar:": "🐗",
  ":bomb:": "💣",
  ":book:": "📖",
  ":bookmark:": "🔖",
  ":bookmark_tabs:": "📑",
  ":books:": "📚",
  ":boom:": "💥",
  ":boot:": "👢",
  ":bouquet:": "💐",
  ":bow:": "🙇",
  ":bowling:": "🎳",
  ":boy:": "👦",
  ":bread:": "🍞",
  ":bride_with_veil:": "👰",
  ":bridge_at_night:": "🌉",
  ":briefcase:": "💼",
  ":broken_heart:": "💔",
  ":bug:": "🐛",
  ":bulb:": "💡",
  ":bullettrain_front:": "🚅",
  ":bullettrain_side:": "🚄",
  ":bus:": "🚌",
  ":busstop:": "🚏",
  ":bust_in_silhouette:": "👤",
  ":busts_in_silhouette:": "👥",
  ":cactus:": "🌵",
  ":cake:": "🍰",
  ":calendar:": "📆",
  ":calling:": "📲",
  ":camel:": "🐫",
  ":camera:": "📷",
  ":candy:": "🍬",
  ":capital_abcd:": "🔠",
  ":car:": "🚗",
  ":card_index:": "📇",
  ":carousel_horse:": "🎠",
  ":cat:": "🐱",
  ":cat2:": "🐈",
  ":cd:": "💿",
  ":chart:": "💹",
  ":chart_with_downwards_trend:": "📉",
  ":chart_with_upwards_trend:": "📈",
  ":checkered_flag:": "🏁",
  ":cherries:": "🍒",
  ":cherry_blossom:": "🌸",
  ":chestnut:": "🌰",
  ":chicken:": "🐔",
  ":children_crossing:": "🚸",
  ":chocolate_bar:": "🍫",
  ":christmas_tree:": "🎄",
  ":cinema:": "🎦",
  ":circus_tent:": "🎪",
  ":city_sunrise:": "🌇",
  ":city_sunset:": "🌆",
  ":cl:": "🆑",
  ":clap:": "👏",
  ":clapper:": "🎬",
  ":clipboard:": "📋",
  ":clock1:": "🕐",
  ":clock10:": "🕙",
  ":clock1030:": "🕥",
  ":clock11:": "🕚",
  ":clock1130:": "🕦",
  ":clock12:": "🕛",
  ":clock1230:": "🕧",
  ":clock130:": "🕜",
  ":clock2:": "🕑",
  ":clock230:": "🕝",
  ":clock3:": "🕒",
  ":clock330:": "🕞",
  ":clock4:": "🕓",
  ":clock430:": "🕟",
  ":clock5:": "🕔",
  ":clock530:": "🕠",
  ":clock6:": "🕕",
  ":clock630:": "🕡",
  ":clock7:": "🕖",
  ":clock730:": "🕢",
  ":clock8:": "🕗",
  ":clock830:": "🕣",
  ":clock9:": "🕘",
  ":clock930:": "🕤",
  ":closed_book:": "📕",
  ":closed_lock_with_key:": "🔐",
  ":closed_umbrella:": "🌂",
  ":cocktail:": "🍸",
  ":cold_sweat:": "😰",
  ":collision:": "💥",
  ":computer:": "💻",
  ":confetti_ball:": "🎊",
  ":confounded:": "😖",
  ":confused:": "😕",
  "%-)": "😕",
  "%)": "😕",
  ":construction:": "🚧",
  ":construction_worker:": "👷",
  ":convenience_store:": "🏪",
  ":cookie:": "🍪",
  ":cool:": "🆒",
  ":cop:": "👮",
  ":corn:": "🌽",
  ":couple:": "👫",
  ":couple_with_heart:": "💑",
  ":couplekiss:": "💏",
  ":cow:": "🐮",
  ":cow2:": "🐄",
  ":credit_card:": "💳",
  ":crocodile:": "🐊",
  ":crossed_flags:": "🎌",
  ":crown:": "👑",
  ":cry:": "😢",
  ":'(": "😢",
  ":-'(": "😢",
  ":crying_cat_face:": "😿",
  ":crystal_ball:": "🔮",
  ":cupid:": "💘",
  ":currency_exchange:": "💱",
  ":curry:": "🍛",
  ":custard:": "🍮",
  ":customs:": "🛃",
  ":cyclone:": "🌀",
  ":dancer:": "💃",
  ":dancers:": "👯",
  ":dango:": "🍡",
  ":dart:": "🎯",
  ":dash:": "💨",
  ":date:": "📅",
  ":deciduous_tree:": "🌳",
  ":department_store:": "🏬",
  ":diamond_shape_with_a_dot_inside:": "💠",
  ":disappointed:": "😞",
  ":disappointed_relieved:": "😥",
  ":dizzy:": "💫",
  ":dizzy_face:": "😵",
  ":do_not_litter:": "🚯",
  ":dog:": "🐶",
  ":dog2:": "🐕",
  ":dollar:": "💵",
  ":dolls:": "🎎",
  ":dolphin:": "🐬",
  ":door:": "🚪",
  ":doughnut:": "🍩",
  ":dragon:": "🐉",
  ":dragon_face:": "🐲",
  ":dress:": "👗",
  ":dromedary_camel:": "🐪",
  ":droplet:": "💧",
  ":dvd:": "📀",
  ":e-mail:": "📧",
  ":ear:": "👂",
  ":ear_of_rice:": "🌾",
  ":earth_africa:": "🌍",
  ":earth_americas:": "🌎",
  ":earth_asia:": "🌏",
  ":egg:": "🍳",
  ":eggplant:": "🍆",
  ":electric_plug:": "🔌",
  ":elephant:": "🐘",
  ":end:": "🔚",
  ":envelope_with_arrow:": "📩",
  ":euro:": "💶",
  ":european_castle:": "🏰",
  ":european_post_office:": "🏤",
  ":evergreen_tree:": "🌲",
  ":expressionless:": "😑",
  ":eyeglasses:": "👓",
  ":eyes:": "👀",
  ":facepunch:": "👊",
  ":factory:": "🏭",
  ":fallen_leaf:": "🍂",
  ":family:": "👪",
  ":fax:": "📠",
  ":fearful:": "😨",
  ":feet:": "🐾",
  ":ferris_wheel:": "🎡",
  ":file_folder:": "📁",
  ":fire:": "🔥",
  ":fire_engine:": "🚒",
  ":fireworks:": "🎆",
  ":first_quarter_moon:": "🌓",
  ":first_quarter_moon_with_face:": "🌛",
  ":fish:": "🐟",
  ":fish_cake:": "🍥",
  ":fishing_pole_and_fish:": "🎣",
  ":flags:": "🎏",
  ":flashlight:": "🔦",
  ":floppy_disk:": "💾",
  ":flower_playing_cards:": "🎴",
  ":flushed:": "😳",
  ":foggy:": "🌁",
  ":football:": "🏈",
  ":footprints:": "👣",
  ":fork_and_knife:": "🍴",
  ":four_leaf_clover:": "🍀",
  ":free:": "🆓",
  ":fried_shrimp:": "🍤",
  ":fries:": "🍟",
  ":frog:": "🐸",
  ":frowning:": "😦",
  ":(": "😦",
  ":-(": "😦",
  ":-[": "😦",
  ":[": "😦",
  ":full_moon:": "🌕",
  ":full_moon_with_face:": "🌝",
  ":game_die:": "🎲",
  ":gem:": "💎",
  ":ghost:": "👻",
  ":gift:": "🎁",
  ":gift_heart:": "💝",
  ":girl:": "👧",
  ":globe_with_meridians:": "🌐",
  ":goat:": "🐐",
  ":grapes:": "🍇",
  ":green_apple:": "🍏",
  ":green_book:": "📗",
  ":green_heart:": "💚",
  ":grimacing:": "😬",
  ":grin:": "😁",
  "xD": "😁",
  "x-D": "😁",
  "XD": "😁",
  "X-D": "😁",
  ":grinning:": "😀",
  ":guardsman:": "💂",
  ":guitar:": "🎸",
  ":gun:": "🔫",
  ":haircut:": "💇",
  ":hamburger:": "🍔",
  ":hammer:": "🔨",
  ":hamster:": "🐹",
  ":handbag:": "👜",
  ":hankey:": "💩",
  ":hatched_chick:": "🐥",
  ":hatching_chick:": "🐣",
  ":headphones:": "🎧",
  ":hear_no_evil:": "🙉",
  ":heart_decoration:": "💟",
  ":heart_eyes:": "😍",
  ":heart_eyes_cat:": "😻",
  ":heartbeat:": "💓",
  ":heartpulse:": "💗",
  ":heavy_dollar_sign:": "💲",
  ":helicopter:": "🚁",
  ":herb:": "🌿",
  ":hibiscus:": "🌺",
  ":high_brightness:": "🔆",
  ":high_heel:": "👠",
  ":hocho:": "🔪",
  ":honey_pot:": "🍯",
  ":honeybee:": "🐝",
  ":horse:": "🐴",
  ":horse_racing:": "🏇",
  ":hospital:": "🏥",
  ":hotel:": "🏨",
  ":house:": "🏠",
  ":house_with_garden:": "🏡",
  ":hushed:": "😯",
  ":ice_cream:": "🍨",
  ":icecream:": "🍦",
  ":id:": "🆔",
  ":ideograph_advantage:": "🉐",
  ":imp:": "👿",
  ":inbox_tray:": "📥",
  ":incoming_envelope:": "📨",
  ":information_desk_person:": "💁",
  ":innocent:": "😇",
  ":halo:": "😇",
  "0:-)": "😇",
  "0:)": "😇",
  "0:3": "😇",
  "0:-3": "😇",
  ":iphone:": "📱",
  ":izakaya_lantern:": "🏮",
  ":jack_o_lantern:": "🎃",
  ":japan:": "🗾",
  ":japanese_castle:": "🏯",
  ":japanese_goblin:": "👺",
  ":japanese_ogre:": "👹",
  ":jeans:": "👖",
  ":joy:": "😂",
  ":joy_cat:": "😹",
  ":key:": "🔑",
  ":keycap_ten:": "🔟",
  ":kimono:": "👘",
  ":kiss:": "💋",
  ":kissing:": "😗",
  ":*": "😗",
  ":^*": "😗",
  ":kissing_cat:": "😽",
  ":kissing_closed_eyes:": "😚",
  ":kissing_heart:": "😘",
  ":kissing_smiling_eyes:": "😙",
  ":koala:": "🐨",
  ":koko:": "🈁",
  ":large_blue_circle:": "🔵",
  ":large_blue_diamond:": "🔷",
  ":large_orange_diamond:": "🔶",
  ":last_quarter_moon:": "🌗",
  ":last_quarter_moon_with_face:": "🌜",
  ":laughing:": "😆",
  ":laugh:": "😆",
  ":-D": "😆",
  ":D": "😆",
  ":leaves:": "🍃",
  ":ledger:": "📒",
  ":left_luggage:": "🛅",
  ":lemon:": "🍋",
  ":leopard:": "🐆",
  ":light_rail:": "🚈",
  ":link:": "🔗",
  ":lips:": "👄",
  ":lipstick:": "💄",
  ":lock:": "🔒",
  ":lock_with_ink_pen:": "🔏",
  ":lollipop:": "🍭",
  ":loudspeaker:": "📢",
  ":love_hotel:": "🏩",
  ":love_letter:": "💌",
  ":low_brightness:": "🔅",
  ":mag:": "🔍",
  ":mag_right:": "🔎",
  ":mahjong:": "🀄",
  ":mailbox:": "📫",
  ":mailbox_closed:": "📪",
  ":mailbox_with_mail:": "📬",
  ":mailbox_with_no_mail:": "📭",
  ":man:": "👨",
  ":man_with_gua_pi_mao:": "👲",
  ":man_with_turban:": "👳",
  ":mans_shoe:": "👞",
  ":maple_leaf:": "🍁",
  ":mask:": "😷",
  ":massage:": "💆",
  ":meat_on_bone:": "🍖",
  ":mega:": "📣",
  ":melon:": "🍈",
  ":memo:": "📝",
  ":mens:": "🚹",
  ":metro:": "🚇",
  ":microphone:": "🎤",
  ":microscope:": "🔬",
  ":milky_way:": "🌌",
  ":minibus:": "🚐",
  ":minidisc:": "💽",
  ":mobile_phone_off:": "📴",
  ":money_with_wings:": "💸",
  ":moneybag:": "💰",
  ":monkey:": "🐒",
  ":monkey_face:": "🐵",
  ":monorail:": "🚝",
  ":moon:": "🌙",
  ":mortar_board:": "🎓",
  ":mount_fuji:": "🗻",
  ":mountain_bicyclist:": "🚵",
  ":mountain_cableway:": "🚠",
  ":mountain_railway:": "🚞",
  ":mouse:": "🐭",
  ":mouse2:": "🐁",
  ":movie_camera:": "🎥",
  ":moyai:": "🗿",
  ":muscle:": "💪",
  ":mushroom:": "🍄",
  ":musical_keyboard:": "🎹",
  ":musical_note:": "🎵",
  ":musical_score:": "🎼",
  ":mute:": "🔇",
  ":nail_care:": "💅",
  ":name_badge:": "📛",
  ":necktie:": "👔",
  ":neutral_face:": "😐",
  ":|": "😐",
  ":-|": "😐",
  ":new:": "🆕",
  ":new_moon:": "🌑",
  ":new_moon_with_face:": "🌚",
  ":newspaper:": "📰",
  ":ng:": "🆖",
  ":no_bell:": "🔕",
  ":no_bicycles:": "🚳",
  ":no_entry_sign:": "🚫",
  ":no_good:": "🙅",
  ":no_mobile_phones:": "📵",
  ":no_mouth:": "😶",
  ":no_pedestrians:": "🚷",
  ":no_smoking:": "🚭",
  ":non-potable_water:": "🚱",
  ":nose:": "👃",
  ":notebook:": "📓",
  ":notebook_with_decorative_cover:": "📔",
  ":notes:": "🎶",
  ":nut_and_bolt:": "🔩",
  ":o2:": "🅾",
  ":ocean:": "🌊",
  ":octopus:": "🐙",
  ":oden:": "🍢",
  ":office:": "🏢",
  ":ok:": "🆗",
  ":ok_hand:": "👌",
  ":ok_woman:": "🙆",
  ":older_man:": "👴",
  ":older_woman:": "👵",
  ":on:": "🔛",
  ":oncoming_automobile:": "🚘",
  ":oncoming_bus:": "🚍",
  ":oncoming_police_car:": "🚔",
  ":oncoming_taxi:": "🚖",
  ":open_book:": "📖",
  ":open_file_folder:": "📂",
  ":open_hands:": "👐",
  ":open_mouth:": "😮",
  ":O": "😮",
  ":-O": "😮",
  ":-o": "😮",
  ":o": "😮",
  ":orange_book:": "📙",
  ":outbox_tray:": "📤",
  ":ox:": "🐂",
  ":package:": "📦",
  ":page_facing_up:": "📄",
  ":page_with_curl:": "📃",
  ":pager:": "📟",
  ":palm_tree:": "🌴",
  ":panda_face:": "🐼",
  ":paperclip:": "📎",
  ":parking:": "🅿",
  ":passport_control:": "🛂",
  ":paw_prints:": "🐾",
  ":peach:": "🍑",
  ":pear:": "🍐",
  ":pencil:": "📝",
  ":penguin:": "🐧",
  ":pensive:": "😔",
  ":performing_arts:": "🎭",
  ":persevere:": "😣",
  ":person_frowning:": "🙍",
  ":person_with_blond_hair:": "👱",
  ":person_with_pouting_face:": "🙎",
  ":pig:": "🐷",
  ":pig2:": "🐖",
  ":pig_nose:": "🐽",
  ":pill:": "💊",
  ":pineapple:": "🍍",
  ":pizza:": "🍕",
  ":point_down:": "👇",
  ":point_left:": "👈",
  ":point_right:": "👉",
  ":point_up_2:": "👆",
  ":police_car:": "🚓",
  ":poodle:": "🐩",
  ":poop:": "💩",
  ":post_office:": "🏣",
  ":postal_horn:": "📯",
  ":postbox:": "📮",
  ":potable_water:": "🚰",
  ":pouch:": "👝",
  ":poultry_leg:": "🍗",
  ":pound:": "💷",
  ":pouting_cat:": "😾",
  ":pray:": "🙏",
  ":princess:": "👸",
  ":punch:": "👊",
  ":purple_heart:": "💜",
  ":purse:": "👛",
  ":pushpin:": "📌",
  ":put_litter_in_its_place:": "🚮",
  ":rabbit:": "🐰",
  ":rabbit2:": "🐇",
  ":racehorse:": "🐎",
  ":radio:": "📻",
  ":radio_button:": "🔘",
  ":rage:": "😡",
  ":railway_car:": "🚃",
  ":rainbow:": "🌈",
  ":raised_hands:": "🙌",
  ":raising_hand:": "🙋",
  ":ram:": "🐏",
  ":ramen:": "🍜",
  ":rat:": "🐀",
  ":red_car:": "🚗",
  ":red_circle:": "🔴",
  ":relieved:": "😌",
  ":repeat:": "🔁",
  ":repeat_one:": "🔂",
  ":restroom:": "🚻",
  ":revolving_hearts:": "💞",
  ":ribbon:": "🎀",
  ":rice:": "🍚",
  ":rice_ball:": "🍙",
  ":rice_cracker:": "🍘",
  ":rice_scene:": "🎑",
  ":ring:": "💍",
  ":rocket:": "🚀",
  ":roller_coaster:": "🎢",
  ":rooster:": "🐓",
  ":rose:": "🌹",
  ":rotating_light:": "🚨",
  ":round_pushpin:": "📍",
  ":rowboat:": "🚣",
  ":rugby_football:": "🏉",
  ":runner:": "🏃",
  ":running:": "🏃",
  ":running_shirt_with_sash:": "🎽",
  ":sa:": "🈂",
  ":sake:": "🍶",
  ":sandal:": "👡",
  ":santa:": "🎅",
  ":satellite:": "📡",
  ":satisfied:": "😆",
  ":saxophone:": "🎷",
  ":school:": "🏫",
  ":school_satchel:": "🎒",
  ":scream:": "😱",
  ":scream_cat:": "🙀",
  ":scroll:": "📜",
  ":seat:": "💺",
  ":see_no_evil:": "🙈",
  ":seedling:": "🌱",
  ":shaved_ice:": "🍧",
  ":sheep:": "🐑",
  ":shell:": "🐚",
  ":ship:": "🚢",
  ":shirt:": "👕",
  ":shit:": "💩",
  ":shoe:": "👞",
  ":shower:": "🚿",
  ":signal_strength:": "📶",
  ":six_pointed_star:": "🔯",
  ":ski:": "🎿",
  ":skull:": "💀",
  ":sleeping:": "😴",
  ":sleepy:": "😪",
  ":slot_machine:": "🎰",
  ":small_blue_diamond:": "🔹",
  ":small_orange_diamond:": "🔸",
  ":small_red_triangle:": "🔺",
  ":small_red_triangle_down:": "🔻",
  ":smile:": "😄",
  ":))": "😄",
  ":-))": "😄",
  ":smile_cat:": "😸",
  ":smiley:": "😃",
  ":-)": "😃",
  ":)": "😃",
  ":]": "😃",
  ":o)": "😃",
  ":smiley_cat:": "😺",
  ":smiling_imp:": "😈",
  "}:-)": "😈",
  "3:-)": "😈",
  "}:)": "😈",
  "3:)": "😈",
  ":smirk:": "😏",
  ":smirk_cat:": "😼",
  ":smoking:": "🚬",
  ":snail:": "🐌",
  ":snake:": "🐍",
  ":snowboarder:": "🏂",
  ":sob:": "😭",
  ":soon:": "🔜",
  ":sos:": "🆘",
  ":sound:": "🔉",
  ":space_invader:": "👾",
  ":spaghetti:": "🍝",
  ":sparkler:": "🎇",
  ":sparkling_heart:": "💖",
  ":speak_no_evil:": "🙊",
  ":speaker:": "🔊",
  ":speech_balloon:": "💬",
  ":speedboat:": "🚤",
  ":star2:": "🌟",
  ":stars:": "🌃",
  ":station:": "🚉",
  ":statue_of_liberty:": "🗽",
  ":steam_locomotive:": "🚂",
  ":stew:": "🍲",
  ":straight_ruler:": "📏",
  ":strawberry:": "🍓",
  ":stuck_out_tongue:": "😛",
  ":P": "😛",
  ":-P": "😛",
  ":-p": "😛",
  ":p": "😛",
  ":stuck_out_tongue_closed_eyes:": "😝",
  "XP": "😝",
  "X-P": "😝",
  "xP": "😝",
  "x-P": "😝",
  "Xp": "😝",
  "X-p": "😝",
  ":stuck_out_tongue_winking_eye:": "😜",
  ":sun_with_face:": "🌞",
  ":sunflower:": "🌻",
  ":sunglasses:": "😎",
  "8-)": "😎",
  "8)": "😎",
  ":sunrise:": "🌅",
  ":sunrise_over_mountains:": "🌄",
  ":surfer:": "🏄",
  ":sushi:": "🍣",
  ":suspension_railway:": "🚟",
  ":sweat:": "😓",
  ":sweat_drops:": "💦",
  ":sweat_smile:": "😅",
  ":sweet_potato:": "🍠",
  ":swimmer:": "🏊",
  ":symbols:": "🔣",
  ":syringe:": "💉",
  ":tada:": "🎉",
  ":tanabata_tree:": "🎋",
  ":tangerine:": "🍊",
  ":taxi:": "🚕",
  ":tea:": "🍵",
  ":telephone_receiver:": "📞",
  ":telescope:": "🔭",
  ":tennis:": "🎾",
  ":thought_balloon:": "💭",
  ":thumbsdown:": "👎",
  ":thumbsup:": "👍",
  ":ticket:": "🎫",
  ":tiger:": "🐯",
  ":tiger2:": "🐅",
  ":tired_face:": "😫",
  ":toilet:": "🚽",
  ":tokyo_tower:": "🗼",
  ":tomato:": "🍅",
  ":tongue:": "👅",
  ":top:": "🔝",
  ":tophat:": "🎩",
  ":tractor:": "🚜",
  ":traffic_light:": "🚥",
  ":train:": "🚃",
  ":train2:": "🚆",
  ":tram:": "🚊",
  ":triangular_flag_on_post:": "🚩",
  ":triangular_ruler:": "📐",
  ":trident:": "🔱",
  ":triumph:": "😤",
  ":trolleybus:": "🚎",
  ":trophy:": "🏆",
  ":tropical_drink:": "🍹",
  ":tropical_fish:": "🐠",
  ":truck:": "🚚",
  ":trumpet:": "🎺",
  ":tshirt:": "👕",
  ":tulip:": "🌷",
  ":turtle:": "🐢",
  ":tv:": "📺",
  ":twisted_rightwards_arrows:": "🔀",
  ":two_hearts:": "💕",
  ":two_men_holding_hands:": "👬",
  ":two_women_holding_hands:": "👭",
  ":u5272:": "🈹",
  ":u5408:": "🈴",
  ":u55b6:": "🈺",
  ":u6307:": "🈯",
  ":u6708:": "🈷",
  ":u6709:": "🈶",
  ":u6e80:": "🈵",
  ":u7121:": "🈚",
  ":u7533:": "🈸",
  ":u7981:": "🈲",
  ":u7a7a:": "🈳",
  ":unamused:": "😒",
  ":\\": "😒",
  ":-\\": "😒",
  ":-/": "😒",
  ":/": "😒",
  ":underage:": "🔞",
  ":unlock:": "🔓",
  ":up:": "🆙",
  ":vertical_traffic_light:": "🚦",
  ":vhs:": "📼",
  ":vibration_mode:": "📳",
  ":video_camera:": "📹",
  ":video_game:": "🎮",
  ":violin:": "🎻",
  ":volcano:": "🌋",
  ":vs:": "🆚",
  ":walking:": "🚶",
  ":waning_crescent_moon:": "🌘",
  ":waning_gibbous_moon:": "🌖",
  ":water_buffalo:": "🐃",
  ":watermelon:": "🍉",
  ":wave:": "👋",
  ":waxing_crescent_moon:": "🌒",
  ":waxing_gibbous_moon:": "🌔",
  ":wc:": "🚾",
  ":weary:": "😩",
  ":wedding:": "💒",
  ":whale:": "🐳",
  ":whale2:": "🐋",
  ":white_flower:": "💮",
  ":white_square_button:": "🔳",
  ":wind_chime:": "🎐",
  ":wine_glass:": "🍷",
  ":wink:": "😉",
  ";)": "😉",
  ";-)": "😉",
  ":wolf:": "🐺",
  ":woman:": "👩",
  ":womans_clothes:": "👚",
  ":womans_hat:": "👒",
  ":womens:": "🚺",
  ":worried:": "😟",
  ":wrench:": "🔧",
  ":yellow_heart:": "💛",
  ":yen:": "💴",
  ":yum:": "😋",
  ":zzz:": "💤"
};

/***/ })

};;