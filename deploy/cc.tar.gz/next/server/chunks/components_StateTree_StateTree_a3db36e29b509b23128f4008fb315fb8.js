exports.ids = [4];
exports.modules = {

/***/ "./components/StateTree/StateTree.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("react");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types__ = __webpack_require__("prop-types");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_prop_types___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_prop_types__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_json_view__ = __webpack_require__("react-json-view");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_react_json_view___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_react_json_view__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils__ = __webpack_require__("./utils/index.js");
var _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/components/StateTree/StateTree.js";

/*
 *
 * StateTree
 *
 */



/* import PropTypes from 'prop-types' */


/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_3__utils__["H" /* makeDebugger */])('c:StateTree:index');
/* eslint-enable no-unused-vars */

/* apathy flat ocean tube */

var StateTree = function StateTree(_ref) {
  var json = _ref.json;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 20
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_react_json_view___default.a, {
    src: json,
    theme: "rjv-default",
    name: "rootStore",
    collapsed: 1,
    iconStyle: "circle",
    displayDataTypes: false,
    enableClipboard: false,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21
    }
  }));
};

StateTree.propTypes = {
  json: __WEBPACK_IMPORTED_MODULE_1_prop_types___default.a.object.isRequired // https://www.npmjs.com/package/prop-types

};
StateTree.defaultProps = {};
/* harmony default export */ __webpack_exports__["default"] = (StateTree);

/***/ })

};;
//# sourceMappingURL=components_StateTree_StateTree_a3db36e29b509b23128f4008fb315fb8.js.map