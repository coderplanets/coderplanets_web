webpackHotUpdate(7,{

/***/ "./components/CommunityContent/styles/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Wrapper; });
/* unused harmony export holder */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__("./utils/index.js");


var Wrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s7p7byu-0"
})(["width:94%;margin:40px;margin-top:25px;margin-bottom:10px;height:70%;min-height:70vh;color:", ";background:", ";border-radius:6px;padding:1em 6em;@media (max-width:1600px){padding:1em 2em;}@media (max-width:1400px){padding:1em 2em;padding-bottom:0;}@media (max-width:1200px){padding:1em 1em;padding-bottom:0;}"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('font'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('content.bg'));
var holder = 1;

/***/ })

})
//# sourceMappingURL=7.621ef0bac62a2f51eafb.hot-update.js.map