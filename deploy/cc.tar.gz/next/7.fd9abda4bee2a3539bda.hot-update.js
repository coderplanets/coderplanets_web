webpackHotUpdate(7,{

/***/ "./components/CommunityContent/styles/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Wrapper; });
/* unused harmony export holder */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__("./utils/index.js");


var Wrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__Wrapper",
  componentId: "s7p7byu-0"
})(["width:94%;margin:40px;margin-top:25px;margin-bottom:10px;height:70%;min-height:70vh;color:", ";background:", ";border-radius:6px;padding:1em 6em;@media (max-width:1400px){padding:1em 2em;padding-bottom:0;}@media (max-width:1200px){padding:1em 1em;padding-bottom:0;}"], Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('font'), Object(__WEBPACK_IMPORTED_MODULE_1__utils__["X" /* theme */])('content.bg'));
var holder = 1;

/***/ }),

/***/ "./containers/Sidebar/PinButton.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__styles_index__ = __webpack_require__("./containers/Sidebar/styles/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__config__ = __webpack_require__("./config/index.js");
var _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/Sidebar/PinButton.js";




var PinButton = function PinButton(_ref) {
  var pin = _ref.pin,
      onClick = _ref.onClick;
  return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__styles_index__["k" /* PinIconWrapper */], {
    onClick: onClick,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 7
    }
  }, __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__styles_index__["j" /* PinIcon */], {
    pin: pin,
    src: "".concat(__WEBPACK_IMPORTED_MODULE_2__config__["e" /* ICON_ASSETS */], "/cmd/pin.svg"),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    }
  }));
};

/* harmony default export */ __webpack_exports__["a"] = (PinButton);

/***/ }),

/***/ "./containers/Sidebar/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower__ = __webpack_require__("./node_modules/ramda/src/toLower.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__("./node_modules/mobx-react/index.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__ = __webpack_require__("./node_modules/react-beautiful-dnd/esm/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__PinButton__ = __webpack_require__("./containers/Sidebar/PinButton.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__styles__ = __webpack_require__("./containers/Sidebar/styles/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__logic__ = __webpack_require__("./containers/Sidebar/logic.js");


var _this = this,
    _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/Sidebar/index.js";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 *
 * Sidebar
 *
 */








var debug = Object(__WEBPACK_IMPORTED_MODULE_5__utils__["H" /* makeDebugger */])('C:Sidebar:index');

var getItemStyle = function getItemStyle(isDragging, draggableStyle) {
  return _objectSpread({}, draggableStyle);
};

var MenuList = function MenuList(_ref) {
  var items = _ref.items,
      pin = _ref.pin,
      activeRaw = _ref.activeRaw;

  /* const sparkData = [0, 2, 5, 9, 5, 10, 3, 5, 0, 0, 1, 8, 2, 9, 0] */
  // const sparkData = [0, 0, 0, 1, 0, 0, 1]
  var listItems = __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__["a" /* DragDropContext */], {
    onDragEnd: debug,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__["c" /* Droppable */], {
    droppableId: "droppable",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }, function (provided) {
    return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
      ref: provided.innerRef,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44
      }
    }, items.map(function (item, index) {
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__["b" /* Draggable */], {
        key: item.raw,
        draggableId: item.raw,
        index: index,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 46
        }
      }, function (provided, snapshot) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["g" /* MenuItemWrapper */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 48
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", _extends({
          ref: provided.innerRef
        }, provided.draggableProps, provided.dragHandleProps, {
          style: getItemStyle(snapshot.isDragging, provided.draggableProps.style),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 49
          }
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["e" /* MenuItemEach */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 58
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          onClick: __WEBPACK_IMPORTED_MODULE_8__logic__["b" /* onCommunitySelect */].bind(_this, item),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 59
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["h" /* MenuRow */], {
          pin: pin,
          active: activeRaw === __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower___default()(item.raw),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 60
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["f" /* MenuItemIcon */], {
          active: activeRaw === __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower___default()(item.raw),
          src: item.logo,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 64
          }
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          style: {
            marginRight: 10
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 69
          }
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("a", {
          style: {
            textDecoration: 'none'
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 70
          }
        }, item.title), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["i" /* MiniChartWrapper */], {
          pin: pin,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 74
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components__["E" /* TrendLine */], {
          data: item.contributesDigest,
          duration: 300,
          radius: 15,
          width: 7,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 75
          }
        })))))), provided.placeholder);
      });
    }), provided.placeholder);
  }));
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["d" /* MenuItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 97
    }
  }, listItems);
};

var reorder = function reorder(list, startIndex, endIndex) {
  var result = Array.from(list);

  var _result$splice = result.splice(startIndex, 1),
      _result$splice2 = _slicedToArray(_result$splice, 1),
      removed = _result$splice2[0];

  result.splice(endIndex, 0, removed);
  return result;
};

var SidebarContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SidebarContainer, _React$Component);

  function SidebarContainer() {
    _classCallCheck(this, SidebarContainer);

    return _possibleConstructorReturn(this, (SidebarContainer.__proto__ || Object.getPrototypeOf(SidebarContainer)).apply(this, arguments));
  }

  _createClass(SidebarContainer, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var sidebar = this.props.sidebar;
      __WEBPACK_IMPORTED_MODULE_8__logic__["a" /* init */](sidebar);
    }
  }, {
    key: "onDragEnd",
    value: function onDragEnd(result) {
      // dropped outside the list
      if (!result.destination) {
        return;
      }
      /*
      const items = reorder(
        this.state.items,
        result.source.index,
        result.destination.index
      )
      this.setState({
        items,
      })
      */


      this.setState(function (prevState) {
        return {
          items: reorder(prevState.items, result.source.index, result.destination.index)
        };
      });
    }
  }, {
    key: "render",
    value: function render() {
      var sidebar = this.props.sidebar;
      var curCommunity = sidebar.curCommunity,
          pin = sidebar.pin,
          subscribedCommunities = sidebar.subscribedCommunities; //    onMouseLeave={logic.leaveSidebar}
      // onMouseLeave is not unreliable in chrome: https://github.com/facebook/react/issues/4492

      var activeRaw = curCommunity.raw;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["a" /* Container */], {
        pin: pin,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 147
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["b" /* Header */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 148
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__styles__["c" /* HeaderFuncs */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 149
        }
      }, "."), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__PinButton__["a" /* default */], {
        pin: pin,
        onClick: __WEBPACK_IMPORTED_MODULE_8__logic__["c" /* pin */],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 150
        }
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(MenuList, {
        items: subscribedCommunities,
        pin: pin,
        activeRaw: activeRaw,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 152
        }
      }));
    }
  }]);

  return SidebarContainer;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["b" /* inject */])(Object(__WEBPACK_IMPORTED_MODULE_5__utils__["U" /* storePlug */])('sidebar'))(Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["c" /* observer */])(SidebarContainer)));

/***/ }),

/***/ "./containers/Sidebar/logic.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["c"] = pin;
/* harmony export (immutable) */ __webpack_exports__["b"] = onCommunitySelect;
/* unused harmony export loadSubscribedCommunities */
/* harmony export (immutable) */ __webpack_exports__["a"] = init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__schema__ = __webpack_require__("./containers/Sidebar/schema.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_network_sr71__ = __webpack_require__("./utils/network/sr71.js");
// import R from 'ramda'
// const debug = makeDebugger('L:sidebar')




var sr71$ = new __WEBPACK_IMPORTED_MODULE_3__utils_network_sr71__["a" /* default */]({
  resv_event: [__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGOUT, __WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGIN]
});
var store = null;
var sub$ = null;
/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_0__utils__["H" /* makeDebugger */])('L:Sidebar');
/* eslint-enable no-unused-vars */

function pin() {
  store.markState({
    pin: !store.pin
  });
}
function onCommunitySelect(community) {
  debug('onCommunitySelect --> ', community);
  store.markRoute({
    mainPath: community.raw,
    subPath: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["_2" /* thread2Subpath */])(__WEBPACK_IMPORTED_MODULE_0__utils__["j" /* THREAD */].POST)
  });
  Object(__WEBPACK_IMPORTED_MODULE_0__utils__["u" /* dispatchEvent */])(__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].COMMUNITY_CHANGE);
}
function loadSubscribedCommunities() {
  var user = __WEBPACK_IMPORTED_MODULE_0__utils__["c" /* BStore */].get('user');
  var args = {
    filter: {
      page: 1,
      size: 30
    }
  };

  if (user) {
    args.userId = user.id;
    args.filter.size = 20;
  }

  console.log('loadSubscribedCommunities: ', __WEBPACK_IMPORTED_MODULE_1__config__["d" /* GRAPHQL_ENDPOINT */]);
  sr71$.query(__WEBPACK_IMPORTED_MODULE_2__schema__["a" /* default */].subscribedCommunities, args);
}
var DataSolver = [{
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["n" /* asyncRes */])('subscribedCommunities'),
  action: function action(_ref) {
    var subscribedCommunities = _ref.subscribedCommunities;
    return store.loadSubscribedCommunities(subscribedCommunities);
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["n" /* asyncRes */])(__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGOUT),
  action: function action() {
    return loadSubscribedCommunities();
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["n" /* asyncRes */])(__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGIN),
  action: function action() {
    return loadSubscribedCommunities();
  }
}];
var ErrSolver = [{
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_0__utils__["d" /* ERR */].CRAPHQL),
  action: function action(_ref2) {
    var details = _ref2.details;
    debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_0__utils__["d" /* ERR */].TIMEOUT),
  action: function action(_ref3) {
    var details = _ref3.details;
    debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_0__utils__["d" /* ERR */].NETWORK),
  action: function action(_ref4) {
    var details = _ref4.details;
    debug('ERR.NETWORK -->', details);
  }
}];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(__WEBPACK_IMPORTED_MODULE_0__utils__["a" /* $solver */])(DataSolver, ErrSolver));
  loadSubscribedCommunities();
}

/***/ }),

/***/ "./containers/Sidebar/styles/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Container; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Header; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return HeaderFuncs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return PinIconWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return PinIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return MenuItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return MenuItemWrapper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return MenuItemEach; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return MenuRow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return MiniChartWrapper; });
/* unused harmony export MiniChartBar */
/* unused harmony export MiniChartText */
/* unused harmony export SVGIconWrapper */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return MenuItemIcon; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_components__ = __webpack_require__("./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utils__ = __webpack_require__("./utils/index.js");


 // 纯css，div隐藏滚动条，保留鼠标滚动效果。
// http://blog.csdn.net/liusaint1992/article/details/51277751

var Container =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].aside.withConfig({
  displayName: "styles__Container",
  componentId: "a6oifj-0"
})(["display:flex;flex-direction:column;border-right:1px solid;position:fixed;height:100vh;top:0;width:", ";box-shadow:", ";background:", ";border-color:", ";z-index:1000;overflow:hidden;transition:width 0.2s,opacity 0.8s,box-shadow 0.1s linear 0.1s,background-color 0.3s;&:hover{width:250px;box-shadow:3px 0 20px rgba(0,0,0,0.2);}"], function (_ref) {
  var pin = _ref.pin;
  return pin ? '250px' : '56px';
}, function (_ref2) {
  var pin = _ref2.pin;
  return pin ? '3px 0 20px rgba(0, 0, 0, 0.2); ' : '';
}, Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('sidebar.bg'), Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('sidebar.borderColor'));
var Header =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__Header",
  componentId: "a6oifj-1"
})(["display:flex;margin-top:10px;"]);
var HeaderFuncs =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__HeaderFuncs",
  componentId: "a6oifj-2"
})(["flex-grow:1;&:hover{cursor:pointer;}"]);
var PinIconWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__PinIconWrapper",
  componentId: "a6oifj-3"
})(["&:hover{cursor:pointer;}"]);
var PinIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "styles__PinIcon",
  componentId: "a6oifj-4"
})(["fill:", ";margin-right:10px;width:23px;height:23px;visibility:", ";opacity:", ";transition:visibility 0s,opacity 0.3s linear;cursor:pointer;&:hover{cursor:pointer;}", ":hover &{visibility:visible;opacity:1;}"], function (_ref3) {
  var pin = _ref3.pin;
  return pin ? Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('sidebar.pinActive') : 'grey';
}, function (_ref4) {
  var pin = _ref4.pin;
  return pin ? 'visible' : 'hidden';
}, function (_ref5) {
  var pin = _ref5.pin;
  return pin ? 1 : 0;
}, Container);
var MenuItem =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].ul.withConfig({
  displayName: "styles__MenuItem",
  componentId: "a6oifj-5"
})(["margin-top:0px;left:0;position:relative;width:260px;height:95vh;overflow-y:scroll;transition:left 0.2s;"]);
var MenuItemWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].li.withConfig({
  displayName: "styles__MenuItemWrapper",
  componentId: "a6oifj-6"
})(["display:block;&:hover{background:", ";}"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('sidebar.menuHover'));
var MenuItemEach =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__MenuItemEach",
  componentId: "a6oifj-7"
})(["cursor:pointer;opacity:1;transition:color 0.2s;padding-left:15px;font-size:15px;line-height:50px;height:50px;width:100%;box-sizing:border-box;color:", ";"], Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('sidebar.menuLink'));
var MenuRow =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__MenuRow",
  componentId: "a6oifj-8"
})(["display:flex;justify-content:left;font-size:1em;> a{display:", ";color:", ";opacity:", ";flex-grow:1;max-width:50%;}", ":hover &{a{display:block;flex-grow:1;max-width:50%;}}"], function (_ref6) {
  var pin = _ref6.pin;
  return pin ? 'block' : 'none';
}, Object(__WEBPACK_IMPORTED_MODULE_2__utils__["X" /* theme */])('sidebar.menuLink'), function (_ref7) {
  var active = _ref7.active;
  return active ? 1 : 0.7;
}, Container); // TODO: hover

var MiniChartWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__MiniChartWrapper",
  componentId: "a6oifj-9"
})(["width:12vh;justify-content:flex-end;align-items:center;position:relative;margin-top:-2px;display:", ";", ":hover &{display:flex;}"], function (_ref8) {
  var pin = _ref8.pin;
  return pin ? 'flex' : 'none';
}, Container);
var MiniChartBar =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__MiniChartBar",
  componentId: "a6oifj-10"
})(["height:8px;width:60px;background-color:#285763;border-radius:2px;"]);
var MiniChartText =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__MiniChartText",
  componentId: "a6oifj-11"
})(["position:absolute;font-size:1.1em;top:-2px;color:#5396a7;right:2px;", ":hover &{font-weight:bold;}"], MenuRow);
var SVGIconWrapper =
/*#__PURE__*/
__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */].div.withConfig({
  displayName: "styles__SVGIconWrapper",
  componentId: "a6oifj-12"
})(["margin-top:5px;opacity:", ";> svg{width:22px;height:22px;}"], function (_ref9) {
  var active = _ref9.active;
  return active ? 1 : 0.5;
});
var MenuItemIcon =
/*#__PURE__*/
Object(__WEBPACK_IMPORTED_MODULE_0_styled_components__["c" /* default */])(__WEBPACK_IMPORTED_MODULE_1__components__["l" /* Img */]).withConfig({
  displayName: "styles__MenuItemIcon",
  componentId: "a6oifj-13"
})(["opacity:", ";margin-top:1em;width:22px;height:22px;"], function (_ref10) {
  var active = _ref10.active;
  return active ? 1 : 0.5;
});

/***/ })

})
//# sourceMappingURL=7.fd9abda4bee2a3539bda.hot-update.js.map