webpackHotUpdate(7,{

/***/ "./containers/Sidebar/logic.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["c"] = pin;
/* harmony export (immutable) */ __webpack_exports__["b"] = onCommunitySelect;
/* unused harmony export loadSubscribedCommunities */
/* harmony export (immutable) */ __webpack_exports__["a"] = init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__schema__ = __webpack_require__("./containers/Sidebar/schema.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_network_sr71__ = __webpack_require__("./utils/network/sr71.js");
// import R from 'ramda'
// const debug = makeDebugger('L:sidebar')




var sr71$ = new __WEBPACK_IMPORTED_MODULE_3__utils_network_sr71__["a" /* default */]({
  resv_event: [__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGOUT, __WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGIN]
});
var store = null;
var sub$ = null;
/* eslint-disable no-unused-vars */

var debug = Object(__WEBPACK_IMPORTED_MODULE_0__utils__["H" /* makeDebugger */])('L:Sidebar');
/* eslint-enable no-unused-vars */

function pin() {
  store.markState({
    pin: !store.pin
  });
}
function onCommunitySelect(community) {
  debug('onCommunitySelect --> ', community);
  store.markRoute({
    mainPath: community.raw,
    subPath: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["_2" /* thread2Subpath */])(__WEBPACK_IMPORTED_MODULE_0__utils__["j" /* THREAD */].POST)
  });
  Object(__WEBPACK_IMPORTED_MODULE_0__utils__["u" /* dispatchEvent */])(__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].COMMUNITY_CHANGE);
}
function loadSubscribedCommunities() {
  var user = __WEBPACK_IMPORTED_MODULE_0__utils__["c" /* BStore */].get('user');
  console.log('store.accountInfo in sidebar: ', store.accountInfo);
  var args = {
    filter: {
      page: 1,
      size: 30
    }
  };

  if (user) {
    args.userId = user.id;
    args.filter.size = 20;
  }

  console.log('loadSubscribedCommunities: ', __WEBPACK_IMPORTED_MODULE_1__config__["d" /* GRAPHQL_ENDPOINT */]);
  sr71$.query(__WEBPACK_IMPORTED_MODULE_2__schema__["a" /* default */].subscribedCommunities, args);
}
var DataSolver = [{
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["n" /* asyncRes */])('subscribedCommunities'),
  action: function action(_ref) {
    var subscribedCommunities = _ref.subscribedCommunities;
    return store.loadSubscribedCommunities(subscribedCommunities);
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["n" /* asyncRes */])(__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGOUT),
  action: function action() {
    return loadSubscribedCommunities();
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["n" /* asyncRes */])(__WEBPACK_IMPORTED_MODULE_0__utils__["e" /* EVENT */].LOGIN),
  action: function action() {
    return loadSubscribedCommunities();
  }
}];
var ErrSolver = [{
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_0__utils__["d" /* ERR */].CRAPHQL),
  action: function action(_ref2) {
    var details = _ref2.details;
    debug('ERR.CRAPHQL -->', details);
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_0__utils__["d" /* ERR */].TIMEOUT),
  action: function action(_ref3) {
    var details = _ref3.details;
    debug('ERR.TIMEOUT -->', details);
  }
}, {
  match: Object(__WEBPACK_IMPORTED_MODULE_0__utils__["m" /* asyncErr */])(__WEBPACK_IMPORTED_MODULE_0__utils__["d" /* ERR */].NETWORK),
  action: function action(_ref4) {
    var details = _ref4.details;
    debug('ERR.NETWORK -->', details);
  }
}];
function init(_store) {
  if (store) return false;
  store = _store;
  if (sub$) sub$.unsubscribe();
  sub$ = sr71$.data().subscribe(Object(__WEBPACK_IMPORTED_MODULE_0__utils__["a" /* $solver */])(DataSolver, ErrSolver));
  loadSubscribedCommunities();
}

/***/ })

})
//# sourceMappingURL=7.742c896904c93df77c81.hot-update.js.map