webpackHotUpdate(7,{

/***/ "./containers/Sidebar/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower__ = __webpack_require__("./node_modules/ramda/src/toLower.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__("./node_modules/mobx-react/index.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__ = __webpack_require__("./node_modules/react-beautiful-dnd/esm/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components__ = __webpack_require__("./components/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__config__ = __webpack_require__("./config/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__utils__ = __webpack_require__("./utils/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__PinButton__ = __webpack_require__("./containers/Sidebar/PinButton.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__styles__ = __webpack_require__("./containers/Sidebar/styles/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__logic__ = __webpack_require__("./containers/Sidebar/logic.js");


var _this = this,
    _jsxFileName = "/Users/xieyiming/code/coderplanets/coderplanets_web/containers/Sidebar/index.js";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 *
 * Sidebar
 *
 */









var debug = Object(__WEBPACK_IMPORTED_MODULE_6__utils__["H" /* makeDebugger */])('C:Sidebar:index');

var getItemStyle = function getItemStyle(isDragging, draggableStyle) {
  return _objectSpread({}, draggableStyle);
};

var MenuList = function MenuList(_ref) {
  var items = _ref.items,
      pin = _ref.pin,
      activeRaw = _ref.activeRaw;

  /* const sparkData = [0, 2, 5, 9, 5, 10, 3, 5, 0, 0, 1, 8, 2, 9, 0] */
  // const sparkData = [0, 0, 0, 1, 0, 0, 1]
  var listItems = __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__["a" /* DragDropContext */], {
    onDragEnd: debug,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__["c" /* Droppable */], {
    droppableId: "droppable",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, function (provided) {
    return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
      ref: provided.innerRef,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49
      }
    }, items.map(function (item, index) {
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_react_beautiful_dnd__["b" /* Draggable */], {
        key: item.raw,
        draggableId: item.raw,
        index: index,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        }
      }, function (provided, snapshot) {
        return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["j" /* MenuItemWrapper */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 53
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", _extends({
          ref: provided.innerRef
        }, provided.draggableProps, provided.dragHandleProps, {
          style: getItemStyle(snapshot.isDragging, provided.draggableProps.style),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 54
          }
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["h" /* MenuItemEach */], {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 63
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          onClick: __WEBPACK_IMPORTED_MODULE_9__logic__["b" /* onCommunitySelect */].bind(_this, item),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 64
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["k" /* MenuRow */], {
          pin: pin,
          active: activeRaw === __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower___default()(item.raw),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 65
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["i" /* MenuItemIcon */], {
          active: activeRaw === __WEBPACK_IMPORTED_MODULE_0_ramda_src_toLower___default()(item.raw),
          src: item.logo,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 69
          }
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
          style: {
            marginRight: 10
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 74
          }
        }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("a", {
          style: {
            textDecoration: 'none'
          },
          __source: {
            fileName: _jsxFileName,
            lineNumber: 75
          }
        }, item.title), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["l" /* MiniChartWrapper */], {
          pin: pin,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 79
          }
        }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components__["E" /* TrendLine */], {
          data: item.contributesDigest,
          duration: 300,
          radius: 15,
          width: 7,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 80
          }
        })))))), provided.placeholder);
      });
    }), provided.placeholder);
  }));
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["g" /* MenuItem */], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 102
    }
  }, listItems);
};

var reorder = function reorder(list, startIndex, endIndex) {
  var result = Array.from(list);

  var _result$splice = result.splice(startIndex, 1),
      _result$splice2 = _slicedToArray(_result$splice, 1),
      removed = _result$splice2[0];

  result.splice(endIndex, 0, removed);
  return result;
};

var SidebarContainer =
/*#__PURE__*/
function (_React$Component) {
  _inherits(SidebarContainer, _React$Component);

  function SidebarContainer() {
    _classCallCheck(this, SidebarContainer);

    return _possibleConstructorReturn(this, (SidebarContainer.__proto__ || Object.getPrototypeOf(SidebarContainer)).apply(this, arguments));
  }

  _createClass(SidebarContainer, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var sidebar = this.props.sidebar;
      __WEBPACK_IMPORTED_MODULE_9__logic__["a" /* init */](sidebar);
    }
  }, {
    key: "onDragEnd",
    value: function onDragEnd(result) {
      // dropped outside the list
      if (!result.destination) {
        return;
      }
      /*
      const items = reorder(
        this.state.items,
        result.source.index,
        result.destination.index
      )
      this.setState({
        items,
      })
      */


      this.setState(function (prevState) {
        return {
          items: reorder(prevState.items, result.source.index, result.destination.index)
        };
      });
    }
  }, {
    key: "render",
    value: function render() {
      var sidebar = this.props.sidebar;
      var curCommunity = sidebar.curCommunity,
          pin = sidebar.pin,
          subscribedCommunities = sidebar.subscribedCommunities; //    onMouseLeave={logic.leaveSidebar}
      // onMouseLeave is not unreliable in chrome: https://github.com/facebook/react/issues/4492

      var activeRaw = curCommunity.raw;
      return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["a" /* Container */], {
        pin: pin,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 152
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["e" /* Header */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 153
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["f" /* HeaderFuncs */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 154
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["d" /* ExploreWrapper */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 155
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__components__["d" /* Button */], {
        size: "small",
        type: "primary",
        ghost: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 156
        }
      }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["b" /* ExploreIcon */], {
        src: "".concat(__WEBPACK_IMPORTED_MODULE_5__config__["e" /* ICON_ASSETS */], "/cmd/explore.svg"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 157
        }
      }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__styles__["c" /* ExploreText */], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 158
        }
      }, "explore")))), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__PinButton__["a" /* default */], {
        pin: pin,
        onClick: __WEBPACK_IMPORTED_MODULE_9__logic__["c" /* pin */],
        __source: {
          fileName: _jsxFileName,
          lineNumber: 162
        }
      })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(MenuList, {
        items: subscribedCommunities,
        pin: pin,
        activeRaw: activeRaw,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 164
        }
      }));
    }
  }]);

  return SidebarContainer;
}(__WEBPACK_IMPORTED_MODULE_1_react___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["b" /* inject */])(Object(__WEBPACK_IMPORTED_MODULE_6__utils__["U" /* storePlug */])('sidebar'))(Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["c" /* observer */])(SidebarContainer)));

/***/ })

})
//# sourceMappingURL=7.89e9698a8012930fb1d1.hot-update.js.map